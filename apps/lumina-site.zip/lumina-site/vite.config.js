import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { fileURLToPath, URL } from "node:url";

export default defineConfig({
  plugins: [react()],
  resolve: { alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) } },
  test: {
    environment: "jsdom",
    setupFiles: ["./src/test/setup.js"],
  },
  server: {
    port: 5173,
    proxy: {
      // The Lumina API gateway. Everything reaches the backend through it: it is the
      // only component that validates JWTs and the only one that may set the
      // X-User-* identity headers the downstream services trust.
      //
      // Proxying rather than calling http://localhost:8080 directly keeps the browser
      // on one origin, so there are no preflights and no CORS to configure in dev.
      "/api": {
        target: process.env.VITE_API_PROXY_TARGET ?? "http://localhost:8080",
        changeOrigin: true,
      },
    },
  },
});
