import animate from "tailwindcss-animate";
import { heroui } from "@heroui/theme";

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
    "./node_modules/@heroui/theme/dist/**/*.{js,mjs}",
  ],
  theme: {
    extend: {
      fontFamily: { sans: ["Poppins", "Segoe UI", "sans-serif"] },
      colors: Object.fromEntries(
        ["background", "foreground", "border", "input", "ring"]
          .map((key) => [key, `hsl(var(--${key}))`])
          .concat(
            [
              "primary",
              "secondary",
              "muted",
              "accent",
              "destructive",
              "card",
              "popover",
            ].map((key) => [
              key,
              {
                DEFAULT: `hsl(var(--${key}))`,
                foreground: `hsl(var(--${key}-foreground))`,
              },
            ]),
          ),
      ),
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
    },
  },
  darkMode: "class",
  plugins: [
    animate,
    heroui({
      themes: {
        light: {
          colors: {
            primary: {
              DEFAULT: "#2563eb",
              foreground: "#ffffff",
            },
            secondary: "#0f766e",
            focus: "#2563eb",
          },
        },
      },
    }),
  ],
};
