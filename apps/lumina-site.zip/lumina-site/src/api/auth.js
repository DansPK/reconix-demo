// auth-service. Everything here is public except the profile calls.

import { api } from "./client";

/**
 * Starts registration. No user row exists yet: auth-service holds the details in Redis
 * for 15 minutes and emails a 6-digit code. The account is only created by verify().
 */
export const signup = (payload) =>
  api.post("/v1/auth/signup", payload, { auth: false });

/** Completes registration with the emailed code. */
export const verify = ({ email, otp }) =>
  api.post("/v1/auth/verify", { email, otp }, { auth: false });

export const login = ({ email, password }) =>
  api.post("/v1/auth/login", { email, password }, { auth: false });

/** Exchanges a Google ID token for our own tokens, creating the account if needed. */
export const loginWithGoogle = (idToken) =>
  api.post("/v1/auth/google", { idToken }, { auth: false });

export const forgotPassword = (email) =>
  api.post("/v1/auth/forgot-password", { email }, { auth: false });

export const resetPassword = ({ token, newPassword }) =>
  api.post("/v1/auth/reset-password", { token, newPassword }, { auth: false });

export const getProfile = () => api.get("/v1/profile");

export const updateProfile = (payload) => api.put("/v1/profile", payload);

export const verifyLink = token => api.post("/v1/auth/verify-link", { token }, { auth: false });
export const resendVerification = email => api.post("/v1/auth/resend-verification", { email }, { auth: false });
export const changePassword = payload => api.post("/v1/profile/password", payload);
