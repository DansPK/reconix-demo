import { api } from "./client";

export const DELIVERY_FEE_RESOURCE_KEY = "/v1/store-settings/delivery-fee";

/** Public read used by checkout so the displayed fee matches the server price. */
export const getDeliveryFee = () => api.get(DELIVERY_FEE_RESOURCE_KEY);

/** Admin-only update; existing orders keep their saved delivery-fee snapshot. */
export const updateDeliveryFee = (deliveryFee) =>
  api.put("/v1/admin/store-settings/delivery-fee", { deliveryFee });
