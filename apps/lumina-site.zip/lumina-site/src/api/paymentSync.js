import { invalidate } from "../hooks/useResource";

// Refresh dependent views after server-confirmed payment changes. Polling never
// invalidates its own status resource, preventing a re-verification loop.
export function refreshPaymentViews({ includeStatus = false } = {}) {
  ["/v1/orders", "/v1/admin/orders", "/v1/admin/payments", "/v1/admin/reports", "/v1/cart",
    includeStatus ? "/v1/payments" : "/v1/payments/orders/"]
    .forEach(prefix => invalidate(prefix));
}
