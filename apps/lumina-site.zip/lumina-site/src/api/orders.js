// Orders carry two independent statuses: fulfillmentStatus and paymentStatus.
// A single mixed status is why the admin and storefront order views used to disagree.

import { api, query } from "./client";

export const listMyOrders = (params) => api.get(`/v1/orders${query(params)}`);

export const getMyOrder = (orderId) => api.get(`/v1/orders/${orderId}`);

/** Customer-facing lookup by the public LUM-YYYYMMDD-NNNNN code. */
export const getMyOrderByCode = (orderCode) => api.get(`/v1/orders/code/${orderCode}`);

/**
 * Reads the caller's server cart, locks stock, builds the order and creates the
 * matching payment (real KHQR or COD) all in one transaction. Returns {order, payment}.
 */
export const checkout = (payload) => api.post("/v1/orders/checkout", payload);

export const cancelOrder = (orderId, reason) =>
  api.post(`/v1/orders/${orderId}/cancel${query({ reason })}`);

// ── Admin ────────────────────────────────────────────────────────────────────

export const listOrders = (params) => api.get(`/v1/admin/orders${query(params)}`);

export const getOrder = (orderId) => api.get(`/v1/admin/orders/${orderId}`);

/**
 * Moves an order along the fulfillment pipeline. Transitions are validated server-side
 * (pending -> processing -> shipped -> delivered, or cancelled from any non-terminal
 * state), so an illegal move comes back as a 409 rather than silently corrupting stock.
 */
export const updateFulfillmentStatus = (orderId, payload) =>
  api.put(`/v1/admin/orders/${orderId}`, payload);
