// Admin-only endpoints that are not catalog, orders or payments.

import { api, query } from "./client";

// ── Users (auth-service) ─────────────────────────────────────────────────────

export const listUsers = (params) => api.get(`/v1/admin/users${query(params)}`);

export const createUser = (payload) => api.post("/v1/admin/users", payload);

export const updateUser = (id, payload) => api.put(`/v1/admin/users/${id}`, payload);

export const deactivateUser = (id) => api.del(`/v1/admin/users/${id}`);

// ── Inventory (operation-service) ────────────────────────────────────────────

export const getVariantMovements = (variantId, params) =>
  api.get(`/v1/admin/inventory/variants/${variantId}/movements${query(params)}`);

export const getOrderMovements = (orderId, params) =>
  api.get(`/v1/admin/inventory/orders/${orderId}/movements${query(params)}`);

/**
 * Corrects stock by a signed delta.
 *
 * @param quantity negative removes, positive adds
 * @param reason   admin_restock | manual_adjustment | refund | order_checkout | order_cancelled
 * @param note     the operator's reason, which the prototype collected and discarded
 */
export const adjustStock = (variantId, { quantity, reason, note }) =>
  api.post(`/v1/admin/inventory/variants/${variantId}/adjust`, { quantity, reason, note });

// ── Reports (reporting-service) ──────────────────────────────────────────────

export const getLowStock = (threshold = 5) =>
  api.get(`/v1/admin/reports/low-stock${query({ threshold })}`);

export const getInventoryReport = () => api.get("/v1/admin/reports/inventory");

export const getDailySales = () => api.get("/v1/admin/reports/sales/daily");

export const getWeeklySales = () => api.get("/v1/admin/reports/sales/weekly");

export const getMonthlySales = () => api.get("/v1/admin/reports/sales/monthly");

export const getTopProducts = () => api.get("/v1/admin/reports/top-products");

export const getReportLogs = () => api.get("/v1/admin/reports/logs");

/** The whole admin ReportsPage payload for one period. */
export const getReportOverview = (period) => api.get(`/v1/admin/reports/overview${query({ period })}`);

/** Accounts (auth-service) joined to paid-order totals (operation-service), via a
 * server-side read mirror - not two calls the frontend has to stitch together. */
export const getCustomerReport = (params) => api.get(`/v1/admin/reports/customers${query(params)}`);

export const getCustomerSummary = () => api.get("/v1/admin/reports/customers/summary");
