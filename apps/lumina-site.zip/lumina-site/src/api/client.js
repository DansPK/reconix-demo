// The single place the frontend talks to the backend.
//
// Everything the API layer needs and every screen should be spared: unwrapping the
// ApiRes envelope, turning RFC 7807 problem documents into real errors, attaching the
// access token, and refreshing it exactly once when it expires.

import { getAccessToken, getRefreshToken, setTokens, clearTokens } from "../auth/tokenStore";
import { resolveMock } from "./mockData";

const API_BASE = import.meta.env.VITE_API_BASE ?? "/api";

/**
 * A failed request.
 *
 * The backend answers errors with RFC 7807 problem documents, so `detail` is a sentence
 * written for a human and is safe to show. `errors` is the field-name -> message map that
 * validation failures carry, which is what a form needs to mark individual inputs.
 */
export class ApiError extends Error {
  constructor({ status, title, detail, errors, problem }) {
    super(detail || title || `Request failed with status ${status}`);
    this.name = "ApiError";
    this.status = status;
    this.title = title;
    this.detail = detail;
    this.errors = errors ?? null;
    this.problem = problem ?? null;
  }

  /** Validation failures, which a form should render inline rather than as a banner. */
  get isValidation() {
    return this.status === 400 && !!this.errors;
  }

  /** The caller is not signed in, or their session has gone. */
  get isUnauthenticated() {
    return this.status === 401;
  }

  /** Signed in, but not allowed. Re-authenticating will not help. */
  get isForbidden() {
    return this.status === 403;
  }

  /**
   * A conflict with the current state of things: stock ran out, an order cannot move to
   * that status, a payment is already taken. Always worth showing verbatim - the backend
   * puts the specifics in `detail`.
   */
  get isConflict() {
    return this.status === 409;
  }
}

/**
 * Refresh is single-flight.
 *
 * Several requests routinely fail with 401 at the same moment - a page that loads
 * products, the cart and the profile together. Without this they would each start their
 * own refresh, and all but one would be spending an already-rotated token.
 */
let refreshInFlight = null;

async function refreshAccessToken() {
  const refreshToken = getRefreshToken();
  if (!refreshToken) return null;

  refreshInFlight ??= (async () => {
    try {
      const response = await fetch(`${API_BASE}/v1/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refreshToken }),
      });
      if (!response.ok) {
        clearTokens();
        return null;
      }
      const body = await response.json();
      const accessToken = body?.data?.accessToken;
      if (!accessToken) {
        clearTokens();
        return null;
      }
      // The endpoint returns a new access token only; the refresh token is unchanged.
      setTokens({ accessToken, refreshToken });
      return accessToken;
    } catch {
      clearTokens();
      return null;
    } finally {
      refreshInFlight = null;
    }
  })();

  return refreshInFlight;
}

async function toApiError(response) {
  let problem = null;
  try {
    problem = await response.json();
  } catch {
    // Not every error has a body - a gateway 503 has none.
  }
  return new ApiError({
    status: response.status,
    title: problem?.title,
    detail: problem?.detail,
    errors: problem?.errors,
    problem,
  });
}

async function unwrap(response) {
  if (response.status === 204) return null;
  const body = await response.json().catch(() => null);
  // Every service except reporting wraps payloads in { success, message, data }.
  return body && typeof body === "object" && "data" in body ? body.data : body;
}

/**
 * Performs a request and returns the unwrapped payload.
 *
 * @param path      appended to VITE_API_BASE, e.g. "/v1/products"
 * @param body      serialised as JSON unless `formData` is given
 * @param formData  sent as multipart; the browser sets the boundary, so we must not
 *                  set Content-Type ourselves
 * @param auth      false for endpoints that must be called without credentials
 *                  (login, signup) so a stale token cannot interfere
 */
export async function request(path, { method = "GET", body, formData, headers = {}, auth = true, signal } = {}) {
  // Offline demo: serve baked data for mocked endpoints, no backend. Returns undefined for
  // anything not mocked, which falls through to the real request below.
  const mocked = resolveMock(method, path, body);
  if (mocked !== undefined) return mocked;

  const send = async (token) => {
    const requestHeaders = { ...headers };
    if (body !== undefined && !formData) requestHeaders["Content-Type"] = "application/json";
    if (auth && token) requestHeaders.Authorization = `Bearer ${token}`;

    return fetch(`${API_BASE}${path}`, {
      method,
      headers: requestHeaders,
      body: formData ?? (body !== undefined ? JSON.stringify(body) : undefined),
      signal,
    });
  };

  let response = await send(auth ? getAccessToken() : null);

  // Access tokens last 15 minutes, so this is an ordinary event rather than a failure.
  // Retried once only: a second 401 means the refresh token is gone too.
  if (response.status === 401 && auth && getRefreshToken()) {
    const refreshed = await refreshAccessToken();
    if (refreshed) response = await send(refreshed);
  }

  if (!response.ok) throw await toApiError(response);
  return unwrap(response);
}

export const api = {
  get: (path, options) => request(path, { ...options, method: "GET" }),
  post: (path, body, options) => request(path, { ...options, method: "POST", body }),
  put: (path, body, options) => request(path, { ...options, method: "PUT", body }),
  patch: (path, body, options) => request(path, { ...options, method: "PATCH", body }),
  del: (path, options) => request(path, { ...options, method: "DELETE" }),
  upload: (path, formData, options) => request(path, { ...options, method: "POST", formData }),
};

/** Builds a query string, dropping empty values so they are not sent as "". */
export function query(params) {
  const search = new URLSearchParams();
  Object.entries(params ?? {}).forEach(([key, value]) => {
    if (value === undefined || value === null || value === "") return;
    if (Array.isArray(value)) value.forEach((item) => search.append(key, item));
    else search.append(key, value);
  });
  const string = search.toString();
  return string ? `?${string}` : "";
}
