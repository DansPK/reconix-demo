// Bakong KHQR. The QR payload and its expiry come from the server; payment is confirmed
// by polling the gateway, never by the customer telling us they paid.

import { api, query } from "./client";

/** Creates a payment and returns the real EMVCo KHQR payload plus its expiry. */
export const createKhqrPayment = (orderId) => api.post(`/v1/payments/orders/${orderId}/khqr`);

export const getPaymentStatus = (paymentId, options) => api.get(`/v1/payments/${paymentId}/status`, options);

export const getPaymentForOrder = (orderId) => api.get(`/v1/payments/orders/${orderId}`);

// ── Admin ────────────────────────────────────────────────────────────────────

/** Marks a cash-on-delivery payment complete on delivery. Admin only. */
export const confirmCodPayment = (orderId) => api.post(`/v1/payments/orders/${orderId}/cod/confirm`);

export const listPayments = (params) => api.get(`/v1/admin/payments${query(params)}`);

export const getPaymentSummary = (params) => api.get(`/v1/admin/payments/summary${query(params)}`);

export const refundPayment = (paymentId, { amount, reason }) =>
  api.post(`/v1/admin/payments/${paymentId}/refund`, { amount, reason });
