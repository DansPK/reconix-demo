// Server-backed cart and wishlist. Both were in-memory useState and lost on refresh.

import { api, query } from "./client";

export const getCart = () => api.get("/v1/cart");

export const addToCart = ({ productId, variantId, quantity, selectedSize, selectedColor }) =>
  api.post("/v1/cart", { productId, variantId, quantity, selectedSize, selectedColor });

export const updateCartItem = (cartItemId, quantity) =>
  api.put(`/v1/cart/${cartItemId}`, { quantity });

export const removeCartItem = (cartItemId) => api.del(`/v1/cart/${cartItemId}`);

export const clearCart = () => api.del("/v1/cart");

/** Folds an anonymous pre-login cart into the server cart. Lines whose product or
 * variant no longer exists are skipped rather than failing the whole merge. */
export const mergeCart = (items) => api.post("/v1/cart/merge", { items });

export const getWishlist = (params) => api.get(`/v1/wishlist${query(params)}`);

export const addToWishlist = (productId) => api.post("/v1/wishlist", { productId });

export const removeWishlistItem = (wishlistId) => api.del(`/v1/wishlist/${wishlistId}`);

export const clearWishlist = () => api.del("/v1/wishlist");
