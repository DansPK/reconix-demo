// Catalog reads are anonymous; writes require an admin.

import { api, query } from "./client";

/**
 * The whole three-level category tree in one call, with rolled-up product counts and
 * presigned images. Replaces the nested object the prototype kept in localStorage.
 */
export const getCategoryTree = () => api.get("/v1/categories/tree");

export const getCategory = (id) => api.get(`/v1/categories/${id}`);

export const getCategoryBySlug = (slug) => api.get(`/v1/categories/slug/${slug}`);

export const createCategory = (payload) => api.post("/v1/categories", payload);

export const updateCategory = (id, payload) => api.put(`/v1/categories/${id}`, payload);

export const deleteCategory = (id) => api.del(`/v1/categories/${id}`);

export const uploadCategoryImage = (id, file) => {
  const formData = new FormData();
  formData.append("file", file);
  return api.upload(`/v1/categories/${id}/image`, formData);
};

export const deleteCategoryImage = (id) => api.del(`/v1/categories/${id}/image`);

/**
 * Catalog search. Filtering, sorting and pagination all happen server-side now.
 *
 * @param params q, categoryId, categorySlug, section, tag, status, isActive,
 *               isFeatured, minPrice, maxPrice, sort, page, size
 */
export const listProducts = (params) => api.get(`/v1/products${query(params)}`);

export const getProduct = (id) => api.get(`/v1/products/${id}`);

export const getProductBySlug = (slug) => api.get(`/v1/products/slug/${slug}`);

export const getRelatedProducts = (id, limit = 4) =>
  api.get(`/v1/products/${id}/related${query({ limit })}`);

export const createProduct = (payload) => api.post("/v1/products", payload);

export const updateProduct = (id, payload) => api.put(`/v1/products/${id}`, payload);

export const deleteProduct = (id) => api.del(`/v1/products/${id}`);

/** Multipart upload; replaces the prototype's base64 data URLs in localStorage. */
export const uploadProductImage = (productId, file, { primary, displayOrder, altText } = {}) => {
  const formData = new FormData();
  formData.append("file", file);
  formData.append(
    "request",
    new Blob([JSON.stringify({ primary, displayOrder, altText })], { type: "application/json" })
  );
  return api.upload(`/v1/products/${productId}/images`, formData);
};

export const deleteProductImage = (productId, imageId) =>
  api.del(`/v1/products/${productId}/images/${imageId}`);

// Preserve variant identities when editing products already referenced by orders.
export const createVariant = (productId, payload) => api.post(`/v1/products/${productId}/variants`, payload);
export const updateVariant = (productId, variantId, payload) => api.put(`/v1/products/${productId}/variants/${variantId}`, payload);
export const deleteVariant = (productId, variantId) => api.del(`/v1/products/${productId}/variants/${variantId}`);
