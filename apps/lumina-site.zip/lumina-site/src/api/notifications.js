import { api, query } from "./client";
export const preferences = () => api.get("/v1/notifications/preferences");
export const updatePreferences = payload => api.patch("/v1/notifications/preferences", payload);
export const deliveries = params => api.get(`/v1/admin/notifications${query(params)}`);
export const retryDelivery = id => api.post(`/v1/admin/notifications/${id}/retry`, {});
