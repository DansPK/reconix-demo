// Offline demo data: lets the storefront run with NO backend (no Java gateway, Postgres,
// Redis or Consul). `resolveMock(method, path, body)` returns the UNWRAPPED payload (the inner
// `data` the client would normally extract), or `undefined` for anything not mocked, which then
// falls through to a real network call. Everything here is fabricated demo content.
//
// Enabled by default so `npm run dev` just works offline; set VITE_DEMO="false" to use a real API.
// The storefront starts SIGNED OUT; sign in with any leaked account's cracked password (below).

import { ApiError } from "./client";

const DEMO = import.meta.env.VITE_DEMO !== "false";

// The leaked customer table. These rows are the SAME records the Reconix assessment dumps
// (apps/terminal/reconix/store/templates/web_url.py `_DUMP`): same names, emails, phones, saved
// cards and cracked passwords. In the storefront they do double duty — sign in as any of them with
// the cracked password to land on that victim's account and saved card, and re-run the SQL
// injection from the search box to leak the same table. All of it is fabricated; the card numbers
// are standard test PANs.
// `md5` is the real unsalted-MD5 of the password — that is what the DB actually stores and what the
// injection leaks; the plaintext `password` is kept only to validate a sign-in (what Reconix cracks).
function row(id, name, email, phone, address, brand, card, exp, password, md5) {
  return { id, name, email, phone, address, role: "CUSTOMER",
           brand, card, last4: card.replace(/\s/g, "").slice(-4), exp, password, md5 };
}

export const LEAK = [
  row(1, "Sophea Chan", "sophea_chan@gmail.com", "+855 12 684 207", "No. 23, St 310, Sangkat BKK1, Phnom Penh", "Visa", "4532 9859 9256 5466", "08/27", "Sophea1995", "4e99d89acd5fabad4deb42cd1cd9993d"),
  row(2, "Dara Kim", "darakim88@gmail.com", "+855 11 904 221", "No. 7B, St 240, Sangkat Chaktomuk, Phnom Penh", "Mastercard", "5425 3516 6185 6644", "11/26", "darakim@18", "59dda3b7265b8eb7e648b1466a7c69a6"),
  row(3, "Srey Mom", "sreymom_k@yahoo.com", "+855 96 774 310", "No. 112, St 163, Sangkat Toul Svay Prey, Phnom Penh", "Visa", "4716 0591 7325 9790", "03/28", "sreymom123", "56c725d034e4f05598f7a8d8ebdefbcb"),
  row(4, "Vicheka Sok", "vichekasok@outlook.com", "+855 92 448 177", "No. 45, St 51, Sangkat Boeung Keng Kang, Phnom Penh", "Amex", "3714 438189 90163", "05/27", "vicheka_99", "502df4e365833ed9b974391f0c81357a"),
  row(5, "Rathana Long", "rathana_long@gmail.com", "+855 15 903 562", "No. 88, St 271, Sangkat Tuol Tumpung, Phnom Penh", "Visa", "4485 9003 3143 7951", "09/25", "rathana2020", "fc1d7dc44f85b4368aed2b26d078432c"),
  row(6, "Bopha Nou", "bophanou@gmail.com", "+855 78 112 845", "No. 15, St 105, Sangkat Toul Tom Poung, Phnom Penh", "Discover", "6011 0956 9380 8432", "12/27", "bopha0808", "eba087fde2fb15b8abfef5e35cb74c54"),
  row(7, "Chanthou Meas", "chanthou_m@hotmail.com", "+855 17 657 203", "No. 301, St 182, Sangkat Teuk Laak, Phnom Penh", "Mastercard", "5500 9288 8207 9706", "07/26", "chanthou88", "d2595989445e2779a950bf977c98031d"),
  row(8, "Pisey Heng", "piseyheng@gmail.com", "+855 70 334 918", "No. 9, St 360, Sangkat BKK3, Phnom Penh", "Visa", "4024 8785 8944 1206", "02/28", "Pisey2016!", "dcb385163aac512a21603815be6c322a"),
  row(9, "Vuthy Sam", "vuthy_sam@yahoo.com", "+855 10 220 746", "No. 54, St 598, Sangkat Chrang Chamres, Phnom Penh", "Visa", "4929 2513 7840 8263", "10/26", "vuthysam007", "79628689676e57ec9b9bc8a5fee4fba5"),
  row(10, "Kunthea Yin", "kuntheayin@gmail.com", "+855 86 905 114", "No. 27, St 143, Sangkat Olympic, Phnom Penh", "Mastercard", "5168 5906 4207 5615", "04/27", "kunthea2019", "51384015679d737f1f09182ad22b8da1"),
  row(11, "Makara Chea", "makara_chea@outlook.com", "+855 99 471 028", "No. 6, St 432, Sangkat Toul Tumpung II, Phnom Penh", "Visa", "4539 3594 3327 6963", "06/25", "makara#23", "f1814a3cca8db525d89b614a70470bb6"),
  row(12, "Vanna Prak", "admin@lumina.com", "+855 23 900 004", "No. 1, St 110, Sangkat Wat Phnom, Phnom Penh", "Visa", "4716 8423 5693 9621", "01/29", "Lumina@2024", "be26f688492e640204c723f666f64fae"),
];

// Sophea is the fallback shopper (her account + saved Visa ****5466). Who is signed in is remembered
// by email in localStorage so `/v1/profile` can answer as that victim; google sign-in lands on her.
const SOPHEA = LEAK[0];

function currentAccount() {
  let email = SOPHEA.email;
  try { email = localStorage.getItem("lumina.account") || email; } catch { /* blocked storage */ }
  return LEAK.find((a) => a.email.toLowerCase() === String(email).toLowerCase()) ?? SOPHEA;
}

// The profile the API exposes: identity + the saved card (brand/last4/exp), never the password.
function profileOf(a) {
  return { id: a.id, name: a.name, email: a.email, phone: a.phone, address: a.address,
           role: a.role, card: { brand: a.brand, last4: a.last4, exp: a.exp } };
}

// A search term is "an injection" when it carries the shapes an attacker uses to break out of the
// query: a UNION SELECT, an always-true OR, a quote-then-OR, a comment, or a ; DROP. The store's
// own search box uses this to reproduce the SQL injection live (see CategoryResultsPage).
export function isSqlInjection(q = "") {
  const s = String(q).toLowerCase();
  return /union\s+select/.test(s)
      || /\bor\b\s+['"]?\d+['"]?\s*=\s*['"]?\d+/.test(s)
      || /'\s*or\s*'/.test(s)
      || /'\s*(--|#|;)/.test(s)
      || /;\s*drop\b/.test(s);
}

// No session is seeded on load: the storefront opens signed out. A leaked-account login stores its
// own refresh token (so that session survives a reload), and logout clears it back to signed out.

// --- a small fabricated catalog, served from the placeholder images in public/images -----
// Short per-category blurbs so product pages don't all share one line of copy.
const BLURBS = {
  "T-shirts": "Soft combed-cotton jersey with a clean crew neck — an easy everyday layer.",
  "Shirts & Blouses": "Breathable woven fabric with a relaxed drape, desk to weekend.",
  "Shirts": "Crisp cotton with a tailored collar that holds its shape all day.",
  "Dresses": "A fluid silhouette with a flattering fall — dress it up or down.",
  "Vests & Cardigans": "Fine-gauge knit that layers without bulk when the AC bites.",
  "Blazers & Jackets": "Structured shoulders and a clean line that sharpen any outfit.",
  "Hoodies & Sweatshirts": "Brushed-back fleece that stays soft wash after wash.",
  "Jeans & Trousers": "Mid-weight stretch denim with a slim, comfortable leg.",
  "Sneakers": "Cushioned low-tops on a durable rubber sole — true to size.",
  "Flats & Loafers": "Supple leather uppers with a flexible sole for all-day wear.",
};
let _seq = 0;
function product(name, price, sale, imageUrl, opts = {}) {
  const { category = "woman", section = "featured", type = "T-shirts",
          colors = ["black", "white"], sizes = ["S", "M", "L", "XL"], tags = [] } = opts;
  _seq += 1;
  const id = _seq;
  const label = { man: "Men", woman: "Women", kid: "Kids" }[category] ?? "Women";
  return {
    id,
    slug: name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") + "-" + id,
    name,
    sku: "LUM-" + (1000 + id),
    basePrice: price,
    salePrice: sale ?? null,
    effectivePrice: sale ?? price,
    discountPercent: sale ? Math.round((1 - sale / price) * 100) : null,
    images: [{ imageUrl }],
    variants: colors.flatMap((color, ci) =>
      sizes.map((size, si) => ({ id: id * 100 + ci * 10 + si, color, size, availableStock: 12 }))),
    stock: 24,
    lowStockThreshold: 5,
    status: "ACTIVE",
    categoryPath: [
      { slug: category, name: label },
      { slug: "clothing", name: "Clothing" },
      { slug: type.toLowerCase().replace(/[^a-z0-9]+/g, "-"), name: type },
    ],
    section,
    tags,
    description: BLURBS[type] || (name + " — part of the Lumina edit."),
    modelInfo: /sneaker|loafer|flat|boot|shoe/i.test(type)
      ? "True to size — we suggest your usual fit."
      : "Model is 175cm, wearing size M.",
  };
}

const PRODUCTS = [
  product("Essential Cotton Tee", 18.0, 14.0, "/images/products/woman/2.jpg", { category: "woman", section: "featured", type: "T-shirts" }),
  product("Relaxed Linen Shirt", 32.0, null, "/images/products/woman/3.jpg", { category: "woman", section: "trend", type: "Shirts & Blouses" }),
  product("Pleated Midi Dress", 48.0, 39.0, "/images/products/woman/5.jpg", { category: "woman", section: "atelier", type: "Dresses" }),
  product("Knit Cardigan", 40.0, null, "/images/products/woman/6.jpg", { category: "woman", section: "featured", type: "Vests & Cardigans" }),
  product("Everyday Denim Jacket", 55.0, 45.0, "/images/products/woman/PTAK0331-cr-450x672.jpg", { category: "woman", section: "trend", type: "Blazers & Jackets" }),
  product("Soft Lounge Hoodie", 36.0, null, "/images/products/woman/STU_0012-cr-450x672.jpg", { category: "woman", section: "atelier", type: "Hoodies & Sweatshirts" }),
  product("Classic Oxford Shirt", 34.0, null, "/images/products/man/1.jpg", { category: "man", section: "featured", type: "Shirts" }),
  product("Tailored Blazer", 72.0, 59.0, "/images/products/man/PTAK0084-cr-450x672.jpg", { category: "man", section: "atelier", type: "Blazers & Jackets" }),
  product("Graphic Crew Tee", 16.0, 9.0, "/images/products/man/ZANDO120820256263.jpg", { category: "man", section: "under10", type: "T-shirts" }),
  product("Slim Chino Trousers", 38.0, null, "/images/products/man/STU_0155-cr-450x672.jpg", { category: "man", section: "trend", type: "Jeans & Trousers" }),
  product("Canvas Low Sneakers", 44.0, 34.0, "/images/products/man/PTAK6954-cr-450x672.jpg", { category: "man", section: "footwear", type: "Sneakers" }),
  product("Suede Loafers", 52.0, null, "/images/products/woman/TAKK3425-cr-450x672.jpg", { category: "woman", section: "footwear", type: "Flats & Loafers" }),
];

function page(items, params) {
  const size = Number(params.get("size") ?? 12) || 12;
  const pageNo = Number(params.get("page") ?? 0) || 0;
  const start = pageNo * size;
  const content = items.slice(start, start + size);
  return { content, totalElements: items.length,
           totalPages: Math.max(1, Math.ceil(items.length / size)), page: pageNo, size };
}

// A home rail shows the products tagged for its section, so the title matches what's shown
// (e.g. the under-$10 rail doesn't list a $72 blazer). Falls back to the full list if untagged.
function forSection(section) {
  if (!section) return PRODUCTS;
  const matches = PRODUCTS.filter((p) => p.section === section);
  return matches.length ? matches : PRODUCTS;
}

export function resolveMock(method, rawPath, _body) {
  if (!DEMO) return undefined;
  const [path, qs] = String(rawPath).split("?");
  const params = new URLSearchParams(qs ?? "");
  const m = String(method).toUpperCase();

  if (m === "GET" && path === "/v1/profile") return profileOf(currentAccount());
  if (m === "PUT" && path === "/v1/profile") return { ...profileOf(currentAccount()), ...(_body ?? {}) };

  // Auth: a leaked account signs in with its cracked password and lands on its own account and
  // saved card; anything else is refused, so the demo shows the cracked password is the actual key.
  // google and the boot session sign in as the default shopper (Sophea). refresh returns a fresh
  // access token; signup/verify/forgot/reset/resend/verify-link and the password change acknowledge.
  if (m === "POST" && path === "/v1/auth/login") {
    const email = String(_body?.email ?? "").trim().toLowerCase();
    const account = LEAK.find((a) => a.email.toLowerCase() === email);
    if (!account || _body?.password !== account.password)
      throw new ApiError({ status: 401, title: "Unauthorized", detail: "Invalid email or password." });
    try { localStorage.setItem("lumina.account", account.email); } catch { /* blocked storage */ }
    return { accessToken: "demo-access", refreshToken: "demo-session" };
  }
  if (m === "POST" && path === "/v1/auth/google") {
    try { localStorage.setItem("lumina.account", SOPHEA.email); } catch { /* blocked storage */ }
    return { accessToken: "demo-access", refreshToken: "demo-session" };
  }
  if (m === "POST" && path === "/v1/auth/refresh") return { accessToken: "demo-access" };
  if (m === "POST" && path === "/v1/profile/password") return {};
  if (m === "POST" && path.startsWith("/v1/auth/")) return {};
  if (m === "GET" && path === "/v1/categories/tree") return [];            // mega-menu has a fallback
  if (m === "GET" && path === "/v1/products") return page(forSection(params.get("section")), params);
  if (m === "GET" && /^\/v1\/products\/\d+\/related$/.test(path)) return PRODUCTS.slice(0, 4);
  if (m === "GET" && path.startsWith("/v1/products/slug/")) {
    const slug = decodeURIComponent(path.slice("/v1/products/slug/".length));
    return PRODUCTS.find((p) => p.slug === slug) ?? PRODUCTS[0];
  }
  if (m === "GET" && /^\/v1\/products\/\d+$/.test(path)) {
    const id = Number(path.split("/").pop());
    return PRODUCTS.find((p) => p.id === id) ?? PRODUCTS[0];
  }
  if (m === "GET" && path === "/v1/cart") return [];
  if (m === "GET" && path === "/v1/wishlist")
    return { content: [], totalElements: 0, totalPages: 1, page: 0, size: 100 };
  if (path === "/v1/notifications/preferences")
    return { sendingEnabled: true, orderAlerts: true, stockAlerts: false, dailySummary: false };
  if (m === "GET" && path === "/v1/store-settings/delivery-fee") return { deliveryFee: 1.5 };

  // Cart/wishlist writes the demo doesn't persist: acknowledge so the UI promise resolves.
  if (path.startsWith("/v1/cart") || path.startsWith("/v1/wishlist")) return null;

  // Guest or member checkout. No backend here, so acknowledge the order and its payment
  // at once: cash-on-delivery stays pending-on-delivery; Bakong KHQR comes back paid
  // (instant bank confirmation) so the buyer lands on the receipt. The payload carries no
  // account by design — buying needs no sign-in.
  if (m === "POST" && path === "/v1/orders/checkout") {
    const cod = _body?.paymentMethod === "cash_on_delivery";
    const d = new Date();
    const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, "0")}${String(d.getDate()).padStart(2, "0")}`;
    const seq = String(Math.floor(Math.random() * 90000) + 10000);
    const orderId = `${ymd}${seq}`;
    return {
      order: { orderId, orderCode: `LUM-${ymd}-${seq}`, fulfillmentStatus: "pending" },
      payment: cod
        ? { id: orderId, paymentMethod: "cash_on_delivery", paymentStatus: "pending" }
        : { id: orderId, paymentMethod: "bakong_khqr", paymentStatus: "paid" },
    };
  }

  return undefined;   // not mocked -> real fetch (other payment endpoints stay stubbed in the demo)
}
