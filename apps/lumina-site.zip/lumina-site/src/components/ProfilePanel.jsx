import ChangePasswordForm from "./ChangePasswordForm";
import { Link } from "react-router-dom";
import { useProfileForm } from "../auth/useProfileForm";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Field, FieldGroup, FieldLabel } from "./ui/field";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "./ui/card";
import { Alert, AlertDescription } from "./ui/alert";
import { CreditCard } from "lucide-react";

// The saved card comes from the signed-in account (`/v1/profile`), so each leaked customer shows
// their own card — matching the Reconix dump. Falls back to Sophea's Visa ****5466 if absent.
const SAVED_CARD = { brand: "Visa", last4: "5466", exp: "08/27" };
export default function ProfilePanel({ admin = false, hideHeader = false }) {
  const {
    user,
    form,
    setField,
    dirty,
    saving,
    save,
    sendingReset,
    requestPasswordReset,
    message,
  } = useProfileForm();
  return (
    <div className={`mx-auto flex w-full max-w-3xl flex-col gap-6 ${hideHeader ? "" : "px-5 py-10"}`}>
      {!hideHeader && <div>
        <p className="mb-2 text-xs uppercase tracking-[.2em] text-muted-foreground">
          Your Lumina account
        </p>
        <h1 className="text-3xl font-semibold">
          {admin
            ? "Account settings"
            : "Hello, " + (user?.name?.split(" ")[0] || "you") + "."}
        </h1>
      </div>}
      <Card>
        <CardHeader>
          <CardTitle>Your details</CardTitle>
          <CardDescription>
            Keep your contact details up to date.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={save}>
            <FieldGroup>
              <Field data-disabled>
                <FieldLabel htmlFor="profile-email">Email</FieldLabel>
                <Input id="profile-email" value={user?.email || ""} disabled />
              </Field>
              {[
                ["name", "Name", "name"],
                ["phone", "Phone", "tel"],
              ].map(([key, label, complete]) => (
                <Field key={key}>
                  <FieldLabel htmlFor={`profile-${key}`}>{label}</FieldLabel>
                  <Input
                    id={`profile-${key}`}
                    value={form[key]}
                    onChange={setField(key)}
                    autoComplete={complete}
                  />
                </Field>
              ))}
              <Field>
                <FieldLabel htmlFor="profile-address">
                  Delivery address
                </FieldLabel>
                <textarea
                  id="profile-address"
                  value={form.address}
                  onChange={setField("address")}
                  autoComplete="street-address"
                  rows={3}
                  maxLength={500}
                  className="rounded-md border border-input bg-background p-3 text-sm"
                />
              </Field>
              <Button
                type="submit"
                disabled={saving || !dirty}
                className="self-start"
              >
                {saving ? "Saving…" : "Save changes"}
              </Button>
            </FieldGroup>
          </form>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Payment methods</CardTitle>
          <CardDescription>Cards saved for faster checkout.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4 rounded-lg border border-input bg-muted/30 p-4">
            <CreditCard className="h-6 w-6 shrink-0 text-muted-foreground" aria-hidden="true" />
            <div className="flex-1">
              <p className="font-medium tracking-wider">
                {(user?.card?.brand ?? SAVED_CARD.brand) + " " + "•••• •••• •••• " + (user?.card?.last4 ?? SAVED_CARD.last4)}
              </p>
              <p className="text-sm text-muted-foreground">
                {"Expires " + (user?.card?.exp ?? SAVED_CARD.exp) + " · " + (user?.name || "Sophea Chan")}
              </p>
            </div>
            <span className="rounded bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
              Default
            </span>
          </div>
          <Button variant="outline" className="mt-4 self-start" type="button">
            + Add card
          </Button>
        </CardContent>
      </Card>
      {message.text && (
        <Alert variant={message.type === "error" ? "destructive" : "default"}>
          <AlertDescription role="status">{message.text}</AlertDescription>
        </Alert>
      )}
      <Card>
        <CardHeader>
          <CardTitle>Password</CardTitle>
          <CardDescription>
            We’ll email you a link to choose a new password.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChangePasswordForm />
          <Button
            variant="outline"
            disabled={sendingReset}
            onClick={requestPasswordReset}
          >
            {sendingReset ? "Sending…" : "Email me a reset link"}
          </Button>
        </CardContent>
      </Card>
      {!admin && (
        <Button variant="link" asChild className="self-start">
          <Link to="/orders">View my orders</Link>
        </Button>
      )}
    </div>
  );
}
