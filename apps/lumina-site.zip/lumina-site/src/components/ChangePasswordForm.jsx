import { useState } from "react";
import { useAuth } from "../auth/AuthContext";
import { changePassword } from "../api/auth";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
export default function ChangePasswordForm() {
  const { logout } = useAuth();
  const [form, setForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  async function submit(event) {
    event.preventDefault(); if (busy) return;
    if (form.newPassword !== form.confirm) { setError("New passwords do not match."); return; }
    setBusy(true); setError("");
    try { await changePassword({ currentPassword: form.currentPassword, newPassword: form.newPassword }); await logout(); }
    catch (failure) { setError(failure?.detail || "Could not change password."); }
    finally { setBusy(false); }
  }
  return <form onSubmit={submit} className="mb-5 space-y-3">{[["currentPassword", "Current password"], ["newPassword", "New password"], ["confirm", "Confirm new password"]].map(([key, label]) => <label key={key} className="block text-sm">{label}<Input type="password" required minLength={key === "currentPassword" ? undefined : 8} autoComplete={key === "currentPassword" ? "current-password" : "new-password"} value={form[key]} onChange={event => setForm(previous => ({ ...previous, [key]: event.target.value }))} /></label>)}{error && <p role="alert">{error}</p>}<Button disabled={busy}>{busy ? "Changing…" : "Change password and sign out"}</Button><p className="text-xs text-muted-foreground">Google-only account? Use the reset link below to establish a password.</p></form>;
}
