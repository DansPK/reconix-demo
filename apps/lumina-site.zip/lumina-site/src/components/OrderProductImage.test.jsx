// @vitest-environment jsdom
import React from "react";
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import OrderProductImage from "./OrderProductImage";
const resource = vi.hoisted(() => vi.fn());
vi.mock("../hooks/useResource", () => ({ useResource: resource }));
afterEach(cleanup);
it("tries catalog images when the order photo fails and falls back after all images fail", () => {
  resource.mockImplementation(key => ({ data: key ? { images: [{ primary: true, imageUrl: "/catalog.jpg" }, { imageUrl: "/other.jpg" }] } : null, loading: false }));
  render(<OrderProductImage productId={12} name="Shirt" imageUrl="/snapshot.jpg" />);
  expect(screen.getByRole("img").getAttribute("src")).toBe("/snapshot.jpg");
  fireEvent.error(screen.getByRole("img"));
  expect(screen.getByRole("img").getAttribute("src")).toBe("/catalog.jpg");
  fireEvent.error(screen.getByRole("img"));
  expect(screen.getByRole("img").getAttribute("src")).toBe("/other.jpg");
  fireEvent.error(screen.getByRole("img"));
  expect(screen.getByRole("img", { name: "Shirt: image unavailable" }).tagName).toBe("DIV");
});
