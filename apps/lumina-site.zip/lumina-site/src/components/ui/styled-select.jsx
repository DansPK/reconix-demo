import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "./button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "./dropdown-menu";

const heightClasses = {
  sm: "h-9 px-2.5 text-xs",
  md: "h-10 px-3 text-sm",
  lg: "h-12 px-3 text-sm",
};

export default function StyledSelect({
  id,
  name,
  value,
  onValueChange,
  options,
  placeholder = "Select an option",
  ariaLabel,
  disabled = false,
  size = "md",
  className = "",
  contentClassName = "",
}) {
  const selected = options.find((option) => String(option.value) === String(value));

  return (
    <>
      {name && <input type="hidden" name={name} value={value ?? ""} />}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            id={id}
            type="button"
            variant="outline"
            aria-label={ariaLabel}
            disabled={disabled}
            className={cn(
              "w-full justify-between gap-2 border-input bg-background font-normal shadow-none hover:bg-accent/50",
              heightClasses[size] || heightClasses.md,
              className,
            )}
          >
            <span className="flex min-w-0 items-center gap-2">
              {selected?.tone && (
                <span
                  aria-hidden="true"
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{ background: `var(--admin-${selected.tone})` }}
                />
              )}
              <span className="truncate">{selected?.label ?? placeholder}</span>
            </span>
            <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent
          align="start"
          sideOffset={6}
          className={cn(
            "max-h-[min(18rem,var(--radix-dropdown-menu-content-available-height))] w-[var(--radix-dropdown-menu-trigger-width)] min-w-40 max-w-[calc(100vw-2rem)] rounded-lg p-1.5",
            contentClassName,
          )}
        >
          <DropdownMenuRadioGroup
            value={value == null ? "" : String(value)}
            onValueChange={onValueChange}
            aria-label={ariaLabel}
          >
            {options.map((option) => (
              <DropdownMenuRadioItem
                key={String(option.value)}
                value={String(option.value)}
                disabled={option.disabled}
                className="cursor-pointer rounded-md py-2.5 pr-3 text-sm data-[state=checked]:bg-accent data-[state=checked]:text-accent-foreground"
              >
                <span className="flex min-w-0 items-center gap-2">
                  {option.tone && (
                    <span
                      aria-hidden="true"
                      className="h-2 w-2 shrink-0 rounded-full"
                      style={{ background: `var(--admin-${option.tone})` }}
                    />
                  )}
                  <span className="truncate">{option.label}</span>
                </span>
              </DropdownMenuRadioItem>
            ))}
          </DropdownMenuRadioGroup>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );
}
