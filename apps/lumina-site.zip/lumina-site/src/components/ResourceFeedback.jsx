import { Skeleton } from "./ui/skeleton";
import { Alert, AlertDescription } from "./ui/alert";
import { Button } from "./ui/button";
export function ResourceError({
  message = "We couldn’t load this page.",
  retry,
}) {
  return (
    <Alert variant="destructive">
      <AlertDescription>
        {message}
        {retry && (
          <Button variant="link" onClick={retry}>
            Try again
          </Button>
        )}
      </AlertDescription>
    </Alert>
  );
}
export function ResourceLoading() {
  return (
    <div
      role="status"
      aria-label="Loading"
      className="mx-auto flex w-full max-w-5xl flex-col gap-5 px-5 py-10"
    >
      <Skeleton className="h-8 w-1/3" />
      {[0, 1, 2].map((i) => (
        <Skeleton key={i} className="h-24 w-full" />
      ))}
    </div>
  );
}
