import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import { motion, useReducedMotion, useAnimationControls } from "framer-motion";
export function PageMotion({ children, className }) {
  const { pathname } = useLocation();
  const reduced = useReducedMotion();
  const ref = useRef(null);
  const controls = useAnimationControls();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "instant" });
    if (ref.current) ref.current.scrollTop = 0;
  }, [pathname]);
  useEffect(() => {
    controls.set({ opacity: reduced ? 1 : 0.75, y: reduced ? 0 : 6 });
    controls.start({
      opacity: 1,
      y: 0,
      transition: { duration: reduced ? 0 : 0.2 },
    });
  }, [pathname, reduced, controls]);
  return (
    <motion.main
      ref={ref}
      className={className}
      initial={false}
      animate={controls}
      transition={{ duration: reduced ? 0 : 0.2 }}
    >
      {children}
    </motion.main>
  );
}
export function Reveal({ children, className }) {
  const reduced = useReducedMotion();
  return (
    <motion.div
      className={className}
      initial={reduced ? false : { opacity: 0, y: 12 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.1 }}
      transition={{ duration: 0.22 }}
    >
      {children}
    </motion.div>
  );
}
