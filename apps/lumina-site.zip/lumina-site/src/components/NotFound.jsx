import { Link } from "react-router-dom";
import { Button } from "./ui/button";
export default function NotFound({ home = "/" }) {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center gap-5 px-6 py-24 text-center">
      <p className="text-sm text-muted-foreground">404 / PAGE NOT FOUND</p>
      <h1 className="text-4xl font-semibold">A little off course.</h1>
      <p className="text-muted-foreground">
        This page may have moved or is no longer available.
      </p>
      <Button asChild>
        <Link to={home}>Back to {home === "/" ? "shopping" : "dashboard"}</Link>
      </Button>
    </div>
  );
}
