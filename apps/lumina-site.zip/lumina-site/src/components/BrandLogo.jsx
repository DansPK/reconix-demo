import logoUrl from "../resources/image.png";
import { cn } from "../lib/utils";

// View only the artwork bounds, preserving the supplied PNG and its transparency.
export default function BrandLogo({ className }) {
  return (
    <svg
      role="img"
      aria-label="Lumina"
      viewBox="135 261 1673 495"
      width="1673"
      height="495"
      className={cn("brand-logo block h-auto w-36 shrink-0", className)}
    >
      <image href={logoUrl} width="1942" height="809" />
    </svg>
  );
}
