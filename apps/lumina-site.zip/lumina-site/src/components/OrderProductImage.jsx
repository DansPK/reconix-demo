import { useState } from "react";
import { Package } from "lucide-react";
import { getProduct } from "../api/catalog";
import { useResource } from "../hooks/useResource";

export default function OrderProductImage({ productId, name, imageUrl, className = "h-24 w-24" }) {
  const [failedUrls, setFailedUrls] = useState([]);
  const { data: product, loading } = useResource((!imageUrl || failedUrls.includes(imageUrl)) && productId ? `/v1/products/${productId}` : null, () => getProduct(productId), { keepPreviousData: false });
  const images = product?.images || [];
  const photo = [...images].sort((a, b) => Number(Boolean(b.primary)) - Number(Boolean(a.primary)) || (a.displayOrder || 0) - (b.displayOrder || 0)).find(image => image.imageUrl && !failedUrls.includes(image.imageUrl));
  const src = imageUrl && !failedUrls.includes(imageUrl) ? imageUrl : photo?.imageUrl;
  return src ? <img src={src} alt={name} className={`${className} shrink-0 rounded-lg border object-cover`} loading="lazy" onError={() => setFailedUrls(urls => [...urls, src])} /> : <div role="img" aria-label={`${name}: ${loading ? "loading photo" : "image unavailable"}`} className={`${className} flex shrink-0 items-center justify-center rounded-lg border bg-muted text-muted-foreground ${loading ? "motion-safe:animate-pulse" : ""}`}><Package size={24} aria-hidden="true" /></div>;
}
