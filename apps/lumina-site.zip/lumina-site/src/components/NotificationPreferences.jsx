import { useState } from "react";
import { useAuth } from "../auth/AuthContext";
import { useResource, invalidate } from "../hooks/useResource";
import * as notifications from "../api/notifications";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "./ui/card";
import { Button } from "./ui/button";
import { Bell } from "lucide-react";
export default function NotificationPreferences() {
  const { canAccessAdmin } = useAuth();
  const { data, loading, error, refetch } = useResource("/v1/notifications/preferences", notifications.preferences, { pollMs: 10000 });
  const [busy, setBusy] = useState(false), [failure, setFailure] = useState("");
  async function act(action) {
    if (busy) return;
    setBusy(true); setFailure("");
    try { await action(); invalidate("/v1/notifications/preferences"); }
    catch (e) { setFailure(e.detail || "Could not update notifications. Please try again."); }
    finally { setBusy(false); }
  }
  return <Card className="mx-auto w-full max-w-3xl shadow-none">
    <CardHeader><CardTitle className="flex items-center gap-2 text-base"><Bell size={18} /> Notifications</CardTitle><CardDescription>{canAccessAdmin ? "Choose which email updates you receive." : "Order updates arrive by email."}</CardDescription></CardHeader>
    <CardContent className="space-y-4">
      {loading && !data ? <p className="text-sm text-muted-foreground">Loading notification settings…</p> : error ? <div role="alert"><p className="text-sm">Notification settings could not be loaded.</p><Button variant="outline" onClick={refetch}>Retry</Button></div> : data ? <>
        {!data.sendingEnabled ? <p className="text-xs text-muted-foreground">Email delivery is currently paused. Receipts remain in order history.</p> : null}
        <fieldset className="space-y-3" disabled={busy}>
          <legend className="mb-3 text-sm font-medium">Send me</legend>
          {[["orderAlerts", "Order and payment updates"], ...(canAccessAdmin ? [["stockAlerts", "Low-stock and out-of-stock alerts"], ["dailySummary", "Daily stock summary · 8:00 AM Phnom Penh"]] : [])].map(([key, label]) => <label key={key} className="flex items-start gap-3 text-sm"><input className="mt-0.5 h-4 w-4 accent-primary" type="checkbox" checked={!!data[key]} onChange={event => act(() => notifications.updatePreferences({ orderAlerts: data.orderAlerts, stockAlerts: data.stockAlerts, dailySummary: data.dailySummary, [key]: event.target.checked }))} />{label}</label>)}
        </fieldset>
      </> : null}
      {failure ? <p role="alert" className="text-sm text-destructive">{failure}</p> : null}
    </CardContent>
  </Card>;
}
