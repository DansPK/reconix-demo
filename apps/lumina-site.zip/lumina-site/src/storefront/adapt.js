// Maps an API product onto the shape the storefront components render.
//
// This is a presentation mapping, not a second source of truth: prices, colour swatches
// and image URLs get arranged for display, and nothing is invented. It exists so
// ProductCard, SizeSelector and ColorSwatchSelector did not all have to be rewritten.
//
// It replaces adaptAdminProduct, which had a harder job: the prototype had two different
// product shapes (a hardcoded catalogue and admin-created products in localStorage) and
// had to reconcile them. There is one shape now.

const FALLBACK_IMAGE = "/images/products/unsplash/tee.jpg";

/** Swaps a broken <img> (an expired presigned URL, a since-deleted object) for a real
 * photo instead of leaving a blank tile. Not the happy path - rustfs serves real product
 * photos - this only fires on an actual load failure. */
function onImageError(event) {
  if (event.target.getAttribute("src") !== FALLBACK_IMAGE)
    event.target.src = FALLBACK_IMAGE;
}

/** Distinct values of one variant field, in the order the server returned them. */
function distinct(variants, field) {
  return [...new Set((variants ?? []).map((v) => v[field]).filter(Boolean))];
}

export function toStorefrontProduct(product) {
  if (!product) return null;

  const variants = product.variants ?? [];
  const images = (product.images ?? [])
    .map((image) => image.imageUrl)
    .filter(Boolean);
  const onSale =
    product.salePrice != null && product.salePrice < product.basePrice;

  // The category trail is root-first (Man / Clothing / T-shirts), so the first entry is
  // the main category the storefront filters by and the last is the sub-category.
  const path = product.categoryPath ?? [];
  const mainCategory = path[0]?.slug ?? null;
  const leafCategory = path[path.length - 1]?.name ?? null;

  return {
    id: product.id,
    slug: product.slug,
    name: product.name,
    code: product.sku,

    // effectivePrice already accounts for a sale; originalPrice is only shown when
    // there is something to strike through.
    price: product.effectivePrice ?? product.basePrice,
    originalPrice: onSale ? product.basePrice : null,
    discountPercent: product.discountPercent ?? null,

    images: images.length ? images : [FALLBACK_IMAGE],

    // Swatch colours are fed straight into a CSS background, so they must be colour
    // names the browser understands - which is what the admin form collects.
    colors: distinct(variants, "color"),
    sizes: distinct(variants, "size"),
    variants,

    // Server-derived: the sum of variant stock, and the status computed from it.
    stock: product.stock,
    lowStockThreshold: product.lowStockThreshold ?? 5,
    status: product.status,

    category: mainCategory,
    section: product.section,
    taxonomy: { type: leafCategory, styles: product.tags ?? [] },

    description: product.description ?? "",
    modelInfo: product.modelInfo ?? "",
  };
}

export function toStorefrontProducts(products) {
  return (products ?? []).map(toStorefrontProduct).filter(Boolean);
}

export { FALLBACK_IMAGE, onImageError };
