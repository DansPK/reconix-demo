import React from "react";
import { Button, Card, CardBody, Chip } from "@heroui/react";
import { Heart, Minus, Plus } from "lucide-react";
import { Link } from "react-router-dom";
import { Button as ActionButton } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { onImageError } from "./adapt";
import { useWishlist } from "./providers";

function PriceTag({ price, originalPrice, discountPercent }) {
  return (
    <div className="flex items-center flex-wrap gap-1.5">
      <span className="text-foreground text-[14px] font-extrabold leading-none">
        ${price.toFixed(2)}
      </span>
      {discountPercent ? (
        <span className="text-foreground text-[12px] font-bold leading-none">
          -{discountPercent}%
        </span>
      ) : null}
      {originalPrice ? (
        <span className="text-gray-400 line-through text-[12px] leading-none">
          ${originalPrice.toFixed(2)}
        </span>
      ) : null}
    </div>
  );
}

function QuantityStepper({ value, onChange, max = Infinity }) {
  return (
    <div className="flex items-center gap-1 rounded-medium border border-default-200 bg-content1 p-1 w-fit">
      <Button
        isIconOnly
        size="sm"
        variant="light"
        aria-label="Decrease quantity"
        isDisabled={value <= 1}
        onPress={() => onChange(Math.max(1, value - 1))}
      >
        <Minus size={16} />
      </Button>
      <span className="min-w-8 text-center text-sm font-semibold">{value}</span>
      <Button
        isIconOnly
        size="sm"
        variant="light"
        aria-label="Increase quantity"
        isDisabled={value >= max}
        onPress={() => onChange(Math.min(max, value + 1))}
      >
        <Plus size={16} />
      </Button>
    </div>
  );
}

function SizeSelector({ sizes, selected, onSelect, disabledSizes = [] }) {
  return (
    <div className="flex flex-wrap gap-2">
      {sizes.map((s) => (
        <Button
          key={s}
          size="sm"
          variant="bordered"
          isDisabled={disabledSizes.includes(s)}
          onPress={() => onSelect(s)}
          className={`min-w-11 border font-semibold ${selected === s ? "border-zinc-900 bg-white text-zinc-900" : "border-zinc-200 bg-zinc-100 text-zinc-800 hover:border-zinc-400"}`}
        >
          {s}
        </Button>
      ))}
    </div>
  );
}

function ColorSwatchSelector({ colors, selected, onSelect }) {
  return (
    <div className="flex items-center gap-3">
      {colors.map((c) => (
        <button
          type="button"
          key={c}
          onClick={() => onSelect(c)}
          aria-label={`Choose ${c}`}
          aria-pressed={selected === c}
          className={`flex h-8 w-8 items-center justify-center rounded-full border-2 p-1 transition-colors ${selected === c ? "border-zinc-900 bg-white" : "border-transparent bg-white hover:border-zinc-300"}`}
        >
          <span
            className="h-5 w-5 rounded-full border border-black/10"
            style={{ background: c }}
          />
        </button>
      ))}
    </div>
  );
}

function ProductCard({ product, layout = "grid" }) {
  const { toggleWishlist, isWishlisted } = useWishlist();
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState("");
  const saved = isWishlisted(product.id);
  async function toggle() {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      await toggleWishlist(product);
    } catch (e) {
      setError(e?.detail || "Could not update wishlist. Try again.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <article className={layout === "row" ? "card group flex min-w-0 flex-row gap-4 rounded-xl border border-border p-3 sm:gap-6 sm:p-4" : "card group flex min-w-0 flex-col"}>
      <figure className={`relative overflow-hidden rounded-md bg-muted ${layout === "row" ? "w-28 shrink-0 sm:w-40" : ""}`}>
        <div className="pointer-events-none absolute left-3 top-3 z-10 flex flex-col gap-2">
          {product.isNew && <Badge variant="secondary">New in</Badge>}
          {product.discountPercent > 0 && (
            <Badge>-{product.discountPercent}%</Badge>
          )}
        </div>
        <ActionButton
          variant="default"
          size="icon"
          className="absolute right-3 top-3 z-10 rounded-full bg-[#E0271F] text-white hover:bg-[#c5221b]"
          disabled={busy}
          onClick={toggle}
          aria-label={
            saved
              ? `Remove ${product.name} from wishlist`
              : `Save ${product.name} to wishlist`
          }
          aria-pressed={saved}
        >
          <Heart className={saved ? "fill-current" : ""} />
        </ActionButton>
        <Link to={`/product/${product.slug || product.id}`} className="block">
          <img
            src={product.images[0]}
            alt={product.name}
            loading="lazy"
            onError={onImageError}
            className="aspect-[2/3] w-full object-contain"
          />
        </Link>
      </figure>
      <div className={`card-body flex min-w-0 flex-col gap-2 ${layout === "row" ? "flex-1 justify-center" : "pt-3"}`}>
        <Link
          to={`/product/${product.slug || product.id}`}
          className="card-title line-clamp-2 text-base font-medium leading-6 text-foreground hover:underline hover:underline-offset-4"
        >
          {product.name}
        </Link>
        <div>
          <span className="text-xs text-muted-foreground">{product.stock > 0 ? "In stock" : "Out of stock"}</span>
        <PriceTag
            price={product.price}
            originalPrice={product.originalPrice}
            discountPercent={0}
          />
        </div>
        {error && (
          <p role="alert" className="text-xs text-destructive">
            {error}
          </p>
        )}
      </div>
    </article>
  );
}
export {
  PriceTag,
  QuantityStepper,
  SizeSelector,
  ColorSwatchSelector,
  ProductCard,
};
