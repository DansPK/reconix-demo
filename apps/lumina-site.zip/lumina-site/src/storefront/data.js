// Storefront UI constants.
//
// This file used to hold the catalogue: 21 hardcoded products, a PRODUCT_TAXONOMY map
// keyed by product id, a fake `services` layer, and adaptAdminProduct for reconciling
// them with the admin's localStorage products. All of that is gone - the catalogue comes
// from the API now, and ~19 of those 21 products pointed at image paths that 404'd.
//
// What remains is the URL-building helpers that turn a category into a link.

/**
 * Maps a main category slug to the `cat` value used in storefront URLs.
 *
 * The API's slugs are man/woman/kid; the storefront's existing links and filters use
 * men/women/kid. Kept as a translation rather than changed on either side, because the
 * URLs are user-visible and the slugs are what the database stores.
 */
const CATEGORY_VALUE_MAP = { man: "men", woman: "women", kid: "kid" };

/** The reverse, for turning a URL back into a category slug the API understands. */
const URL_TO_CATEGORY_SLUG = { men: "man", women: "woman", kid: "kid" };

function productSlug(name) {
  return String(name ?? "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/**
 * Builds a /category link.
 *
 * @param activeMain the main category slug (man | woman | kid)
 * @param item       the category node being linked to
 * @param kind       "type" for a sub-category, "style" for a style tag
 */
function buildCategoryHref(activeMain, item, kind) {
  const params = new URLSearchParams();
  const cat = CATEGORY_VALUE_MAP[activeMain] ?? activeMain;
  if (cat) params.set("cat", cat);

  const value =
    typeof item === "string"
      ? item
      : (item?.name ?? item?.[kind] ?? item?.label);
  if (value && value.toLowerCase() !== "all") params.set(kind, value);
  return `/category?${params.toString()}`;
}

export {
  CATEGORY_VALUE_MAP,
  URL_TO_CATEGORY_SLUG,
  productSlug,
  buildCategoryHref,
};
