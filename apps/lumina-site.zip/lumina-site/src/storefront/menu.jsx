﻿import React from "react";
import { Skeleton } from "../components/ui/skeleton";
import { Alert, AlertDescription } from "../components/ui/alert";
import { Button } from "../components/ui/button";
import { Reveal } from "../components/PageMotion";
import { Link } from "react-router-dom";
import { ArrowUpRight, X } from "lucide-react";
import { onImageError } from "./adapt";
import { buildCategoryHref } from "./data";
import { useSectionProducts } from "./useCatalog";
import { ProductCard } from "./productComponents";

const GRID_COLUMN_CLASSES = {
  4: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5 lg:gap-7",
  5: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-5 lg:gap-7",
};

function Section({ title, section, category = "all", columns = 4 }) {
  // One request per rail, asking the server for exactly this section. Cached by URL, so
  // navigating away and back does not refetch. The prototype pulled the whole catalogue
  // and filtered it here.
  const { products, loading, error, refetch } = useSectionProducts(
    section,
    columns,
    category,
  );
  if (!loading && !error && !products.length) return null;
  return (
    <Reveal className="mx-auto max-w-[1280px] px-5 py-8 md:py-12">
      <div className="mb-6 flex items-end justify-between gap-4">
        <div>
          <p className="mb-2 text-xs uppercase tracking-[.2em] text-muted-foreground">
            The Lumina edit
          </p>
          <h2 className="text-2xl font-semibold tracking-tight md:text-3xl">
            {title}
          </h2>
        </div>
        <Link
          to={`/category?cat=${category}&section=${section}`}
          className="text-sm underline underline-offset-4"
        >
          View all
        </Link>
      </div>
      {error ? (
        <Alert variant="destructive">
          <AlertDescription>
            Could not load this collection.{" "}
            <Button variant="link" onClick={refetch}>
              Try again
            </Button>
          </AlertDescription>
        </Alert>
      ) : (
        <div className={GRID_COLUMN_CLASSES[columns] || GRID_COLUMN_CLASSES[4]}>
          {loading && !products.length
            ? Array.from({ length: columns }, (_, i) => (
                <div key={i} className="flex flex-col gap-3">
                  <Skeleton className="aspect-[4/5] w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/3" />
                </div>
              ))
            : products.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      )}
    </Reveal>
  );
}

function CategoryGrid() {
  return (
    //Second Banner
    <div className="max-w-[1280px] mx-auto px-5 mt-8">
      <Link
        to="/category?cat=men"
        className="relative block overflow-hidden rounded-xl h-[280px] md:h-[392px]"
      >
        <img
          src="/images/products/banner/2.jpg"
          alt="Shop the season's edit"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-6">
          <div className="text-white font-extrabold text-[28px] leading-none px-3 py-1  tracking-tight">
            EXPLORE THE SEASON’S EDIT →
          </div>
        </div>
      </Link>
    </div>
  );
}

//sub menu
const megaCategoryData = {
  man: {
    clothing: {
      left: [
        {
          label: "All",
          type: "all",
          image:
            "https://images.unsplash.com/photo-1617137968427-85924c800a22?w=240&q=80&fit=crop",
        },
        {
          label: "T-shirts",
          type: "T-shirts",
          image:
            "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=240&q=80&fit=crop",
        },
        {
          label: "Blazers & Jackets",
          type: "Blazers & Jackets",
          image:
            "https://images.unsplash.com/photo-1617127365659-c47fa864d8bc?w=240&q=80&fit=crop",
        },
        {
          label: "Hoodies & Sweatshirts",
          type: "Hoodies & Sweatshirts",
          image:
            "https://images.unsplash.com/photo-1578768079052-aa76e52ff62e?w=240&q=80&fit=crop",
        },
        {
          label: "Shorts",
          type: "Shorts",
          image:
            "https://images.unsplash.com/photo-1506629905607-a6f9cfb8f3f0?w=240&q=80&fit=crop",
        },
      ],
      middle: [
        {
          label: "Shirts",
          type: "Shirts",
          image:
            "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=240&q=80&fit=crop",
        },
        {
          label: "Polo Shirts",
          type: "Polo Shirts",
          image:
            "https://images.unsplash.com/photo-1614251055880-ee96e4803393?w=240&q=80&fit=crop",
        },
        {
          label: "Vests & Cardigans",
          type: "Vests & Cardigans",
          image:
            "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=240&q=80&fit=crop",
        },
        {
          label: "Jeans & Trousers",
          type: "Jeans & Trousers",
          image:
            "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=240&q=80&fit=crop",
        },
        {
          label: "Underwear",
          type: "Underwear",
          image:
            "https://images.unsplash.com/photo-1603252109303-2751441dd157?w=240&q=80&fit=crop",
        },
      ],
      styleLeft: [
        {
          label: "All",
          style: "all",
          image:
            "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=240&q=80&fit=crop",
        },
        {
          label: "Casual",
          style: "Casual",
          image:
            "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=240&q=80&fit=crop",
        },
        {
          label: "Office Wear",
          style: "Office Wear",
          image:
            "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=240&q=80&fit=crop",
        },
      ],
      styleRight: [
        {
          label: "Best Sellers",
          style: "Best Sellers",
          image:
            "https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=240&q=80&fit=crop",
        },
        {
          label: "Graphics Tees",
          style: "Graphics Tees",
          image:
            "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=240&q=80&fit=crop",
        },
      ],
    },
    shoes: {
      mode: "grid",
      items: [
        {
          label: "All",
          type: "all",
          image:
            "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=240&q=80&fit=crop",
        },
        {
          label: "Sandals",
          type: "Sandals",
          image:
            "https://images.unsplash.com/photo-1560769629-975ec94e6a86?w=240&q=80&fit=crop",
        },
        {
          label: "Sneakers",
          type: "Sneakers",
          image:
            "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=240&q=80&fit=crop",
        },
        {
          label: "Socks",
          type: "Socks",
          image:
            "https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=240&q=80&fit=crop",
        },
      ],
    },
  },
  woman: {
    clothing: {
      left: [
        {
          label: "All",
          type: "all",
          image:
            "https://images.unsplash.com/photo-1464863979621-258859e62245?w=240&q=80&fit=crop",
        },
        {
          label: "T-shirts",
          type: "T-shirts",
          image:
            "https://images.unsplash.com/photo-1495385794356-15371f348c31?w=240&q=80&fit=crop",
        },
        {
          label: "Shirts & Blouses",
          type: "Shirts & Blouses",
          image:
            "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=240&q=80&fit=crop",
        },
        {
          label: "Vests & Cardigans",
          type: "Vests & Cardigans",
          image:
            "https://images.unsplash.com/photo-1544717305-2782549b5136?w=240&q=80&fit=crop",
        },
        {
          label: "Jeans & Trousers",
          type: "Jeans & Trousers",
          image:
            "https://images.unsplash.com/photo-1551232864-3f0890e580d9?w=240&q=80&fit=crop",
        },
        {
          label: "Shorts",
          type: "Shorts",
          image:
            "https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=240&q=80&fit=crop",
        },
      ],
      middle: [
        {
          label: "Dresses",
          type: "Dresses",
          image:
            "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=240&q=80&fit=crop",
        },
        {
          label: "Polo Shirts",
          type: "Polo Shirts",
          image:
            "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=240&q=80&fit=crop",
        },
        {
          label: "Blazers & Jackets",
          type: "Blazers & Jackets",
          image:
            "https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?w=240&q=80&fit=crop",
        },
        {
          label: "Hoodies & Sweatshirts",
          type: "Hoodies & Sweatshirts",
          image:
            "https://images.unsplash.com/photo-1552902865-b72c031ac5ea?w=240&q=80&fit=crop",
        },
        {
          label: "Skorts & Skirts",
          type: "Skorts & Skirts",
          image:
            "https://images.unsplash.com/photo-1583496661160-fb5886a13d8b?w=240&q=80&fit=crop",
        },
        {
          label: "Undergarment",
          type: "Undergarment",
          image:
            "https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?w=240&q=80&fit=crop",
        },
      ],
      styleLeft: [
        {
          label: "All",
          style: "all",
          image:
            "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=240&q=80&fit=crop",
        },
        {
          label: "Casual",
          style: "Casual",
          image:
            "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=240&q=80&fit=crop",
        },
        {
          label: "Party Wear",
          style: "Party Wear",
          image:
            "https://images.unsplash.com/photo-1544717305-2782549b5136?w=240&q=80&fit=crop",
        },
      ],
      styleRight: [
        {
          label: "Best Sellers",
          style: "Best Sellers",
          image:
            "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=240&q=80&fit=crop",
        },
        {
          label: "Office Wear",
          style: "Office Wear",
          image:
            "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=240&q=80&fit=crop",
        },
      ],
    },
    shoes: {
      mode: "list",
      left: [
        {
          label: "All",
          type: "all",
          image:
            "https://images.unsplash.com/photo-1511556670410-f7099c9cd8f6?w=240&q=80&fit=crop",
        },
        {
          label: "Sandals",
          type: "Sandals",
          image:
            "https://images.unsplash.com/photo-1515347619252-60a4bf4fff4f?w=240&q=80&fit=crop",
        },
        {
          label: "Flats & Loafers",
          type: "Flats & Loafers",
          image:
            "https://images.unsplash.com/photo-1514989940723-e8e51635b782?w=240&q=80&fit=crop",
        },
      ],
      right: [
        {
          label: "Heels",
          type: "Heels",
          image:
            "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=240&q=80&fit=crop",
        },
        {
          label: "Sneakers",
          type: "Sneakers",
          image:
            "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=240&q=80&fit=crop",
        },
        {
          label: "Leg Warmers & Socks",
          type: "Leg Warmers & Socks",
          image:
            "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=240&q=80&fit=crop",
        },
      ],
    },
  },
  kid: {
    clothing: {
      left: [
        {
          label: "All",
          type: "all",
          image:
            "https://images.unsplash.com/photo-1519238359922-989348752efb?w=240&q=80&fit=crop",
        },
        {
          label: "T-shirts",
          type: "T-shirts",
          image:
            "https://images.unsplash.com/photo-1519340241574-2cec6aef0c01?w=240&q=80&fit=crop",
        },
        {
          label: "Shirts",
          type: "Shirts",
          image:
            "https://images.unsplash.com/photo-1503454537195-1dcabb73ffb9?w=240&q=80&fit=crop",
        },
        {
          label: "Polo Shirts",
          type: "Polo Shirts",
          image:
            "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?w=240&q=80&fit=crop",
        },
      ],
      middle: [
        {
          label: "Hoodies & Sweatshirts",
          type: "Hoodies & Sweatshirts",
          image:
            "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=240&q=80&fit=crop",
        },
        {
          label: "Jeans & Trousers",
          type: "Jeans & Trousers",
          image:
            "https://images.unsplash.com/photo-1516627145497-ae6968895b74?w=240&q=80&fit=crop",
        },
        {
          label: "Shorts",
          type: "Shorts",
          image:
            "https://images.unsplash.com/photo-1522771930-78848d9293e8?w=240&q=80&fit=crop",
        },
        {
          label: "Underwear",
          type: "Underwear",
          image:
            "https://images.unsplash.com/photo-1619785292559-2184818d2d2f?w=240&q=80&fit=crop",
        },
      ],
      styleLeft: [
        {
          label: "All",
          style: "all",
          image:
            "https://images.unsplash.com/photo-1607453998774-d533f65dac99?w=240&q=80&fit=crop",
        },
        {
          label: "Casual",
          style: "Casual",
          image:
            "https://images.unsplash.com/photo-1503919005314-30d93d07d823?w=240&q=80&fit=crop",
        },
      ],
      styleRight: [
        {
          label: "School Wear",
          style: "School Wear",
          image:
            "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?w=240&q=80&fit=crop",
        },
        {
          label: "Best Sellers",
          style: "Best Sellers",
          image:
            "https://images.unsplash.com/photo-1511556820780-d912e42b4980?w=240&q=80&fit=crop",
        },
      ],
    },
    shoes: {
      mode: "grid",
      items: [
        {
          label: "All",
          type: "all",
          image:
            "https://images.unsplash.com/photo-1514996937319-344454492b37?w=240&q=80&fit=crop",
        },
        {
          label: "Sandals",
          type: "Sandals",
          image:
            "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=240&q=80&fit=crop",
        },
        {
          label: "Sneakers",
          type: "Sneakers",
          image:
            "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=240&q=80&fit=crop",
        },
        {
          label: "Socks",
          type: "Socks",
          image:
            "https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=240&q=80&fit=crop",
        },
      ],
    },
  },
};

function CategoryListItem({ item, href, onSelect }) {
  return (
    <li>
      <Link
        to={href}
        onClick={onSelect}
        className="group flex min-h-10 items-center justify-between gap-3 rounded-md px-2 py-2 text-base text-muted-foreground transition-colors hover:bg-muted hover:text-[#E0271F] focus-visible:outline-offset-2"
      >
        <span>{item.label === "All" ? "View all" : item.label}</span>
        <ArrowUpRight
          aria-hidden="true"
          size={14}
          className="shrink-0 opacity-0 transition-opacity group-hover:opacity-100 group-focus-visible:opacity-100"
        />
      </Link>
    </li>
  );
}

function ClothingMegaPanel({ data, activeMain, onItemSelect }) {
  return (
    <div className="grid gap-8 md:grid-cols-[minmax(0,2fr)_minmax(0,1fr)]">
      <section aria-labelledby="menu-clothing-title">
        <h3
          id="menu-clothing-title"
          className="mb-4 px-2 text-xs font-semibold uppercase tracking-[.16em]"
        >
          Shop clothing
        </h3>
        <ul className="menu grid grid-cols-1 gap-x-8 sm:grid-cols-2">
          {[...data.left, ...data.middle].map((item) => (
            <CategoryListItem
              key={item.label}
              item={item}
              href={buildCategoryHref(activeMain, item, "type")}
              onSelect={onItemSelect}
            />
          ))}
        </ul>
      </section>
      <section
        aria-labelledby="menu-style-title"
        className="md:border-l md:border-border md:pl-6"
      >
        <h3
          id="menu-style-title"
          className="mb-4 px-2 text-xs font-semibold uppercase tracking-[.16em]"
        >
          Shop by style
        </h3>
        <ul className="menu">
          {[...data.styleLeft, ...data.styleRight].map((item) => (
            <CategoryListItem
              key={item.label}
              item={item}
              href={buildCategoryHref(activeMain, item, "style")}
              onSelect={onItemSelect}
            />
          ))}
        </ul>
      </section>
    </div>
  );
}

function ShoesGridPanel({ items, activeMain, onItemSelect }) {
  return (
    <section aria-labelledby="menu-shoes-title">
      <h3
        id="menu-shoes-title"
        className="mb-4 px-2 text-xs font-semibold uppercase tracking-[.16em]"
      >
        Shop shoes
      </h3>
      <ul className="menu grid grid-cols-1 gap-x-8 sm:grid-cols-2">
        {items.map((item) => (
          <CategoryListItem
            key={item.label}
            item={item}
            href={buildCategoryHref(activeMain, item, "type")}
            onSelect={onItemSelect}
          />
        ))}
      </ul>
    </section>
  );
}
//main menu
/**
 * Builds the mega-menu panels for one main category from the API category tree.
 *
 * The hardcoded megaCategoryData is kept only as a source of fallback imagery for
 * sub-categories that have not had one uploaded yet; every label, link and grouping now
 * comes from the database. Previously this merged the hardcoded data with a nested
 * object in localStorage, so the menu only showed what the admin dashboard had written
 * in that same browser.
 */
function getStoreMegaCategoryData(activeMain, tree) {
  const base = megaCategoryData[activeMain];

  const mainNode = (tree ?? []).find(
    (node) =>
      node.slug === activeMain || node.name.toLowerCase() === activeMain,
  );
  if (!mainNode) return base;

  const groupNamed = (needle) =>
    mainNode.children?.find((child) =>
      child.name
        .toLowerCase()
        .replace(/[^a-z]/g, "")
        .includes(needle),
    );

  // Fallback images, looked up by label out of the hardcoded data.
  const fallbackImages = {};
  Object.values(base ?? {}).forEach((group) => {
    Object.values(group ?? {}).forEach((items) => {
      if (Array.isArray(items))
        items.forEach((item) => {
          fallbackImages[item.label] = item.image;
        });
    });
  });

  const toItem = (node, kind) => ({
    label: node.name,
    [kind]: node.name,
    image: node.imageUrl || fallbackImages[node.name] || FALLBACK_MENU_IMAGE,
  });

  // "All" is a navigation affordance, not a category row, so it is added here.
  const withAll = (nodes, kind) => [
    {
      label: "All",
      [kind]: "all",
      image: nodes[0]?.imageUrl || FALLBACK_MENU_IMAGE,
    },
    ...nodes.map((node) => toItem(node, kind)),
  ];

  const clothingNodes = groupNamed("clothing")?.children ?? [];
  const styleNodes = groupNamed("shopbystyle")?.children ?? [];
  const shoeNodes = groupNamed("shoes")?.children ?? [];

  const clothing = withAll(clothingNodes, "type");
  const styles = withAll(styleNodes, "style");
  const half = Math.ceil(clothing.length / 2);
  const styleHalf = Math.ceil(styles.length / 2);

  return {
    clothing: {
      left: clothing.slice(0, half),
      middle: clothing.slice(half),
      styleLeft: styles.slice(0, styleHalf),
      styleRight: styles.slice(styleHalf),
      promo: base?.clothing?.promo,
    },
    shoes: shoeNodes.length
      ? { mode: "grid", items: withAll(shoeNodes, "type") }
      : (base?.shoes ?? { mode: "grid", items: [] }),
  };
}

const FALLBACK_MENU_IMAGE = "/images/products/unsplash/linen-shirt.jpg";

function MegaMenuPanel({
  activeMain,
  categoryTree,
  activeNav,
  onNavChange,
  onClose,
  onItemSelect,
}) {
  const navItems = ["Clothing", "Shoes"];
  const activeData = getStoreMegaCategoryData(activeMain, categoryTree);

  const categoryName =
    { woman: "Women", man: "Men", kid: "Kids" }[activeMain] || activeMain;
  const categoryHref = buildCategoryHref(activeMain, "all", "type");
  const image =
    {
      woman: "/images/products/unsplash/linen-shirt.jpg",
      man: "/images/products/unsplash/oxford-shirt.jpg",
      kid: "/images/products/banner/2.jpg",
    }[activeMain] || FALLBACK_MENU_IMAGE;

  return (
    <nav
      aria-label={`${categoryName} categories`}
      className="hidden border-t border-border bg-white shadow-lg md:block"
    >
      <div className="mx-auto max-w-[1280px] px-6 lg:px-10">
        <div className="flex items-center justify-between gap-4 border-b border-border">
          <div className="flex gap-6" aria-label="Category groups">
            {navItems.map((item) => (
              <button
                key={item}
                type="button"
                id={`menu-tab-${item}`}
                aria-pressed={activeNav === item}
                aria-controls="category-menu-panel"
                onClick={() => onNavChange(item)}
                className={`border-b-2 py-4 text-base font-medium transition-colors ${activeNav === item ? "border-[#E0271F] text-[#E0271F]" : "border-transparent text-muted-foreground hover:text-foreground"}`}
              >
                {item}
              </button>
            ))}
          </div>
          <button
            type="button"
            aria-label="Close category menu"
            onClick={onClose}
            className="btn btn-ghost rounded-md p-2 text-muted-foreground hover:bg-muted hover:text-foreground"
          >
            <X size={18} />
          </button>
        </div>
        <div className="grid gap-10 py-8 lg:grid-cols-[minmax(0,1fr)_280px]">
          <div
            id="category-menu-panel"
            role="region"
            aria-labelledby={`menu-tab-${activeNav}`}
          >
            {activeNav === "Clothing" ? (
              <ClothingMegaPanel
                data={activeData.clothing}
                activeMain={activeMain}
                onItemSelect={onItemSelect}
              />
            ) : (
              <ShoesGridPanel
                items={
                  activeData.shoes.mode === "list"
                    ? [...activeData.shoes.left, ...activeData.shoes.right]
                    : activeData.shoes.items
                }
                activeMain={activeMain}
                onItemSelect={onItemSelect}
              />
            )}
          </div>
          <Link
            to={categoryHref}
            onClick={onItemSelect}
            className="group relative hidden min-h-[270px] overflow-hidden rounded-lg bg-muted lg:block"
          >
            <img
              src={image}
              alt=""
              onError={onImageError}
              className="absolute inset-0 h-full w-full object-cover transition-transform duration-200 motion-safe:group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-5 text-white">
              <p className="mb-2 text-xs uppercase tracking-[.15em]">
                The {categoryName.toLowerCase()}’s edit
              </p>
              <span className="flex items-center justify-between gap-3 text-xl font-medium">
                Explore the collection{" "}
                <ArrowUpRight aria-hidden="true" size={20} />
              </span>
            </div>
          </Link>
        </div>
        <div className="flex items-center justify-between border-t border-border py-4 text-base">
          <span className="text-muted-foreground">
            Find your everyday favorites.
          </span>
          <Link
            to={categoryHref}
            onClick={onItemSelect}
            className="flex items-center gap-2 font-medium hover:text-[#E0271F]"
          >
            Shop all {categoryName.toLowerCase()}{" "}
            <ArrowUpRight aria-hidden="true" size={16} />
          </Link>
        </div>
      </div>
    </nav>
  );
}

export { Section, CategoryGrid, MegaMenuPanel, GRID_COLUMN_CLASSES };
