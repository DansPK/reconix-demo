import { useState } from "react";
import { useCart, useWishlist } from "../providers";
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../../components/ui/dialog";

export default function WishlistMove({ product }) {
  const { addToBag } = useCart();
  const { toggleWishlist } = useWishlist();
  const [open, setOpen] = useState(false), [variantId, setVariantId] = useState("");
  const [busy, setBusy] = useState(false), [error, setError] = useState("");
  const [added, setAdded] = useState(false);
  async function move(event) {
    event.preventDefault();
    if (busy) return;
    const variant = product.variants?.find(v => String(v.id) === variantId);
    if (!variant && !added) return;
    setBusy(true); setError("");
    try {
      if (!added) {
        await addToBag({ productId: product.id, variantId: variant.id, quantity: 1, selectedSize: variant.size, selectedColor: variant.color, name: product.name, price: product.price + Number(variant.priceAdjustment ?? 0), image: product.images?.[0] });
        setAdded(true);
      }
      await toggleWishlist(product);
      setOpen(false);
    } catch (failure) { setError(failure?.detail || "Could not finish the move. Your favorite is preserved."); }
    finally { setBusy(false); }
  }
  return <><Button variant="outline" className="mt-3 w-full" onClick={() => setOpen(true)}>Move to bag</Button>
    <Dialog open={open} onOpenChange={value => { if (!busy) setOpen(value); }}><DialogContent><DialogHeader><DialogTitle>Move {product.name} to bag</DialogTitle></DialogHeader>
      <form onSubmit={move} className="space-y-4"><label className="block text-sm">Size and color<select className="select block w-full border border-input rounded p-2" value={variantId} disabled={added} required={!added} onChange={event => setVariantId(event.target.value)}><option value="">Choose an option</option>{product.variants?.map(v => <option key={v.id} value={v.id} disabled={v.active === false || v.availableStock <= 0}>{v.size} / {v.color} — {v.availableStock} available</option>)}</select></label>
      {error && <p role="alert">{error}</p>}<Button disabled={busy}>{busy ? "Moving…" : added ? "Finish removing favorite" : "Move to bag"}</Button></form>
    </DialogContent></Dialog></>;
}
