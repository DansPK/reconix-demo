import { useResource } from "../../hooks/useResource";
import { api } from "../../api/client";
import { ResourceError } from "../../components/ResourceFeedback";
export default function PaymentReceipt({ code }) {
  const path = `/v1/orders/code/${encodeURIComponent(code)}/receipt`;
  const { data, error, refetch } = useResource(path, () => api.get(path), { keepPreviousData: false });
  if (error) return <ResourceError retry={refetch} />;
  if (!data) return <p role="status">Loading receipt…</p>;
  const money=value=>`$${Number(value ?? 0).toFixed(2)}`;
  return <section aria-label="Payment receipt" className="mt-4 space-y-2 border-t border-border pt-4"><h3 className="font-semibold">Payment receipt · {data.orderCode}</h3><p>{data.customerName}</p><p>{data.shippingAddress}</p><ul>{data.items.map(item=><li key={item.id}>{item.productName} · {item.selectedSize} / {item.selectedColor} · {item.quantity} × {money(item.unitPrice)}</li>)}</ul><p>Paid: {money(data.totalAmount)}</p>{Number(data.refundedAmount)>0&&<p>Refund recorded: {money(data.refundedAmount)}</p>}<p>Payment confirmed: {data.paymentDate ? new Date(data.paymentDate).toLocaleString("en",{timeZone:"Asia/Phnom_Penh"}) : "Timestamp unavailable"} · Phnom Penh time</p></section>;
}
