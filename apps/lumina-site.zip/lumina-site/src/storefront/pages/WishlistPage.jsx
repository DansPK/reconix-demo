import { useState } from "react";
import WishlistMove from "./WishlistMove";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import { useWishlist } from "../providers";
import { ProductCard } from "../productComponents";
import { Button } from "../../components/ui/button";
import { Skeleton } from "../../components/ui/skeleton";
import { Alert, AlertDescription } from "../../components/ui/alert";
function WishlistPage() {
  const { wishlist, loading, error, refetch, clearWishlist } = useWishlist();
  const [actionError, setActionError] = useState("");
  const [clearing, setClearing] = useState(false);
  return (
    <div className="mx-auto max-w-[1280px] px-5 py-10">
      <p className="mb-3 text-xs uppercase tracking-[.2em] text-muted-foreground">
        Saved for later
      </p>
      <h1 className="mb-3 text-4xl font-semibold">Your favorites.</h1>
      <p className="mb-8 text-muted-foreground">
        {wishlist.length} pieces you love. Choose a piece to find your size and
        add it to your bag.
      </p>
      {wishlist.length > 0 && <Button disabled={clearing} variant="outline" className="mb-5" onClick={async () => { setClearing(true); setActionError(""); try { await clearWishlist(); } catch { setActionError("Could not clear favorites. Try again."); } finally { setClearing(false); } }}>Clear all favorites</Button>}
      {actionError && <p role="alert">{actionError}</p>}
      {error ? (
        <Alert variant="destructive">
          <AlertDescription>
            Could not load your favorites.{" "}
            <Button variant="link" onClick={refetch}>
              Try again
            </Button>
          </AlertDescription>
        </Alert>
      ) : loading && !wishlist.length ? (
        <div className="grid grid-cols-2 gap-5 md:grid-cols-4">
          {[0, 1, 2, 3].map((i) => (
            <Skeleton key={i} className="aspect-[4/5]" />
          ))}
        </div>
      ) : wishlist.length ? (
        <div className="grid grid-cols-2 gap-5 md:grid-cols-4">
          {wishlist.map((product) => (
            <div key={product.id}><ProductCard product={product} /><WishlistMove product={product} /></div>
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-4 py-16 text-center">
          <Heart className="size-10 text-muted-foreground" />
          <h2 className="text-2xl font-semibold">Make room for favorites.</h2>
          <p className="text-muted-foreground">
            Tap the heart on a piece you love to save it here.
          </p>
          <Button asChild>
            <Link to="/category">Explore the collection</Link>
          </Button>
        </div>
      )}
    </div>
  );
}
export { WishlistPage };
