import { ResourceError } from "../../components/ResourceFeedback";
import React, { useState } from "react";
import { Button } from "@heroui/react";
import { Heart, ShoppingBag, Trash2 } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { onImageError } from "../adapt";
import { useCart, useWishlist } from "../providers";
import { PriceTag } from "../productComponents";
import StyledSelect from "../../components/ui/styled-select";
import { useDeliveryFee } from "../../hooks/useDeliveryFee";

function OrderSummaryCard({
  items,
  deliveryFee,
  feeLoading,
  feeError,
  retryFee,
  blackButtonLabel,
  onBlackAction,
}) {
  const subtotal = items.reduce((n, i) => n + i.price * i.qty, 0);
  const hasDeliveryFee = Number.isFinite(deliveryFee);
  const total = subtotal + (items.length && hasDeliveryFee ? deliveryFee : 0);
  return (
    <div className="border border-gray-200 rounded-xl p-5 bg-white shadow-sm">
      <div className="flex justify-between items-center">
        <div className="font-bold text-lg text-[#111111]">Order summary</div>
        <div className="font-extrabold text-xl text-foreground">
          {hasDeliveryFee ? `$${total.toFixed(2)}` : "—"}
        </div>
      </div>
      <div className="h-px bg-gray-200 my-4" />
      <div className="space-y-2.5 text-sm text-gray-600">
        <div className="flex justify-between">
          <span>Subtotal</span>
          <span className="font-medium text-[#111111]">
            ${subtotal.toFixed(2)}
          </span>
        </div>
        <div className="flex justify-between">
          <span>Delivery</span>
          <span className="font-medium text-[#111111]">
            {feeLoading ? "Loading…" : hasDeliveryFee ? `$${items.length ? deliveryFee.toFixed(2) : "0.00"}` : "Unavailable"}
          </span>
        </div>
      </div>
      {feeError ? (
        <div role="alert" className="mt-3 flex items-center justify-between gap-2 text-xs text-red-700">
          <span>Could not load delivery price.</span>
          <button type="button" onClick={retryFee} className="font-semibold underline">Retry</button>
        </div>
      ) : null}
      {blackButtonLabel ? (
        <Button
          onPress={onBlackAction}
          isDisabled={!hasDeliveryFee || feeLoading || !!feeError}
          className="w-full h-12 mt-5 bg-[#111111] text-white font-bold shadow-sm hover:bg-black"
        >
          {blackButtonLabel}
        </Button>
      ) : null}
    </div>
  );
}

function BagPage() {
  const navigate = useNavigate();
  const {
    items,
    mergeRejected = [],
    removeItem,
    updateQty,
    user,
    loading,
    error: resourceError,
    refetch,
  } = useCart();
  const { toggleWishlist, isWishlisted } = useWishlist();
  const deliveryFeeResource = useDeliveryFee();
  const deliveryFee = deliveryFeeResource.data?.deliveryFee == null
    ? null
    : Number(deliveryFeeResource.data.deliveryFee);
  const [error, setError] = useState("");
  const [pending, setPending] = useState(null);
  async function mutate(id, action) {
    if (pending) return;
    setPending(id);
    setError("");
    try {
      await action();
    } catch (e) {
      setError(e?.detail || "Could not update your bag. Please try again.");
    } finally {
      setPending(null);
    }
  }

  if (resourceError)
    return (
      <div className="mx-auto max-w-4xl px-5 py-10">
      {mergeRejected.length > 0 && <div role="alert" className="rounded border border-border p-4"><p>Some items could not be moved from your guest bag. They are preserved until you sign out.</p><ul>{mergeRejected.map((line, index) => <li key={index}>Product {line.productId}: {line.reason}</li>)}</ul></div>}
        <ResourceError message="Could not load your bag." retry={refetch} />
      </div>
    );

  if (loading && !items.length) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center text-gray-400">
        Loading…
      </div>
    );
  }

  if (!items.length) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <ShoppingBag size={48} className="mx-auto text-gray-300" />
        <h2 className="text-2xl font-bold mt-4">Your Bag is empty</h2>
        <p className="text-gray-500 mt-2">
          No items in your bag yet. Add products to continue checkout.
        </p>
        <Link
          to="/"
          className="inline-block mt-6 bg-black text-white px-5 py-3 rounded-md font-semibold"
        >
          Start shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
        <header className="mb-5 flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.12em] text-[#E0271F]">
              Shopping bag
            </p>
            <h1 className="text-3xl font-extrabold text-[#111111] mt-1">
              Your bag <span className="text-gray-400">({items.length})</span>
            </h1>
          </div>
          <Link
            to="/"
            className="text-sm font-semibold text-[#E0271F] hover:text-[#BE1F19]"
          >
            Continue shopping
          </Link>
        </header>
        {error && (
          <p
            role="alert"
            className="mb-4 rounded-md border border-destructive p-3 text-sm text-destructive"
          >
            {error}
          </p>
        )}
      <div className="grid grid-cols-1 items-start gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div className="min-w-0">
        <div className="space-y-4">
          {items.map((item) => (
            <div
              key={item.cartItemId}
              className="border border-gray-200 rounded-xl bg-white p-4 grid grid-cols-[64px_minmax(0,1fr)] sm:grid-cols-[96px_minmax(0,1fr)_auto] gap-4 shadow-sm transition-shadow hover:shadow-md"
            >
              <img
                src={item.image}
                alt={item.name}
                onError={onImageError}
                className="w-16 h-20 sm:w-24 sm:h-24 object-cover rounded-lg"
              />
              <div>
                <div className="font-bold text-[#111111]">{item.name}</div>
                <div className="text-sm text-gray-500">Code. {item.code}</div>
                <div className="flex gap-2 mt-3">
                  <span className="rounded-md bg-muted px-2 py-1.5 text-sm">
                    {item.size || "One size"}
                  </span>
                  <StyledSelect
                    value={String(item.qty)}
                    ariaLabel={`Quantity for ${item.name}`}
                    disabled={pending !== null}
                    onValueChange={(value) =>
                      mutate(item.cartItemId, () =>
                        updateQty(item.cartItemId, Number(value)),
                      )
                    }
                    options={Array.from(
                      { length: Math.max(5, item.qty) },
                      (_, i) => i + 1,
                    ).map((quantity) => ({
                      value: String(quantity),
                      label: String(quantity),
                    }))}
                    size="sm"
                    className="h-9 w-16 border-gray-300 bg-gray-50 px-2 text-sm font-medium"
                  />
                </div>
                <button
                  disabled={pending !== null}
                  onClick={() =>
                    mutate(item.cartItemId, () =>
                      isWishlisted(item.productId)
                        ? Promise.resolve()
                        : toggleWishlist({
                            id: item.productId,
                            slug: item.slug,
                            name: item.name,
                            code: item.code,
                            price: item.price,
                            originalPrice: item.originalPrice,
                            images: [item.image],
                          }),
                    )
                  }
                  className="mt-3 text-[#E0271F] text-sm font-semibold flex items-center gap-1"
                >
                  <Heart size={14} />
                  Save to wishlist
                </button>
              </div>
              <div className="text-right">
                <PriceTag
                  price={item.price}
                  originalPrice={item.originalPrice}
                />
                <button
                  disabled={pending !== null}
                  onClick={() =>
                    mutate(item.cartItemId, () => removeItem(item.cartItemId))
                  }
                  aria-label={`Remove ${item.name} from bag`}
                  className="mt-8 inline-flex h-9 w-9 items-center justify-center rounded-md border border-gray-200 bg-black text-white hover:bg-gray-800"
                >
                  <Trash2 size={17} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="lg:sticky lg:top-24 h-fit">

        <OrderSummaryCard
          items={items}
          deliveryFee={deliveryFee}
          feeLoading={deliveryFeeResource.loading}
          feeError={deliveryFeeResource.error}
          retryFee={deliveryFeeResource.refetch}
          blackButtonLabel="Continue to checkout"
          onBlackAction={() => navigate(user ? "/checkout" : "/login")}
        />
        {!user ? (
          <div className="text-sm text-gray-600 bg-gray-50 border border-gray-200 rounded-md p-3 mt-3">
            Please{" "}
            <Link to="/login" className="text-[#E0271F] font-semibold">
              log in
            </Link>{" "}
            or{" "}
            <Link to="/register" className="text-[#E0271F] font-semibold">
              create an account
            </Link>{" "}
            to place an order.
          </div>
        ) : null}
      </div>
      </div>
    </div>
  );
}

export { BagPage };
