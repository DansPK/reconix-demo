import ProfilePanel from "../../components/ProfilePanel";
import NotificationPreferences from "../../components/NotificationPreferences";
function AccountPage() {
  return <div className="space-y-6 pb-8"><ProfilePanel /><div className="px-4 sm:px-6"><NotificationPreferences /></div></div>;
}
export { AccountPage };
