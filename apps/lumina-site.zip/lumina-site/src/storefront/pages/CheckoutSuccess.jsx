import { motion, useReducedMotion } from "framer-motion";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "../../components/ui/dialog";
import { Button } from "../../components/ui/button";

export default function CheckoutSuccess({ isCod, noPaymentRequired, order, amount, onOrders, onContinue }) {
  const reducedMotion = useReducedMotion();
  return (
    <Dialog open onOpenChange={open => { if (!open) onOrders(); }}>
      <DialogContent className="max-h-[90dvh] overflow-y-auto px-6 py-8 text-center sm:max-w-[460px] sm:px-8">
        <div className="flex flex-col items-center">
          <motion.div className="relative mb-5 flex h-24 w-24 items-center justify-center rounded-full bg-success/10 text-success-700" initial={reducedMotion ? false : { scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 220, damping: 18 }}>
            {!reducedMotion && Array.from({ length: 12 }, (_, index) => {
              const angle = index * Math.PI / 6;
              return <motion.span key={index} aria-hidden="true" className="pointer-events-none absolute left-1/2 top-1/2 h-1.5 w-1.5 rounded-full bg-success/40" initial={{ x: 0, y: 0, opacity: 0 }} animate={{ x: Math.cos(angle) * 85, y: Math.sin(angle) * 85, opacity: [0, 1, 0], scale: [0.5, 1, 0.5] }} transition={{ duration: 0.9, delay: 0.25, ease: "easeOut" }} />;
            })}
            <svg viewBox="0 0 80 80" className="h-20 w-20" fill="none" aria-hidden="true">
              <motion.circle cx="40" cy="40" r="29" stroke="currentColor" strokeWidth="3" initial={reducedMotion ? false : { pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.5 }} />
              <motion.path d="M27 40l9 9 17-18" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" initial={reducedMotion ? false : { pathLength: 0, opacity: 0 }} animate={{ pathLength: 1, opacity: 1 }} transition={{ duration: 0.35, delay: reducedMotion ? 0 : 0.3 }} />
            </svg>
          </motion.div>
          <DialogTitle className="text-center text-2xl font-semibold tracking-tight text-success-700">{isCod || noPaymentRequired ? "Order placed!" : "Payment successful!"}</DialogTitle>
          <DialogDescription className="mt-3 max-w-xs text-center text-sm leading-6">{noPaymentRequired ? "Your order is confirmed. No payment is required." : isCod ? "Your order is confirmed. Pay when it arrives." : "Thank you for shopping with Lumina. Your payment has been received."}</DialogDescription>
        </div>
        <dl className="mt-4 space-y-3 rounded-lg border bg-muted/40 p-4 text-xs">
          {[["Order", order?.orderCode || "—"], ["Amount", `$${Number(order?.totalAmount ?? amount).toFixed(2)}`], ["Payment", noPaymentRequired ? "No payment required" : isCod ? "Cash on delivery" : "Bakong KHQR"], ["Status", noPaymentRequired ? "Confirmed" : isCod ? "Pending payment" : "Paid"]].map(([label, value]) => <div key={label} className="grid grid-cols-[70px_minmax(0,1fr)] items-baseline gap-3 text-left"><dt className="text-muted-foreground">{label}</dt><dd className={`break-words text-right font-medium ${label === "Status" && !isCod ? "text-success-700" : "text-foreground"}`}>{value}</dd></div>)}
        </dl>
        <div className="mt-3 flex flex-col gap-2"><Button onClick={onOrders} className="h-10 w-full bg-foreground text-background hover:bg-foreground/90">View Order</Button><Button variant="outline" onClick={onContinue} className="h-10 w-full">Continue Shopping</Button></div>
      </DialogContent>
    </Dialog>
  );
}
