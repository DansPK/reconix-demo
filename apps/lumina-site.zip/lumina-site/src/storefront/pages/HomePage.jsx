import { ArrowRight } from "lucide-react";
import { Link, useLocation, Navigate } from "react-router-dom";
import { Section, CategoryGrid } from "../menu";
import { Button } from "../../components/ui/button";
import { Reveal } from "../../components/PageMotion";
function HomePage() {
  const { search } = useLocation();
  const params = new URLSearchParams(search);
  const category = params.get("cat") || "all";
  if (params.get("q")) return <Navigate to={`/category${search}`} replace />;
  return (
    <>
      <section className="relative isolate min-h-[480px] overflow-hidden bg-secondary md:min-h-[620px]">
        <img
          src="/images/products/banner/banner1.jpg"
          alt="The new season Lumina collection"
          className="absolute inset-0 h-full w-full object-cover"
          fetchpriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/35 to-transparent" />
        <Reveal className="relative mx-auto flex min-h-[480px] max-w-[1280px] flex-col justify-center px-6 py-16 text-white md:min-h-[620px] md:px-10">
          <p className="mb-5 text-xs uppercase tracking-[.3em] text-white/80">
            Everyday, thoughtfully styled
          </p>
          <h1 className="max-w-xl text-5xl font-semibold leading-[1.05] tracking-tight md:text-7xl">
            Your style.
            <br />
            Your everyday.
          </h1>
          <p className="mt-6 max-w-sm text-base leading-relaxed text-white/80">
            Fresh perspectives. Effortless essentials. Discover pieces that feel
            like you.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/category?cat=women">
                Shop women <ArrowRight data-icon="inline-end" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="secondary" className="text-black">
              <Link to="/category?cat=men">Explore men</Link>
            </Button>
          </div>
        </Reveal>
      </section>
      <nav
        aria-label="Shop collections"
        className="mx-auto flex max-w-[1280px] flex-wrap items-center justify-center gap-3 border-b border-border px-5 py-6"
      >
        {[
          ["all", "All collections"],
          ["women", "Women"],
          ["men", "Men"],
          ["kid", "Kids"],
        ].map(([value, label]) => (
          <Button
            key={value}
            asChild
            variant={category === value ? "default" : "ghost"}
          >
            <Link
              to={value === "all" ? "/" : `/?cat=${value}`}
              aria-current={category === value ? "page" : undefined}
            >
              {label}
            </Link>
          </Button>
        ))}
      </nav>
      <Section title="Fresh arrivals" section="featured" category={category} />
      <Section
        title="In the everyday rotation"
        section="trend"
        category={category}
        columns={5}
      />
      <CategoryGrid />
      <Section
        title="The atelier collection"
        section="atelier"
        category={category}
      />
      <Section
        title="Little prices. Great finds."
        section="under10"
        category={category}
        columns={5}
      />
      <Section
        title="A step in your direction"
        section="footwear"
        category={category}
      />
    </>
  );
}
export { HomePage };
