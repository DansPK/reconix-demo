import { useState } from "react";
import { Link } from "react-router-dom";
import * as ordersApi from "../../api/orders";
import { useResource } from "../../hooks/useResource";
import { useCart } from "../providers";
import {
  ResourceError,
  ResourceLoading,
} from "../../components/ResourceFeedback";
import { Button } from "../../components/ui/button";
import { Package } from "lucide-react";
import OrderListCard from "../components/OrderListCard";

function OrdersPage() {
  const { user } = useCart();
  const [page, setPage] = useState(0);
  const { data, loading, error, refetch } = useResource(
    user ? `/v1/orders?page=${page}` : null,
    () => ordersApi.listMyOrders({ page, size: 20 }),
    { keepPreviousData: false, pollMs: 10000 },
  );
  const orders = data?.content ?? [];
  if (loading && !data) return <ResourceLoading />;
  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-6 sm:gap-5 sm:px-6 sm:py-10">
      <div>
        <p className="mb-1.5 text-[11px] uppercase tracking-[.18em] text-muted-foreground">
          From our store to your door
        </p>
        <h1 className="text-xl font-semibold sm:text-2xl">Your orders.</h1>
        <p className="mt-1 text-sm text-muted-foreground">View order updates and continue any pending payment.</p>
      </div>
      {error ? (
        <ResourceError retry={refetch} />
      ) : orders.length ? (
        <div className="grid gap-4">
          {orders.map((order) => <OrderListCard key={order.orderCode} order={order} />)}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-4 rounded-xl border border-border bg-card px-5 py-16 text-center">
          <span className="grid h-14 w-14 place-items-center rounded-full bg-muted text-muted-foreground"><Package size={24} aria-hidden="true" /></span>
          <h2 className="text-2xl font-semibold">Your story starts here.</h2>
          <p className="text-muted-foreground">
            Your orders will appear here once you’ve found your favorites.
          </p>
          <Button asChild>
            <Link to="/category">Explore the collection</Link>
          </Button>
        </div>
      )}
      {data?.totalPages > 1 && (
        <nav
          aria-label="Order pagination"
          className="flex items-center justify-center gap-4"
        >
          <Button
            variant="outline"
            disabled={!page || loading}
            onClick={() => setPage((p) => p - 1)}
          >
            Previous
          </Button>
          <span>
            {page + 1} / {data.totalPages}
          </span>
          <Button
            variant="outline"
            disabled={page + 1 >= data.totalPages || loading}
            onClick={() => setPage((p) => p + 1)}
          >
            Next
          </Button>
        </nav>
      )}
    </div>
  );
}
export { OrdersPage };
