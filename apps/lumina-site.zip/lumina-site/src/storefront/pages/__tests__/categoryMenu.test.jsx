// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { MegaMenuPanel } from "../../menu";
import { buildCategoryHref } from "../../data";

afterEach(cleanup);
it("keeps category and style values in menu destinations", () => {
  expect(buildCategoryHref("woman", { label: "Shirts & Blouses", type: "Shirts & Blouses" }, "type"))
    .toBe("/category?cat=women&type=Shirts+%26+Blouses");
  expect(buildCategoryHref("man", { label: "Office Wear", style: "Office Wear" }, "style"))
    .toBe("/category?cat=men&style=Office+Wear");
  expect(buildCategoryHref("kid", { label: "All", type: "all" }, "type"))
    .toBe("/category?cat=kid");
});
it("shows API categories, working navigation, group selection and close controls", () => {
  const onClose = vi.fn(), onNavChange = vi.fn(), onItemSelect = vi.fn();
  render(<MemoryRouter><MegaMenuPanel activeMain="woman" activeNav="Clothing"
    categoryTree={[{ slug: "woman", name: "Women", children: [
      { name: "Clothing", children: [{ name: "Dresses" }] },
      { name: "Shop by style", children: [{ name: "Casual" }] },
    ] }]} onClose={onClose} onNavChange={onNavChange} onItemSelect={onItemSelect} />
  </MemoryRouter>);
  expect(screen.getByRole("link", { name: "Dresses" }).getAttribute("href"))
    .toBe("/category?cat=women&type=Dresses");
  expect(screen.getByRole("link", { name: "Casual" }).getAttribute("href"))
    .toBe("/category?cat=women&style=Casual");
  fireEvent.click(screen.getByRole("button", { name: "Shoes" }));
  expect(onNavChange).toHaveBeenCalledWith("Shoes");
  fireEvent.click(screen.getByRole("button", { name: "Close category menu" }));
  expect(onClose).toHaveBeenCalledOnce();
  fireEvent.click(screen.getByRole("link", { name: "Dresses" }));
  expect(onItemSelect).toHaveBeenCalledOnce();
});
