// @vitest-environment jsdom
import { act, cleanup, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { usePaymentPolling } from "../usePaymentPolling";
import { invalidateAll } from "../../../hooks/useResource";
const get = vi.hoisted(() => vi.fn());
vi.mock("../../../api/payments", () => ({
  getPaymentStatus: (...args) => get(...args),
}));
beforeEach(() => {
  vi.useFakeTimers();
  get.mockReset();
});
afterEach(() => {
  cleanup();
  invalidateAll();
  vi.useRealTimers();
});
it("polls pending payments and stops after bank confirmation", async () => {
  get
    .mockResolvedValueOnce({ id: 1, paymentStatus: "pending" })
    .mockResolvedValue({ id: 1, paymentStatus: "paid" });
  const { result } = renderHook(() => usePaymentPolling(1, true));
  await act(async () => {});
  expect(result.current.data.paymentStatus).toBe("pending");
  await act(async () => {
    vi.advanceTimersByTime(3000);
  });
  expect(result.current.data.paymentStatus).toBe("paid");
  await act(async () => {
    vi.advanceTimersByTime(12000);
  });
  expect(get).toHaveBeenCalledTimes(2);
});
it("preserves a recoverable error and retries while payment is pending", async () => {
  get
    .mockRejectedValueOnce(new Error("offline"))
    .mockResolvedValue({ id: 1, paymentStatus: "pending" });
  const { result } = renderHook(() => usePaymentPolling(1, true));
  await act(async () => {});
  expect(result.current.error.message).toBe("offline");
  await act(async () => {
    vi.advanceTimersByTime(3000);
  });
  expect(result.current.error).toBeNull();
  expect(result.current.data.paymentStatus).toBe("pending");
});
it("never polls when there is no active payment", async () => {
  renderHook(() => usePaymentPolling(null, false));
  await act(async () => {
    vi.advanceTimersByTime(6000);
  });
  expect(get).not.toHaveBeenCalled();
});
