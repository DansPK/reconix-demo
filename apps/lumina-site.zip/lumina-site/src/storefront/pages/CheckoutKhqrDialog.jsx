import {
  AlertCircle,
  Clock3,
  Landmark,
} from "lucide-react";
import KhqrReceipt from "../components/KhqrReceipt";
import { Button } from "../../components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";

const QR_LIFETIME_SECONDS = 15 * 60;

function CheckoutKhqrDialog({
  payment,
  orderCode,
  total,
  formattedTime,
  secondsLeft,
  isExpired,
  isCancelled,
  paymentStatusError,
  error,
  busy,
  onOpenChange,
  onRegenerate,
  onContinue,
}) {
  const progress = Math.max(
    0,
    Math.min(100, (secondsLeft / QR_LIFETIME_SECONDS) * 100),
  );
  const isUrgent = secondsLeft <= 60;
  const amount = Number(payment?.amount ?? total);
  const qrPayload = payment?.khqrString;

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent
        className="khqr-dialog p-0 [&>button:last-child]:right-3 [&>button:last-child]:top-3 [&>button:last-child]:z-10 [&>button:last-child]:rounded-full [&>button:last-child]:bg-muted [&>button:last-child]:p-2 [&>button:last-child]:text-foreground [&>button:last-child]:opacity-100"
        onPointerDownOutside={(event) => event.preventDefault()}
      >
        <DialogHeader className="sr-only">
          <DialogTitle>Pay with KHQR</DialogTitle>
          <DialogDescription>Scan using a Bakong-enabled banking app.</DialogDescription>
        </DialogHeader>

        <div className="khqr-body">
          {error ? (
            <p
              role="alert"
              className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs font-medium text-red-700"
            >
              <AlertCircle size={15} className="mt-0.5 shrink-0" aria-hidden="true" />
              {error}
            </p>
          ) : null}
          {paymentStatusError ? (
            <p
              role="status"
              className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800"
            >
              <AlertCircle size={15} className="mt-0.5 shrink-0" aria-hidden="true" />
              We couldn’t check the payment yet. We’ll keep retrying; please don’t pay twice.
            </p>
          ) : null}

          {isCancelled ? (
            <div className="khqr-terminal rounded-2xl bg-card p-6 text-center">
              <span className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-[#F4F2ED] text-[#777168]">
                <AlertCircle size={21} aria-hidden="true" />
              </span>
              <h2 className="mt-3 text-base font-semibold text-[#1A1714]">This order was cancelled</h2>
              <p className="mt-1 text-sm text-[#777168]">You can review the order from My Orders.</p>
              <Button onClick={onContinue} className="mt-4 w-full">View my orders</Button>
            </div>
          ) : isExpired ? (
            <div className="khqr-terminal rounded-2xl bg-card p-6 text-center">
              <span className="mx-auto grid h-11 w-11 place-items-center rounded-full bg-red-50 text-[#E0271F]">
                <Clock3 size={21} aria-hidden="true" />
              </span>
              <h2 className="mt-3 text-base font-semibold text-[#1A1714]">This QR code has expired</h2>
              <p className="mx-auto mt-1 max-w-xs text-sm leading-5 text-[#777168]">
                Generate a fresh code to continue payment for this order.
              </p>
              <div className="mt-4 space-y-2">
                <Button
                  disabled={busy}
                  onClick={onRegenerate}
                  className="w-full bg-[#E0271F] text-white hover:bg-[#bd211b]"
                >
                  {busy ? "Generating…" : "Generate new QR"}
                </Button>
                <Button variant="outline" onClick={onContinue} className="w-full bg-white">
                  Continue later in My Orders
                </Button>
              </div>
            </div>
          ) : (
            <div className="khqr-payment">
              <div className="khqr-amount px-10 text-center">
                <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                  Lumina · Order {orderCode || "—"}
                </p>
              </div>

              <div className="khqr-qr">
                <KhqrReceipt value={qrPayload} amount={Number.isFinite(amount) ? amount : total} currency={payment?.currency || "USD"} />
              </div>

              <div className="khqr-timer rounded-xl border border-[#EEE8DA] bg-[#FAF8F2] px-3.5 py-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex min-w-0 items-center gap-2.5">
                    <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-white text-[#8A5A12] shadow-sm">
                      <Clock3 size={16} aria-hidden="true" />
                    </span>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-[#29251E]">QR expires in</p>
                      <p className="text-[11px] text-[#777168]">Pay before the code expires</p>
                    </div>
                  </div>
                  <time
                    aria-label={`${formattedTime} remaining`}
                    className={`shrink-0 text-lg font-semibold tabular-nums ${isUrgent ? "text-[#C23020]" : "text-[#8A5A12]"}`}
                  >
                    {formattedTime}
                  </time>
                </div>
                <div
                  role="progressbar"
                  aria-label="QR code time remaining"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Math.round(progress)}
                  className="mt-2.5 h-1.5 overflow-hidden rounded-full bg-[#E8E2D5]"
                >
                  <div
                    className={`h-full rounded-full transition-[width] duration-700 ${isUrgent ? "bg-[#E0271F]" : "bg-[#B57923]"}`}
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>

              <div className="khqr-instructions flex items-start gap-2.5 px-1 py-1">
                <Landmark size={16} className="mt-0.5 shrink-0 text-muted-foreground" aria-hidden="true" />
                <p className="text-xs leading-5 text-muted-foreground">
                  Scan with your banking app. Payment status updates automatically.
                </p>
              </div>

              <div className="khqr-actions">
                <Button variant="outline" onClick={onContinue} className="w-full bg-white">
                  Continue later in My Orders
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default CheckoutKhqrDialog;
