import { Link } from "react-router-dom";
import { Button } from "../../components/ui/button";
function PaymentSuccessPage() {
  return (
    <div className="mx-auto flex max-w-lg flex-col items-center gap-5 px-6 py-20 text-center">
      <h1 className="text-3xl font-semibold">Your order, at a glance.</h1>
      <p className="text-muted-foreground">
        Check your orders for the latest payment and delivery status.
      </p>
      <Button asChild>
        <Link to="/orders">View my orders</Link>
      </Button>
      <Button asChild variant="outline">
        <Link to="/category">Continue shopping</Link>
      </Button>
    </div>
  );
}
export { PaymentSuccessPage };
