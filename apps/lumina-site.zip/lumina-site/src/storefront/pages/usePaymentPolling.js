import { useEffect, useRef } from "react";
import { refreshPaymentViews } from "../../api/paymentSync";
import * as paymentsApi from "../../api/payments";
import { peek, useResource } from "../../hooks/useResource";
function usePaymentPolling(paymentId, active) {
  const key = active && paymentId ? `/v1/payments/${paymentId}/status` : null;
  const status = peek(key)?.paymentStatus;
  const terminal = status && status !== "pending";
  const resource = useResource(key, () => paymentsApi.getPaymentStatus(paymentId), {
    pollMs: terminal ? undefined : 3000,
    refetchOnFocus: true,
    keepPreviousData: false,
  });
  const observed = useRef(null);
  useEffect(() => {
    const status = resource.data?.paymentStatus;
    const next = status && key ? `${key}:${status}` : null;
    if (!next || observed.current === next) return;
    observed.current = next;
    if (status !== "pending") refreshPaymentViews();
  }, [key, resource.data?.paymentStatus]);
  return resource;
}
export { usePaymentPolling };
