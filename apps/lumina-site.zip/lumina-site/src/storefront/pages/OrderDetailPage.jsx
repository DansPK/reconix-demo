import PaymentReceipt from "./PaymentReceipt";
import React from "react";
import { Link, Navigate, useParams } from "react-router-dom";
import * as ordersApi from "../../api/orders";
import { useResource } from "../../hooks/useResource";
import CancelOrderAction from "../components/CancelOrderAction";
import OrderPaymentPanel from "./OrderPaymentPanel";
import {
  ResourceError,
  ResourceLoading,
} from "../../components/ResourceFeedback";
import OrderProductImage from "../../components/OrderProductImage";
import { useCart } from "../providers";
import { ArrowLeft, MapPin, Package, Phone, Truck } from "lucide-react";
import { Badge } from "../../components/ui/badge";

function OrderDetailPage() {
  const { code } = useParams();
  const { user } = useCart();
  const {
    data: order,
    loading,
    error,
    refetch,
  } = useResource(
    user && code ? `/v1/orders/code/${code}` : null,
    () => ordersApi.getMyOrderByCode(code),
    { keepPreviousData: false, pollMs: 10000 },
  );

  if (!user) return <Navigate to="/login" replace />;

  if (loading && !order) {
    return <ResourceLoading />;
  }

  if (error && error.status !== 404)
    return (
      <div className="mx-auto max-w-3xl px-5 py-10">
        <ResourceError retry={refetch} />
      </div>
    );
  if (error || !order) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold">Order not found</h2>
        <Link
          to="/orders"
          className="inline-block mt-6 bg-black text-white px-5 py-3 rounded-md font-semibold"
        >
          Back to Orders
        </Link>
      </div>
    );
  }

  const cancelledUnpaid =
    order.fulfillmentStatus === "cancelled" && order.paymentStatus === "pending";
  const paymentLabel = cancelledUnpaid ? "Unavailable — order cancelled" : order.paymentStatus;

  const items = order.items ?? [];
  const money = (value) => `$${Number(value ?? 0).toFixed(2)}`;
  const placedAt = new Intl.DateTimeFormat("en", {
    dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Phnom_Penh",
  }).format(new Date(order.createdAt));

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 sm:py-10">
      <Link to="/orders" className="group inline-flex min-h-9 items-center gap-1.5 rounded-md py-1 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-4">
        <ArrowLeft size={14} strokeWidth={1.75} className="transition-transform group-hover:-translate-x-0.5" aria-hidden="true" /> Back to orders
      </Link>
      <header className="mb-6 mt-5 flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <p className="mb-1 text-xs font-medium uppercase tracking-widest text-muted-foreground">Order details</p>
          <h1 className="break-words text-xl font-semibold tracking-tight sm:text-2xl">Order #{order.orderCode}</h1>
          <p className="mt-2 text-xs text-muted-foreground">Placed {placedAt} · Phnom Penh time</p>
        </div>
        <Badge variant="outline" className={`w-fit shrink-0 gap-2 rounded-full px-3 py-1.5 capitalize ${order.fulfillmentStatus === "cancelled" ? "border-red-200 bg-red-50 text-red-700" : "border-border bg-muted text-foreground"}`}>
          <Package size={14} aria-hidden="true" /> {order.fulfillmentStatus}
        </Badge>
      </header>

      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="min-w-0 space-y-5">
          <section className="overflow-hidden rounded-2xl border border-border bg-card">
            <div className="flex items-center justify-between gap-3 border-b border-border px-5 py-4">
              <h2 className="text-base font-semibold">Ordered items</h2>
              <span className="text-xs text-muted-foreground">{items.reduce((sum, item) => sum + Number(item.quantity ?? 0), 0)} items</span>
            </div>
            <div className="divide-y divide-border px-4 sm:px-5">
              {items.map((item) => (
                <div key={item.id} className="grid grid-cols-[64px_minmax(0,1fr)] items-center gap-4 py-5 sm:grid-cols-[72px_minmax(0,1fr)_auto]">
                  <OrderProductImage className="h-16 w-16 rounded-lg sm:h-[72px] sm:w-[72px]" productId={item.productId} name={item.productName} imageUrl={item.imageUrl} />
                  <div className="min-w-0">
                    <p className="break-words text-sm font-semibold">{item.productName}</p>
                    <p className="mt-1 break-words text-xs text-muted-foreground">{item.selectedSize ?? "—"} · {item.selectedColor ?? "—"} · Qty: {item.quantity}</p>
                    <p className="mt-1 break-words text-[11px] text-muted-foreground">SKU {item.variantSku}</p>
                  </div>
                  <div className="col-start-2 text-sm sm:col-start-auto sm:text-right">
                    <p className="font-semibold tabular-nums">{money(Number(item.unitPrice) * Number(item.quantity))}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">{money(item.unitPrice)} each</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-2xl border border-border bg-card p-5">
            <h2 className="text-base font-semibold">Order timeline</h2>
            {(order.statusHistory ?? []).length ? (
              <ul className="timeline timeline-vertical timeline-compact mt-5 flex flex-col" aria-label="Order status history">
                {order.statusHistory.map((event, index) => (
                  <li key={event.id ?? index} className="relative grid grid-cols-[12px_minmax(0,1fr)] gap-x-3 pb-5 last:pb-0">
                    {index < order.statusHistory.length - 1 && <span className="absolute bottom-0 left-[5px] top-3 w-px bg-border" aria-hidden="true" />}
                    <div className="timeline-middle col-start-1 row-span-2 row-start-1 pt-1" aria-hidden="true">
                      <span className={`relative block h-3 w-3 rounded-full border-2 border-card ring-1 ring-border ${["cancelled", "expired", "failed"].includes(event.newStatus) ? "bg-muted-foreground" : "bg-primary"}`} />
                    </div>
                    <p className="timeline-end col-start-2 row-start-1 min-w-0 break-words text-sm font-medium capitalize leading-5">
                      {event.statusKind}: {String(event.newStatus ?? "").replaceAll("_", " ")}
                    </p>
                    {event.changedAt && (
                      <time dateTime={event.changedAt} className="timeline-start col-start-2 row-start-2 mt-1 text-xs leading-5 text-muted-foreground">
                        {new Date(event.changedAt).toLocaleString("en", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Phnom_Penh" })}
                      </time>
                    )}
                  </li>
                ))}
              </ul>
            ) : <p className="mt-4 text-sm text-muted-foreground">No activity recorded yet.</p>}
          </section>
          <section className="rounded-2xl border border-border bg-card p-5">
            <h2 className="flex items-center gap-2 text-base font-semibold"><MapPin size={18} className="text-muted-foreground" aria-hidden="true" /> Delivery details</h2>
            <div className="mt-4 border-l-2 border-border pl-4">
              <p className="text-sm font-semibold">{order.customerName}</p>
              <p className="mt-2 whitespace-pre-line break-words text-sm leading-relaxed text-muted-foreground">{order.shippingAddress}</p>
              <p className="mt-3 flex items-center gap-2 text-sm"><Phone size={14} className="shrink-0 text-muted-foreground" aria-hidden="true" /> {order.customerPhone}</p>
            </div>
            {order.courierName ? <p className="mt-3 text-sm">Courier: {order.courierName}</p> : null}
            {order.estimatedDeliveryDate ? <p className="mt-2 text-sm">Estimated delivery: {order.estimatedDeliveryDate}</p> : null}
            {order.trackingUrl?.startsWith("https://") ? <a className="mt-3 inline-block text-sm underline" href={order.trackingUrl} target="_blank" rel="noreferrer">Track shipment</a> : null}
            {order.trackingNumber ? (
              <div className="mt-5 flex items-start gap-3 rounded-xl bg-muted p-3">
                <Truck size={18} className="mt-0.5 shrink-0 text-muted-foreground" aria-hidden="true" />
                <div className="min-w-0"><p className="text-xs text-muted-foreground">Tracking number</p><p className="mt-1 break-words text-sm font-medium">{order.trackingNumber}</p></div>
              </div>
            ) : null}
          </section>
        </div>

        <aside className="min-w-0 space-y-5" aria-label="Order summary and payment">
          <section className="rounded-2xl border border-border bg-card p-5">
            <h2 className="text-base font-semibold">Order summary</h2>
            <dl className="mt-4 space-y-3 text-sm">
              <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Subtotal</dt><dd className="tabular-nums">{money(order.subtotalAmount)}</dd></div>
              <div className="flex justify-between gap-4"><dt className="text-muted-foreground">Delivery</dt><dd className="tabular-nums">{money(order.deliveryFee)}</dd></div>
              {Number(order.discountAmount ?? 0) > 0 ? <div className="flex justify-between gap-4"><dt className="break-words text-muted-foreground">Discount</dt><dd className="shrink-0 tabular-nums text-emerald-700">−{money(order.discountAmount)}</dd></div> : null}
              <div className="flex items-center justify-between gap-4 border-t border-border pt-4"><dt className="font-semibold">Total</dt><dd className="text-xl font-semibold tabular-nums">{money(order.totalAmount)}</dd></div>
            </dl>
            <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-lg bg-muted px-3 py-2.5">
              <span className="text-xs text-muted-foreground">Payment status</span>
              <span className={`text-xs font-semibold capitalize ${cancelledUnpaid ? "text-muted-foreground" : order.paymentStatus === "paid" ? "text-emerald-700" : order.paymentStatus === "pending" ? "text-amber-700" : "text-muted-foreground"}`}>{paymentLabel}</span>
            </div>
            {["paid", "partially_refunded", "refunded"].includes(order.paymentStatus) && <Link className="mt-4 inline-block underline" to={`/orders/${order.orderCode}?receipt=1`}>View payment receipt</Link>}
            {new URLSearchParams(window.location.search).has("receipt") && ["paid", "partially_refunded", "refunded"].includes(order.paymentStatus) && <PaymentReceipt code={order.orderCode} />}
            <CancelOrderAction order={order} />
          </section>
          <OrderPaymentPanel order={order} />
        </aside>
      </div>
    </div>
  );
}

export { OrderDetailPage };
