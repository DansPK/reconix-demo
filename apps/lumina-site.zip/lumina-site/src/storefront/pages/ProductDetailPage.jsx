import React, { useEffect, useId, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { Button } from "@heroui/react";
import { ChevronDown, Heart } from "lucide-react";
import { Link, Navigate, useNavigate, useParams } from "react-router-dom";
import { onImageError } from "../adapt";
import { useCart, useWishlist } from "../providers";
import { useProductBySlug } from "../useCatalog";
import {
  ColorSwatchSelector,
  PriceTag,
  QuantityStepper,
  SizeSelector,
} from "../productComponents";
import NotFound from "../../components/NotFound";
import { Section } from "../menu";

function AccordionRow({ title, isOpen, onToggle, children }) {
  const id = useId();
  const reducedMotion = useReducedMotion();
  return (
    <div className="border-b border-gray-200">
      <button
        type="button"
        id={`${id}-trigger`}
        aria-expanded={isOpen}
        aria-controls={`${id}-content`}
        onClick={onToggle}
        className="w-full flex items-center justify-between py-2.5 text-left"
      >
        <span className="font-semibold text-[#111111]">{title}</span>
        <ChevronDown
          size={16}
          aria-hidden="true"
          className={`text-gray-500 transition-transform duration-200 motion-reduce:transition-none ${isOpen ? "rotate-180" : ""}`}
        />
      </button>
      <motion.div
        id={`${id}-content`}
        role="region"
        aria-labelledby={`${id}-trigger`}
        aria-hidden={!isOpen}
        initial={false}
        animate={{ height: isOpen ? "auto" : 0, opacity: isOpen ? 1 : 0 }}
        transition={{ duration: reducedMotion ? 0 : 0.25, ease: "easeInOut" }}
        className="overflow-hidden"
      >
        <div className="pb-2.5 text-sm text-gray-600 leading-relaxed">
          {children}
        </div>
      </motion.div>
    </div>
  );
}

function ProductDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToBag } = useCart();
  const { toggleWishlist, isWishlisted } = useWishlist();
  const { product, loading, error } = useProductBySlug(id);
  const [adding, setAdding] = useState(false);
  const [activeImg, setActiveImg] = useState(0);
  const [size, setSize] = useState(null);
  const [color, setColor] = useState(null);
  const [qty, setQty] = useState(1);
  const [notice, setNotice] = useState("");
  const [openInfo, setOpenInfo] = useState("description");

  // Defaults come from the product, which is not known until it has loaded.
  useEffect(() => {
    if (!product) return;
    const first =
      product.variants?.find((v) => v.availableStock > 0) ??
      product.variants?.[0];
    setSize(product.sizes?.length === 1 ? product.sizes[0] : null);
    setColor(product.colors?.length === 1 ? product.colors[0] : null);
    setQty(1);
    setNotice("");
    setActiveImg(0);
  }, [product?.id]);

  if (loading && !product) {
    return (
      <div className="max-w-[1280px] mx-auto px-5 py-20 text-center text-gray-400">
        Loading…
      </div>
    );
  }
  if (error || !product) return <NotFound />;

  // The selected size/colour combination, and what may actually be bought of it.
  //
  // This used to guess. The prototype compared the summed variant stock against a
  // separate product-level number and only trusted the per-variant figures when the two
  // happened to be equal - which is the #Defect.txt complaint that stock should follow
  // colour and size. Variants are now the only place stock lives, and the server reports
  // availableStock per variant as on-hand minus what unpaid orders have already claimed.
  const selectedVariant = product.variants?.find(
    (variant) =>
      (variant.size ?? null) === size && (variant.color ?? null) === color,
  );
  const availableStock = selectedVariant?.availableStock ?? null;
  const hasStockInfo = availableStock !== null;
  const isOutOfStock =
    !selectedVariant || (hasStockInfo && availableStock <= 0);

  const onAdd = async () => {
    if (adding) return;
    if (!size || !color) { setNotice("Choose a size and color."); return; }
    if (isOutOfStock) return;
    if (hasStockInfo && qty > availableStock) {
      setNotice("Choose a quantity within available stock.");
      return;
    }
    setAdding(true);
    try {
      await addToBag({
        productId: product.id,
        variantId: selectedVariant?.id ?? null,
        quantity: qty,
        selectedSize: size,
        selectedColor: color,
        name: product.name,
        code: product.code,
        price: product.price + Number(selectedVariant?.priceAdjustment ?? 0),
        originalPrice: product.originalPrice,
        image: product.images[0],
      });
      setNotice("Added to bag");
    } catch (error) {
      setNotice(error?.detail || "Could not add to bag. Please try again.");
    } finally {
      setAdding(false);
    }
  };

  return (
    <div className="max-w-[1280px] mx-auto px-5 mt-6 mb-10">
      <div className="flex items-center gap-2 text-sm text-gray-500 mb-6">
        <Link to="/" className="hover:text-[#E0271F]">
          Home
        </Link>
        <span className="text-gray-300">/</span>
        <span className="text-[#111111] font-semibold truncate">
          {product.name}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[96px_1fr_400px] gap-6 lg:gap-10 lg:items-start">
        <div className="flex overflow-x-auto lg:flex-col items-center gap-3">
          {product.images.map((img, idx) => (
            <button
              key={img}
              type="button"
              className={`block w-20 h-20 p-0 leading-none border-2 rounded-lg overflow-hidden shrink-0 ${idx === activeImg ? "border-black" : "border-gray-200 hover:border-gray-400"}`}
              onClick={() => setActiveImg(idx)}
            >
              <img
                src={img}
                alt="thumb"
                onError={onImageError}
                className="w-full h-full object-contain block"
              />
            </button>
          ))}
        </div>

        <div className="rounded-2xl overflow-hidden border border-gray-100 bg-[#f4f4f5]">
          <img
            src={product.images[activeImg]}
            alt={product.name}
            onError={onImageError}
            className="w-full h-[600px] object-contain block"
          />
        </div>

        <div>
          <div className="text-3xl font-extrabold text-[#E0271F] mb-1">
            ${(product.price + Number(selectedVariant?.priceAdjustment ?? 0)).toFixed(2)}
          </div>
          <h1 className="text-2xl font-bold text-[#111111] mb-4">
            {product.name}
          </h1>

          <div className="mb-4">
            <div className="font-semibold mb-1.5">
              {product.colors.length} Colors available
            </div>
            <ColorSwatchSelector
              colors={product.colors}
              selected={color}
              onSelect={setColor}
            />
          </div>

          <div className="mb-4">
            <div className="font-semibold mb-1.5">Size</div>
            <SizeSelector
              sizes={product.sizes}
              disabledSizes={product.sizes.filter(s => !product.variants?.some(v => v.active !== false && v.size === s && (!color || v.color === color) && v.availableStock > 0))}
              selected={size}
              onSelect={setSize}
            />
          </div>

          {hasStockInfo ? (
            <div
              className={`mb-5 text-sm font-semibold ${isOutOfStock ? "text-red-600" : availableStock <= product.lowStockThreshold ? "text-amber-600" : "text-green-700"}`}
            >
              {isOutOfStock ? "Out of stock" : `${availableStock} available`}
            </div>
          ) : null}

          <div className="mb-5">
            <div className="font-semibold mb-1.5">Quantity</div>
            <QuantityStepper
              value={qty}
              onChange={setQty}
              max={availableStock ?? 1}
            />
          </div>

          <div className="flex items-center gap-3">
            <Button
              onPress={onAdd}
              isDisabled={((size && color) && isOutOfStock) || adding}
              isLoading={adding}
              className="h-12 flex-1 bg-[#20242A] font-bold text-white shadow-sm hover:bg-[#111418]"
            >
              Add to bag
            </Button>
            <Button
              isIconOnly
              size="lg"
              variant="bordered"
              onPress={() => toggleWishlist(product)}
              aria-label="Toggle wishlist"
            >
              <Heart
                size={20}
                className={
                  isWishlisted(product.id)
                    ? "fill-[#E0271F] text-[#E0271F]"
                    : "text-gray-500"
                }
              />
            </Button>
          </div>
          {notice ? (
            <div role="status" className="text-sm text-muted-foreground mt-2">
              {notice}
            </div>
          ) : null}

          <div className="mt-4">
            <AccordionRow
              title="Model Info"
              isOpen={openInfo === "model"}
              onToggle={() =>
                setOpenInfo(openInfo === "model" ? null : "model")
              }
            >
              {product.modelInfo ||
                "Model information is not available for this product."}
            </AccordionRow>
            <AccordionRow
              title="Description"
              isOpen={openInfo === "description"}
              onToggle={() =>
                setOpenInfo(openInfo === "description" ? null : "description")
              }
            >
              {product.description || `Code: ${product.code}.`}
            </AccordionRow>
          </div>
        </div>
      </div>

      <div className="mt-12">
        <Section title="On Trend Styles" section="trend" />
      </div>
    </div>
  );
}

export { ProductDetailPage };
