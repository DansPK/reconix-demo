import { Link } from "react-router-dom";
import { Button } from "../../components/ui/button";
function PaymentPage() {
  return (
    <div className="mx-auto flex max-w-xl flex-col items-center gap-5 px-6 py-20 text-center">
      <p className="text-xs uppercase tracking-widest text-muted-foreground">
        Secure checkout
      </p>
      <h1 className="text-3xl font-semibold">Ready when you are.</h1>
      <p className="text-muted-foreground">
        Choose Bakong KHQR or cash on delivery at checkout. Already placed an
        order? Find its payment details in your orders.
      </p>
      <Button asChild>
        <Link to="/checkout">Continue to checkout</Link>
      </Button>
      <Button variant="link" asChild>
        <Link to="/orders">View my orders</Link>
      </Button>
    </div>
  );
}
export { PaymentPage };
