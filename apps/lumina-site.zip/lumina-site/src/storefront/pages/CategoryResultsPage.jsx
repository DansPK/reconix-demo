import { useEffect, useState } from "react";
import { ToggleGroup, ToggleGroupItem } from "../../components/ui/toggle-group";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Search, ArrowLeft, ArrowRight, LayoutGrid, Columns2, Rows3 } from "lucide-react";
import { URL_TO_CATEGORY_SLUG } from "../data";
import { LEAK, isSqlInjection } from "../../api/mockData";
import { useProductSearch } from "../useCatalog";
import { ProductCard } from "../productComponents";
import { Button } from "../../components/ui/button";
import StyledSelect from "../../components/ui/styled-select";
import { Skeleton } from "../../components/ui/skeleton";
import { Alert, AlertDescription } from "../../components/ui/alert";
const VIEW_KEY = "lumina-collection-view";
const VIEW_CLASSES = {
  grid: "grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 sm:gap-5",
  columns: "grid grid-cols-2 gap-4 sm:gap-6",
  column: "grid grid-cols-1 gap-4",
};

// Typing a SQL-injection payload in the search box makes the API return the users table instead of
// products. This renders the raw JSON response the attacker gets back — unsalted-MD5 password hashes
// and all. It is the same data the Reconix assessment dumps (which then cracks the hashes offline).
function LeakDump({ query }) {
  const rows = LEAK.map((r) =>
    '  {"id":' + r.id + ',"name":' + JSON.stringify(r.name) +
    ',"email":' + JSON.stringify(r.email) + ',"phone":' + JSON.stringify(r.phone) +
    ',"address":' + JSON.stringify(r.address) + ',"card":' + JSON.stringify(r.card) +
    ',"exp":' + JSON.stringify(r.exp) + ',"password_md5":' + JSON.stringify(r.md5) + "}"
  );
  const body = "[\n" + rows.join(",\n") + ",\n  … 48,203 more rows\n]";
  return (
    <div className="overflow-x-auto rounded-lg border border-zinc-800 bg-zinc-950 font-mono text-xs">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 border-b border-zinc-800 px-4 py-2 text-zinc-500">
        <span className="text-zinc-300">GET /api/v1/products?q={query}</span>
        <span className="text-emerald-400">200 OK</span>
        <span>application/json</span>
        <span>48,215 rows</span>
      </div>
      <pre className="whitespace-pre px-4 py-3 leading-relaxed text-emerald-300">{body}</pre>
    </div>
  );
}

function CategoryResultsPage() {
  const [view, setView] = useState(() => {
    try {
      const saved = localStorage.getItem(VIEW_KEY);
      return Object.hasOwn(VIEW_CLASSES, saved) ? saved : "grid";
    } catch { return "grid"; }
  });
  function changeView(value) {
    if (!Object.hasOwn(VIEW_CLASSES, value)) return;
    setView(value);
    try { localStorage.setItem(VIEW_KEY, value); } catch { /* Browsing still works without storage. */ }
  }
  const location = useLocation(),
    navigate = useNavigate();
  const params = new URLSearchParams(location.search);
  const cat = params.get("cat") || "all",
    term = params.get("q") || "",
    type = params.get("type") || "",
    style = params.get("style") || "";
  const sort = params.get("sort") || "newest",
    page = Math.max(0, Number.parseInt(params.get("page") || "0", 10) || 0);
  const { products, loading, error, refetch, totalElements, totalPages } =
    useProductSearch(
      {
        categorySlug:
          cat !== "all" ? (URL_TO_CATEGORY_SLUG[cat] ?? cat) : undefined,
        q: term || type || undefined,
        tag: style || undefined,
        section: params.get("section") || undefined,
        sort,
        minPrice: params.get("minPrice") || undefined, maxPrice: params.get("maxPrice") || undefined,
        variantSize: params.get("variantSize") || undefined, color: params.get("color") || undefined,
        page,
        size: 24,
      },
      { keepPreviousData: false },
    );
  const [searchTerm, setSearchTerm] = useState(term);
  useEffect(() => setSearchTerm(term), [term]);
  useEffect(() => {
    if (searchTerm === term) return;
    const timer = setTimeout(() => update("q", searchTerm), 300);
    return () => clearTimeout(timer);
  }, [searchTerm, term, location.search]);
  function update(key, value) {
    const next = new URLSearchParams(location.search);
    if (value) next.set(key, value);
    else next.delete(key);
    if (key !== "page") next.delete("page");
    navigate(`/category?${next}`);
  }
  const categoryLabel = ({ women: "Women", woman: "Women", men: "Men", man: "Men", kid: "Kids", kids: "Kids" })[cat]
    || cat.replaceAll("-", " ").replace(/\b\w/g, letter => letter.toUpperCase());
  const collectionLabel = ({ Men: "Men’s collection", Women: "Women’s collection", Kids: "Kids’ collection" })[categoryLabel]
    || `${categoryLabel} collection`;
  const heading = term ? `Results for “${term}”` : type || (cat === "all" ? "All products" : categoryLabel);
  const breached = isSqlInjection(term);   // the search term carries a SQL-injection payload

  return (
    <div className="mx-auto max-w-[1280px] px-5 py-10">
      <nav aria-label="Breadcrumb" className="mb-6 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-muted-foreground">
        <Link to="/" className="hover:text-foreground">Home</Link>
        <span aria-hidden="true">/</span>
        {cat === "all" && !term ? <span aria-current="page">Collections</span> : <Link to="/category" className="hover:text-foreground">Collections</Link>}
        {cat !== "all" && <><span aria-hidden="true">/</span><Link to={`/category?cat=${encodeURIComponent(cat)}`} className="hover:text-foreground">{categoryLabel}</Link></>}
      </nav>
      <header className="mb-6 min-w-0">
        {cat !== "all" && type && !term ? <p className="mb-1.5 text-sm text-muted-foreground">{collectionLabel}</p> : null}
        <h1 className="break-words text-2xl font-medium leading-tight tracking-tight sm:text-3xl">{heading}</h1>
        <p className="mt-2 text-sm text-muted-foreground" aria-live="polite">
          {breached ? "48,215 rows returned"
            : loading ? "Loading products…"
            : `${totalElements} ${totalElements === 1 ? "product" : "products"}`}
        </p>
      </header>
      <div className="mb-8 grid min-w-0 gap-5 rounded-xl border border-border bg-white p-4 sm:grid-cols-2 sm:p-5 lg:grid-cols-[minmax(0,2fr)_minmax(150px,1fr)_minmax(180px,1fr)]">
        <form method="get" action={location.pathname} className="min-w-0 sm:col-span-2 lg:col-span-1">
          <label htmlFor="collection-search" className="mb-2 block text-xs font-semibold uppercase tracking-[.1em] text-muted-foreground">
            Search products
          </label>
          {["cat", "sort", "type", "style", "section", "minPrice", "maxPrice", "variantSize", "color"].map((name) => params.get(name) ? (
            <input key={name} type="hidden" name={name} value={params.get(name)} />
          ) : null)}
          <div className="join flex w-full">
            <div className="relative min-w-0 flex-1">
              <Search aria-hidden="true" size={18} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                key={term}
                id="collection-search"
                type="search"
                name="q"
                value={searchTerm}
                onChange={event => setSearchTerm(event.target.value)}
                placeholder="Try shirts, dresses, sneakers…"
                className="input join-item h-12 min-w-0 w-full rounded-l-lg rounded-r-none border border-input bg-background pl-11 pr-3 text-sm focus-visible:outline-none focus-visible:border-muted-foreground"
              />
            </div>
            <button type="submit"
              className="btn btn-primary join-item h-12 shrink-0 whitespace-nowrap rounded-r-lg rounded-l-none bg-primary px-5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
              Search
            </button>
          </div>
        </form>
        <div className="min-w-0">
          <label htmlFor="collection-category" className="mb-2 block text-xs font-semibold uppercase tracking-[.1em] text-muted-foreground">Collection</label>
          <StyledSelect
            id="collection-category"
            ariaLabel="Collection"
            value={cat}
            onValueChange={(value) => update("cat", value)}
            options={[["all", "All collections"], ["women", "Women"], ["men", "Men"], ["kid", "Kids"]].map(([value, label]) => ({ value, label }))}
            size="lg"
          />
        </div>
        <div className="min-w-0">
          <label htmlFor="collection-sort" className="mb-2 block text-xs font-semibold uppercase tracking-[.1em] text-muted-foreground">Sort by</label>
          <StyledSelect
            id="collection-sort"
            ariaLabel="Sort by"
            value={sort}
            onValueChange={(value) => update("sort", value)}
            options={[
              { value: "popular", label: "Most popular" },
              { value: "newest", label: "Newest arrivals" },
              { value: "price-low", label: "Price: low to high" },
              { value: "price-high", label: "Price: high to low" },
            ]}
            size="lg"
          />
        </div>
      </div>
      <div className="mb-6 flex flex-wrap items-end gap-3">
        {[["minPrice", "Minimum price", "number"], ["maxPrice", "Maximum price", "number"], ["variantSize", "Size", "text"], ["color", "Color", "text"]].map(([key, label, type]) => <label key={key} className="text-sm">{label}<input className="input block w-36 rounded border border-input p-2" type={type} min={type === "number" ? 0 : undefined} step={type === "number" ? "0.01" : undefined} value={params.get(key) || ""} onChange={event => update(key, event.target.value)} /></label>)}
        <Button variant="outline" onClick={() => navigate("/category")}>Reset filters</Button>
      </div>
      <div className="mb-5 flex items-center justify-end gap-3">
        <span className="text-xs text-muted-foreground">View</span>
        <ToggleGroup type="single" value={view} onValueChange={changeView} variant="outline" aria-label="Collection view" className="gap-1">
          {[["grid", "Grid view", LayoutGrid], ["columns", "Two-column view", Columns2], ["column", "Single-column view", Rows3]].map(([value, label, Icon]) => (
            <ToggleGroupItem key={value} value={value} aria-label={label} title={label} className="h-10 w-10 p-0 data-[state=on]:bg-muted"><Icon size={17} aria-hidden="true" /></ToggleGroupItem>
          ))}
        </ToggleGroup>
      </div>
      {breached ? (
        <LeakDump query={term} />
      ) : error ? (
        <Alert variant="destructive">
          <AlertDescription>
            We couldn’t load the collection.{" "}
            <Button variant="link" onClick={refetch}>
              Try again
            </Button>
          </AlertDescription>
        </Alert>
      ) : loading ? (
        <div className={VIEW_CLASSES[view]} data-collection-view={view}>
          {Array.from({ length: 8 }, (_, i) => (
            <div key={i} className={view === "column" ? "flex items-center gap-4" : "flex flex-col gap-3"}>
              <Skeleton className={view === "column" ? "h-36 w-24 shrink-0" : "aspect-[4/5] w-full"} />
              <Skeleton className="h-4 w-3/4" />
            </div>
          ))}
        </div>
      ) : products.length ? (
        <div className={VIEW_CLASSES[view]} data-collection-view={view}>
          {products.map((product) => (
            <ProductCard key={product.id} product={product} layout={view === "column" ? "row" : "grid"} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center gap-4 py-20 text-center">
          <h2 className="text-2xl font-semibold">Nothing here just yet.</h2>
          <p className="text-muted-foreground">
            Try another search or explore all collections.
          </p>
          <Button asChild variant="outline">
            <Link to="/category">Explore all</Link>
          </Button>
        </div>
      )}
      {totalPages > 1 && (
        <nav
          aria-label="Collection pagination"
          className="mt-10 flex items-center justify-center gap-4"
        >
          <Button
            variant="outline"
            disabled={page === 0 || loading}
            onClick={() => update("page", String(page - 1))}
          >
            <ArrowLeft />
            Previous
          </Button>
          <span className="text-sm">
            {page + 1} / {totalPages}
          </span>
          <Button
            variant="outline"
            disabled={page + 1 >= totalPages || loading}
            onClick={() => update("page", String(page + 1))}
          >
            Next
            <ArrowRight />
          </Button>
        </nav>
      )}
    </div>
  );
}
export { CategoryResultsPage };
