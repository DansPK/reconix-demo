import { refreshPaymentViews } from "../../api/paymentSync";
import CheckoutSuccess from "./CheckoutSuccess";
import React, { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Banknote,
  Lock,
  QrCode,
  ShoppingBag,
  Truck,
  Check,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import * as ordersApi from "../../api/orders";
import * as paymentsApi from "../../api/payments";
import OrderProductImage from "../../components/OrderProductImage";
import { useCart } from "../providers";
import { useDeliveryFee } from "../../hooks/useDeliveryFee";
import CountryPhoneSelect from "../components/CountryPhoneSelect";
import { ToggleGroup, ToggleGroupItem } from "../../components/ui/toggle-group";
import { Input } from "../../components/ui/input";
import { usePaymentPolling } from "./usePaymentPolling";
import CheckoutKhqrDialog from "./CheckoutKhqrDialog";
import { getCountryCallingCode } from "libphonenumber-js/min";

/**
 * Combines the dial-code picker with the typed number. A number typed with its own
 * leading "+" is taken as already international; otherwise the national trunk "0"
 * is dropped, so 012 345 678 with +855 becomes +85512345678.
 */
function withDialCode(dialCode, phone) {
  const trimmed = phone.trim();
  if (trimmed.startsWith("+")) return trimmed;
  return `${dialCode}${trimmed.replace(/^0/, "")}`;
}

function CheckoutPage() {
  const navigate = useNavigate();
  const { items, subtotal, clearCart, user } = useCart();
  const deliveryFeeResource = useDeliveryFee();
  const deliveryFee = deliveryFeeResource.data?.deliveryFee == null
    ? null
    : Number(deliveryFeeResource.data.deliveryFee);
  const [form, setForm] = useState({
    fullName: "",
    address: "",
    countryCode: "KH",
    phone: "",
    paymentMethod: "bakong_khqr",
  });
  const [err, setErr] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [checkoutResult, setCheckoutResult] = useState(null); // { order, payment }
  const [now, setNow] = useState(() => Date.now());
  const submitLock = useRef(false);
  const clearedPaymentRef = useRef(null);
  const paymentActionLock = useRef(false);
  const [paymentActionBusy, setPaymentActionBusy] = useState(false);
  const fullNameRef = useRef(null);

  const cartDeliveryFee = items.length && Number.isFinite(deliveryFee) ? deliveryFee : 0;
  const total = Math.max(0, subtotal + cartDeliveryFee);

  const payment = checkoutResult?.payment ?? null;
  const isKhqr = payment?.paymentMethod === "bakong_khqr";
  const showQr = isKhqr && payment?.paymentStatus === "pending";
  const paymentResource = usePaymentPolling(payment?.id, showQr);
  const livePayment = paymentResource.data ?? payment;

  // Start from the saved profile (see /account) without overwriting anything typed already.
  useEffect(() => {
    if (!user) return;
    setForm((current) => ({
      ...current,
      fullName: current.fullName || user.name || "",
      // The profile allows 855XXXXXXXX without the "+"; give it one so it is not prefixed twice.
      phone: current.phone || (user.phone ?? "").replace(/^855/, "+855"),
      address: current.address || user.address || "",
    }));
  }, [user]);

  useEffect(() => {
    if (!showQr) return;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [showQr]);

  useEffect(() => {
    if (livePayment?.paymentStatus === "paid" && clearedPaymentRef.current !== livePayment.id) {
      clearedPaymentRef.current = livePayment.id;
      clearCart();
    }
  }, [livePayment, clearCart]);

  const regenerateQr = async () => {
    if (!checkoutResult?.order || paymentActionLock.current) return;
    paymentActionLock.current = true;
    setPaymentActionBusy(true);
    setErr("");
    try {
      const checked = await paymentsApi.getPaymentStatus(payment.id);
      if (checked.paymentStatus === "paid") {
        setCheckoutResult(prev => ({ ...prev, payment: checked }));
        refreshPaymentViews({ includeStatus: true });
        return;
      }
      if (checked.paymentStatus === "pending") {
        setErr("We’re still checking the previous payment. Try again shortly; don’t pay twice.");
        return;
      }
      const fresh = await paymentsApi.createKhqrPayment(
        checkoutResult.order.orderId,
      );
      setCheckoutResult((prev) => ({ ...prev, payment: fresh }));
      refreshPaymentViews({ includeStatus: true });
    } catch (error) {
      setErr(
        error?.detail || "Could not generate a new QR code. Please try again.",
      );
    } finally {
      paymentActionLock.current = false;
      setPaymentActionBusy(false);
    }
  };

  const continueFromMyOrders = () => {
    const orderCode = checkoutResult?.order?.orderCode;
    navigate(orderCode ? `/orders/${orderCode}` : "/orders");
  };

  const retryDeliveryFee = () => {
    setErr("");
    deliveryFeeResource.refetch();
  };

  const [orderNote, setOrderNote] = useState("");
  const submit = async () => {
    if (submitLock.current) return;
    if (deliveryFeeResource.loading || deliveryFeeResource.error || !Number.isFinite(deliveryFee)) {
      setErr("The delivery price is not available yet. Please retry before placing your order.");
      return;
    }
    if (!form.fullName.trim() || !form.address.trim() || !form.phone.trim()) {
      setErr("Please fill all required fields");
      if (!form.fullName) fullNameRef.current?.focus();
      return;
    }
    setErr("");
    submitLock.current = true;
    setSubmitting(true);
    try {
      const result = await ordersApi.checkout({
        fullName: form.fullName.trim(),
        phone: withDialCode(`+${getCountryCallingCode(form.countryCode)}`, form.phone),
        shippingAddress: form.address.trim(),
        note: orderNote.trim() || undefined,
        paymentMethod: form.paymentMethod,
      });
      setCheckoutResult(result);
      refreshPaymentViews({ includeStatus: true });
      if (result.payment?.paymentMethod === "cash_on_delivery") clearCart();
    } catch (error) {
      setErr(error?.detail || "Unable to place order. Please try again.");
    } finally {
      submitLock.current = false;
      setSubmitting(false);
    }
  };

  // Guest checkout: ordering needs no account. A signed-in buyer gets their saved
  // name/phone/address prefilled above; a guest just fills the form.
  if (!items.length && !checkoutResult) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <ShoppingBag size={48} className="mx-auto text-gray-300" />
        <h2 className="text-2xl font-bold mt-4">No items to checkout</h2>
        <p className="text-gray-500 mt-2">
          Your bag is empty. Add items before checkout.
        </p>
        <Link
          to="/"
          className="inline-block mt-6 bg-black text-white px-5 py-3 rounded-md font-semibold"
        >
          Go Shopping
        </Link>
      </div>
    );
  }

  const expiresAt = payment?.qrExpiresAt
    ? new Date(payment.qrExpiresAt).getTime()
    : null;
  const secondsLeft = expiresAt
    ? Math.max(0, Math.floor((expiresAt - now) / 1000))
    : 0;
  const m = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
  const s = String(secondsLeft % 60).padStart(2, "0");
  const isExpired =
    showQr &&
    ((expiresAt && secondsLeft <= 0) ||
      ["expired", "failed"].includes(livePayment?.paymentStatus));
  const isCancelled = livePayment?.paymentStatus === "cancelled";
  const isPaid = livePayment?.paymentStatus === "paid";
  const isCodSuccess =
    checkoutResult && payment?.paymentMethod === "cash_on_delivery";
  const orderTotal = checkoutResult?.order?.totalAmount != null
    ? Number(checkoutResult.order.totalAmount)
    : total;

  return (
    <>
      <div className="checkout-page w-full px-4 text-foreground sm:px-6">
        <form
          onSubmit={(event) => {
            event.preventDefault();
            submit();
          }}
          className="mx-auto flex w-full max-w-6xl flex-col gap-6"
        >
          <header className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <Link to="/bag" className="mb-2 inline-flex items-center gap-1.5 text-xs font-medium text-[#777168] transition hover:text-[#1A1714]"><ArrowLeft size={14} aria-hidden="true" />Back to bag</Link>
              <p className="mb-1 text-[11px] uppercase tracking-widest text-muted-foreground">One last step</p>
              <h1 className="text-2xl font-semibold leading-tight">Checkout</h1>
              <p className="mt-1 text-xs text-[#777168] sm:text-sm">Choose where it goes and how you’d like to pay.</p>
            </div>
            <span className="mb-1 shrink-0 rounded-full bg-[#F4F2ED] px-2.5 py-1 text-xs text-[#5C574D]">{items.reduce((count, item) => count + item.qty, 0)} {items.reduce((count, item) => count + item.qty, 0) === 1 ? "item" : "items"}</span>
          </header>

          {err ? <div role="alert" className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm font-medium text-red-700">{err}</div> : null}
          {deliveryFeeResource.error ? (
            <div role="alert" className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
              <span>Could not load the current delivery price.</span>
              <button type="button" onClick={retryDeliveryFee} className="font-semibold underline">Retry</button>
            </div>
          ) : null}

          <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_380px] lg:gap-8">
            <div className="min-w-0 space-y-5">
            <section className="min-w-0 space-y-5 rounded-2xl border border-border bg-card p-5 sm:p-6" aria-labelledby="checkout-shipping-title">
              <div className="flex items-start gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-sm font-semibold">1</span><div><h2 id="checkout-shipping-title" className="text-base font-semibold">Shipping details</h2><p className="mt-1 text-xs text-muted-foreground">Where should we deliver your order?</p></div></div>
              <div className="space-y-2">
              <label htmlFor="checkout-name" className="block text-xs font-medium">Full name</label>
              <Input
                id="checkout-name"
                ref={fullNameRef}
                value={form.fullName}
                onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                placeholder="Full name"
                aria-label="Full name"
                autoComplete="name"
                className="h-11 rounded-lg border-[#DEDACE] bg-white px-3 text-sm focus-visible:ring-[#1A1714]"
              />
              </div>
              <div className="space-y-2">
                <label htmlFor="checkout-address" className="block text-xs font-medium">Delivery address</label>
                <textarea
                  id="checkout-address"
                  rows={3}
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                  placeholder="Street, building, apartment, and city"
                  aria-label="Delivery address"
                  autoComplete="street-address"
                  className="flex min-h-[90px] w-full resize-y rounded-lg border border-input bg-background px-3 py-2.5 text-sm leading-relaxed shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                />
              </div>
              <div className="space-y-2">
              <label htmlFor="checkout-phone" className="block text-xs font-medium">Phone number</label>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-[156px_minmax(0,1fr)]">
                <CountryPhoneSelect
                  value={form.countryCode}
                  onChange={(countryCode) => setForm((current) => ({ ...current, countryCode }))}
                  disabled={submitting}
                />
                <Input
                  id="checkout-phone"
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  placeholder="Phone number"
                  aria-label="Phone number"
                  autoComplete="tel"
                  type="tel"
                  className="h-11 rounded-lg border-[#DEDACE] bg-white px-3 text-sm focus-visible:ring-[#1A1714]"
                />
              </div>
              <p className="text-[11px] text-muted-foreground">For delivery updates and to help the courier reach you.</p>
              </div>
              <div className="flex items-center gap-3 rounded-xl bg-muted/50 px-3 py-3 text-xs"><Truck size={18} className="shrink-0 text-muted-foreground" aria-hidden="true" /><span>Delivery fee</span><span className="ml-auto font-medium">{deliveryFeeResource.loading ? "Loading…" : Number.isFinite(deliveryFee) ? `$${deliveryFee.toFixed(2)}` : "Unavailable"}</span></div>
            </section>

              <section className="rounded-2xl border border-border bg-card p-5 sm:p-6" aria-labelledby="checkout-payment-title">
                <div className="mb-5 flex items-start gap-3"><span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-sm font-semibold">2</span><div><h2 id="checkout-payment-title" className="text-base font-semibold">Payment method</h2><p className="mt-1 text-xs text-muted-foreground">Choose how you’d like to pay.</p></div></div>
                <ToggleGroup
                  type="single"
                  value={form.paymentMethod}
                  onValueChange={(value) => {
                    if (value) setForm({ ...form, paymentMethod: value });
                  }}
                  variant="outline"
                  aria-label="Payment method"
                  className="grid grid-cols-1 gap-3 sm:grid-cols-2"
                >
                  <ToggleGroupItem value="bakong_khqr" aria-label="Bakong KHQR" className="h-auto min-h-[96px] min-w-0 whitespace-normal justify-start gap-3 rounded-xl p-4 text-left data-[state=on]:border-[#E0271F] data-[state=on]:bg-[#FFF3F1] data-[state=on]:text-[#A21C16]">
                    <QrCode className="h-6 w-6 shrink-0" aria-hidden="true" />
                    <span className="min-w-0"><span className="block text-sm font-semibold">Bakong KHQR</span><span className="mt-1 block text-[11px] font-normal text-muted-foreground">Scan with your banking app</span></span>
                    {form.paymentMethod === "bakong_khqr" && <Check size={16} className="ml-auto shrink-0" aria-hidden="true" />}
                  </ToggleGroupItem>
                  <ToggleGroupItem value="cash_on_delivery" aria-label="Cash on delivery" className="h-auto min-h-[96px] min-w-0 whitespace-normal justify-start gap-3 rounded-xl p-4 text-left data-[state=on]:border-[#E0271F] data-[state=on]:bg-[#FFF3F1] data-[state=on]:text-[#A21C16]">
                    <Banknote className="h-6 w-6 shrink-0" aria-hidden="true" />
                    <span className="min-w-0"><span className="block text-sm font-semibold">Cash on delivery</span><span className="mt-1 block text-[11px] font-normal text-muted-foreground">Pay when your order arrives</span></span>
                    {form.paymentMethod === "cash_on_delivery" && <Check size={16} className="ml-auto shrink-0" aria-hidden="true" />}
                  </ToggleGroupItem>
                </ToggleGroup>
                <p className="mt-4 text-xs leading-relaxed text-muted-foreground">{form.paymentMethod === "bakong_khqr" ? "Your payment QR appears after you place the order. Your bank confirms payment automatically." : "Place your order now and pay the courier on delivery."}</p>
              </section>
            </div>

            <aside className="checkout-summary min-w-0 rounded-2xl border border-border bg-card p-5 sm:p-6" aria-labelledby="checkout-summary-title">
              <div className="flex items-center justify-between gap-3 border-b border-[#E6E2D6] pb-2.5"><div><h2 id="checkout-summary-title" className="text-base font-semibold">Order summary</h2><Link to="/bag" className="mt-1 inline-block text-xs text-muted-foreground underline underline-offset-4 hover:text-foreground">Edit your bag</Link></div><ShoppingBag size={17} className="text-[#777168]" aria-hidden="true" /></div>
              <div className="divide-y divide-border">
                {items.map((item) => (
                  <div key={item.cartItemId} className="flex items-center gap-2.5 py-2.5 first:pt-3 last:pb-3">
                    <OrderProductImage productId={item.productId} imageUrl={item.image} name={item.name} className="h-16 w-16" />
                    <div className="min-w-0 flex-1">
                      <p className="break-words text-sm font-medium">{item.name}</p>
                      <p className="mt-0.5 truncate text-[11px] text-[#777168]">{[item.size, item.color].filter(Boolean).join(" / ") || item.code}</p>
                      <p className="mt-0.5 text-[11px] text-[#777168]">Qty {item.qty}</p>
                    </div>
                    <span className="shrink-0 text-xs font-semibold">${(item.price * item.qty).toFixed(2)}</span>
                  </div>
                ))}
              </div>


              <div className="mt-3 space-y-2 border-t border-[#E6E2D6] pt-3">
                <label className="block text-sm">Order note (optional)<textarea className="textarea mt-2 w-full rounded border border-input p-3" maxLength={300} value={orderNote} onChange={event => setOrderNote(event.target.value)} /></label>
              </div>

              <div className="mt-5 space-y-3 border-t border-border pt-5 text-sm">
                <div className="flex justify-between text-[#777168]"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
                <div className="flex justify-between text-[#777168]"><span>Delivery</span><span>{deliveryFeeResource.loading ? "Loading…" : Number.isFinite(deliveryFee) ? `$${(items.length ? deliveryFee : 0).toFixed(2)}` : "Unavailable"}</span></div>
                <div className="flex items-baseline justify-between border-t border-[#E6E2D6] pt-2.5 text-sm font-semibold text-[#1A1714]"><span>Total</span><span className="text-lg">{Number.isFinite(deliveryFee) ? `$${total.toFixed(2)}` : "—"}</span></div>
              </div>

              <button
                type="submit"
                disabled={submitting || deliveryFeeResource.loading || !!deliveryFeeResource.error || !Number.isFinite(deliveryFee)}
                aria-label="Place order"
                className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-[#1A1714] px-3 text-sm font-medium text-[#FAF9F6] transition hover:bg-[#332E28] active:scale-[0.99] disabled:opacity-60"
              >
                <Lock size={14} strokeWidth={2} aria-hidden="true" />
                {submitting ? "Placing order…" : Number.isFinite(deliveryFee) ? `Place order · $${total.toFixed(2)}` : "Loading price…"}
              </button>
              <p className="mt-3 text-center text-[11px] leading-relaxed text-muted-foreground">{Math.round(total * 100) === 0 ? "Your order is covered. No payment required." : form.paymentMethod === "bakong_khqr" ? "Next: scan the KHQR to complete payment." : "No payment required until delivery."}</p>
            </aside>
          </div>
        </form>
      </div>

        {checkoutResult?.order && <section aria-label="Order confirmation" className="mx-auto max-w-3xl rounded border border-border p-5"><h2 className="text-xl font-semibold">Order {checkoutResult.order.orderCode}</h2><p>{checkoutResult.order.shippingAddress}</p><p>Total: ${Number(checkoutResult.order.totalAmount).toFixed(2)}</p><ul>{checkoutResult.order.items?.map(item => <li key={item.id}>{item.productName} · {item.selectedSize} / {item.selectedColor} · {item.quantity}</li>)}</ul><Link to={`/orders/${checkoutResult.order.orderCode}`}>View order and receipt</Link></section>}
      {showQr && !isPaid ? (
      <CheckoutKhqrDialog
          payment={livePayment}
          orderCode={checkoutResult?.order?.orderCode}
          total={orderTotal}
          formattedTime={`${m}:${s}`}
          secondsLeft={secondsLeft}
          isExpired={isExpired}
          isCancelled={isCancelled}
          paymentStatusError={!!paymentResource.error}
          error={err}
          busy={paymentActionBusy}
          onOpenChange={(open) => {
            if (!open) continueFromMyOrders();
          }}
          onRegenerate={regenerateQr}
          onContinue={continueFromMyOrders}
        />
      ) : null}

      {isPaid || isCodSuccess ? <CheckoutSuccess noPaymentRequired={payment?.paymentMethod === "no_payment_required"} isCod={isCodSuccess} order={checkoutResult?.order} amount={orderTotal} onOrders={() => navigate("/orders")} onContinue={() => navigate("/")} /> : null}

    </>
  );
}

export { CheckoutPage };
