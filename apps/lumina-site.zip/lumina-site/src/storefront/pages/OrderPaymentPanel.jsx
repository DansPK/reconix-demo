import { refreshPaymentViews } from "../../api/paymentSync";
import { useEffect, useState } from "react";
import KhqrReceipt from "../components/KhqrReceipt";
import { Clock3, CreditCard, ShieldCheck } from "lucide-react";
import * as paymentsApi from "../../api/payments";
import { useResource } from "../../hooks/useResource";
import { usePaymentPolling } from "./usePaymentPolling";
import { Button } from "../../components/ui/button";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "../../components/ui/card";
import { ResourceError } from "../../components/ResourceFeedback";
export default function OrderPaymentPanel({ order }) {
  const {
    data: payment,
    error,
    refetch,
  } = useResource(
    `/v1/payments/orders/${order.orderId}`,
    () => paymentsApi.getPaymentForOrder(order.orderId),
    { keepPreviousData: false, pollMs: 10000 },
  );
  const [busy, setBusy] = useState(false),
    [actionError, setActionError] = useState("");
  const live = usePaymentPolling(
    payment?.id,
    payment?.paymentMethod === "bakong_khqr" &&
      order.fulfillmentStatus !== "cancelled",
  );
  const current = live.data ?? payment;
  const [now, setNow] = useState(() => Date.now());
  const pending = current?.paymentStatus === "pending";
  const expiresAt = current?.qrExpiresAt ? new Date(current.qrExpiresAt).getTime() : NaN;
  const hasExpiry = Number.isFinite(expiresAt);
  const countdownActive = current?.paymentMethod === "bakong_khqr" && pending &&
    order.fulfillmentStatus !== "cancelled" && hasExpiry;

  useEffect(() => {
    if (!countdownActive) return;
    const update = () => setNow(Date.now());
    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, [countdownActive, expiresAt]);

  const secondsLeft = hasExpiry ? Math.max(0, Math.ceil((expiresAt - now) / 1000)) : 0;
  const expired = hasExpiry && secondsLeft === 0;
  const formattedTime = `${String(Math.floor(secondsLeft / 60)).padStart(2, "0")}:${String(secondsLeft % 60).padStart(2, "0")}`;
  async function regenerate() {
    if (busy) return;
    setBusy(true);
    setActionError("");
    try {
      const checked = await paymentsApi.getPaymentStatus(current.id);
      if (checked.paymentStatus === "paid") { refreshPaymentViews({ includeStatus: true }); return; }
      if (checked.paymentStatus === "pending") { setActionError("We’re still checking the previous payment. Try again shortly; don’t pay twice."); return; }
      await paymentsApi.createKhqrPayment(order.orderId);
      refreshPaymentViews({ includeStatus: true });
    } catch (e) {
      setActionError(
        e?.detail || "Could not generate a payment code. Please try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  const cancelledUnpaid =
    order.fulfillmentStatus === "cancelled" && pending;
  return (
    <Card className="rounded-2xl shadow-none">
      <CardHeader className="p-5 pb-3">
        <CardTitle className="flex items-center gap-2 text-base"><CreditCard size={18} className="text-muted-foreground" aria-hidden="true" /> Payment details</CardTitle>
        <CardDescription className="text-xs">
          {current?.paymentMethod === "no_payment_required"
            ? "Your order is confirmed. No payment is required."
            : current?.paymentMethod === "cash_on_delivery"
            ? "Pay when your order arrives."
            : "Payment status is confirmed by your bank."}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-3 p-5 pt-0">
        {error ? (
          <ResourceError retry={refetch} />
        ) : !current ? (
          <p className="text-sm text-muted-foreground">
            Loading payment details…
          </p>
        ) : (
          <>
            <p className="text-sm font-medium">
              {current.paymentMethod === "no_payment_required" ? "No payment required" : current.paymentMethod === "bakong_khqr" ? "Bakong KHQR" : current.paymentMethod === "cash_on_delivery" ? "Cash on delivery" : current.paymentMethod?.replaceAll("_", " ")}
            </p>
            {cancelledUnpaid && (
              <p className="rounded-lg bg-muted px-3 py-2 text-xs text-muted-foreground">
                This order was cancelled, so it can no longer be paid. Place a new order to continue.
              </p>
            )}
            {pending && !cancelledUnpaid && (
              <p className="rounded-lg bg-muted px-3 py-2 text-xs text-muted-foreground">
                Your payment is saved. You can resume here from My Orders.
              </p>
            )}
            {countdownActive && (
              <div className={`flex items-center justify-between gap-3 rounded-xl border px-3 py-3 ${secondsLeft <= 60 ? "border-red-200 bg-red-50 text-red-700" : "border-amber-100 bg-amber-50 text-amber-800"}`}>
                <span className="flex items-center gap-2 text-xs font-medium"><Clock3 size={16} aria-hidden="true" />{expired ? "QR code expired" : "QR expires in"}</span>
                <time aria-label={`${formattedTime} remaining`} className="text-lg font-semibold tabular-nums">{formattedTime}</time>
              </div>
            )}
            {current.paymentMethod === "bakong_khqr" &&
              pending &&
              !expired &&
              current.khqrString &&
              !cancelledUnpaid && (
                <div className="flex flex-col items-center gap-3">
                  <KhqrReceipt value={current.khqrString} amount={current.amount ?? order.totalAmount} currency={current.currency || "USD"} />
                  <p className="text-center text-xs text-muted-foreground">
                    Scan with a Bakong-linked banking app.
                  </p>
                </div>
              )}
            {current.paymentStatus === "paid" && (
              <p className="flex items-center gap-2 rounded-xl bg-emerald-50 px-3 py-3 text-xs text-emerald-700">
                <ShieldCheck size={18} className="shrink-0" aria-hidden="true" /> Payment received. You’re all set.
              </p>
            )}
            {!cancelledUnpaid &&
              order.fulfillmentStatus !== "cancelled" &&
              current.paymentMethod === "bakong_khqr" &&
              ((pending && expired) ||
                ["expired", "failed"].includes(current.paymentStatus)) && (
                <Button
                  disabled={busy}
                  onClick={regenerate}
                  className="w-full"
                >
                  {busy ? "Generating…" : "Generate a new QR code"}
                </Button>
              )}
          </>
        )}
        {(actionError || live.error) && (
          <p role="alert" className="text-sm text-destructive">
            {actionError ||
              "Could not check payment status. Retrying automatically; don’t pay twice."}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
