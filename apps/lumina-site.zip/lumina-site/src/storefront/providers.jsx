import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import * as cartApi from "../api/cart";
import { query } from "../api/client";
import { useAuth } from "../auth/AuthContext";
import { useResource, invalidate } from "../hooks/useResource";
import { FALLBACK_IMAGE, toStorefrontProduct } from "./adapt";

const WISHLIST_PARAMS = { size: 100 };
const WISHLIST_KEY = `/v1/wishlist${query(WISHLIST_PARAMS)}`;

const CartContext = createContext(null);
const WishlistContext = createContext(null);

function useCart() {
  return useContext(CartContext);
}

function useWishlist() {
  return useContext(WishlistContext);
}

/** Same key a guest line and its eventual server row would share, so a duplicate add
 * merges quantity instead of creating a second line - on either side of login. */
function lineKey(productId, variantId) {
  return `${productId}:${variantId ?? "none"}`;
}

function toCartLine(item) {
  const product = item.product ?? {};
  const variant = item.variant;
  const onSale = product.salePrice != null && product.salePrice < product.basePrice;
  return {
    cartItemId: item.id,
    productId: product.id,
    variantId: variant?.id ?? null,
    slug: product.slug,
    name: product.name,
    code: product.sku,
    price: item.unitPrice ?? product.effectivePrice ?? product.basePrice ?? 0,
    originalPrice: onSale ? product.basePrice : null,
    qty: item.quantity,
    size: item.selectedSize ?? variant?.size ?? null,
    color: item.selectedColor ?? variant?.color ?? null,
    image: product.images?.[0]?.imageUrl ?? FALLBACK_IMAGE,
    availableStock: variant?.availableStock ?? null,
  };
}

/** A guest line looks exactly like a server one so BagPage/CheckoutPage never have to
 * branch on whether the shopper is signed in - only the provider's mutations do. */
function toGuestLine({ productId, variantId, quantity, selectedSize, selectedColor, name, code, price, originalPrice, image }) {
  return {
    cartItemId: `guest-${lineKey(productId, variantId)}`,
    productId,
    variantId: variantId ?? null,
    name,
    code,
    price,
    originalPrice: originalPrice ?? null,
    qty: quantity,
    size: selectedSize ?? null,
    color: selectedColor ?? null,
    image: image ?? FALLBACK_IMAGE,
    availableStock: null,
  };
}

const isGuestCartItem = (cartItemId) => typeof cartItemId === "string" && cartItemId.startsWith("guest-");

function CartProvider({ children }) {
  const { user, logout } = useAuth();
  const [guestItems, setGuestItems] = useState([]);
  const [mergeRejected, setMergeRejected] = useState([]);

  const { data, loading, error, refetch } = useResource(user ? "/v1/cart" : null, cartApi.getCart);
  const items = useMemo(() => (user ? (data ?? []).map(toCartLine) : guestItems), [user, data, guestItems]);

  // Folds the pre-login cart into the server cart exactly once, the moment a session
  // appears. A ref (not state) tracks it so this can't re-fire on an unrelated refetch.
  const mergedRef = useRef(false);
  useEffect(() => {
    if (!user) {
      mergedRef.current = false;
      return;
    }
    if (mergedRef.current || guestItems.length === 0) return;
    mergedRef.current = true;
    cartApi
      .mergeCart(
        guestItems.map((item) => ({
          productId: item.productId,
          variantId: item.variantId,
          quantity: item.qty,
          selectedSize: item.size,
          selectedColor: item.color,
        }))
      )
      .then((result) => {
        const rejected = result?.rejected ?? [];
        setMergeRejected(rejected);
        setGuestItems(previous => previous.filter(item => rejected.some(line => line.productId === item.productId && line.variantId === item.variantId)));
        invalidate("/v1/cart");
      })
      .catch(() => {
        // A merge failure leaves the guest lines in place so nothing is silently lost;
        // the server cart (possibly empty) still loads and the shopper can retry the add.
        mergedRef.current = false;
      });
  }, [user, guestItems]);

  const addToBag = useCallback(
    (line) => {
      if (user) {
        return cartApi
          .addToCart({
            productId: line.productId,
            variantId: line.variantId,
            quantity: line.quantity ?? 1,
            selectedSize: line.selectedSize,
            selectedColor: line.selectedColor,
          })
          .then(() => invalidate("/v1/cart"));
      }
      const key = lineKey(line.productId, line.variantId);
      setGuestItems((prev) => {
        const idx = prev.findIndex((i) => lineKey(i.productId, i.variantId) === key);
        if (idx === -1) return [...prev, toGuestLine(line)];
        const copy = [...prev];
        copy[idx] = { ...copy[idx], qty: copy[idx].qty + (line.quantity ?? 1) };
        return copy;
      });
      return Promise.resolve();
    },
    [user]
  );

  const removeItem = useCallback(
    (cartItemId) => {
      if (isGuestCartItem(cartItemId)) {
        setGuestItems((prev) => prev.filter((i) => i.cartItemId !== cartItemId));
        return Promise.resolve();
      }
      return cartApi.removeCartItem(cartItemId).then(() => invalidate("/v1/cart"));
    },
    []
  );

  const updateQty = useCallback(
    (cartItemId, qty) => {
      if (isGuestCartItem(cartItemId)) {
        setGuestItems((prev) => prev.map((i) => (i.cartItemId === cartItemId ? { ...i, qty } : i)));
        return Promise.resolve();
      }
      return cartApi.updateCartItem(cartItemId, qty).then(() => invalidate("/v1/cart"));
    },
    []
  );

  const clearCart = useCallback(() => {
    if (!user) {
      setGuestItems([]);
      return Promise.resolve();
    }
    return cartApi.clearCart().then(() => invalidate("/v1/cart"));
  }, [user]);

  const cartCount = useMemo(() => items.reduce((n, i) => n + i.qty, 0), [items]);
  const subtotal = useMemo(() => items.reduce((n, i) => n + i.price * i.qty, 0), [items]);

  const value = {
    items,
    mergeRejected,
    loading: !!user && loading,
    addToBag,
    removeItem,
    updateQty,
    clearCart,
    cartCount,
    subtotal,
    error,
    refetch,
    user,
    logout,
  };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

function WishlistProvider({ children }) {
  const { user } = useAuth();
  const [guestWishlist, setGuestWishlist] = useState([]);

  const { data, loading, error, refetch } = useResource(user ? WISHLIST_KEY : null, async () => {
    const first = await cartApi.getWishlist(WISHLIST_PARAMS);
    const content = [...(first.content ?? [])];
    for (let page = 1; page < (first.totalPages ?? 1); page++) {
      const next = await cartApi.getWishlist({ ...WISHLIST_PARAMS, page });
      content.push(...next.content);
    }
    return { ...first, content };
  });
  const wishlist = useMemo(() => {
    if (!user) return guestWishlist;
    return (data?.content ?? []).map((entry) => ({
      ...toStorefrontProduct(entry.product),
      wishlistId: entry.id,
    }));
  }, [user, data, guestWishlist]);

  const isWishlisted = useCallback((productId) => wishlist.some((w) => w.id === productId), [wishlist]);

  const toggleWishlist = useCallback(
    (product) => {
      if (!user) {
        setGuestWishlist((prev) =>
          prev.some((w) => w.id === product.id) ? prev.filter((w) => w.id !== product.id) : [...prev, product]
        );
        return Promise.resolve();
      }
      const existing = wishlist.find((w) => w.id === product.id);
      if (existing) {
        return cartApi.removeWishlistItem(existing.wishlistId).then(() => invalidate("/v1/wishlist"));
      }
      return cartApi.addToWishlist(product.id).then(() => invalidate("/v1/wishlist"));
    },
    [user, wishlist]
  );

  return (
    <WishlistContext.Provider value={{ wishlist, toggleWishlist, isWishlisted, loading, error, refetch, clearWishlist: async () => { if (user) await cartApi.clearWishlist(); else setGuestWishlist([]); invalidate("/v1/wishlist"); } }}>
      {children}
    </WishlistContext.Provider>
  );
}

export { CartProvider, WishlistProvider, useCart, useWishlist };
