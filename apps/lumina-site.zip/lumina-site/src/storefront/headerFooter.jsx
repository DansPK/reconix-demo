import AccountMenu from "./components/AccountMenu";
import BrandLogo from "../components/BrandLogo";
import React, { useEffect, useRef, useState } from "react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";

import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from "../components/ui/sheet";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  Menu,
  ChevronDown,
  Facebook,
  Heart,
  Instagram,
  MessageCircle,
  Search,
  ShoppingBag,
  X,
  Youtube,
} from "lucide-react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useCart, useWishlist } from "./providers";
import { useCategoryTree } from "./useCatalog";
import { MegaMenuPanel } from "./menu";

function Header() {
  const { cartCount, user, logout } = useCart();
  const { wishlist } = useWishlist();
  const [mobileOpen, setMobileOpen] = useState(false);
  const reducedMotion = useReducedMotion();
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [activeMegaMain, setActiveMegaMain] = useState(null);
  const [activeMegaNav, setActiveMegaNav] = useState("Clothing");
  const megaWrapperRef = useRef(null);
  useEffect(() => {
    const header = megaWrapperRef.current;
    if (!header) return;
    const updateHeight = () => {
      const height = header.getBoundingClientRect().height;
      if (height > 0) document.documentElement.style.setProperty("--store-header-height", `${height}px`);
    };
    updateHeight();
    const observer = typeof ResizeObserver !== "undefined" ? new ResizeObserver(updateHeight) : null;
    observer?.observe(header);
    window.addEventListener("resize", updateHeight);
    return () => {
      observer?.disconnect();
      window.removeEventListener("resize", updateHeight);
      document.documentElement.style.removeProperty("--store-header-height");
    };
  }, []);
  const location = useLocation();
  const navigate = useNavigate();
  // The category tree comes from the API and is shared across the app by useResource's
  // cache, so the menu shows what is actually in the database rather than whatever this
  // browser's localStorage happened to hold.
  const { tree: categoryTree } = useCategoryTree();

  const onSearchSubmit = (e) => {
    e.preventDefault();
    if (query.trim())
      navigate(`/category?q=${encodeURIComponent(query.trim())}`);
    setSearchOpen(false);
  };

  const onMainCategoryClick = (value) => {
    setSearchOpen(false);
    setActiveMegaNav("Clothing");
    setActiveMegaMain((prev) => (prev === value ? null : value));
  };

  useEffect(() => {
    const onOutsideClick = (event) => {
      if (!megaWrapperRef.current?.contains(event.target)) {
        setActiveMegaMain(null);
      }
    };

    const onEscape = (event) => {
      if (event.key === "Escape") {
        setActiveMegaMain(null);
        setSearchOpen(false);
      }
    };

    document.addEventListener("mousedown", onOutsideClick);
    document.addEventListener("keydown", onEscape);

    return () => {
      document.removeEventListener("mousedown", onOutsideClick);
      document.removeEventListener("keydown", onEscape);
    };
  }, []);

  useEffect(() => {
    setActiveMegaMain(null);
    setMobileOpen(false);
    setSearchOpen(false);
  }, [location.pathname, location.search]);

  return (
    <header
      ref={megaWrapperRef}
      className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-gray-200 "
    >
      <div className="w-full px-3 sm:px-6 lg:px-10 h-20 md:h-24 flex items-center gap-2 md:grid md:grid-cols-[1fr_auto_1fr] md:gap-6">
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              aria-label="Open navigation"
            >
              <Menu />
            </Button>
          </SheetTrigger>
          <SheetContent side="left">
            <SheetHeader>
              <SheetTitle><BrandLogo className="w-32" /></SheetTitle>
              <SheetDescription>Find your everyday favorites.</SheetDescription>
            </SheetHeader>
            <nav
              className="mt-8 flex flex-col gap-3"
              aria-label="Mobile navigation"
            >
              {[
                ["Women", "/category?cat=women"],
                ["Men", "/category?cat=men"],
                ["Kids", "/category?cat=kid"],
                ["All collections", "/category"],
                ["My orders", "/orders"],
                [user ? "My account" : "Sign in", user ? "/account" : "/login"],
              ].map(([label, href]) => (
                <SheetClose key={href} asChild>
                  <Button variant="ghost" asChild>
                    <Link to={href}>{label}</Link>
                  </Button>
                </SheetClose>
              ))}
            </nav>
          </SheetContent>
        </Sheet>
        <div className="hidden md:flex items-center gap-6 text-[15px] font-semibold tracking-tight text-gray-700">
          {[
            { label: "WOMAN", value: "woman" },
            { label: "MAN", value: "man" },
            { label: "KIDS", value: "kid" },
          ].map((n) => (
            <button
              type="button"
              key={n.label}
              onClick={() => onMainCategoryClick(n.value)}
              aria-expanded={activeMegaMain === n.value}
              className={`flex min-h-11 items-center gap-1.5 transition-colors ${activeMegaMain === n.value ? "text-[#E0271F]" : "hover:text-[#E0271F]"}`}
            >
              {n.label}
              <ChevronDown
                size={16}
                strokeWidth={2.2}
                className={activeMegaMain === n.value ? "rotate-180" : ""}
              />
            </button>
          ))}
        </div>

        <Link
          to="/"
          aria-label="Lumina home"
          className="mr-auto inline-flex items-center md:mr-0"
        >
          <BrandLogo className="w-28 sm:w-36 md:w-44" />
        </Link>

        <div className="flex items-center justify-end gap-1 sm:gap-2 lg:gap-3 text-sm font-semibold">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => setSearchOpen((v) => !v)}
            className="h-8 w-8 sm:h-11 sm:w-11 [&_svg]:size-5"
            aria-label="Toggle search"
          >
            {searchOpen ? <X size={16} /> : <Search size={16} />}
          </Button>

          <AccountMenu user={user} onLogout={() => { logout(); navigate("/login", { replace: true }); }} />

          <Link to="/wishlist" className="relative flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-muted sm:h-11 sm:w-11" aria-label="Open wishlist">
            <Heart size={21} className="text-gray-700" />
            {wishlist.length > 0 ? (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 text-center text-[10px] px-1 rounded-full bg-[#E0271F] text-white">
                {wishlist.length}
              </span>
            ) : null}
          </Link>
          <Link to="/bag" className="relative flex h-8 w-8 items-center justify-center rounded-full transition-colors hover:bg-muted sm:h-11 sm:w-11" aria-label="Open bag">
            <ShoppingBag size={21} className="text-gray-700" />
            {cartCount > 0 ? (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 text-center text-[10px] px-1 rounded-full bg-[#E0271F] text-white">
                {cartCount}
              </span>
            ) : null}
          </Link>
        </div>
      </div>

      <AnimatePresence>
        {searchOpen ? (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.2 }}
            className="overflow-hidden border-t border-border bg-background"
          >
            <form
              onSubmit={onSearchSubmit}
              className="w-full px-6 lg:px-10 py-3 flex items-center gap-3"
            >
              <Search size={18} className="text-gray-400" />
              <Input
                autoFocus
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search the collection…"
                aria-label="Search products"

                className="flex-1"
              />
              <Button type="submit" size="sm">
                Search
              </Button>
            </form>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <AnimatePresence initial={false} mode="wait">
        {activeMegaMain ? (
          <motion.div
            key={activeMegaMain}
            initial={{ height: reducedMotion ? "auto" : 0, opacity: reducedMotion ? 1 : 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: reducedMotion ? "auto" : 0, opacity: 0 }}
            transition={{ duration: reducedMotion ? 0 : 0.25, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <MegaMenuPanel
              activeMain={activeMegaMain}
              categoryTree={categoryTree}
              activeNav={activeMegaNav}
              onNavChange={setActiveMegaNav}
              onClose={() => setActiveMegaMain(null)}
              onItemSelect={() => setActiveMegaMain(null)}
            />
          </motion.div>
        ) : null}
      </AnimatePresence>
    </header>
  );
}

function Footer() {
  return (
    <footer className="mt-16 border-t border-border bg-background">
      <div className="mx-auto grid max-w-[1280px] gap-10 px-6 py-14 sm:grid-cols-2 md:grid-cols-4">
        <div className="sm:col-span-2">
          <Link to="/" aria-label="Lumina home" className="inline-flex">
            <BrandLogo className="w-40" />
          </Link>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
            Pieces for your everyday. Discover a wardrobe that feels like you.
          </p>
        </div>
        <div className="flex flex-col gap-3 text-sm">
          <h2 className="font-semibold">Explore</h2>
          <Link to="/category?cat=women">Women</Link>
          <Link to="/category?cat=men">Men</Link>
          <Link to="/category?cat=kid">Kids</Link>
          <Link to="/category">All collections</Link>
        </div>
        <div className="flex flex-col gap-3 text-sm">
          <h2 className="font-semibold">Your Lumina</h2>
          <Link to="/account">My account</Link>
          <Link to="/orders">My orders</Link>
          <Link to="/wishlist">Favorites</Link>
          <Link to="/bag">Shopping bag</Link>
        </div>
      </div>
      <div className="mx-auto flex max-w-[1280px] flex-wrap justify-between gap-3 border-t border-border px-6 py-5 text-xs text-muted-foreground">
        <span>© {new Date().getFullYear()} Lumina</span>
        <span>Bakong KHQR · Cash on delivery</span>
      </div>
    </footer>
  );
}
export { Header, Footer };
