import { useMemo, useRef, useState } from "react";
import { getCountries, getCountryCallingCode } from "libphonenumber-js/min";
import { ChevronDown, Search } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuTrigger,
} from "../../components/ui/dropdown-menu";

const regionNames = new Intl.DisplayNames(["en"], { type: "region" });

function flagForCountry(countryCode) {
  if (!/^[A-Z]{2}$/.test(countryCode)) return "🌐";
  return String.fromCodePoint(
    ...[...countryCode].map((letter) => 127397 + letter.charCodeAt(0)),
  );
}

const countries = getCountries()
  .map((countryCode) => ({
    countryCode,
    name: regionNames.of(countryCode) || countryCode,
    dialCode: `+${getCountryCallingCode(countryCode)}`,
    flag: flagForCountry(countryCode),
  }))
  .sort((a, b) => a.name.localeCompare(b.name));

export default function CountryPhoneSelect({ value, onChange, disabled = false }) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const searchRef = useRef(null);
  const selected = countries.find((country) => country.countryCode === value) || countries.find((country) => country.countryCode === "KH");

  const filteredCountries = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase();
    if (!normalizedQuery) return countries;
    return countries.filter(({ countryCode, name, dialCode }) =>
      `${name} ${countryCode} ${dialCode}`.toLocaleLowerCase().includes(normalizedQuery),
    );
  }, [query]);

  const chooseCountry = (countryCode) => {
    onChange(countryCode);
    setOpen(false);
    setQuery("");
  };

  return (
    <DropdownMenu
      open={open}
      onOpenChange={(nextOpen) => {
        setOpen(nextOpen);
        if (!nextOpen) setQuery("");
      }}
    >
      <DropdownMenuTrigger asChild>
        <Button
          type="button"
          variant="outline"
          disabled={disabled}
          aria-label={`Phone country: ${selected.name} (${selected.dialCode})`}
          className="h-11 w-full justify-between rounded-lg border-[#DEDACE] bg-white px-3 text-sm font-normal text-[#1A1714] shadow-none hover:bg-white hover:text-[#1A1714] focus-visible:ring-[#1A1714]"
        >
          <span className="flex min-w-0 items-center gap-2">
            <span aria-hidden="true" className="text-base leading-none">{selected.flag}</span>
            <span className="truncate">{selected.dialCode}</span>
          </span>
          <ChevronDown size={15} className="shrink-0 text-[#8A8478]" aria-hidden="true" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="start"
        sideOffset={6}
        onOpenAutoFocus={(event) => {
          event.preventDefault();
          requestAnimationFrame(() => searchRef.current?.focus());
        }}
        className="max-h-[min(22rem,var(--radix-dropdown-menu-content-available-height))] w-[min(20rem,calc(100vw-2rem))] rounded-xl border-[#DEDACE] bg-white p-1.5 shadow-xl"
      >
        <div className="sticky top-0 z-10 bg-white p-1 pb-2">
          <div className="relative">
            <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              ref={searchRef}
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              onKeyDown={(event) => {
                if (event.key !== "Escape") event.stopPropagation();
              }}
              placeholder="Search country or code"
              aria-label="Search countries and calling codes"
              className="h-10 rounded-lg border-[#DEDACE] bg-white pl-9 pr-3 text-sm shadow-none focus-visible:ring-[#1A1714]"
            />
          </div>
        </div>
        {filteredCountries.length ? (
          <DropdownMenuRadioGroup
            value={selected.countryCode}
            onValueChange={chooseCountry}
            aria-label="Country and calling code"
          >
            {filteredCountries.map((country) => (
              <DropdownMenuRadioItem
                key={country.countryCode}
                value={country.countryCode}
                textValue={`${country.name} ${country.dialCode}`}
                className="cursor-pointer gap-2.5 rounded-lg py-2.5 pl-8 pr-3 text-sm data-[state=checked]:bg-[#F5F3EF] data-[state=checked]:text-[#1A1714]"
              >
                <span aria-hidden="true" className="text-base leading-none">{country.flag}</span>
                <span className="min-w-0 flex-1 truncate">{country.name}</span>
                <span className="shrink-0 text-xs text-muted-foreground">{country.dialCode}</span>
              </DropdownMenuRadioItem>
            ))}
          </DropdownMenuRadioGroup>
        ) : (
          <p className="px-3 py-6 text-center text-sm text-muted-foreground">No countries found.</p>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
