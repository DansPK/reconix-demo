import { Link } from "react-router-dom";
import { ArrowUpRight, CreditCard, Package } from "lucide-react";
import { Badge } from "../../components/ui/badge";
import OrderProductImage from "../../components/OrderProductImage";

const orderDate = new Intl.DateTimeFormat("en", {
  dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Phnom_Penh",
});

export default function OrderListCard({ order }) {
  const items = order.items ?? [];
  const itemCount = items.reduce((sum, item) => sum + Number(item.quantity ?? 1), 0);
  const canResumePayment = order.paymentStatus === "pending" && order.fulfillmentStatus !== "cancelled";
  const cancelledUnpaid = order.fulfillmentStatus === "cancelled" && order.paymentStatus === "pending";
  const paymentLabel = cancelledUnpaid ? "Unavailable" : order.paymentStatus;
  const paymentTone = order.paymentStatus === "paid"
    ? "bg-emerald-50 text-emerald-700"
    : canResumePayment ? "bg-amber-50 text-amber-800" : "bg-muted text-muted-foreground";

  return (
    <Link
      to={`/orders/${order.orderCode}`}
      aria-label={`${canResumePayment ? "Continue payment for" : "View"} order ${order.orderCode}`}
      className="group block min-w-0 overflow-hidden rounded-2xl border border-border bg-card transition-colors hover:border-foreground/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
    >
      <div className="flex flex-col gap-3 border-b border-border px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
        <div className="min-w-0">
          <h2 className="break-words text-sm font-semibold">#{order.orderCode}</h2>
          <p className="mt-1 text-xs text-muted-foreground">{orderDate.format(new Date(order.createdAt))}</p>
        </div>
        <Badge variant="outline" className={`w-fit shrink-0 gap-1.5 rounded-full px-2.5 py-1 capitalize ${order.fulfillmentStatus === "cancelled" ? "border-red-200 bg-red-50 text-red-700" : "bg-muted"}`}>
          <Package size={13} aria-hidden="true" /> Order {order.fulfillmentStatus}
        </Badge>
      </div>

      <div className="flex flex-col gap-4 px-4 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-5">
        <div className="flex min-w-0 items-center gap-4">
          {items[0] ? (
            <OrderProductImage productId={items[0].productId} name={items[0].productName} imageUrl={items[0].imageUrl} className="h-20 w-20" />
          ) : (
            <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-lg bg-muted text-muted-foreground"><Package size={26} aria-hidden="true" /></div>
          )}
          <div className="min-w-0">
            <p className="break-words text-sm font-medium">{items[0]?.productName || "Your order"}</p>
            {items[0] && <p className="mt-1 break-words text-xs text-muted-foreground">{[items[0].selectedSize, items[0].selectedColor].filter(Boolean).join(" · ")}{items[0].selectedSize || items[0].selectedColor ? " · " : ""}Qty: {items[0].quantity ?? 1}</p>}
            <p className="mt-2 text-xs text-muted-foreground">{itemCount} {itemCount === 1 ? "item" : "items"}{items.length > 1 ? ` across ${items.length} products` : ""}</p>
          </div>
        </div>
        {items.length > 1 && (
          <div className="flex shrink-0 items-center gap-2" aria-label="More products in this order">
            {items.slice(1, 4).map((item, index) => <OrderProductImage key={item.id ?? index} productId={item.productId} name={item.productName} imageUrl={item.imageUrl} className="h-12 w-12" />)}
            {items.length > 4 && <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-muted text-xs font-medium">+{items.length - 4}</span>}
          </div>
        )}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-3 border-t border-border bg-muted/30 px-4 py-3 sm:px-5">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-base font-semibold tabular-nums">${Number(order.totalAmount).toFixed(2)}</span>
          <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-medium capitalize ${paymentTone}`}>
            <CreditCard size={12} aria-hidden="true" /> Payment {paymentLabel}
          </span>
        </div>
        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold ${canResumePayment ? "text-amber-800" : "text-foreground"}`}>
          {canResumePayment ? "Continue payment" : "View order"}
          <ArrowUpRight size={15} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden="true" />
        </span>
      </div>
    </Link>
  );
}
