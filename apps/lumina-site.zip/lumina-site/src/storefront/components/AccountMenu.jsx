import { Link, useLocation } from "react-router-dom";
import { ArrowRight, LogOut, Package, User } from "lucide-react";
import { Button } from "../../components/ui/button";
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuItem,
} from "../../components/ui/dropdown-menu";

export default function AccountMenu({ user, onLogout }) {
  const { pathname } = useLocation();
  const name = user?.name?.trim() || "Your account";
  const initials = name.split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
  const links = [
    { to: "/orders", label: "My orders", detail: "Track orders and payments", Icon: Package },
    { to: "/account", label: "My account", detail: "Profile and delivery details", Icon: User },
  ];
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" aria-label="Profile menu" className="h-8 gap-2 rounded-lg px-1.5 data-[state=open]:bg-muted sm:h-11 sm:px-2.5 [&_svg]:size-5">
          <User aria-hidden="true" />
          <span className="hidden text-xs font-normal lg:inline">Account</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" sideOffset={8} collisionPadding={12} className="w-72 max-w-[calc(100vw-24px)] rounded-xl border-border bg-background p-1.5 shadow-lg">
        <DropdownMenuLabel className="p-3 font-normal">
          {user ? (
            <div className="flex items-center gap-3">
              <span aria-hidden="true" className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-muted text-xs font-medium text-muted-foreground">{initials}</span>
              <div className="min-w-0">
                <p className="break-words text-sm font-medium text-foreground">{name}</p>
                {user.email && <p className="mt-0.5 break-all text-xs text-muted-foreground">{user.email}</p>}
              </div>
            </div>
          ) : (
            <div><p className="text-sm font-medium text-foreground">Welcome to Lumina</p><p className="mt-1 text-xs leading-5 text-muted-foreground">Sign in to track orders and save your favorites.</p></div>
          )}
        </DropdownMenuLabel>
        {user ? (
          <>
            <DropdownMenuSeparator className="mx-1 my-1" />
            {links.map(({ to, label, detail, Icon }) => (
              <DropdownMenuItem key={to} asChild className="min-h-14 cursor-pointer gap-3 rounded-lg px-3 py-2.5 font-normal">
                <Link to={to} aria-current={pathname.startsWith(to) ? "page" : undefined}>
                  <Icon aria-hidden="true" className="text-muted-foreground" />
                  <span className="min-w-0"><span className="block text-sm">{label}</span><span className="mt-0.5 block text-[11px] text-muted-foreground">{detail}</span></span>
                  <ArrowRight aria-hidden="true" className="ml-auto text-muted-foreground" />
                </Link>
              </DropdownMenuItem>
            ))}
            <DropdownMenuSeparator className="mx-1 my-1" />
            <DropdownMenuItem className="min-h-10 cursor-pointer gap-3 rounded-lg px-3 py-2 text-xs font-normal text-muted-foreground" onSelect={onLogout}><LogOut aria-hidden="true" />Log out</DropdownMenuItem>
          </>
        ) : (
          <div className="space-y-1.5 px-2 pb-2">
            <DropdownMenuItem asChild className="min-h-11 cursor-pointer justify-center rounded-lg bg-primary px-3 text-sm font-medium text-primary-foreground focus:bg-primary/90 focus:text-primary-foreground"><Link to="/login">Sign in</Link></DropdownMenuItem>
            <DropdownMenuItem asChild className="min-h-11 cursor-pointer justify-center rounded-lg border border-input px-3 text-xs font-normal"><Link to="/register">Create an account</Link></DropdownMenuItem>
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
