import { useRef, useState } from "react";
import { refreshPaymentViews } from "../../api/paymentSync";
import { cancelOrder } from "../../api/orders";
import { getPaymentForOrder } from "../../api/payments";
import { invalidate, useResource } from "../../hooks/useResource";
import { usePaymentPolling } from "../pages/usePaymentPolling";
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../../components/ui/dialog";

export default function CancelOrderAction({ order }) {
  const { data: payment } = useResource(`/v1/payments/orders/${order.orderId}`,
    () => getPaymentForOrder(order.orderId), { keepPreviousData: false });
  const live = usePaymentPolling(payment?.id, payment?.paymentMethod === "bakong_khqr" && (order.fulfillmentStatus === "pending"));
  const status = live.data?.paymentStatus ?? payment?.paymentStatus ?? order.paymentStatus;
  const eligible = (order.fulfillmentStatus === "pending") &&
    ["pending", "expired", "failed", "cancelled"].includes(status) && order.paymentStatus !== "paid";
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const lock = useRef(false);

  async function confirmCancellation() {
    if (lock.current || !eligible) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      // Check again because payment may have completed while confirmation was open.
      const latest = await getPaymentForOrder(order.orderId);
      if (!["pending", "expired", "failed", "cancelled"].includes(latest.paymentStatus)) {
        setError("This order can no longer be cancelled because payment has completed.");
        invalidate(`/v1/payments/orders/${order.orderId}`);
        invalidate("/v1/orders");
        return;
      }
      await cancelOrder(order.orderId, "Customer cancelled an unpaid order");
      refreshPaymentViews({ includeStatus: true });
      setOpen(false);
    } catch (failure) {
      setError(failure?.detail || "Could not cancel your order. Please try again.");
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }

  if (!eligible) return null;
  return (
    <>
      <Button variant="outline" className="mt-4 w-full text-destructive hover:text-destructive" onClick={() => { setError(""); setOpen(true); }}>Cancel order</Button>
      <Dialog open={open} onOpenChange={value => { if (!busy) setOpen(value); }}>
        <DialogContent className="w-[calc(100%-2rem)] sm:max-w-md" onEscapeKeyDown={event => { if (busy) event.preventDefault(); }} onPointerDownOutside={event => { if (busy) event.preventDefault(); }}>
          <DialogHeader>
            <DialogTitle>Cancel this order?</DialogTitle>
            <DialogDescription>Your unpaid order will be cancelled. You can place a new order whenever you’re ready.</DialogDescription>
          </DialogHeader>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
            <Button variant="outline" disabled={busy} onClick={() => setOpen(false)}>Keep order</Button>
            <Button variant="destructive" disabled={busy} onClick={confirmCancellation}>{busy ? "Cancelling…" : "Yes, cancel order"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
