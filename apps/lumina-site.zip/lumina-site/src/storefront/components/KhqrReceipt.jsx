import { useRef, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { QrCode } from "lucide-react";

import { Button } from "../../components/ui/button";

export default function KhqrReceipt({ value, amount, currency = "USD", merchantName = "Lumina" }) {
  const qrRef = useRef(null);
  const [feedback, setFeedback] = useState("");
  const numericAmount = Number(amount);
  const renderQrCanvas = () => new Promise((resolve, reject) => {
    const source = qrRef.current.querySelector("svg").cloneNode(true);
    source.querySelectorAll("image").forEach(node => node.remove());
    const url = URL.createObjectURL(new Blob([new XMLSerializer().serializeToString(source)], { type: "image/svg+xml" }));
    const picture = new Image();
    picture.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        canvas.width = canvas.height = 768;
        canvas.getContext("2d").drawImage(picture, 0, 0, 768, 768);
        resolve(canvas);
      } catch (error) {
        reject(error);
      } finally {
        URL.revokeObjectURL(url);
      }
    };
    picture.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not render QR image"));
    };
    picture.src = url;
  });

  const downloadQr = async (format) => {
    const label = format === "pdf" ? "PDF" : "PNG";
    try {
      const canvas = await renderQrCanvas();
      const png = canvas.toDataURL("image/png");
      if (format === "pdf") {
        const { jsPDF } = await import("jspdf");
        const doc = new jsPDF({ unit: "mm", format: [100, 145] });
        doc.setProperties({ title: "Lumina KHQR payment code" });
        doc.setFillColor(207, 52, 56);
        doc.rect(0, 0, 100, 20, "F");
        doc.setTextColor(255, 255, 255);
        doc.setFontSize(20);
        doc.text("KHQR", 50, 13, { align: "center" });
        doc.setTextColor(23, 21, 18);
        doc.setFontSize(12);
        doc.text(doc.splitTextToSize(merchantName, 84).slice(0, 2), 50, 29, { align: "center" });
        if (Number.isFinite(numericAmount)) {
          doc.setFontSize(16);
          doc.text(`${numericAmount.toFixed(currency === "KHR" ? 0 : 2)} ${currency}`, 50, 43, { align: "center" });
        }
        doc.addImage(png, "PNG", 16, 50, 68, 68);
        doc.setFontSize(9);
        doc.text("Scan with your banking app.", 50, 126, { align: "center" });
        doc.text("Valid until the payment code expires.", 50, 132, { align: "center" });
        doc.save("lumina-khqr.pdf");
      } else {
        const link = document.createElement("a");
        link.download = "lumina-khqr.png";
        link.href = png;
        link.click();
      }
      setFeedback(`${label} downloaded.`);
    } catch {
      setFeedback(`Could not download ${label}.`);
    }
  };
  return (
    <div className="khqr-widget">
      <div className="khqr-receipt-frame">
        <div className="khqr-receipt" ref={qrRef}>
          <div className="khqr-receipt-header" aria-hidden="true">KHQR</div>
          <div className="khqr-receipt-merchant">
            <p className="khqr-receipt-name">{merchantName}</p>
            {Number.isFinite(numericAmount) && (
              <p className="khqr-receipt-amount">
                <span>{currency === "USD" ? "$" : ""}{numericAmount.toFixed(currency === "KHR" ? 0 : 2)}</span>
                <span className="khqr-receipt-currency">{currency}</span>
              </p>
            )}
          </div>
          <div className="khqr-receipt-code">
            {value ? (
              <div role="img" aria-label="Bakong KHQR payment code" className="khqr-receipt-svg">
                <QRCodeSVG
                  value={value}
                  size={256}
                  level="H"
                  includeMargin
                  fgColor="#171512"
                  bgColor="#FFFFFF"
                />
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 text-center text-xs text-muted-foreground">
                <QrCode size={24} aria-hidden="true" /> Preparing your payment code…
              </div>
            )}
          </div>
        </div>
      </div>
      {value && (
        <div className="khqr-receipt-controls flex flex-wrap justify-center gap-2 px-2">
          <Button type="button" variant="outline" size="sm" onClick={() => downloadQr("png")}>Download PNG</Button>
          <Button type="button" variant="outline" size="sm" onClick={() => downloadQr("pdf")}>Download PDF</Button>
        </div>
      )}
      {feedback && <p role="status" className="m-0 px-3 text-center text-xs">{feedback}</p>}
    </div>
  );
}
