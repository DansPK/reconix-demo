import React from "react";
import { CartProvider, WishlistProvider, useCart, useWishlist } from "./providers";
import { StoreLayout } from "./StoreLayout";

export default function LuminaStoreApp() {
  // ProductsProvider is gone: the catalogue comes from the API, and each screen fetches
  // what it needs through the useCatalog hooks. There is no shared product list to hold.
  return (
    <CartProvider>
      <WishlistProvider>
        <StoreLayout />
      </WishlistProvider>
    </CartProvider>
  );
}

export { useCart, useWishlist };
