// Catalog reads for the storefront.
//
// Every one of these hits the API anonymously - the gateway allows unauthenticated GETs
// on products and categories, so browsing works signed out. Results are cached and
// revalidated by useResource, which is what replaced the localStorage event bus.

import { URL_TO_CATEGORY_SLUG } from "./data";
import { useMemo } from "react";
import * as catalogApi from "../api/catalog";
import { query } from "../api/client";
import { useResource } from "../hooks/useResource";
import { toStorefrontProduct, toStorefrontProducts } from "./adapt";

/** The whole three-level tree, for the mega menu and the category filters. */
export function useCategoryTree() {
  const { data, loading, error } = useResource(
    "/v1/categories/tree",
    catalogApi.getCategoryTree,
  );
  return { tree: data ?? [], loading, error };
}

/**
 * Searches the catalog.
 *
 * Filtering, sorting and pagination all happen on the server. The prototype fetched
 * everything and did this work in the browser, which meant the storefront and the admin
 * list could disagree about what matched.
 */
export function useProductSearch(params, options) {
  // The URL is the cache key, so it has to be built the same way every render.
  const search = query(params);
  const { data, loading, error, refetch } = useResource(
    `/v1/products${search}`,
    () => catalogApi.listProducts(params),
    options,
  );

  const products = useMemo(() => toStorefrontProducts(data?.content), [data]);
  return {
    products,
    totalElements: data?.totalElements ?? 0,
    totalPages: data?.totalPages ?? 0,
    page: data?.page ?? 0,
    loading,
    error,
    refetch,
  };
}

/** One homepage rail: the newest few products tagged with a given section. */
export function useSectionProducts(section, limit = 4, category = "all") {
  return useProductSearch({
    section,
    size: limit,
    sort: "newest",
    categorySlug:
      category === "all"
        ? undefined
        : (URL_TO_CATEGORY_SLUG[category] ?? category),
  });
}

/**
 * A single product, by slug.
 *
 * The route is /product/:id and the prototype accepted either an id or a slug, so this
 * falls back to an id lookup when the parameter is numeric.
 */
export function useProductBySlug(slugOrId) {
  const isNumericId = /^\d+$/.test(String(slugOrId ?? ""));
  const key = slugOrId
    ? isNumericId
      ? `/v1/products/${slugOrId}`
      : `/v1/products/slug/${slugOrId}`
    : null;

  const { data, loading, error } = useResource(
    key,
    () =>
      isNumericId
        ? catalogApi.getProduct(slugOrId)
        : catalogApi.getProductBySlug(slugOrId),
    { keepPreviousData: false, pollMs: 10000 },
  );

  const product = useMemo(() => toStorefrontProduct(data), [data]);
  return { product, loading, error };
}

export function useRelatedProducts(productId, limit = 4) {
  const key = productId
    ? `/v1/products/${productId}/related${query({ limit })}`
    : null;
  const { data, loading } = useResource(key, () =>
    catalogApi.getRelatedProducts(productId, limit),
  );
  return {
    products: useMemo(() => toStorefrontProducts(data), [data]),
    loading,
  };
}
