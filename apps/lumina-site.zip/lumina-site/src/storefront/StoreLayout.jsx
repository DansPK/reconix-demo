﻿import React from "react";
import { PageMotion } from "../components/PageMotion";
import NotFound from "../components/NotFound";
import { Route, Routes, useLocation } from "react-router-dom";
import { Header, Footer } from "./headerFooter";
import {
  AccountPage,
  BagPage,
  CategoryResultsPage,
  CheckoutPage,
  HomePage,
  OrderDetailPage,
  OrdersPage,
  PaymentPage,
  PaymentSuccessPage,
  ProductDetailPage,
  WishlistPage,
} from "./pages";
// The prototype's LoginPage and RegisterPage were replaced wholesale: they issued no
// token and skipped email verification entirely.
import {
  ForgotPasswordPage,
  LoginPage,
  RegisterPage,
  RequireAuth,
  ResetPasswordPage,
  VerifyEmailPage,
} from "../auth/AuthPages";

function StoreLayout() {
  const location = useLocation();
  // Full-bleed auth screens have no header or footer.
  const isAuth = [
    "/login",
    "/register",
    "/verify",
    "/forgot-password",
    "/reset-password",
  ].includes(location.pathname);
  return (
    <div className="min-h-screen bg-white text-[#111111]">
      {!isAuth ? <Header /> : null}
      <PageMotion className="store-main">
        <Routes>
          <Route
            path="/"
            element={
              <RequireAuth blockAdmin>
                <HomePage />
              </RequireAuth>
            }
          />
          <Route
            path="/category"
            element={
              <RequireAuth blockAdmin>
                <CategoryResultsPage />
              </RequireAuth>
            }
          />
          <Route
            path="/product/:id"
            element={
              <RequireAuth blockAdmin>
                <ProductDetailPage />
              </RequireAuth>
            }
          />
          <Route
            path="/wishlist"
            element={
              <RequireAuth blockAdmin>
                <WishlistPage />
              </RequireAuth>
            }
          />
          <Route
            path="/bag"
            element={
              <RequireAuth blockAdmin>
                <BagPage />
              </RequireAuth>
            }
          />
          <Route
            path="/checkout"
            element={
              <RequireAuth requireAuth blockAdmin>
                <CheckoutPage />
              </RequireAuth>
            }
          />
          <Route
            path="/payment"
            element={
              <RequireAuth blockAdmin>
                <PaymentPage />
              </RequireAuth>
            }
          />
          <Route
            path="/payment/success"
            element={
              <RequireAuth blockAdmin>
                <PaymentSuccessPage />
              </RequireAuth>
            }
          />
          <Route
            path="/orders"
            element={
              <RequireAuth requireAuth blockAdmin>
                <OrdersPage />
              </RequireAuth>
            }
          />
          <Route
            path="/orders/:code"
            element={
              <RequireAuth requireAuth blockAdmin>
                <OrderDetailPage />
              </RequireAuth>
            }
          />
          <Route
            path="/account"
            element={
              <RequireAuth requireAuth blockAdmin>
                <AccountPage />
              </RequireAuth>
            }
          />
          <Route path="*" element={<NotFound />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          {/* The step that did not exist: registration is not complete until the
              emailed code is accepted, because no user row is created before then. */}
          <Route path="/verify" element={<VerifyEmailPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
        </Routes>
      </PageMotion>
      {!isAuth ? <Footer /> : null}
    </div>
  );
}

export { StoreLayout };
