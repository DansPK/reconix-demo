import SettingsCardHeader from "../components/SettingsCardHeader";
import { useNavigate } from "react-router-dom";
import { ArrowRight, BadgePercent } from "lucide-react";
import AdminPageHeader from "../components/AdminPageHeader";
import DeliveryFeeSettingsCard from "./DeliveryFeeSettingsCard";
import {
  Card,
  CardContent,
} from "../../components/ui/card";
import { Button } from "../../components/ui/button";

export default function ConfigPage() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col gap-6 p-6">
      <AdminPageHeader
        spaced={false}
        title="Config"
        description="Manage checkout pricing and catalog promotions for your store."
      />

      <div className="grid items-stretch gap-5 xl:grid-cols-2">
        <DeliveryFeeSettingsCard />

        <Card className="flex h-full w-full flex-col shadow-none">
          <SettingsCardHeader icon={BadgePercent} title="Product discounts" description="Set a percentage in a product’s pricing section. The sale price is calculated automatically and shown to shoppers." />
          <CardContent className="flex flex-1 flex-col">
            <div className="mt-auto border-t border-border pt-4">
            <Button type="button" onClick={() => navigate("/dashboard/products")}>
              Manage products
              <ArrowRight size={16} aria-hidden="true" />
            </Button>
            </div>
          </CardContent>
        </Card>
      </div>

    </div>
  );
}
