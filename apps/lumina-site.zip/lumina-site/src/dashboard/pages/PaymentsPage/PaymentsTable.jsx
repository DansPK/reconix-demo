import { RotateCcw, Search } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import StyledSelect from "../../../components/ui/styled-select";
import { PAYMENT_METHOD_LABELS, PAYMENT_STATUS_LABELS } from "../../adminPayments";
import { fmtDate, fmtUsd } from "./helpers";
import StatusPill from "./StatusPill";

export default function PaymentsTable({
  filtered,
  loading,
  selected,
  setSelectedId,
  navigate,
  search,
  setSearch,
  statusFilter,
  setStatusFilter,
  methodFilter,
  setMethodFilter,
  sortBy,
  setSortBy,
  paymentsLoaded,
  totalElements,
}) {
  const hasFilters =
    !!search || statusFilter !== "All" || methodFilter !== "All" || sortBy !== "latest";

  const clearFilters = () => {
    setSearch("");
    setStatusFilter("All");
    setMethodFilter("All");
    setSortBy("latest");
  };

  return (
    <section className="min-w-0 overflow-hidden rounded-xl border bg-card text-card-foreground shadow-none" aria-labelledby="payments-table-title">
      <div className="space-y-4 border-b border-border px-4 py-4 sm:px-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 id="payments-table-title" className="text-base font-semibold">Transactions</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Search, filter, and select a payment to review its details.
            </p>
          </div>
          <span className="shrink-0 rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
            {filtered.length.toLocaleString()} {filtered.length === 1 ? "match" : "matches"}
          </span>
        </div>

        <div className="grid gap-2 sm:grid-cols-2 2xl:grid-cols-[minmax(180px,1fr)_145px_155px_170px_auto]">
          <div className="relative min-w-0 sm:col-span-2 2xl:col-span-1">
            <Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              aria-label="Search payments"
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search order, payment ID, customer…"
              className="h-10 rounded-lg pl-9 text-sm"
            />
          </div>
          <StyledSelect
            ariaLabel="Payment status"
            value={statusFilter}
            onValueChange={setStatusFilter}
            options={[
              { value: "All", label: "All statuses" },
              ...Object.entries(PAYMENT_STATUS_LABELS).map(([value, label]) => ({ value, label })),
            ]}
            className="h-10 w-full rounded-lg text-sm"
          />
          <StyledSelect
            ariaLabel="Payment method"
            value={methodFilter}
            onValueChange={setMethodFilter}
            options={[
              { value: "All", label: "All methods" },
              ...Object.entries(PAYMENT_METHOD_LABELS).map(([value, label]) => ({ value, label })),
            ]}
            className="h-10 w-full rounded-lg text-sm"
          />
          <StyledSelect
            ariaLabel="Sort payments"
            value={sortBy}
            onValueChange={setSortBy}
            options={[
              { value: "latest", label: "Newest first" },
              { value: "oldest", label: "Oldest first" },
              { value: "amount-high", label: "Amount: high to low" },
              { value: "amount-low", label: "Amount: low to high" },
            ]}
            className="h-10 w-full rounded-lg text-sm"
          />
          <Button
            type="button"
            variant="outline"
            onClick={clearFilters}
            disabled={!hasFilters}
            className="h-10 gap-1.5 px-3 text-xs"
          >
            <RotateCcw size={14} aria-hidden="true" />
            Reset
          </Button>
        </div>
      </div>

      <div className="max-h-[560px] overflow-auto" aria-busy={loading}>
        <table className="w-full min-w-[860px] border-collapse text-left text-sm">
          <caption className="sr-only">Admin payment transactions</caption>
          <thead className="sticky top-0 z-10 bg-muted/95 text-[11px] uppercase tracking-wide text-muted-foreground backdrop-blur">
            <tr className="border-b border-border">
              <th scope="col" className="px-4 py-3 font-semibold">Payment / order</th>
              <th scope="col" className="px-3 py-3 font-semibold">Customer</th>
              <th scope="col" className="px-3 py-3 font-semibold">Method</th>
              <th scope="col" className="px-3 py-3 font-semibold">Status</th>
              <th scope="col" className="px-3 py-3 text-right font-semibold">Gross</th>
              <th scope="col" className="px-3 py-3 text-right font-semibold">Net</th>
              <th scope="col" className="px-4 py-3 font-semibold">Created</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-4 py-12 text-center">
                  <p className="text-sm font-medium text-foreground">
                    {loading ? "Loading payments…" : "No payments match these filters"}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {loading ? "Payment records will appear here shortly." : hasFilters ? "Try a different search or reset the filters." : "New transactions will appear here."}
                  </p>
                  {hasFilters && !loading ? (
                    <Button type="button" variant="ghost" size="sm" onClick={clearFilters} className="mt-2">
                      Reset filters
                    </Button>
                  ) : null}
                </td>
              </tr>
            ) : (
              filtered.map((payment) => {
                const isSelected = selected?.id === payment.id;
                return (
                  <tr
                    key={payment.id}
                    aria-selected={isSelected}
                    className={`border-b border-border/80 transition-colors last:border-b-0 hover:bg-muted/40 ${isSelected ? "bg-primary/5" : "bg-card"}`}
                  >
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        aria-label={`View order ${payment.orderCode || payment.orderId}`}
                        onClick={() => navigate(`/dashboard/orders/${payment.orderId}`)}
                        className="block font-semibold text-primary hover:underline"
                      >
                        {payment.orderCode || `Order #${payment.orderId}`}
                      </button>
                      <button
                        type="button"
                        aria-label={`View payment ${payment.id}`}
                        onClick={() => setSelectedId(payment.id)}
                        className="mt-0.5 block text-xs text-muted-foreground hover:text-foreground"
                      >
                        Payment #{payment.id}
                      </button>
                    </td>
                    <td className="max-w-[180px] truncate px-3 py-3 text-sm text-muted-foreground" title={payment.customer}>
                      {payment.customer}
                    </td>
                    <td className="px-3 py-3 text-sm">{PAYMENT_METHOD_LABELS[payment.method] ?? payment.method}</td>
                    <td className="px-3 py-3"><StatusPill status={payment.status} /></td>
                    <td className="px-3 py-3 text-right font-semibold tabular-nums">{fmtUsd(payment.amount)}</td>
                    <td className="px-3 py-3 text-right font-semibold tabular-nums text-[var(--admin-success)]">{fmtUsd(payment.net)}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-xs text-muted-foreground">{fmtDate(payment.createdAt)}</td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-3 text-xs text-muted-foreground sm:px-5">
        <span>
          Showing {filtered.length.toLocaleString()} of {paymentsLoaded.toLocaleString()} loaded payments
        </span>
        {totalElements > paymentsLoaded ? (
          <span>Loaded {paymentsLoaded.toLocaleString()} of {totalElements.toLocaleString()} total records</span>
        ) : null}
        {loading && paymentsLoaded > 0 ? <span>Refreshing…</span> : null}
      </footer>
    </section>
  );
}
