import { Dialog, DialogContent, DialogTitle } from "../../../components/ui/dialog";
import { PAYMENT_METHOD_LABELS, PAYMENT_STATUS_LABELS } from "../../adminPayments";
import { C, fmtUsd, fmtDate } from "./helpers";

export default function ReceiptModal({ selected, onClose }) {
  return (
    <Dialog open onOpenChange={open => { if (!open) onClose(); }}>
      <DialogContent aria-describedby={undefined}>
        <DialogTitle style={{ margin: "0 0 14px", fontSize: "1.2857rem" }}>Payment receipt</DialogTitle>
        <div style={{ display: "grid", gap: 8, fontSize: "0.92857rem" }}>
          <div><strong>Order:</strong> {selected.orderCode}</div><div><strong>Payment ID:</strong> #{selected.id}</div>
          <div><strong>Customer:</strong> {selected.customer}</div><div><strong>Method:</strong> {PAYMENT_METHOD_LABELS[selected.method] ?? selected.method}</div><div><strong>Status:</strong> {PAYMENT_STATUS_LABELS[selected.status] ?? selected.status}</div>
          <div><strong>Gross Amount:</strong> {fmtUsd(selected.amount)}</div><div><strong>Gateway Fee:</strong> {fmtUsd(selected.fee)}</div><div><strong>Net Amount:</strong> {fmtUsd(selected.net)}</div><div><strong>Created:</strong> {fmtDate(selected.createdAt)}</div>
        </div>
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 16 }}><button onClick={onClose} style={{ border: `1px solid ${C.border}`, background: C.white, borderRadius: 8, padding: "9px 12px", cursor: "pointer" }}>Close</button></div>
      </DialogContent>
    </Dialog>
  );
}
