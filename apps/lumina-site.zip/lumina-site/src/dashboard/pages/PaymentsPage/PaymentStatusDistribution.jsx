import { PAYMENT_STATUS_LABELS } from "../../adminPayments";

const STATUSES = [
  { value: "paid", color: "var(--admin-success)" },
  { value: "pending", color: "var(--admin-warning)" },
  { value: "failed", color: "var(--admin-danger)" },
  { value: "expired", color: "#B42318" },
  { value: "refunded", color: "var(--admin-neutral)" },
  { value: "partially_refunded", color: "#3B6FA5" },
];

export default function PaymentStatusDistribution({
  summary,
  loading,
  statusFilter,
  setStatusFilter,
}) {
  const items = STATUSES.map((status) => ({
    ...status,
    label: PAYMENT_STATUS_LABELS[status.value],
    count: Number(summary?.[`${status.value === "partially_refunded" ? "partiallyRefunded" : status.value}Count`] ?? 0),
  }));
  const total = items.reduce((sum, item) => sum + item.count, 0);
  const description = items
    .map(({ label, count }) => `${label}: ${count.toLocaleString()}`)
    .join(", ");

  return (
    <section className="rounded-xl border bg-card p-4 text-card-foreground shadow-none sm:p-5" aria-labelledby="payment-status-title">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 id="payment-status-title" className="text-sm font-semibold">Payment status</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">
            All-time counts; select a status to filter loaded transactions.
          </p>
        </div>
        <span className="rounded-full bg-muted px-2.5 py-1 text-xs font-medium text-muted-foreground">
          {loading && !summary ? "Loading…" : `${total.toLocaleString()} records`}
        </span>
      </div>

      {total > 0 ? (
        <div
          role="img"
          aria-label={`Payment status mix: ${description}`}
          className="mt-4 flex h-2.5 overflow-hidden rounded-full bg-muted"
        >
          {items.filter((item) => item.count > 0).map((item) => (
            <span
              key={item.value}
              style={{
                width: `${(item.count / total) * 100}%`,
                background: item.color,
              }}
              title={`${item.label}: ${item.count}`}
            />
          ))}
        </div>
      ) : (
        <div className="mt-4 h-2.5 rounded-full bg-muted" aria-hidden="true" />
      )}

      <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
        <button
          type="button"
          aria-pressed={statusFilter === "All"}
          onClick={() => setStatusFilter("All")}
          className={`flex min-w-0 items-center justify-between gap-2 rounded-lg border px-2.5 py-2 text-left text-xs transition-colors ${statusFilter === "All" ? "border-primary/40 bg-primary/5 text-primary" : "border-border bg-background hover:bg-muted/60"}`}
        >
          <span className="truncate">All statuses</span>
          <span className="shrink-0 font-semibold tabular-nums">{total.toLocaleString()}</span>
        </button>
        {items.map((item) => {
          const active = statusFilter === item.value;
          return (
            <button
              key={item.value}
              type="button"
              aria-pressed={active}
              onClick={() => setStatusFilter(active ? "All" : item.value)}
              className={`flex min-w-0 items-center justify-between gap-2 rounded-lg border px-2.5 py-2 text-left text-xs transition-colors ${active ? "border-primary/40 bg-primary/5 text-primary" : "border-border bg-background hover:bg-muted/60"}`}
            >
              <span className="flex min-w-0 items-center gap-1.5">
                <span aria-hidden="true" className="h-2 w-2 shrink-0 rounded-full" style={{ background: item.color }} />
                <span className="truncate">{item.label}</span>
              </span>
              <span className="shrink-0 font-semibold tabular-nums">{item.count.toLocaleString()}</span>
            </button>
          );
        })}
      </div>
      {total === 0 && !loading ? (
        <p className="mt-2 text-xs text-muted-foreground">No payment records yet.</p>
      ) : null}
    </section>
  );
}
