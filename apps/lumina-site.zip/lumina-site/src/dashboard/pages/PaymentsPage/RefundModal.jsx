import { Dialog, DialogContent, DialogTitle } from "../../../components/ui/dialog";
import StyledSelect from "../../../components/ui/styled-select";
import { C, fmtUsd } from "./helpers";

export default function RefundModal({
  selected,
  refundAmount,
  setRefundAmount,
  refundReason,
  setRefundReason,
  refundError,
  refunding,
  refundableRemaining,
  submitRefund,
  onClose,
}) {
  return (
    <Dialog open onOpenChange={open => { if (!open && !refunding) onClose(); }}>
      <DialogContent className="max-h-[85dvh] overflow-y-auto" aria-describedby={undefined}>
      <form onSubmit={submitRefund} onClick={(event) => event.stopPropagation()} >
        <DialogTitle style={{ margin: "0 0 14px", fontSize: "1.2857rem" }}>Issue refund</DialogTitle>
        <div style={{ display: "grid", gap: 9, fontSize: "0.92857rem" }}>
          <div><strong>Order:</strong> {selected.orderCode}</div>
          <div><strong>Customer:</strong> {selected.customer}</div>
          <div><strong>Payment:</strong> #{selected.id}</div>
          <div><strong>Refundable remaining:</strong> {fmtUsd(refundableRemaining)}</div>
          <label style={{ display: "grid", gap: 5, marginTop: 5, fontSize: "0.85714rem", fontWeight: 600 }}>Refund amount
            <input required type="number" min="0.01" max={refundableRemaining} step="0.01" value={refundAmount} onChange={(event) => setRefundAmount(event.target.value)} style={{ border: `1px solid ${C.border}`, borderRadius: 8, padding: "9px 10px" }} />
          </label>
          <div style={{ display: "grid", gap: 5, fontSize: "0.85714rem", fontWeight: 600 }}>
            <span>Refund reason</span>
            <StyledSelect
              ariaLabel="Refund reason"
              value={refundReason}
              onValueChange={setRefundReason}
              options={[
                "Customer requested refund",
                "Wrong item",
                "Damaged item",
                "Payment issue",
                "Duplicate payment",
                "Other",
              ].map((reason) => ({ value: reason, label: reason }))}
              className="h-10 rounded-lg bg-white text-sm"
            />
          </div>
          {refundError && <div style={{ color: C.danger, fontSize: "0.85714rem" }}>{refundError}</div>}
          <div style={{ padding: 10, borderRadius: 8, background: C.warningBg, color: "var(--admin-warning)", fontSize: "0.85714rem" }}>
            A refund that reaches the full payment amount returns every reserved unit to stock.
          </div>
        </div>
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 16 }}>
          <button type="button" onClick={onClose} style={{ border: `1px solid ${C.border}`, background: C.white, borderRadius: 8, padding: "9px 12px", cursor: "pointer" }}>Cancel</button>
          <button type="submit" disabled={refunding} style={{ border: "none", background: "var(--admin-danger-action)", color: "var(--admin-danger-action-foreground)", borderRadius: 8, padding: "9px 12px", fontWeight: 700, cursor: refunding ? "not-allowed" : "pointer" }}>{refunding ? "Processing…" : "Confirm Refund"}</button>
        </div>
      </form>
      </DialogContent>
    </Dialog>
  );
}
