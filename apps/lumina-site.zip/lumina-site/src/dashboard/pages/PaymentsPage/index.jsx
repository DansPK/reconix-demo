import { usePaymentReconciliation } from "../../usePaymentReconciliation";
import { usePaymentPolling } from "../../../storefront/pages/usePaymentPolling";
import { useAuth } from "../../../auth/AuthContext";
import { exportTablePdf } from "../../../lib/exportPdf";
import ExportControls from "../../components/ExportControls";
import AdminPageHeader from "../../components/AdminPageHeader";
import { usePageFilters } from "../../usePageFilters";
import { ResourceError } from "../../../components/ResourceFeedback";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  useAdminPayments,
  useAdminPaymentSummary,
  useRefundPayment,
  PAYMENT_METHOD_LABELS,
  PAYMENT_STATUS_LABELS,
} from "../../adminPayments";
import { ApiError } from "../../../api/client";
import { C, FONT_STACK, fmtUsd, csvValue } from "./helpers";
import PaymentOverview from "./PaymentOverview";
import PaymentStatusDistribution from "./PaymentStatusDistribution";
import PaymentsTable from "./PaymentsTable";
import PaymentDetail from "./PaymentDetail";
import RefundModal from "./RefundModal";
import ReceiptModal from "./ReceiptModal";

export default function PaymentsPage() {
  const navigate = useNavigate();
  const { isAdmin, isStaff } = useAuth();
  const { payments, totalElements, loading, error, refetch } = useAdminPayments();
  const { summary, loading: summaryLoading, error: summaryError, refetch: refetchSummary } = useAdminPaymentSummary();
  const refundPayment = useRefundPayment();

  const [filters, updateFilters] = usePageFilters({"q": "", "status": "All", "method": "All", "sort": "latest"});
  const search = filters.q;
  const setSearch = value => updateFilters({ q: value });
  const statusFilter = filters.status;
  const setStatusFilter = value => updateFilters({ status: value });
  const methodFilter = filters.method;
  const setMethodFilter = value => updateFilters({ method: value });
  const sortBy = filters.sort;
  const setSortBy = value => updateFilters({ sort: value });




  const [selectedId, setSelectedId] = useState(null);
  const [refundOpen, setRefundOpen] = useState(false);
  const [receiptOpen, setReceiptOpen] = useState(false);
  const [refundAmount, setRefundAmount] = useState("");
  const [refundReason, setRefundReason] = useState("Customer requested refund");
  const [refundError, setRefundError] = useState("");
  const [refundSuccess, setRefundSuccess] = useState("");
  const [refunding, setRefunding] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();

    const list = payments.filter((t) => {
      const matchSearch =
        !q ||
        String(t.id).toLowerCase().includes(q) ||
        String(t.orderCode ?? "")
          .toLowerCase()
          .includes(q) ||
        String(t.customer ?? "")
          .toLowerCase()
          .includes(q);
      const matchStatus = statusFilter === "All" || t.status === statusFilter;
      const matchMethod = methodFilter === "All" || t.method === methodFilter;
      return matchSearch && matchStatus && matchMethod;
    });

    return list.sort((a, b) => {
      if (sortBy === "latest")
        return new Date(b.createdAt) - new Date(a.createdAt);
      if (sortBy === "oldest")
        return new Date(a.createdAt) - new Date(b.createdAt);
      if (sortBy === "amount-high") return b.amount - a.amount;
      if (sortBy === "amount-low") return a.amount - b.amount;
      return String(a.id).localeCompare(String(b.id));
    });
  }, [payments, search, statusFilter, methodFilter, sortBy]);

  const selected =
    filtered.find((t) => t.id === selectedId) || filtered[0] || null;
  const selectedLivePayment = usePaymentPolling(selected?.id, selected?.method === "bakong_khqr" && selected?.status === "pending");
  usePaymentReconciliation(payments, selected?.method === "bakong_khqr" && selected?.status === "pending" ? selected.id : null);
  const refundableRemaining = selected
    ? selected.amount - selected.refundedAmount
    : 0;
  const canRefund =
    isAdmin && selected && refundableRemaining > 0 &&
    (selected.status === "paid" || selected.status === "partially_refunded");

  const exportRows = () => [
      [
        "Order Code",
        "Payment ID",
        "Customer",
        "Method",
        "Status",
        "Amount",
        "Gateway Fee",
        "Net",
        "Refunded",
        "Created At",
      ],
      ...filtered.map((t) => [
        t.orderCode,
        t.id,
        t.customer,
        PAYMENT_METHOD_LABELS[t.method] ?? t.method,
        PAYMENT_STATUS_LABELS[t.status] ?? t.status,
        t.amount.toFixed(2),
        t.fee.toFixed(2),
        t.net.toFixed(2),
        t.refundedAmount.toFixed(2),
        t.createdAt,
      ]),
    ];
  const exportPdf = () => {
    const [columns, ...rows] = exportRows();
    return exportTablePdf({ filename: "payment-report.pdf", title: "Payment report", scope: `Loaded payments matching the current filters / ${rows.length} records. Monetary amounts in USD.`, sections: [{ title: "Payments", columns, rows }] });
  };
  const exportReport = () => {
    const rows = exportRows();
    const csv = rows.map((row) => row.map(csvValue).join(",")).join("\r\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `payment-report-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  const submitRefund = async (event) => {
    event.preventDefault();
    if (refunding) return;
    const amount = Number(refundAmount);
    if (
      !selected ||
      !canRefund ||
      !Number.isFinite(amount) ||
      amount <= 0 ||
      amount > refundableRemaining
    ) {
      setRefundError(
        `Enter a refund amount greater than zero and no more than ${fmtUsd(refundableRemaining)}.`,
      );
      return;
    }
    setRefunding(true);
    setRefundError("");
    try {
      await refundPayment(selected.id, { amount, reason: refundReason });
      setRefundOpen(false);
      setRefundSuccess(
        `Refund processed for ${selected.orderCode}: ${fmtUsd(amount)}`,
      );
      setTimeout(() => setRefundSuccess(""), 4000);
    } catch (error) {
      setRefundError(
        error instanceof ApiError
          ? error.detail
          : "Could not process the refund.",
      );
    } finally {
      setRefunding(false);
    }
  };

  return (
    <div
      style={{
        flex: 1,
        overflowY: "auto",
        padding: 24,
        background: C.surface,
        fontFamily: FONT_STACK,
        color: C.text,
      }}
    >
      <AdminPageHeader title="Payments" description="Track transaction status, gateways, and payment reconciliation." actions={
        <ExportControls onCsv={exportReport} onPdf={exportPdf} csvLabel="Export Report" disabled={loading || !!error} />
      } />
      {error && (
        <ResourceError message="Could not load payments." retry={refetch} />
      )}


      <div className="mb-4 space-y-4">
        {summaryError ? (
          <ResourceError message="Could not load payment summary." retry={refetchSummary} />
        ) : (
          <>
            <PaymentOverview summary={summary} loading={summaryLoading} />
            <PaymentStatusDistribution
              summary={summary}
              loading={summaryLoading}
              statusFilter={statusFilter}
              setStatusFilter={setStatusFilter}
            />
          </>
        )}
      </div>

      {selectedLivePayment.error && <p role="status" className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-xs text-amber-800">Payment verification is temporarily unavailable. Retrying automatically.</p>}
      <div
        className="admin-panel-grid"
        style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.8fr) minmax(290px, 0.8fr)", gap: 16, alignItems: "start" }}
      >
        <PaymentsTable
          filtered={filtered}
          loading={loading}
          selected={selected}
          setSelectedId={setSelectedId}
          navigate={navigate}
          search={search}
          setSearch={setSearch}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          methodFilter={methodFilter}
          setMethodFilter={setMethodFilter}
          sortBy={sortBy}
          setSortBy={setSortBy}
          paymentsLoaded={payments.length}
          totalElements={totalElements}
        />

        <PaymentDetail
          selected={selected}
          canConfirmCod={isAdmin || isStaff}
          canRefund={canRefund}
          navigate={navigate}
          onOpenRefund={() => {
            setRefundAmount(String(refundableRemaining));
            setRefundError("");
            setRefundSuccess("");
            setRefundOpen(true);
          }}
          onOpenReceipt={() => setReceiptOpen(true)}
        />
      </div>

      {refundOpen && selected && (
        <RefundModal
          selected={selected}
          refundAmount={refundAmount}
          setRefundAmount={setRefundAmount}
          refundReason={refundReason}
          setRefundReason={setRefundReason}
          refundError={refundError}
          refunding={refunding}
          refundableRemaining={refundableRemaining}
          submitRefund={submitRefund}
          onClose={() => setRefundOpen(false)}
        />
      )}

      {receiptOpen && selected && (
        <ReceiptModal
          selected={selected}
          onClose={() => setReceiptOpen(false)}
        />
      )}
      {refundSuccess && (
        <div
          role="status"
          style={{
            position: "fixed",
            right: 24,
            bottom: 24,
            zIndex: 40,
            padding: "12px 16px",
            borderRadius: 10,
            background: C.successBg,
            color: "var(--admin-success)",
            border: `1px solid ${C.success}`,
          }}
        >
          {refundSuccess}
        </div>
      )}
    </div>
  );
}
