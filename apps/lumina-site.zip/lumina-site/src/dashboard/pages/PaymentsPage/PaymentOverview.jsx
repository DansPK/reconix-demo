import {
  Banknote,
  CircleDollarSign,
  Clock3,
  CreditCard,
  RotateCcw,
  Wallet,
} from "lucide-react";
import { C, fmtUsd } from "./helpers";

const count = (value) => Number(value ?? 0).toLocaleString();

export default function PaymentOverview({ summary, loading }) {
  const unavailable = loading && !summary;
  const metrics = [
    {
      label: "Payments",
      value: unavailable ? "—" : count(summary?.totalCount),
      note: "All records",
      icon: CreditCard,
      color: C.primary,
      background: C.primaryBg,
    },
    {
      label: "Gross amount",
      value: unavailable ? "—" : fmtUsd(summary?.grossAmount),
      note: "Across payment records",
      icon: CircleDollarSign,
      color: C.primary,
      background: C.primaryBg,
    },
    {
      label: "Gateway fees",
      value: unavailable ? "—" : fmtUsd(summary?.feeAmount),
      note: "Recorded fees",
      icon: Banknote,
      color: C.textSub,
      background: C.surface,
    },
    {
      label: "Net amount",
      value: unavailable ? "—" : fmtUsd(summary?.netAmount),
      note: "After gateway fees",
      icon: Wallet,
      color: C.success,
      background: C.successBg,
    },
    {
      label: "Pending",
      value: unavailable ? "—" : count(summary?.pendingCount),
      note: "Awaiting confirmation",
      icon: Clock3,
      color: C.warning,
      background: C.warningBg,
    },
    {
      label: "Refunded",
      value: unavailable ? "—" : fmtUsd(summary?.refundedAmount),
      note: "Refunded amount",
      icon: RotateCcw,
      color: "var(--admin-neutral)",
      background: "var(--admin-neutral-soft)",
    },
  ];

  return (
    <section aria-label="Payment overview">
      <div className="mb-2 flex flex-wrap items-end justify-between gap-2">
        <div>
          <h2 className="text-sm font-semibold text-foreground">Payment overview</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">
            All-time totals across payment records
          </p>
        </div>
        {loading && summary ? <span className="text-xs text-muted-foreground">Refreshing…</span> : null}
      </div>
      <div className="grid grid-cols-2 gap-2.5 md:grid-cols-3 xl:grid-cols-6">
        {metrics.map(({ label, value, note, icon: Icon, color, background }) => (
          <article
            key={label}
            className="min-w-0 rounded-xl border bg-card p-3.5 text-card-foreground shadow-none sm:p-4"
            style={{ borderColor: C.border }}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="truncate text-xs font-medium text-muted-foreground">{label}</span>
              <span
                className="grid h-8 w-8 shrink-0 place-items-center rounded-lg"
                style={{ background, color }}
                aria-hidden="true"
              >
                <Icon size={16} />
              </span>
            </div>
            <p className="mt-2 truncate text-lg font-semibold leading-tight tabular-nums sm:text-xl" title={String(value)}>
              {value}
            </p>
            <p className="mt-1 truncate text-[11px] text-muted-foreground">{note}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
