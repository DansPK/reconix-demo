import { PAYMENT_STATUS_LABELS } from "../../adminPayments";
import { C } from "./helpers";

export default function StatusPill({ status }) {
  let bg = C.surface;
  let color = C.textSub;

  if (status === "paid") { bg = C.successBg; color = "var(--admin-success)"; }
  if (status === "pending") { bg = C.warningBg; color = "var(--admin-warning)"; }
  if (status === "failed" || status === "expired") { bg = C.dangerBg; color = "var(--admin-danger)"; }
  if (status === "refunded" || status === "partially_refunded") { bg = "var(--admin-neutral-soft)"; color = "var(--admin-neutral)"; }

  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap", fontSize: "0.78571rem", fontWeight: 600, padding: "4px 9px", borderRadius: 999, background: bg, color }}>
      <span aria-hidden="true" style={{ width: 7, height: 7, borderRadius: "50%", background: color }} />
      {PAYMENT_STATUS_LABELS[status] ?? status}
    </span>
  );
}
