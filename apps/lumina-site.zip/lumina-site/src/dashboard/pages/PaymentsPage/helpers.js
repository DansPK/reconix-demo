import { C as theme } from "../../components/constants";
export const C = {
  ...theme,
  primary: "var(--admin-primary)",
  success: "var(--admin-success)",
  warning: "var(--admin-warning)",
  danger: "var(--admin-danger)",
  text: "var(--admin-foreground)",
  textSub: "var(--admin-muted-foreground)",
  muted: "var(--admin-muted-foreground)",
  surface: "var(--admin-background)",
  white: "var(--admin-card)",
  border: "var(--admin-border)",
  primaryBg: "var(--admin-primary-soft)",
  successBg: "var(--admin-success-soft)",
  warningBg: "var(--admin-warning-soft)",
  dangerBg: "var(--admin-danger-soft)",
};

export const FONT_STACK = "'Poppins','Segoe UI',sans-serif";

export function fmtUsd(value) {
  return `$${Number(value ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function fmtDate(value) {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleString(undefined, {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return String(value);
  }
}

export { csvValue } from "../../../lib/utils";
