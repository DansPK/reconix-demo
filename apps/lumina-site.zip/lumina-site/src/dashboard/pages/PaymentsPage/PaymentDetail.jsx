import ConfirmCodPayment from "../../components/ConfirmCodPayment";
import {
  ArrowUpRight,
  CalendarDays,
  CreditCard,
  ReceiptText,
  RotateCcw,
  UserRound,
} from "lucide-react";
import { Button } from "../../../components/ui/button";
import { PAYMENT_METHOD_LABELS } from "../../adminPayments";
import { fmtDate, fmtUsd } from "./helpers";
import StatusPill from "./StatusPill";

function DetailRow({ label, children }) {
  return (
    <div className="flex items-start justify-between gap-3 text-sm">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="max-w-[65%] text-right font-medium text-foreground">{children}</dd>
    </div>
  );
}

export default function PaymentDetail({
  selected,
  canRefund,
  canConfirmCod,
  navigate,
  onOpenRefund,
  onOpenReceipt,
}) {
  return (
    <aside className="h-fit min-w-0 rounded-xl border bg-card p-4 text-card-foreground shadow-none sm:p-5 xl:sticky xl:top-4" aria-labelledby="payment-detail-title">
      {!selected ? (
        <div className="py-8 text-center">
          <span className="mx-auto grid h-11 w-11 place-items-center rounded-xl bg-muted text-muted-foreground">
            <CreditCard size={20} aria-hidden="true" />
          </span>
          <h2 id="payment-detail-title" className="mt-3 text-sm font-semibold">Payment details</h2>
          <p className="mt-1 text-xs text-muted-foreground">Select a transaction to review amounts and actions.</p>
        </div>
      ) : (
        <>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs font-medium text-muted-foreground">Payment details</p>
              <h2 id="payment-detail-title" className="mt-0.5 text-xl font-semibold">Payment #{selected.id}</h2>
            </div>
            <StatusPill status={selected.status} />
          </div>

          <div className="mt-4 rounded-lg bg-muted/50 p-3">
            <div className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">Order</div>
            <button
              type="button"
              onClick={() => navigate(`/dashboard/orders/${selected.orderId}`)}
              className="mt-1 inline-flex max-w-full items-center gap-1 break-all text-sm font-semibold text-primary hover:underline"
            >
              {selected.orderCode || `Order #${selected.orderId}`}
              <ArrowUpRight size={14} className="shrink-0" aria-hidden="true" />
            </button>
            <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
              <UserRound size={14} aria-hidden="true" />
              <span className="truncate">{selected.customer}</span>
            </div>
          </div>

          <div className="mt-3 rounded-lg border border-border p-3.5">
            <p className="text-xs text-muted-foreground">Gross amount</p>
            <p className="mt-0.5 text-2xl font-semibold tabular-nums">{fmtUsd(selected.amount)}</p>
            <dl className="mt-3 space-y-2 border-t border-border pt-3">
              <DetailRow label="Gateway fee">{fmtUsd(selected.fee)}</DetailRow>
              <DetailRow label="Net amount">
                <span className="text-[var(--admin-success)]">{fmtUsd(selected.net)}</span>
              </DetailRow>
              {selected.refundedAmount > 0 ? (
                <DetailRow label="Refunded">{fmtUsd(selected.refundedAmount)}</DetailRow>
              ) : null}
            </dl>
          </div>

          <dl className="mt-4 space-y-3">
            <DetailRow label="Method">{PAYMENT_METHOD_LABELS[selected.method] ?? selected.method}</DetailRow>
            {selected.channel ? <DetailRow label="Channel">{selected.channel}</DetailRow> : null}
            <DetailRow label={<span className="inline-flex items-center gap-1.5"><CalendarDays size={13} aria-hidden="true" />Created</span>}>
              {fmtDate(selected.createdAt)}
            </DetailRow>
            {selected.refundedAt ? <DetailRow label="Refund date">{fmtDate(selected.refundedAt)}</DetailRow> : null}
          </dl>

          <ConfirmCodPayment allowed={canConfirmCod} orderId={selected.orderId} method={selected.method} status={selected.status} />
          <div className="mt-4 grid gap-2 border-t border-border pt-4">
            <Button type="button" variant="outline" onClick={onOpenReceipt} className="w-full justify-start gap-2">
              <ReceiptText size={15} aria-hidden="true" />
              View receipt
            </Button>
            <Button
              type="button"
              variant="outline"
              disabled={!canRefund}
              onClick={onOpenRefund}
              className="w-full justify-start gap-2 border-destructive/30 text-destructive hover:bg-destructive/5 hover:text-destructive disabled:text-muted-foreground"
            >
              <RotateCcw size={15} aria-hidden="true" />
              {canRefund ? "Issue refund" : "Refund unavailable"}
            </Button>
          </div>
          {!canRefund ? <p className="mt-2 text-[11px] text-muted-foreground">Refunds are available after a successful payment.</p> : null}
        </>
      )}
    </aside>
  );
}
