export default function StatusDonut({ items, unit }) {
  const total = items.reduce((sum, item) => sum + Number(item.value || 0), 0);
  const circumference = 2 * Math.PI * 46;
  let offset = 0;
  const arcs = items.map(item => {
    const length = total ? Number(item.value || 0) / total * circumference : 0;
    const arc = { ...item, length, offset };
    offset += length;
    return arc;
  });
  if (!total) return <p className="py-8 text-center text-sm text-muted-foreground">No {unit} to display.</p>;
  return (
    <div className="flex flex-col items-center gap-6 sm:flex-row">
      <div className="relative h-40 w-40 shrink-0">
        <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90" role="img" aria-label={`${unit} distribution: ${items.map(item => `${item.name}, ${item.value}`).join('; ')}`}>
          <circle cx="60" cy="60" r="46" fill="none" stroke="var(--admin-muted)" strokeWidth="12" />
          {arcs.filter(arc => arc.length > 0).map(arc => <circle key={arc.name} cx="60" cy="60" r="46" fill="none" stroke={arc.color} strokeWidth="12" strokeDasharray={`${arc.length} ${circumference - arc.length}`} strokeDashoffset={-arc.offset} />)}
        </svg>
        <div aria-hidden="true" className="absolute inset-0 flex flex-col items-center justify-center"><span className="text-3xl font-semibold tabular-nums">{total.toLocaleString()}</span><span className="mt-1 text-xs text-muted-foreground">{unit}</span></div>
      </div>
      <dl className="w-full min-w-0 flex-1 space-y-3">
        {items.map(item => <div key={item.name} className="flex items-center justify-between gap-3 text-xs">
          <dt className="flex items-center gap-2"><span aria-hidden="true" className="h-2 w-2 shrink-0 rounded-full" style={{ background: item.color }} />{item.name}</dt>
          <dd className="whitespace-nowrap tabular-nums"><span className="font-semibold">{Number(item.value || 0).toLocaleString()}</span><span className="ml-2 text-muted-foreground">{(Number(item.value || 0) / total * 100).toFixed(1)}%</span></dd>
        </div>)}
      </dl>
    </div>
  );
}
