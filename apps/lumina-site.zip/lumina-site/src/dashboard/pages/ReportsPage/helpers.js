import { C as theme } from "../../components/constants";
export const C = {
  ...theme,
  accent: "var(--admin-primary)",
  accentLight: "var(--admin-primary-soft)",
  accentText: "var(--admin-primary-text)",
  success: "var(--admin-success)",
  successBg: "var(--admin-success-soft)",
  successText: "var(--admin-success)",
  warning: "var(--admin-warning)",
  warningBg: "var(--admin-warning-soft)",
  danger: "var(--admin-danger)",
  dangerBg: "var(--admin-danger-soft)",
  border: "var(--admin-border)",
  muted: "var(--admin-muted-foreground)",
  surface: "var(--admin-background)",
  white: "var(--admin-card)",
  text: "var(--admin-foreground)",
  textSub: "var(--admin-muted-foreground)",
  textLight: "var(--admin-muted-foreground)",
};

export function formatMoney(value) {
  return (
    "$" +
    Number(value ?? 0).toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}
