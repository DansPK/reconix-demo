import ShareDonut from "../../components/ShareDonut";
import { CreditCard } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../../components/ui/card";
import ReportEmpty from "./ReportEmpty";
export default function PaymentSplit({ split }) {
  return (
    <Card className="h-full shadow-none">
      <CardHeader><CardTitle className="text-base">Payment methods</CardTitle><CardDescription>Share of successful payments by method</CardDescription></CardHeader>
      <CardContent>
        {!split.length ? <ReportEmpty icon={CreditCard} title="No payment data yet" /> : (
          <ShareDonut items={split} label="Payment mix" />
        )}
      </CardContent>
    </Card>
  );
}
