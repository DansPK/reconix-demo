import ExportControls from "../../components/ExportControls";
import { formatMoney } from "./helpers";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../../../components/ui/table";
export default function DailyTable({
  bars,
  selectedRow,
  setSelectedRow,
  onExport,
  onExportPdf,
}) {
  return (
    <Card className="min-w-0 shadow-none">
      <CardHeader className="flex-row items-center justify-between gap-3">
        <CardTitle className="text-base">Daily breakdown</CardTitle>
        <ExportControls onCsv={onExport} onPdf={onExportPdf} csvLabel="CSV export" pdfLabel="PDF export" />
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              {["Date", "Orders", "Revenue", "Avg value", "vs previous day"].map(
                (label) => (
                  <TableHead key={label}>{label}</TableHead>
                ),
              )}
            </TableRow>
          </TableHeader>
          <TableBody>
            {bars.length ? (
              bars.map((bar, index) => {
                const change = bar.change;
                return (
                  <TableRow
                    key={bar.d}
                    data-state={selectedRow === index ? "selected" : undefined}
                  >
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        aria-pressed={selectedRow === index}
                        onClick={() => setSelectedRow(index)}
                      >
                        {bar.d}
                      </Button>
                    </TableCell>
                    <TableCell>{bar.o}</TableCell>
                    <TableCell>{formatMoney(bar.v)}</TableCell>
                    <TableCell>
                      {formatMoney(bar.o ? bar.v / bar.o : 0)}
                    </TableCell>
                    <TableCell>
                      {change == null
                        ? "N/A"
                        : `${change >= 0 ? "+" : ""}${change}%`}
                    </TableCell>
                  </TableRow>
                );
              })
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="py-10 text-center">
                  No paid orders in this period yet.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
