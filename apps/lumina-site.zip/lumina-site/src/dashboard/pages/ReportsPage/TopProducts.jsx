import OrderProductImage from "../../../components/OrderProductImage";
import { Package } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../../components/ui/card";
import ReportEmpty from "./ReportEmpty";
export default function TopProducts({ products, byRevenue = false }) {
  return (
    <Card className="h-full shadow-none">
      <CardHeader><CardTitle className="text-base">Top products</CardTitle><CardDescription>{byRevenue ? "Ranked by net revenue" : "Ranked by units sold"}</CardDescription></CardHeader>
      <CardContent>
        {!products.length ? <ReportEmpty icon={Package} title="No top products yet" /> : (
          <ol className="divide-y divide-border">
            {products.map((product, index) => (
              <li key={product.productId ?? product.name} className="flex items-center gap-3 py-4">
                <div className="relative shrink-0">
                  <OrderProductImage productId={product.productId} imageUrl={product.imageUrl} name={product.name} className="h-12 w-12" />
                  <span aria-label={`Rank ${index + 1}`} className="absolute -bottom-1 -left-1 grid h-5 w-5 place-items-center rounded-full border border-border bg-background text-[10px] font-medium text-muted-foreground">{index + 1}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium leading-relaxed">{product.name}</p>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted"><div className="h-full rounded-full bg-primary" style={{ width: `${Math.max(0, Math.min(100, product.pct || 0))}%` }} /></div>
                </div>
                <span className="shrink-0 text-right text-sm font-medium tabular-nums">{byRevenue ? `$${Number(product.revenue ?? 0).toFixed(2)}` : product.units}<span className="mt-1 block text-[10px] font-normal text-muted-foreground">{product.units === 1 ? "unit" : "units"}</span></span>
              </li>
            ))}
          </ol>
        )}
      </CardContent>
    </Card>
  );
}
