import { DollarSign, ShoppingBag, Users, Receipt } from "lucide-react";
import { Card } from "../../../components/ui/card";
import { formatMoney } from "./helpers";
import Trend from "./Trend";
export default function ReportOverview({ data }) {
  const metrics = [
    { label: "New customers", value: (data.newCustomers ?? 0).toLocaleString(), trend: data.newCustomerTrend, icon: Users },
    { label: "Total revenue", value: formatMoney(data.revenue), trend: data.revTrend, icon: DollarSign },
    { label: "Paid orders", value: data.orders.toLocaleString(), trend: data.ordTrend, icon: ShoppingBag },
    { label: "Average order value", value: formatMoney(data.aov), trend: data.aovTrend, icon: Receipt },
    { label: "Paying customers", value: data.customers.toLocaleString(), trend: data.custTrend, icon: Users },
  ];
  return (
    <section aria-label="Report overview" className="stats grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {metrics.map(({ label, value, trend, icon: Icon }) => (
        <Card key={label} className="stat min-w-0 p-5 shadow-none">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 className="stat-title text-sm font-medium text-muted-foreground">{label}</h2>
            <Icon size={18} aria-hidden="true" className="shrink-0 text-muted-foreground" />
          </div>
          <p className="stat-value mb-3 break-words text-3xl font-semibold tracking-tight tabular-nums text-foreground">{value}</p>
          <Trend value={trend} />
        </Card>
      ))}
    </section>
  );
}
