import { csvRows } from "../../../lib/csv";
import { exportTablePdf } from "../../../lib/exportPdf";
import ExportControls from "../../components/ExportControls";
import AdminPageHeader from "../../components/AdminPageHeader";
import { useState } from "react";
import { useReportPeriod, useAllReportPeriods } from "../../adminReports";
import { Download, CalendarDays } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "../../../components/ui/toggle-group";
import { Skeleton } from "../../../components/ui/skeleton";
import { ResourceError } from "../../../components/ResourceFeedback";
import ReportOverview from "./ReportOverview";
import SalesTrend from "../../components/SalesTrend";
import TopProducts from "./TopProducts";
import DailyTable from "./DailyTable";
import CategoryBars from "./CategoryBars";
import PaymentSplit from "./PaymentSplit";
import PeriodTable from "./PeriodTable";

function downloadText(filename, text) {
  const blob = new Blob([text], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

export default function ReportsPage() {
  const [period, setPeriod] = useState("7d");
  const [selectedRow, setSelectedRow] = useState(0);

  const { data, loading, error, refetch } = useReportPeriod(period);
  const { periods: PERIODS, loading: comparisonLoading, error: comparisonError, refetch: refetchComparison } = useAllReportPeriods();

  const exportDailyCsv = () => {
    if (!data) return;
    const rows = ["Date,Paid Orders,Revenue,Avg Value,Vs Previous Calendar Day"];
    (data.dailyBars ?? data.bars).forEach((bar, index) => {
      const prev = (data.dailyBars ?? data.bars)[index - 1];
      const change = bar.change == null ? "N/A" : `${bar.change}%`;
      rows.push([bar.d, bar.o, bar.v, bar.o ? (bar.v / bar.o).toFixed(2) : "0.00", change].map(value => csvRows([[value]])).join(","));
    });
    downloadText("reports-daily.csv", rows.join("\n"));
  };

  const exportComparisonCsv = () => {
    const rows = [["Period","Revenue","Paid Orders","Avg Order","Paying Customers","New Customers","KHQR Share (%)"]];
    Object.keys(PERIODS).forEach((key) => {
      const item = PERIODS[key];
      if (!item) return;
      const khqrPct = item.paymentSplit.find((entry) => entry.name === "Bakong KHQR")?.pct ?? 0;
      rows.push(
        [
          item.label,
          item.revenue,
          item.orders,
          item.aov,
          item.customers,
          item.newCustomers ?? 0,
          khqrPct,
        ]
      );
    });
    downloadText("reports-comparison.csv", csvRows(rows));
  };

  const exportDailyPdf = () => exportTablePdf({ filename: "reports-daily.pdf", title: "Daily net sales", scope: `${data.label} / paid, non-cancelled orders less refunds. USD.`, sections: [{ title: "Calendar days", columns: ["Date", "Paid orders", "Net revenue (USD)", "Average order (USD)", "Vs previous day"], rows: (data.dailyBars ?? data.bars).map(bar => [bar.d, bar.o, Number(bar.v).toFixed(2), bar.o ? (bar.v / bar.o).toFixed(2) : "0.00", bar.change == null ? "N/A" : `${bar.change}%`]) }] });
  const exportComparisonPdf = () => exportTablePdf({ filename: "reports-comparison.pdf", title: "Sales period comparison", scope: "Net paid, non-cancelled orders / USD. Periods overlap; do not add them.", sections: [{ title: "Reporting periods", columns: ["Period", "Net revenue", "Paid orders", "Average order", "Paying customers", "KHQR share (%)", "New customers"], rows: Object.values(PERIODS).filter(Boolean).map(item => [item.label, Number(item.revenue).toFixed(2), item.orders, Number(item.aov).toFixed(2), item.customers, item.paymentSplit.find(entry => entry.name === "Bakong KHQR")?.pct ?? 0, item.newCustomers ?? 0]) }] });

  function selectPeriod(value) {
    if (!value) return;
    setPeriod(value);
    setSelectedRow(0);
  }

  return (
    <div className="min-w-0 bg-background p-6">
      <AdminPageHeader title="Sales reports" description="Revenue, products, and payments at a glance." actions={<>
            <ToggleGroup type="single" value={period} onValueChange={selectPeriod} aria-label="Report period" className="flex-wrap justify-start rounded-lg border border-border bg-card p-1">
              {[["7d", "7 days"], ["30d", "30 days"], ["month", "This month"], ["year", "This year"]].map(([key, label]) => (
                <ToggleGroupItem key={key} value={key} className="text-xs data-[state=on]:bg-primary/10 data-[state=on]:text-primary">{label}</ToggleGroupItem>
              ))}
            </ToggleGroup>
            <ExportControls onCsv={exportComparisonCsv} onPdf={exportComparisonPdf} disabled={comparisonLoading || !!comparisonError || !Object.values(PERIODS).some(Boolean)} />
      </>} />
      <div className="mx-auto flex max-w-[1440px] flex-col gap-6">
        <div className="flex items-center gap-2 text-xs text-muted-foreground"><CalendarDays size={15} aria-hidden="true" /><span>{data?.label || "Loading period…"}</span><span className="ml-auto hidden sm:inline">Compared with the previous period</span></div>
        {error && <ResourceError message="Could not load the selected report." retry={refetch} />}
        {loading || (!data && !error) ? (
          <div role="status" aria-label="Loading reports" className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[0, 1, 2, 3].map((key) => <Skeleton key={key} className="h-40 rounded-xl" />)}</div>
            <Skeleton className="h-80 rounded-xl" />
          </div>
        ) : data ? (
          <>
            <ReportOverview data={data} />
            <div className="grid min-w-0 gap-5 xl:grid-cols-[minmax(0,1.7fr)_minmax(0,1fr)]">
              <SalesTrend key={period} bars={data.bars} />
              <TopProducts products={data.topProducts} />
              <TopProducts products={data.topProductsByRevenue ?? []} byRevenue />
            </div>
            <div className="grid min-w-0 gap-5 lg:grid-cols-2">
              <CategoryBars categories={data.categories} />
              <PaymentSplit split={data.paymentSplit} />
            </div>
            <section className="rounded border border-border p-4"><h2 className="font-semibold">Sale merchandising revenue</h2><p className="text-xs text-muted-foreground">Overlaps category totals; do not add these figures to category revenue.</p>{data.saleBreakdown?.map(slice => <p key={slice.name}>{slice.name}: ${Number(slice.amount).toFixed(2)}</p>)}<Button variant="outline" onClick={() => downloadText("reports-details.csv",csvRows([["Section","Name","Units","Net revenue"], ...data.topProducts.map(p => ["Top units",p.name,p.units,p.revenue]), ...(data.topProductsByRevenue ?? []).map(p => ["Top revenue",p.name,p.units,p.revenue]), ...data.categories.map(p => ["Category",p.name,"",p.amount]), ...data.paymentSplit.map(p => ["Payment",p.name,"",p.amount]), ...(data.saleBreakdown ?? []).map(p => ["Sale view",p.name,"",p.amount])]))}>Export rankings and breakdowns CSV</Button></section>
            <DailyTable bars={data.dailyBars ?? data.bars} selectedRow={selectedRow} setSelectedRow={setSelectedRow} onExport={exportDailyCsv} onExportPdf={exportDailyPdf} />
          </>
        ) : null}
        {comparisonError ? <ResourceError message="Could not load the period comparison." retry={refetchComparison} /> : comparisonLoading ? <Skeleton className="h-64 rounded-xl" /> : <PeriodTable periods={PERIODS} activePeriod={period} onSelect={selectPeriod} onExport={exportComparisonCsv} onExportPdf={exportComparisonPdf} />}
      </div>
    </div>
  );
}
