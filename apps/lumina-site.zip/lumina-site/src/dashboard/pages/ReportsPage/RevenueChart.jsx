import { useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../../components/ui/card";
import { ToggleGroup, ToggleGroupItem } from "../../../components/ui/toggle-group";
import { formatMoney } from "./helpers";
import ReportEmpty from "./ReportEmpty";

const METRICS = {
  revenue: { label: "Revenue", title: "Revenue over time", value: bar => Number(bar.v || 0), format: formatMoney },
  orders: { label: "Orders", title: "Paid orders over time", value: bar => Number(bar.o || 0), format: value => Number(value).toLocaleString() },
  aov: { label: "Avg. order", title: "Average order value", value: bar => bar.o ? Number(bar.v || 0) / bar.o : 0, format: formatMoney },
};
export default function RevenueChart({ bars, hoveredBar, setHoveredBar }) {
  const [metric, setMetric] = useState("revenue");
  const config = METRICS[metric];
  const maximum = Math.max(1, ...bars.map(config.value));
  const ticks = metric === "orders" && maximum < 3 ? Array.from({ length: maximum + 1 }, (_, index) => (maximum - index) / maximum) : [1, 2 / 3, 1 / 3, 0];
  const revenue = bars.reduce((sum, bar) => sum + Number(bar.v || 0), 0);
  const orders = bars.reduce((sum, bar) => sum + Number(bar.o || 0), 0);
  const total = metric === "orders" ? orders : metric === "aov" ? (orders ? revenue / orders : 0) : revenue;
  return (
    <Card className="h-full min-w-0 shadow-none">
      <CardHeader className="flex-row flex-wrap items-start justify-between gap-4">
        <div className="flex flex-col gap-2"><CardTitle>{config.title}</CardTitle><CardDescription>Paid, non-cancelled orders · buckets with sales</CardDescription></div>
        <div className="text-right"><p className="text-xl font-semibold tabular-nums">{config.format(total)}</p><p className="mt-1 text-xs text-muted-foreground">{metric === "aov" ? "Period average" : "Period total"}</p></div>
      </CardHeader>
      <CardContent className="flex flex-col gap-5">
        <ToggleGroup type="single" value={metric} onValueChange={value => { if (value) { setMetric(value); setHoveredBar(null); } }} variant="outline" size="sm" className="justify-start" aria-label="Chart metric">
          {Object.entries(METRICS).map(([key, item]) => <ToggleGroupItem key={key} value={key}>{item.label}</ToggleGroupItem>)}
        </ToggleGroup>
        {!bars.length ? <ReportEmpty /> : <>
          <div className="overflow-x-auto pb-2">
            <div className="relative pl-16" style={{ minWidth: Math.max(420, bars.length * 30 + 64) }}>
              <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 top-4 flex h-[180px] flex-col justify-between">
                {ticks.map(fraction => <div key={fraction} className="flex items-center gap-3"><span className="w-14 shrink-0 text-right text-[10px] tabular-nums text-muted-foreground">{config.format(metric === "orders" ? Math.round(maximum * fraction) : maximum * fraction)}</span><div className="flex-1 border-t border-dashed border-border" /></div>)}
              </div>
              <div className="relative flex items-end gap-2">
                {bars.map((bar, index) => <div key={bar.d} className="flex min-w-0 flex-1 flex-col items-center">
                  <button type="button" aria-label={`${bar.d}: ${config.format(config.value(bar))}, ${bar.o} ${bar.o === 1 ? "order" : "orders"}`}
                    onMouseEnter={() => setHoveredBar(index)} onMouseLeave={() => setHoveredBar(null)} onFocus={() => setHoveredBar(index)} onBlur={() => setHoveredBar(null)}
                    className="group relative flex h-[196px] w-full items-end justify-center rounded-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    title={`${bar.d}: ${config.format(config.value(bar))}`}>
                    {hoveredBar === index && <span className="absolute top-0 whitespace-nowrap rounded-md bg-foreground px-2 py-1 text-[10px] text-background">{config.format(config.value(bar))}</span>}
                    <span className="block w-full max-w-10 rounded-t-md bg-primary/80 transition-colors group-hover:bg-primary" style={{ height: Math.max(2, config.value(bar) / maximum * 180) }} />
                  </button><span className="mt-3 max-w-full truncate text-[10px] text-muted-foreground">{bar.d}</span>
                </div>)}
              </div>
            </div>
          </div>
          <details className="text-sm"><summary className="cursor-pointer text-muted-foreground">View chart data</summary><div className="mt-3 overflow-auto"><table className="w-full"><caption className="sr-only">Paid sales by reported bucket</caption><thead><tr><th className="p-2">Date</th><th className="p-2">Revenue</th><th className="p-2">Paid orders</th><th className="p-2">Average order</th></tr></thead><tbody>{bars.map(bar => <tr key={bar.d} className="border-t border-border"><td className="p-2">{bar.d}</td><td className="p-2 tabular-nums">{formatMoney(bar.v)}</td><td className="p-2 tabular-nums">{bar.o}</td><td className="p-2 tabular-nums">{formatMoney(METRICS.aov.value(bar))}</td></tr>)}</tbody></table></div></details>
        </>}
      </CardContent>
    </Card>
  );
}
