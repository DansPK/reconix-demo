import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
export default function Trend({ value }) {
  if (value == null) return <p className="text-xs text-muted-foreground">N/A · no previous-period baseline</p>;
  const Icon = value > 0 ? ArrowUpRight : value < 0 ? ArrowDownRight : Minus;
  return (
    <div className="stat-desc flex flex-wrap items-center gap-1 text-xs">
      <span className={`inline-flex items-center gap-1 font-medium ${value > 0 ? "text-emerald-700" : value < 0 ? "text-destructive" : "text-muted-foreground"}`}>
        <Icon size={14} aria-hidden="true" />{value > 0 ? "+" : ""}{value}%
      </span>
      <span className="text-muted-foreground">vs. previous period</span>
    </div>
  );
}
