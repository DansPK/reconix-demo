import ShareDonut from "../../components/ShareDonut";
import { Tags } from "lucide-react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../../components/ui/card";
import ReportEmpty from "./ReportEmpty";
export default function CategoryBars({ categories }) {
  return (
    <Card className="h-full shadow-none">
      <CardHeader><CardTitle className="text-base">Revenue by category</CardTitle><CardDescription>Share of revenue across your collections</CardDescription></CardHeader>
      <CardContent>
        {!categories.length ? <ReportEmpty icon={Tags} title="No category revenue yet" /> : (
          <ShareDonut items={categories} label="Revenue mix" />
        )}
      </CardContent>
    </Card>
  );
}
