import ExportControls from "../../components/ExportControls";
import { formatMoney } from "./helpers";
import {
  Card,
  CardHeader,
  CardTitle,
  CardContent,
} from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "../../../components/ui/table";
export default function PeriodTable({
  periods,
  activePeriod,
  onSelect,
  onExport,
  onExportPdf,
}) {
  const rows = [
    ["7d", "Last 7 days"],
    ["30d", "Last 30 days"],
    ["month", "This month"],
    ["year", "This year"],
  ];
  return (
    <Card className="min-w-0 shadow-none">
      <CardHeader className="flex-row items-center justify-between gap-3">
        <CardTitle className="text-base">Period comparison</CardTitle>
        <ExportControls onCsv={onExport} onPdf={onExportPdf} csvLabel="Export" pdfLabel="PDF" />
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              {[
                "Period",
                "Revenue",
                "Paid orders",
                "Avg order",
                "Paying customers",
                "KHQR share",
              ].map((label) => (
                <TableHead key={label}>{label}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map(([key, label]) => {
              const data = periods[key];
              if (!data) return null;
              const khqr =
                data.paymentSplit.find((entry) => entry.name === "Bakong KHQR")
                  ?.pct ?? 0;
              return (
                <TableRow
                  key={key}
                  data-state={activePeriod === key ? "selected" : undefined}
                >
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      aria-pressed={activePeriod === key}
                      onClick={() => onSelect(key)}
                    >
                      {label}
                    </Button>
                  </TableCell>
                  <TableCell>{formatMoney(data.revenue)}</TableCell>
                  <TableCell>{data.orders}</TableCell>
                  <TableCell>{formatMoney(data.aov)}</TableCell>
                  <TableCell>{data.customers}</TableCell>
                  <TableCell>{khqr}%</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
