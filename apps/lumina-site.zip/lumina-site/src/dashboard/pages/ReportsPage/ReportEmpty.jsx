import { BarChart3 } from "lucide-react";
export default function ReportEmpty({ title = "No paid orders yet", description = "Paid orders in this period will appear here.", icon: Icon = BarChart3 }) {
  return (
    <div className="flex min-h-48 flex-col items-center justify-center gap-3 px-4 py-8 text-center">
      <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-border bg-muted/50 text-muted-foreground"><Icon size={20} aria-hidden="true" /></div>
      <p className="text-sm font-medium text-foreground">{title}</p>
      <p className="max-w-64 text-xs leading-relaxed text-muted-foreground">{description}</p>
    </div>
  );
}
