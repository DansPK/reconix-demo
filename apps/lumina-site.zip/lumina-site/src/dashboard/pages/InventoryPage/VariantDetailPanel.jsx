import { StatusBadge } from "./StatusBadge";
import { ActionButton } from "./ActionButton";

export function VariantDetailPanel({ selected, selectedStatus, openStockAction, canAdjust = true }) {
  const statusTone = selectedStatus === "healthy" ? "success" : selectedStatus === "low" ? "warning" : "danger";
  return (
    <section className="rounded-xl border bg-card p-5 text-card-foreground" aria-label="Selected variant">
      {selected ? (
        <>
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0 flex-1">
              <h3 className="text-sm font-medium leading-6">{selected.name}</h3>
              <p className="mt-1 text-xs text-muted-foreground">{selected.size} / {selected.color} · {selected.location}</p>
            </div>
            <StatusBadge
              label={selectedStatus === "healthy" ? "Healthy" : selectedStatus === "low" ? "Low stock" : "Out of stock"}
              tone={statusTone}
            />
          </div>

          <div className="my-5 flex flex-wrap items-center justify-between gap-4 border-y py-5">
            <div>
              <p className="text-xs text-muted-foreground">Available units</p>
              <p className="mt-1 text-3xl font-semibold tracking-tight tabular-nums">{selected.available}</p>
              <p className="mt-2 text-xs text-muted-foreground">
                <span className="font-medium text-foreground">{selected.stock}</span> on hand
                <span className="mx-2" aria-hidden="true">·</span>
                <span className="font-medium text-foreground">{selected.reserved}</span> reserved
              </p>
            </div>
            {canAdjust && <ActionButton label="Adjust stock" onClick={() => openStockAction("adjust")} color="primary" />}
          </div>

          <details className="group">
            <summary className="cursor-pointer text-xs font-medium text-muted-foreground transition-colors hover:text-foreground">Variant details</summary>
            <dl className="mt-4 space-y-3 text-xs">
              {[
                ["SKU", selected.sku],
                ["Category", [selected.category, selected.subCategory].filter(Boolean).join(" / ")],
                ["Supplier", selected.supplier],
                ["Reorder point", `${selected.reorderPoint} units`],
              ].map(([label, value]) => (
                <div key={label} className="grid grid-cols-[90px_minmax(0,1fr)] gap-3">
                  <dt className="text-muted-foreground">{label}</dt>
                  <dd className="break-words text-right">{value || "—"}</dd>
                </div>
              ))}
            </dl>
          </details>
        </>
      ) : (
        <p className="text-sm text-muted-foreground">No variant selected.</p>
      )}
    </section>
  );
}
