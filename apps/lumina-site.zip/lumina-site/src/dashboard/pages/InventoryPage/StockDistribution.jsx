import { ArrowRight, CheckCircle2, TriangleAlert } from "lucide-react";
import { Button } from "../../../components/ui/button";

export default function StockDistribution({ total, outOfStock, lowStock, onSelect }) {
  const segments = [
    { key: "out", label: "Out of stock", value: outOfStock, tone: "danger" },
    { key: "low", label: "Low stock", value: lowStock, tone: "warning" },
    { key: "healthy", label: "Healthy", value: Math.max(0, total - outOfStock - lowStock), tone: "success" },
  ].map(segment => ({ ...segment, share: total > 0 ? segment.value / total * 100 : 0 }));

  if (!total) return <p className="py-8 text-center text-sm text-muted-foreground">No variants to display.</p>;
  const attention = outOfStock + lowStock;
  const Icon = attention ? TriangleAlert : CheckCircle2;
  const priority = outOfStock ? "out" : "low";

  return (
    <div className="grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)] lg:gap-8">
      <div className="flex flex-col justify-center border-b pb-5 lg:border-b-0 lg:border-r lg:pb-0 lg:pr-6">
        <p className="flex items-center gap-2 text-xs font-medium text-muted-foreground"><Icon size={15} style={{ color: `var(--admin-${attention ? "warning" : "success"})` }} aria-hidden="true" />{attention ? "Needs attention" : "Stock is healthy"}</p>
        <p className="mt-2 text-4xl font-semibold tracking-tight tabular-nums">{attention.toLocaleString()}<span className="ml-2 text-xs font-normal tracking-normal text-muted-foreground">variants</span></p>
        <p className="mt-2 text-xs text-muted-foreground">{(attention / total * 100).toFixed(1)}% of the loaded catalog</p>
        {attention > 0 && onSelect && <Button size="sm" variant="link" className="mt-3 h-auto justify-start self-start p-0 text-xs" onClick={() => onSelect(priority)}>Review {outOfStock ? "out of stock" : "low stock"}<ArrowRight aria-hidden="true" /></Button>}
      </div>
      <div className="min-w-0">
        <div className="mb-2 flex justify-between text-[11px] text-muted-foreground"><span>Status</span><span>Variants · share</span></div>
        <ul className="space-y-1" aria-label="Stock distribution">
          {segments.map(segment => {
            const content = <>
              <span className="flex items-center justify-between gap-3 text-xs">
                <span className="flex items-center gap-2 font-medium"><span aria-hidden="true" className="h-2 w-2 shrink-0 rounded-full" style={{ background: `var(--admin-${segment.tone})` }} />{segment.label}</span>
                <span className="whitespace-nowrap tabular-nums"><span className="font-semibold">{segment.value.toLocaleString()}</span><span className="ml-3 inline-block w-12 text-right text-muted-foreground">{segment.share.toFixed(1)}%</span></span>
              </span>
              <span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-muted" aria-hidden="true"><span className="block h-full rounded-full" style={{ width: `${segment.share}%`, background: `var(--admin-${segment.tone})` }} /></span>
            </>;
            return <li key={segment.key}>{onSelect ? (
              <button type="button" aria-label={`View ${segment.value} ${segment.label.toLowerCase()} variants`} className="block w-full rounded-md px-2 py-3 text-left transition-colors hover:bg-muted/50" onClick={() => onSelect(segment.key)}>{content}</button>
            ) : <div className="px-2 py-3">{content}</div>}</li>;
          })}
        </ul>
        <p className="mt-2 px-2 text-[11px] text-muted-foreground">Each bar represents its share of all {total.toLocaleString()} variants.</p>
      </div>
    </div>
  );
}
