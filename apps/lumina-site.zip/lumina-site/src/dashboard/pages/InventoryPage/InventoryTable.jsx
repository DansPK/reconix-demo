import { useEffect, useState } from "react";
import { Button } from "../../../components/ui/button";
import OrderProductImage from "../../../components/OrderProductImage";
import { inventoryStatus } from "./helpers";
import { StatusBadge } from "./StatusBadge";
const PAGE_SIZE = 10;
export function InventoryTable({ filtered, selected, setSelectedId, onView, onAdjust, canAdjust = true }) {
  const key = filtered.map(item => item.id).join(",");
  const [pagination, setPagination] = useState({ key, page: 1 });
  useEffect(() => { setPagination(previous => previous.key === key ? previous : { key, page: 1 }); }, [key]);
  const pages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const page = pagination.key === key ? Math.min(pagination.page, pages) : 1;
  const offset = (page - 1) * PAGE_SIZE;
  const rows = filtered.slice(offset, offset + PAGE_SIZE);
  const changePage = next => { setPagination({ key, page: next }); const row = filtered[(next - 1) * PAGE_SIZE]; if (row) setSelectedId(row.id); };
  return <div>
    <div className="inventory-row-grid hidden gap-3 border-b bg-muted/30 px-4 py-3 text-xs text-muted-foreground xl:grid">
      {['Product / variant', 'Available', 'Reserved', 'On hand', 'Status', 'Location', 'Actions'].map(label => <span key={label}>{label}</span>)}
    </div>
    <div className="divide-y">
      {rows.map(item => {
        const status = inventoryStatus(item);
        return <article key={item.id} aria-label={`${item.name} ${item.size} ${item.color}`} className={`inventory-row-grid grid grid-cols-2 items-center gap-3 px-4 py-4 ${selected?.id === item.id ? 'bg-primary/5' : ''}`}>
          <div className="col-span-2 flex min-w-0 items-center gap-3 xl:col-span-1">
            <OrderProductImage productId={item.productId} imageUrl={item.imageUrl} name={item.name} className="h-12 w-12" />
            <div className="min-w-0"><button type="button" onClick={() => { setSelectedId(item.id); onView?.(item); }} className="block break-words text-left text-sm font-medium hover:underline">{item.name}</button><p className="mt-0.5 text-xs text-muted-foreground">{item.size} · {item.color}</p><p className="mt-0.5 break-all text-[10px] text-muted-foreground">{item.sku}</p></div>
          </div>
          {[['Available', item.available ?? item.stock - item.reserved], ['Reserved', item.reserved], ['On hand', item.stock]].map(([label,value]) => <div key={label} className="text-sm tabular-nums"><span className="mb-1 block text-[10px] text-muted-foreground xl:hidden">{label}</span>{value}</div>)}
          <div><StatusBadge label={status === 'healthy' ? 'Healthy' : status === 'low' ? 'Low stock' : 'Out of stock'} tone={status} /></div>
          <div className="min-w-0 text-xs text-muted-foreground"><span className="mb-1 block text-[10px] xl:hidden">Location</span><span className="break-words">{item.location}</span></div>
          <div className="col-span-2 flex flex-wrap gap-2 border-t pt-3 xl:col-span-1 xl:border-0 xl:pt-0">{canAdjust && <Button variant="outline" size="sm" onClick={() => { setSelectedId(item.id); onAdjust?.(item); }}>Adjust stock</Button>}<Button variant="ghost" size="sm" aria-label={`Details for ${item.name} ${item.size} ${item.color}`} onClick={() => { setSelectedId(item.id); onView?.(item); }}>Details</Button></div>
        </article>;
      })}
      {!rows.length && <p className="px-4 py-12 text-center text-sm text-muted-foreground">No variants match your filters.</p>}
    </div>
    <nav aria-label="Stock overview pagination" className="flex flex-wrap items-center justify-between gap-3 border-t p-4">
      <p className="text-xs text-muted-foreground" aria-live="polite">Showing {filtered.length ? offset + 1 : 0}–{Math.min(offset + PAGE_SIZE, filtered.length)} of {filtered.length} {filtered.length === 1 ? "variant" : "variants"}</p>
      <div className="flex items-center gap-2"><Button variant="outline" size="sm" disabled={page === 1} onClick={() => changePage(page-1)}>Previous</Button><span className="text-xs text-muted-foreground">Page {page} of {pages}</span><Button variant="outline" size="sm" disabled={page === pages} onClick={() => changePage(page+1)}>Next</Button></div>
    </nav>
  </div>;
}
