export function fmtMoney(value) {
  return "$" + Number(value ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** Product + variant -> one row. Inventory metadata (supplier, location, reorder point,
 * cost) lives on the variant now, not a separate mock table - this is why a row is a
 * variant and not a product: only variants can be edited per colour and size. */
export function toInventoryRows(products) {
  return products.flatMap((product) =>
    (product.variants ?? []).map((variant) => ({
      id: variant.id,
      productId: product.id,
      name: product.name,
      imageUrl: product.image || product.images?.[0],
      sku: variant.sku || product.sku,
      category: product.cat,
      subCategory: product.subCat,
      size: variant.size || "-",
      color: variant.color || "-",
      location: variant.location || "—",
      supplier: variant.supplier || "—",
      stock: Number(variant.stock ?? 0),
      reserved: Number(variant.reserved ?? 0),
      available: Number(variant.available ?? Math.max(0, Number(variant.stock ?? 0))),
      reorderPoint: Number(variant.reorderPoint ?? 0),
      cost: variant.costPrice ?? 0,
      price: product.price,
    }))
  );
}

export function inventoryStatus(item) {
  const available = item.available ?? Math.max(0, item.stock);
  return available <= 0 ? "out" : available <= item.reorderPoint ? "low" : "healthy";
}
