import { C } from "./colors";

export function StatusBadge({ label, tone }) {
  const semanticTone = { healthy: "success", low: "warning", out: "danger" }[tone] || tone;
  const styles =
    semanticTone === "success"
      ? { background: C.successBg, color: C.successText }
      : semanticTone === "warning"
        ? { background: C.warningBg, color: C.warningText }
        : semanticTone === "danger"
          ? { background: C.dangerBg, color: C.dangerText }
          : { background: C.surface, color: C.textLight };
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        minWidth: 70,
        padding: "4px 8px",
        borderRadius: 999,
        fontSize: "0.78571rem",
        fontWeight: 400,
        ...styles,
      }}
    >
      {label}
    </span>
  );
}
