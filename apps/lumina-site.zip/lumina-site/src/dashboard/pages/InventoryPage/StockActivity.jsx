import { useState } from "react";
import { Button } from "../../../components/ui/button";
import { useResource } from "../../../hooks/useResource";
import { getVariantMovements } from "../../../api/admin";
import { ResourceError } from "../../../components/ResourceFeedback";
export default function StockActivity({ variantId }) {
  const [page, setPage] = useState(0);
  const { data, loading, error, refetch } = useResource(variantId ? `/v1/admin/inventory/variants/${variantId}/movements?page=${page}` : null, () => getVariantMovements(variantId, { size: 10, page }));
  const rows = data?.content || [];
  return <section className="rounded-xl border bg-card p-4"><h3 className="text-sm font-medium">Stock movement history</h3>
    {error ? <ResourceError message="Could not load stock activity." retry={refetch} /> : loading ? <p className="mt-3 text-xs text-muted-foreground">Loading activity…</p> : !rows.length ? <p className="mt-3 text-xs text-muted-foreground">No stock movements recorded.</p> : <ul className="mt-3 divide-y">{rows.map(row => <li key={row.id} className="flex items-start justify-between gap-3 py-3"><div className="min-w-0"><p className="text-xs capitalize">{row.reason?.replaceAll("_", " ")}</p><p className="text-xs">{row.note}</p><p className="text-xs text-muted-foreground">Changed by {row.createdBy ?? "system"}</p><p className="mt-1 text-[10px] text-muted-foreground">{new Intl.DateTimeFormat("en", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Phnom_Penh" }).format(new Date(row.timestamp))}</p></div><span className="text-sm tabular-nums">{row.quantity > 0 ? "+" : ""}{row.quantity}</span></li>)}</ul>}
    {data?.totalPages > 1 && <nav aria-label="Stock history pages" className="mt-3 flex gap-3"><Button disabled={!page} variant="outline" onClick={() => setPage(page-1)}>Previous</Button><span>{page+1} / {data.totalPages}</span><Button disabled={data.last} variant="outline" onClick={() => setPage(page+1)}>Next</Button></nav>}
  </section>;
}
