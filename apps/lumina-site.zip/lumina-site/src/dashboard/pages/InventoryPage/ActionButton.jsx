import { C } from "./colors";

export function ActionButton({ label, onClick, color = "default" }) {
  const isPrimary = color === "primary";
  const isWarning = color === "warning";
  const isSuccess = color === "success";
  const isTeal = color === "teal";
  const isDanger = color === "danger";
  return (
    <button
      onClick={onClick}
      style={{
        border: "1px solid " + (isDanger ? "var(--admin-danger-soft)" : isPrimary ? "var(--admin-primary-soft)" : isWarning ? "var(--admin-warning-soft)" : isSuccess ? "var(--admin-success-soft)" : isTeal ? "var(--admin-success-soft)" : C.border),
        background: isDanger ? C.dangerBg : isPrimary ? C.accentLight : isWarning ? "var(--admin-warning-soft)" : isSuccess ? "var(--admin-success-soft)" : isTeal ? "var(--admin-success-soft)" : C.white,
        color: isDanger ? C.dangerText : isPrimary ? C.accentText : isWarning ? "var(--admin-warning)" : isSuccess ? C.successText : isTeal ? "var(--admin-success)" : C.textLight,
        borderRadius: 8,
        padding: "8px 12px",
        fontSize: "0.85714rem",
        fontWeight: 600,
        cursor: "pointer",
      }}
    >
      {label}
    </button>
  );
}
