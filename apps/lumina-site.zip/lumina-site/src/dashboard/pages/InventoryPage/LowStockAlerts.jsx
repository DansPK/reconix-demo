import { useState } from "react";
import { ArrowRight, CheckCircle2, CircleX, TriangleAlert } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../../components/ui/tabs";

const PREVIEW_SIZE = 3;

export function LowStockAlerts({ lowStockItems, outStockItems, onReview, onViewAll }) {
  const [tab, setTab] = useState(null);
  const active = tab ?? (outStockItems.length ? "out" : "low");
  const total = lowStockItems.length + outStockItems.length;
  const groups = [
    { key: "out", label: "Out of stock", items: outStockItems, tone: "danger", Icon: CircleX },
    { key: "low", label: "Low stock", items: lowStockItems, tone: "warning", Icon: TriangleAlert },
  ];

  return (
    <section className="rounded-xl border bg-card p-5 text-card-foreground" aria-label="Stock alerts">
      <div className="flex items-center justify-between gap-3">
        <h3 className="text-sm font-semibold">Stock alerts</h3>
        <span className="rounded-full bg-muted px-2 py-1 text-xs tabular-nums text-muted-foreground">{total} affected</span>
      </div>
      {!total ? (
        <div className="flex items-center gap-2 pt-5 text-sm text-muted-foreground">
          <CheckCircle2 size={18} style={{ color: "var(--admin-success)" }} aria-hidden="true" />All variants are above their reorder point.
        </div>
      ) : (
        <Tabs value={active} onValueChange={setTab} className="mt-4">
          <TabsList className="grid h-auto grid-cols-2" aria-label="Alert severity">
            {groups.map(group => (
              <TabsTrigger key={group.key} value={group.key} className="gap-2 px-2 py-2 text-xs">
                {group.label}<span className="tabular-nums" style={{ color: `var(--admin-${group.tone})` }}>{group.items.length}</span>
              </TabsTrigger>
            ))}
          </TabsList>
          {groups.map(({ key, label, items, tone, Icon }) => (
            <TabsContent key={key} value={key} className="mt-3">
              <ul className="divide-y">
                {items.slice(0, PREVIEW_SIZE).map(item => (
                  <li key={item.id}>
                    <button type="button" onClick={() => onReview(item)} aria-label={`Review ${item.name}, ${item.size}/${item.color}`} className="flex w-full items-start gap-3 rounded-md px-1 py-3 text-left transition-colors hover:bg-muted">
                      <Icon size={16} className="mt-0.5 shrink-0" style={{ color: `var(--admin-${tone})` }} aria-hidden="true" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-medium" title={item.name}>{item.name}</p>
                        <p className="mt-1 text-xs text-muted-foreground">{item.size} / {item.color} · {item.location}</p>
                      </div>
                      <span className="shrink-0 text-right text-xs" style={{ color: `var(--admin-${tone})` }}>
                        <span className="font-semibold tabular-nums">{item.stock} left</span>
                        <span className="mt-1 block text-[11px] text-muted-foreground">Min. {item.reorderPoint}</span>
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
              {!items.length && <p className="py-5 text-center text-xs text-muted-foreground">No {label.toLowerCase()} variants.</p>}
              {items.length > 0 && (
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t pt-3">
                  <p className="text-xs text-muted-foreground">Showing {Math.min(PREVIEW_SIZE, items.length)} of {items.length}</p>
                  <Button variant="ghost" size="sm" className="text-xs" onClick={() => onViewAll(key)}>View all<ArrowRight aria-hidden="true" /></Button>
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      )}
    </section>
  );
}
