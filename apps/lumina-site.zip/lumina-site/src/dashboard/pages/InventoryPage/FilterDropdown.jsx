import StyledSelect from "../../../components/ui/styled-select";

export default function FilterDropdown({ label, value, onChange, options }) {
  return (
    <div className="min-w-0">
      <span className="mb-2 block text-xs font-medium text-muted-foreground">{label}</span>
      <StyledSelect
        ariaLabel={label}
        value={value}
        onValueChange={onChange}
        options={options}
        placeholder="All"
        className="h-10 text-xs"
        contentClassName="max-h-64 min-w-48"
      />
    </div>
  );
}
