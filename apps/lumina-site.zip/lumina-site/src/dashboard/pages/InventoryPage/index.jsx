import { invalidate } from "../../../hooks/useResource";
import { exportTablePdf } from "../../../lib/exportPdf";
import ExportControls from "../../components/ExportControls";
import AdminPageHeader from "../../components/AdminPageHeader";
import { csvValue } from "../../../lib/utils";
import { usePageFilters } from "../../usePageFilters";
import { Plus, CheckCircle2 } from "lucide-react";
import { useAuth } from "../../../auth/AuthContext";
import { Button } from "../../../components/ui/button";
import { ToggleGroup, ToggleGroupItem } from "../../../components/ui/toggle-group";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "../../../components/ui/sheet";

import { ResourceError, ResourceLoading } from "../../../components/ResourceFeedback";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDashboardData } from "../../DashboardDataContext";
import * as adminApi from "../../../api/admin";
import { ApiError } from "../../../api/client";
import { toInventoryRows, inventoryStatus } from "./helpers";

import { InventoryOverview } from "./InventoryOverview";
import { FilterBar } from "./FilterBar";
import { InventoryTable } from "./InventoryTable";
import { VariantDetailPanel } from "./VariantDetailPanel";
import StockActivity from "./StockActivity";
import { AdjustStockModal } from "./AdjustStockModal";

export default function InventoryPage() {
  const { isAdmin } = useAuth();
  const [detailOpen, setDetailOpen] = useState(false);
  const [success, setSuccess] = useState("");
  const navigate = useNavigate();
  const { products, catalog } = useDashboardData();
  const [filters, updateFilters] = usePageFilters({"q": "", "status": "all", "category": "all", "location": "all", "sort": "attention"});
  const query = filters.q;
  const setQuery = value => updateFilters({ q: value });
  const statusFilter = filters.status;
  const categoryFilter = filters.category;
  const setCategoryFilter = value => updateFilters({ category: value });
  const locationFilter = filters.location;
  const setLocationFilter = value => updateFilters({ location: value });




  const [selectedId, setSelectedId] = useState(null);
  const [stockAction, setStockAction] = useState(null);
  const [stockDirection, setStockDirection] = useState("add");
  const [stockAmount, setStockAmount] = useState("");
  const [stockReason, setStockReason] = useState("restock");
  const [stockNote, setStockNote] = useState("");
  const [stockError, setStockError] = useState("");
  const [saving, setSaving] = useState(false);

  const inventoryRows = useMemo(() => toInventoryRows(products), [products]);

  const categories = ["all"].concat(Array.from(new Set(inventoryRows.map((item) => item.category))));
  const locations = ["all"].concat(Array.from(new Set(inventoryRows.map((item) => item.location))));

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return inventoryRows.filter((item) => {
      const stockStatus = inventoryStatus(item);
      const matchesQuery =
        !q ||
        item.name.toLowerCase().includes(q) ||
        item.sku.toLowerCase().includes(q) ||
        String(item.subCategory || "").toLowerCase().includes(q) ||
        String(item.category || "").toLowerCase().includes(q) ||
        item.size.toLowerCase().includes(q) || item.color.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "all" || stockStatus === statusFilter;
      const matchesCategory = categoryFilter === "all" || item.category === categoryFilter;
      const matchesLocation = locationFilter === "all" || item.location === locationFilter;
      return matchesQuery && matchesStatus && matchesCategory && matchesLocation;
    }).sort((a, b) => {
      if (filters.sort === "name") return a.name.localeCompare(b.name) || a.sku.localeCompare(b.sku);
      if (filters.sort === "lowest") return a.available - b.available;
      if (filters.sort === "highest") return b.available - a.available;
      const priority = { out: 0, low: 1, healthy: 2 };
      return priority[inventoryStatus(a)] - priority[inventoryStatus(b)] || a.available - b.available || a.name.localeCompare(b.name);
    });
  }, [query, statusFilter, categoryFilter, locationFilter, filters.sort, inventoryRows]);

  const selected = inventoryRows.find(item => item.id === selectedId) || null;

  const totals = useMemo(() => {
    const totalUnits = inventoryRows.reduce((sum, item) => sum + item.stock, 0);
    const lowStock = inventoryRows.filter((item) => inventoryStatus(item) === "low").length;
    const outOfStock = inventoryRows.filter((item) => inventoryStatus(item) === "out").length;
    const inventoryValue = inventoryRows.reduce((sum, item) => sum + item.stock * item.cost, 0);
    return { totalUnits, lowStock, outOfStock, inventoryValue };
  }, [inventoryRows]);

  const showInventoryStatus = status => { updateFilters({ status }); setSelectedId(null); };
  const selectedStatus = selected ? inventoryStatus(selected) : null;
  const hasFilters = Boolean(query || statusFilter !== "all" || categoryFilter !== "all" || locationFilter !== "all" || filters.sort !== "attention");
  const clearFilters = () => updateFilters({ q: "", status: "all", category: "all", location: "all", sort: "attention" });
  const openStockAction = (action) => {
    setStockAction(action);
    setStockDirection("add");
    setStockAmount("");
    setStockNote("");
    setStockError("");
  };

  const submitStockAction = async (event) => {
    event.preventDefault();
    if (saving || !isAdmin) return;
    const amount = Number(stockAmount);
    if (!selected || !Number.isInteger(amount) || amount <= 0) { setStockError("Enter a whole number greater than zero."); return; }
    if (stockDirection === "remove" && amount > selected.available) { setStockError(`You can remove at most ${selected.available} available units. Stock already committed at checkout has been deducted.`); return; }

    const delta = stockDirection === "remove" ? -amount : amount;
    setSaving(true);
    setStockError("");
    try {
      await adminApi.adjustStock(selected.id, {
        quantity: delta,
        reason: stockReason,
        note: stockNote || undefined,
      });
      invalidate(`/v1/admin/inventory/variants/${selected.id}/movements`);
      catalog.refreshAll();
      setSuccess(`Stock updated for ${selected.name} · ${selected.size} / ${selected.color}.`);
      setStockAction(null);
    } catch (error) {
      setStockError(error instanceof ApiError ? error.detail : "Could not adjust stock.");
    } finally {
      setSaving(false);
    }
  };

  const exportPdf = () => exportTablePdf({
    filename: "inventory.pdf", title: "Inventory report",
    scope: `Loaded inventory / ${filtered.length} matching variants. Status: ${statusFilter}; category: ${categoryFilter}; location: ${locationFilter}; search: ${query || "none"}.`,
    sections: [
      { title: "Stock levels", columns: ["Variant ID", "Product", "SKU", "Size / Colour", "Stock", "Reserved", "Available", "Status"], rows: filtered.map(item => [item.id, item.name, item.sku, `${item.size} / ${item.color}`, item.stock, item.reserved, item.available, inventoryStatus(item) === "out" ? "Out of stock" : inventoryStatus(item) === "low" ? "Low stock" : "Healthy"]) },
      { title: "Inventory details", columns: ["Variant ID", "Category", "Sub-category", "Reorder point", "Location", "Supplier"], rows: filtered.map(item => [item.id, item.category, item.subCategory, item.reorderPoint, item.location, item.supplier]) },
    ],
  });

  const exportCsv = () => {
    const rows = ["Variant ID,Product,SKU,Size,Color,Category,Sub Category,Stock,Reserved,Available,Reorder Point,Location,Supplier,Status"];
    filtered.forEach((item) => {
      const status = inventoryStatus(item) === "out" ? "Out of stock" : inventoryStatus(item) === "low" ? "Low stock" : "Healthy";
      rows.push(
        [
          item.id, item.name, item.sku, item.size, item.color, item.category, item.subCategory,
          item.stock, item.reserved, item.available, item.reorderPoint, item.location, item.supplier, status,
        ].map(csvValue).join(",")
      );
    });

    const blob = new Blob([rows.join("\n")], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "inventory.csv";
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-w-0 bg-background p-6">
      <AdminPageHeader title="Inventory" description="Find a variant, review available stock, and record adjustments." actions={<>
        <ExportControls onCsv={exportCsv} onPdf={exportPdf} disabled={catalog.loading || !!catalog.error} />
        {isAdmin && <Button onClick={() => navigate("/dashboard/products", { state: { create: true } })}><Plus size={16} aria-hidden="true" />Add product</Button>}
      </>} />
      <div className="space-y-5">
        {success && <p role="status" className="flex items-center gap-2 rounded-lg border bg-card px-4 py-3 text-sm"><CheckCircle2 size={16} className="shrink-0 text-emerald-700" aria-hidden="true" />{success}</p>}
        {catalog.error ? <ResourceError message="Could not load inventory." retry={catalog.refreshAll} /> : catalog.loading ? <ResourceLoading /> : <>
          <InventoryOverview totals={totals} onSelect={showInventoryStatus} />
          <section className="min-w-0 overflow-hidden rounded-xl border bg-card" aria-label="Inventory workspace">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b p-4">
              <ToggleGroup type="single" value={statusFilter} onValueChange={value => { if (value) showInventoryStatus(value); }} aria-label="Inventory stock view" variant="outline" className="flex-wrap justify-start">
                {[["all", "All variants", inventoryRows.length], ["out", "Out of stock", totals.outOfStock], ["low", "Low stock", totals.lowStock], ["healthy", "Healthy", inventoryRows.length - totals.outOfStock - totals.lowStock]].map(([value, label, count]) => <ToggleGroupItem key={value} value={value} className="gap-2 text-xs font-normal">{label}<span className="text-[10px] tabular-nums text-muted-foreground">{count}</span></ToggleGroupItem>)}
              </ToggleGroup>
              <p className="text-[11px] text-muted-foreground">{inventoryRows.length} loaded {inventoryRows.length === 1 ? "variant" : "variants"} · stock alerts use available units</p>
            </div>
            <FilterBar query={query} setQuery={setQuery} categoryFilter={categoryFilter} setCategoryFilter={setCategoryFilter} locationFilter={locationFilter} setLocationFilter={setLocationFilter} categories={categories} locations={locations} sort={filters.sort} setSort={value => updateFilters({ sort: value })} hasFilters={hasFilters} onClear={clearFilters} />
            <InventoryTable filtered={filtered} selected={selected} setSelectedId={setSelectedId} canAdjust={isAdmin} onView={() => setDetailOpen(true)} onAdjust={() => { setDetailOpen(false); openStockAction("adjust"); }} />
          </section>
          <p className="text-[11px] leading-5 text-muted-foreground">Available = on hand − reserved. Reserved units are already committed to orders. Export includes the current filtered list.</p>
        </>}
      </div>
      <Sheet open={detailOpen} onOpenChange={setDetailOpen}>
        <SheetContent className="flex w-[min(440px,calc(100vw-1rem))] max-w-none flex-col p-4 sm:max-w-none sm:p-5">
          <SheetHeader className="pr-8"><SheetTitle className="text-base font-medium">Variant details</SheetTitle><SheetDescription>Stock, warehouse information, and recent activity.</SheetDescription></SheetHeader>
          <div className="mt-4 min-h-0 space-y-4 overflow-y-auto">
            <VariantDetailPanel selected={selected} selectedStatus={selectedStatus} canAdjust={isAdmin} openStockAction={() => { setDetailOpen(false); openStockAction("adjust"); }} />
            <StockActivity variantId={detailOpen ? selected?.id : null} />
          </div>
        </SheetContent>
      </Sheet>
      <AdjustStockModal stockReason={stockReason} setStockReason={setStockReason} stockAction={stockAction} setStockAction={setStockAction} stockDirection={stockDirection} setStockDirection={setStockDirection} stockAmount={stockAmount} setStockAmount={setStockAmount} stockNote={stockNote} setStockNote={setStockNote} stockError={stockError} saving={saving} submitStockAction={submitStockAction} selected={selected} />
    </div>
  );
}
