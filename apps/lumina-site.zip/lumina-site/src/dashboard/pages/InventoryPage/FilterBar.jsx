import { Search } from "lucide-react";
import { Input } from "../../../components/ui/input";
import { Button } from "../../../components/ui/button";
import FilterDropdown from "./FilterDropdown";
export function FilterBar({ query, setQuery, categoryFilter, setCategoryFilter, locationFilter, setLocationFilter, categories, locations, sort, setSort, onClear, hasFilters }) {
  return <div className="grid items-end gap-3 border-b p-4 sm:grid-cols-2 xl:grid-cols-[minmax(220px,1.6fr)_repeat(3,minmax(130px,1fr))_auto]">
    <div className="min-w-0"><label htmlFor="inventory-search" className="mb-2 block text-xs text-muted-foreground">Search variants</label><div className="relative"><Search size={16} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" aria-hidden="true" /><Input id="inventory-search" value={query} onChange={event => setQuery(event.target.value)} placeholder="Product, SKU, size or color" className="h-10 pl-9 text-xs shadow-none" /></div></div>
    <FilterDropdown label="Category" value={categoryFilter} onChange={setCategoryFilter} options={categories.map(value => ({ value, label: value === "all" ? "All categories" : value }))} />
    <FilterDropdown label="Location" value={locationFilter} onChange={setLocationFilter} options={locations.map(value => ({ value, label: value === "all" ? "All locations" : value }))} />
    <FilterDropdown label="Sort by" value={sort} onChange={setSort} options={[{ value: "attention", label: "Needs attention first" }, { value: "name", label: "Product name" }, { value: "lowest", label: "Lowest available" }, { value: "highest", label: "Highest available" }]} />
    <Button variant="ghost" size="sm" disabled={!hasFilters} onClick={onClear} className="h-10">Clear filters</Button>
  </div>;
}
