import { Dialog, DialogContent, DialogTitle, DialogDescription, DialogHeader } from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { ToggleGroup, ToggleGroupItem } from "../../../components/ui/toggle-group";
export function AdjustStockModal({ stockReason, setStockReason, stockAction, setStockAction, stockDirection, setStockDirection, stockAmount, setStockAmount, stockNote, setStockNote, stockError, saving, submitStockAction, selected }) {
  if (!stockAction || !selected) return null;
  const amount = Number(stockAmount);
  const valid = stockAmount !== "" && Number.isInteger(amount) && amount > 0 && (stockDirection === "add" || amount <= selected.available);
  const next = selected.stock + (stockDirection === "remove" ? -amount : amount);
  return <Dialog open onOpenChange={open => { if (!open && !saving) setStockAction(null); }}>
    <DialogContent className="grid-cols-[minmax(0,1fr)] sm:max-w-md">
      <DialogHeader><DialogTitle className="text-base font-medium">Adjust stock</DialogTitle><DialogDescription>{selected.name} · {selected.size} / {selected.color}<span className="mt-1 block text-[11px]">{selected.sku}</span></DialogDescription></DialogHeader>
      <form onSubmit={submitStockAction} className="min-w-0 space-y-4">
        <div className="grid grid-cols-3 gap-3 rounded-lg bg-muted/50 p-3 text-xs">{[['On hand',selected.stock],['Reserved',selected.reserved],['Available',selected.available]].map(([label,value])=><div key={label}><p className="text-muted-foreground">{label}</p><p className="mt-1 text-base tabular-nums">{value}</p></div>)}</div>
        <div><p className="mb-2 text-xs">Adjustment type</p><ToggleGroup type="single" value={stockDirection} onValueChange={value => { if (value) { setStockDirection(value); setStockAmount(""); } }} disabled={saving} variant="outline" className="grid grid-cols-2"><ToggleGroupItem value="add" className="min-w-0 whitespace-normal text-xs">Add stock</ToggleGroupItem><ToggleGroupItem value="remove" className="min-w-0 whitespace-normal text-xs">Remove stock</ToggleGroupItem></ToggleGroup></div>
        <label className="block text-sm">Reason<select className="select mt-2 block w-full rounded border border-input p-2" required value={stockReason} onChange={event => setStockReason(event.target.value)}>{["restock","damage","return","correction","transfer"].map(reason => <option key={reason} value={reason}>{reason.toUpperCase()}</option>)}</select></label>
        <div className="space-y-2"><label htmlFor="stock-quantity" className="text-xs">{stockDirection === "add" ? "Units to add" : "Units to remove"}</label><Input autoFocus id="stock-quantity" type="number" inputMode="numeric" min="1" step="1" max={stockDirection === "remove" ? selected.available : undefined} required disabled={saving} value={stockAmount} onChange={event => setStockAmount(event.target.value)} placeholder="Enter a quantity" />{stockDirection === "remove" && <p className="text-[11px] text-muted-foreground">Up to {selected.available} units can be removed. Reserved stock stays protected.</p>}</div>
        <div className="space-y-2"><label htmlFor="stock-note" className="text-xs">Note (optional)</label><textarea id="stock-note" disabled={saving} value={stockNote} onChange={event=>setStockNote(event.target.value)} rows={2} maxLength={500} placeholder="e.g. Supplier delivery or damaged items" className="w-full resize-y rounded-lg border bg-background p-3 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring" /></div>
        {valid && <p className="rounded-lg border px-3 py-2 text-xs">On hand: {selected.stock} → <span className="font-medium">{next}</span><span className="ml-2 text-muted-foreground">({stockDirection === "add" ? "+" : "−"}{amount})</span></p>}
        {stockError && <p role="alert" className="text-xs text-destructive">{stockError}</p>}
        <div className="flex flex-col gap-2 border-t pt-4 sm:flex-row sm:justify-end"><Button variant="outline" type="button" disabled={saving} onClick={()=>setStockAction(null)}>Cancel</Button><Button type="submit" disabled={saving || !valid}>{saving ? "Saving…" : "Save adjustment"}</Button></div>
      </form>
    </DialogContent>
  </Dialog>;
}
