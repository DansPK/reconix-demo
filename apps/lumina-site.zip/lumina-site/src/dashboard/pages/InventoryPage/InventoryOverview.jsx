import { Boxes, AlertTriangle, PackageX, Wallet } from "lucide-react";
import { fmtMoney } from "./helpers";
export function InventoryOverview({ totals, onSelect }) {
  const metrics = [
    { label: "On-hand units", value: totals.totalUnits.toLocaleString(), detail: "Across all loaded variants", Icon: Boxes },
    { label: "Low stock", value: totals.lowStock.toLocaleString(), detail: "At or below reorder point", Icon: AlertTriangle, status: "low", tone: "text-[var(--admin-warning)]" },
    { label: "Out of stock", value: totals.outOfStock.toLocaleString(), detail: "No units available", Icon: PackageX, status: "out", tone: "text-destructive" },
    { label: "Stock value", value: fmtMoney(totals.inventoryValue), detail: "Based on unit cost", Icon: Wallet },
  ];
  return <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
    {metrics.map(({ label, value, detail, Icon, status, tone }) => {
      const content = <><div className="flex items-center justify-between gap-2 text-xs text-muted-foreground"><span>{label}</span><Icon size={15} aria-hidden="true" /></div><p className={`mt-2 break-words text-xl font-medium tracking-tight tabular-nums ${tone || "text-foreground"}`}>{value}</p><p className="mt-1 text-[11px] leading-4 text-muted-foreground">{detail}</p></>;
      return status ? <button key={label} type="button" aria-label={`Review ${label.toLowerCase()}`} onClick={() => onSelect?.(status)} className="rounded-xl border bg-card p-4 text-left transition-colors hover:bg-muted/40 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">{content}</button> : <div key={label} className="rounded-xl border bg-card p-4">{content}</div>;
    })}
  </div>;
}
