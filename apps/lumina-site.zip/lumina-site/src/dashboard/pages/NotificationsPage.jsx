import { useState } from "react";
import { useResource, invalidate } from "../../hooks/useResource";
import * as notifications from "../../api/notifications";
import { query } from "../../api/client";
import AdminPageHeader from "../components/AdminPageHeader";
import { Card, CardContent } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import StyledSelect from "../../components/ui/styled-select";
const statuses = ["queued", "sending", "sent", "skipped", "failed"];
export default function NotificationsPage() {
  const [page, setPage] = useState(0), [status, setStatus] = useState("all"), [busy, setBusy] = useState(null), [failure, setFailure] = useState("");
  const params = { page, size: 25, ...(status !== "all" ? { status } : {}) };
  const { data, loading, error, refetch } = useResource(`/v1/admin/notifications${query(params)}`, () => notifications.deliveries(params), { pollMs: 10000 });
  async function retry(id) { setBusy(id); setFailure(""); try { await notifications.retryDelivery(id); invalidate("/v1/admin/notifications"); } catch (e) { setFailure(e.detail || "Retry failed."); } finally { setBusy(null); } }
  return <div className="space-y-6 p-4 sm:p-6">
    <AdminPageHeader spaced={false} title="Email notifications" description="Review customer email delivery." />
    <Card className="shadow-none"><CardContent className="space-y-4 p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3"><StyledSelect ariaLabel="Delivery status" value={status} onValueChange={value => { setStatus(value); setPage(0); }} options={[{ value: "all", label: "All statuses" }, ...statuses.map(value => ({ value, label: value[0].toUpperCase() + value.slice(1) }))]} className="w-44" /><Button variant="outline" onClick={refetch}>Refresh</Button></div>
      {(error || failure) ? <p role="alert" className="text-sm text-destructive">{failure || "Could not load deliveries. Please refresh."}</p> : null}
      {loading && !data ? <p className="text-sm">Loading deliveries…</p> : !data?.content?.length ? <p className="py-10 text-center text-sm text-muted-foreground">No notification deliveries found.</p> : <><div className="space-y-3 md:hidden">{data.content.map(row => <article key={row.id} className="space-y-3 rounded-lg border p-3">
        <div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="text-sm">{row.eventType.replaceAll("_", " ")}</p><p className="mt-1 break-all text-xs text-muted-foreground">{row.recipient}</p></div><span className="rounded-full bg-muted px-2 py-1 text-xs">{row.status}</span></div>
        <p className="text-xs text-muted-foreground">{row.channel} · {row.audience} · {row.attempts} attempts</p>
        {row.createdAt ? <p className="text-xs text-muted-foreground">{new Date(row.createdAt).toLocaleString("en-GB", { timeZone: "Asia/Phnom_Penh" })}</p> : null}
        {row.failureDetail ? <p className="text-xs text-muted-foreground">{row.failureDetail}</p> : null}
        {row.status === "failed" ? <Button variant="outline" size="sm" disabled={busy !== null} onClick={() => retry(row.id)}>{busy === row.id ? "Queuing…" : "Retry"}</Button> : null}
      </article>)}</div><div className="hidden overflow-x-auto md:block"><table className="w-full text-left text-sm"><thead><tr className="border-b text-xs text-muted-foreground">{["Event / recipient", "Channel", "Status", "Attempts", "Created", "Details", "Action"].map(label => <th className="px-3 py-3 font-medium" key={label}>{label}</th>)}</tr></thead><tbody>{data.content.map(row => <tr className="border-b align-top" key={row.id}>
        <td className="px-3 py-4"><p className="whitespace-nowrap">{row.eventType.replaceAll("_", " ")}</p><p className="mt-1 text-xs text-muted-foreground">{row.recipient}</p><p className="text-xs text-muted-foreground">{row.audience}</p></td><td className="px-3 py-4">{row.channel}</td><td className="px-3 py-4"><span className={`rounded-full px-2 py-1 text-xs ${row.status === "failed" ? "bg-destructive/10 text-destructive" : "bg-muted"}`}>{row.status}</span></td><td className="px-3 py-4">{row.attempts}</td><td className="whitespace-nowrap px-3 py-4 text-xs">{row.createdAt ? new Date(row.createdAt).toLocaleString("en-GB", { timeZone: "Asia/Phnom_Penh" }) : "—"}</td><td className="min-w-48 px-3 py-4 text-xs text-muted-foreground">{row.failureDetail || (row.sentAt ? "Provider accepted the message" : "—")}</td><td className="px-3 py-4">{row.status === "failed" ? <Button variant="outline" size="sm" disabled={busy !== null} onClick={() => retry(row.id)}>{busy === row.id ? "Queuing…" : "Retry"}</Button> : "—"}</td>
      </tr>)}</tbody></table></div></>}
      <div className="flex items-center justify-between gap-3 text-xs text-muted-foreground"><span>{data?.totalElements ?? 0} deliveries</span><div className="flex items-center gap-2"><Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Button><span>Page {page + 1}</span><Button variant="outline" size="sm" disabled={!data || data.last} onClick={() => setPage(page + 1)}>Next</Button></div></div>
    </CardContent></Card>
  </div>;
}
