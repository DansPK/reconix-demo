import SettingsCardHeader from "../components/SettingsCardHeader";
import { useEffect, useState } from "react";
import { CheckCircle2, LoaderCircle, Save, Truck } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Card, CardContent } from "../../components/ui/card";
import { Input } from "../../components/ui/input";
import { invalidate } from "../../hooks/useResource";
import { DELIVERY_FEE_RESOURCE_KEY, updateDeliveryFee } from "../../api/storeSettings";
import { useDeliveryFee } from "../../hooks/useDeliveryFee";

function formatUpdatedAt(value) {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? null
    : new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(date);
}

export default function DeliveryFeeSettingsCard() {
  const { data, loading, error, refetch } = useDeliveryFee();
  const [amount, setAmount] = useState("");
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (data?.deliveryFee !== undefined && data?.deliveryFee !== null) {
      setAmount(Number(data.deliveryFee).toFixed(2));
    }
  }, [data?.deliveryFee]);

  async function handleSubmit(event) {
    event.preventDefault();
    const fee = Number(amount);
    if (!Number.isFinite(fee) || fee < 0) {
      setSaveError("Enter a delivery fee of $0.00 or more.");
      return;
    }

    setSaving(true);
    setSaveError("");
    setSaved(false);
    try {
      const result = await updateDeliveryFee(fee);
      setAmount(Number(result.deliveryFee).toFixed(2));
      setSaved(true);
      invalidate(DELIVERY_FEE_RESOURCE_KEY);
    } catch (requestError) {
      setSaveError(requestError?.detail || "Could not save the delivery fee. Please try again.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card className="flex h-full w-full flex-col shadow-none">
      <SettingsCardHeader icon={Truck} title="Delivery price" description="Set the flat delivery fee shown at checkout and charged on new orders." />
      <CardContent className="flex flex-1 flex-col">
        {error ? (
          <div role="alert" className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-4 py-3 text-sm text-destructive">
            <span>Could not load the current delivery fee.</span>
            <Button type="button" variant="outline" size="sm" onClick={refetch}>Try again</Button>
          </div>
        ) : null}

        <form onSubmit={handleSubmit} className="flex flex-1 flex-col gap-4">
          <div className="max-w-sm space-y-2">
            <label htmlFor="delivery-fee" className="text-sm font-medium">Fee per order</label>
            <div className="relative">
              <span aria-hidden="true" className="pointer-events-none absolute inset-y-0 left-3 flex items-center text-sm text-muted-foreground">$</span>
              <Input
                id="delivery-fee"
                type="number"
                min="0"
                max="99999999.99"
                step="0.01"
                inputMode="decimal"
                required
                value={amount}
                onChange={(event) => { setAmount(event.target.value); setSaved(false); }}
                disabled={loading || saving || !!error}
                className="pl-7 pr-16 tabular-nums"
                aria-describedby="delivery-fee-help"
              />
              <span className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-xs font-medium text-muted-foreground">USD</span>
            </div>
            <p id="delivery-fee-help" className="text-xs leading-5 text-muted-foreground">
              Applies to new orders only. Orders already placed keep their original fee.
            </p>
          </div>

          {saveError ? <p role="alert" className="text-sm text-destructive">{saveError}</p> : null}
          {saved ? (
            <p role="status" className="flex items-center gap-2 text-sm font-medium text-emerald-700">
              <CheckCircle2 size={16} aria-hidden="true" /> Delivery fee saved and checkout updated.
            </p>
          ) : null}
          <div className="mt-auto space-y-3 border-t border-border pt-4">
          {data?.updatedAt ? <p className="text-xs text-muted-foreground">Last updated {formatUpdatedAt(data.updatedAt)}</p> : null}

          <Button type="submit" disabled={loading || saving || !!error || !amount}>
            {saving ? <LoaderCircle size={16} className="animate-spin" aria-hidden="true" /> : <Save size={16} aria-hidden="true" />}
            {saving ? "Saving…" : "Save delivery fee"}
          </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
