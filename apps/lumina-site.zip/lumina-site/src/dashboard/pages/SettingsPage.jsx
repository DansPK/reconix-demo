import NotificationPreferences from "../../components/NotificationPreferences";
import AdminPageHeader from "../components/AdminPageHeader";
import ProfilePanel from "../../components/ProfilePanel";
import { useAdminTheme } from "../AdminTheme";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../components/ui/card";
import { ToggleGroup, ToggleGroupItem } from "../../components/ui/toggle-group";
import { Sun, Moon } from "lucide-react";

export default function SettingsPage() {
  const { theme, setTheme } = useAdminTheme();
  return <div className="flex flex-col gap-6 p-6">
    <AdminPageHeader spaced={false} title="Account settings" description="Manage your profile and admin workspace appearance." />
    <Card className="mx-auto w-full max-w-3xl shadow-none">
      <CardHeader><CardTitle>Appearance</CardTitle><CardDescription>Choose the theme for your admin workspace. Your preference is saved on this device.</CardDescription></CardHeader>
      <CardContent><ToggleGroup type="single" variant="outline" value={theme} onValueChange={value => { if (value) setTheme(value); }} aria-label="Admin appearance" className="justify-start"><ToggleGroupItem value="light"><Sun aria-hidden="true" />Light</ToggleGroupItem><ToggleGroupItem value="dark"><Moon aria-hidden="true" />Dark</ToggleGroupItem></ToggleGroup></CardContent>
    </Card>
    <ProfilePanel admin hideHeader />
    <NotificationPreferences />
  </div>;
}
