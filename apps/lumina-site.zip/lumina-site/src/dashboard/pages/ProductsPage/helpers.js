const C = {
  primary: "var(--admin-primary)",
  success: "var(--admin-success)",
  warning: "var(--admin-warning)",
  danger: "var(--admin-danger)",
  purple: "var(--admin-neutral)",

  primaryBg: "var(--admin-primary-soft)",
  successBg: "var(--admin-success-soft)",
  warningBg: "var(--admin-warning-soft)",
  dangerBg: "var(--admin-danger-soft)",
  purpleBg: "var(--admin-neutral-soft)",

  text: "var(--admin-foreground)",
  textSub: "var(--admin-muted-foreground)",
  muted: "var(--admin-muted-foreground)",
  textMuted: "var(--admin-muted-foreground)",

  surface: "var(--admin-background)",
  white: "var(--admin-card)",
  border: "var(--admin-border)",
};

const FONT_STACK = "'Poppins','Segoe UI',sans-serif";

// ── HELPER FUNCTIONS ────────────────────────────────────────────────────
const getStatusLabel = (status) => {
  const labels = {
    active: "Active",
    "low-stock": "Low stock",
    "out-of-stock": "Out of stock",
  };
  return labels[status] || status;
};

const getStatusColor = (status) => {
  const colors = {
    active: { bg: C.successBg, text: C.success, border: C.success },
    "low-stock": { bg: C.warningBg, text: C.warning, border: C.warning },
    "out-of-stock": { bg: C.dangerBg, text: C.danger, border: C.danger },
  };
  return colors[status] || colors["active"];
};

const getStockColor = (stock) => {
  if (stock === 0) return C.danger;
  if (stock <= 10) return C.warning;
  return C.success;
};

const computeStatus = ({
  isActive = true,
  stock = 0,
  lowStockThreshold = 10,
}) => {
  if (!isActive) return "out-of-stock";
  if (stock <= 0) return "out-of-stock";
  if (stock <= lowStockThreshold) return "low-stock";
  return "active";
};

const getDiscountPercentFromPrices = (basePrice, salePrice) => {
  const base = Number(basePrice);
  const sale = Number(salePrice);
  if (!Number.isFinite(base) || !Number.isFinite(sale) || base <= 0 || sale <= 0 || sale >= base) return "";
  const percent = Math.round((1 - sale / base) * 10000) / 100;
  return percent > 0 && percent < 100 ? String(percent) : "";
};

const getSalePriceFromDiscount = (basePrice, discountPercent) => {
  const base = Number(basePrice);
  const percent = Number(discountPercent);
  if (!Number.isFinite(base) || !Number.isFinite(percent) || base <= 0 || percent <= 0 || percent >= 100) return 0;
  const baseCents = Math.round(base * 100);
  return Math.round((baseCents * (100 - percent)) / 100) / 100;
};

const buildCategoryIndex = (categoryData) => {
  const categoryNames = Object.keys(categoryData);
  const subCatsByCategory = Object.fromEntries(
    categoryNames.map((cat) => {
      const all = Object.values(categoryData[cat]).flat();
      const unique = Array.from(new Set(all.filter((item) => item !== "All")));
      return [cat, unique];
    }),
  );
  const allSubCats = Array.from(
    new Set(Object.values(subCatsByCategory).flat()),
  );
  return { categoryNames, subCatsByCategory, allSubCats };
};

const createFormData = (product, categoryData) => {
  const { categoryNames, subCatsByCategory } = buildCategoryIndex(categoryData);
  const defaultCat = categoryNames[0];
  const defaultSubCat = subCatsByCategory[defaultCat]?.[0] || "";

  const defaults = {
    id: null,
    name: "",
    sku: "",
    cat: defaultCat,
    subCat: defaultSubCat,
    description: "",
    modelInfo: "",
    price: 0,
    discountPercent: "",
    costPrice: 0,
    stock: 0,
    lowStockThreshold: 10,
    isActive: true,
    isFeatured: false,
    tags: [],
    images: [],
    image: "",
    variants: [],
  };

  if (!product) return defaults;

  const normalizedCat = categoryNames.includes(product.cat)
    ? product.cat
    : defaultCat;
  const normalizedSubCats = subCatsByCategory[normalizedCat] || [];
  const normalizedSubCat = normalizedSubCats.includes(product.subCat)
    ? product.subCat
    : normalizedSubCats[0] || "";

  const inferredImages = Array.isArray(product.images)
    ? product.images
    : product.image
      ? [product.image]
      : [];

  return {
    ...defaults,
    ...product,
    cat: normalizedCat,
    subCat: normalizedSubCat,
    discountPercent: product.discountPercent != null
      ? String(product.discountPercent)
      : getDiscountPercentFromPrices(product.price, product.salePrice),
    costPrice: product.costPrice || 0,
    lowStockThreshold: product.lowStockThreshold || 10,
    isActive: product.isActive ?? true,
    isFeatured: product.isFeatured ?? false,
    tags: Array.isArray(product.tags) ? product.tags : [],
    images: inferredImages,
    variants: Array.isArray(product.variants) ? product.variants : [],
  };
};

export {
  C,
  FONT_STACK,
  getStatusLabel,
  getStatusColor,
  getStockColor,
  computeStatus,
  getDiscountPercentFromPrices,
  getSalePriceFromDiscount,
  buildCategoryIndex,
  createFormData,
};
