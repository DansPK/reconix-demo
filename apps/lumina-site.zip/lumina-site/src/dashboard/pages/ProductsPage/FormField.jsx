import { Children, Fragment, cloneElement, isValidElement, useId } from "react";
import { C } from "./helpers";

export default function FormField({ label, required, error, children, helperText }) {
  const id = useId();
  const message = error || helperText;
  const bindControl = child => {
    if (!isValidElement(child)) return child;
    if (child.type === "div" || child.type === Fragment) {
      return cloneElement(child, {}, Children.map(child.props.children, bindControl));
    }
    if (typeof child.type === "string" && !["input", "select", "textarea", "button"].includes(child.type)) return child;
    return cloneElement(child, {
      id,
      "aria-label": label,
      "aria-invalid": !!error,
      "aria-describedby": message ? `${id}-message` : undefined,
    });
  };
  return <div className="mb-4 flex flex-col gap-2">
    {label && <label htmlFor={id} className="text-sm font-medium" style={{ color: C.textSub }}>{label}{required && <span className="ml-1" style={{ color: C.danger }}>*</span>}</label>}
    {Children.map(children, bindControl)}
    {message && <p id={`${id}-message`} className="text-xs" role={error ? "alert" : undefined} style={{ color: error ? C.danger : C.muted }}>{message}</p>}
  </div>;
}
