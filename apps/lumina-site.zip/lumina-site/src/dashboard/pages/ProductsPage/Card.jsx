import { C } from "./helpers";

function Card({title, icon, children, className = ""}) {
  return (
    <div className={`product-form-card ${className}`} style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:"12px",padding:"18px",marginBottom:"18px"}}>
      {title && (
        <h2 style={{fontSize: "1.0714rem",fontWeight:"700",color:C.text,margin:"0 0 10px 0",display:"flex",alignItems:"center",gap:"8px"}}>
          {icon && (
            <span style={{
              fontSize: "0.71429rem",
              fontWeight:"700",
              color:"var(--admin-primary-text)",
              background:C.primaryBg,
              border:`1px solid ${C.border}`,
              borderRadius:"999px",
              padding:"3px 7px",
              letterSpacing:"0.04em",
              textTransform:"uppercase"
            }}>
              {icon}
            </span>
          )}
          {title}
        </h2>
      )}
      {children}
    </div>
  );
}

export default Card;
