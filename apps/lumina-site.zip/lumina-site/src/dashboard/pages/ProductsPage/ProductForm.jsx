import ProductCategoryPicker from "./ProductCategoryPicker";
import { useMemo, useRef, useState } from "react";
import { ArrowLeft, Package } from "lucide-react";
import AdminPageHeader from "../../components/AdminPageHeader";
import { useDashboardData } from "../../DashboardDataContext";
import { toProductPayload } from "../../adminCatalog";
import * as catalogApi from "../../../api/catalog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../../../components/ui/dialog";
import FormField from "./FormField";
import { createFormData, getSalePriceFromDiscount } from "./helpers";
import ProductMedia from "./ProductMedia";
import ProductVariants from "./ProductVariants";
import ProductDeleteDialog from "./ProductDeleteDialog";

const variantPayload = variant => ({ sku: variant.sku || undefined, size: variant.size || "", color: variant.color || "", stock: Number(variant.stock || 0) });

export default function ProductForm({ product, mode, onSave, onCancel, catalog, onBack }) {
  const { categories, catalog: sharedCatalog } = useDashboardData();
  const tree = catalog.tree || sharedCatalog.tree || [];
  const leaves = useMemo(() => tree.flatMap(main => (main.children || []).flatMap(group => (group.children || []).map(leaf => ({ ...leaf, path: `${main.name} / ${group.name} / ${leaf.name}` })))), [tree]);
  const [form, setForm] = useState(() => ({ ...createFormData(product, categories), categoryId: product?.categoryId ?? leaves[0]?.id ?? "" }));
  const [variants, setVariants] = useState(() => product?.variants?.length ? product.variants : [{ sku: "", size: "", color: "", stock: 0 }]);
  const [files, setFiles] = useState([]);
  const [images, setImages] = useState(() => (product?.images || []).map((src, i) => ({ src, id: product.imageIds?.[i] })).filter(image => image.id));
  const [removedImages, setRemovedImages] = useState([]);
  const saved = useRef({ id: product?.id, sku: product?.sku });
  const knownVariants = useRef(new Map((product?.variants || []).map(variant => [variant.id, variantPayload(variant)])));
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [errors, setErrors] = useState({});
  const [failure, setFailure] = useState("");
  const [discard, setDiscard] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const finish = onBack || onSave || onCancel;
  const change = (key, value) => { setForm(previous => ({ ...previous, [key]: value })); setDirty(true); setErrors(previous => ({ ...previous, [key]: undefined })); };
  const leave = () => { if (!busy) { if (dirty) setDiscard(true); else finish?.(); } };
  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Enter a product name.";
    if (!form.categoryId) next.categoryId = "Choose a sub-category.";
    if (form.price === "" || !Number.isFinite(Number(form.price)) || Number(form.price) < 0) next.price = "Enter a price of zero or more.";
    if (form.discountPercent !== "") {
      const percent = Number(form.discountPercent);
      const percentHundredths = Math.round(percent * 100);
      if (!Number.isFinite(percent) || percent <= 0 || percent >= 100 || Math.abs(percent * 100 - percentHundredths) > 1e-8) {
        next.discountPercent = "Enter a percentage from 0.01 to 99.99 with up to 2 decimal places, or leave it blank for no discount.";
      } else {
        const discountedPrice = getSalePriceFromDiscount(form.price, percent);
        if (Number(form.price) <= 0 || discountedPrice <= 0 || discountedPrice >= Number(form.price)) {
          next.discountPercent = "Enter a regular price that can produce a discounted price above $0.00.";
        }
      }
    }
    if (Number(form.costPrice) < 0 || Number(form.lowStockThreshold) < 0) next.advanced = "Cost and low-stock threshold cannot be negative.";
    if (!variants.length || variants.some(variant => variant.stock === "" || !Number.isInteger(Number(variant.stock)) || Number(variant.stock) < 0)) next.variants = "Every variant needs a whole-number stock quantity of zero or more.";
    setErrors(next); return !Object.keys(next).length;
  };
  const save = async event => {
    event.preventDefault();
    if (busy || !validate()) return;
    setBusy(true); setFailure("");
    try {
      const salePrice = getSalePriceFromDiscount(form.price, form.discountPercent);
      const data = { ...form, salePrice, name: form.name.trim(), tags: (form.tags || []).filter(Boolean), variants };
      if (!saved.current.id) {
        const created = await catalog.createProduct(data);
        saved.current = { id: created.id, sku: created.sku };
        const createdVariants = created.variants || [];
        knownVariants.current = new Map(createdVariants.map(variant => [variant.id, variantPayload(variant)]));
        setVariants(createdVariants);
      } else {
        const payload = toProductPayload(data, tree);
        delete payload.variants;
        payload.salePrice = salePrice;
        payload.lowStockThreshold = Number(form.lowStockThreshold);
        const updated = await catalog.patchProduct(saved.current.id, payload);
        saved.current.sku = updated?.sku || form.sku || saved.current.sku;
        const retained = new Set(variants.filter(variant => variant.id).map(variant => variant.id));
        for (let i = 0; i < variants.length; i++) {
          const variant = variants[i];
          const body = variantPayload(variant);
          if (variant.id) {
            const original = knownVariants.current.get(variant.id);
            body.sku ||= original?.sku;
            if (JSON.stringify(body) !== JSON.stringify(original)) { await catalogApi.updateVariant(saved.current.id, variant.id, body); knownVariants.current.set(variant.id, body); }
          } else {
            body.sku ||= `${(saved.current.sku || 'PRODUCT').slice(0, 70)}-${i + 1}-${Date.now().toString(36).toUpperCase()}`;
            const created = await catalogApi.createVariant(saved.current.id, body);
            retained.add(created.id);
            knownVariants.current.set(created.id, variantPayload(created));
            setVariants(current => current.map((entry, index) => index === i ? { ...entry, id: created.id, sku: created.sku } : entry));
          }
        }
        for (const id of knownVariants.current.keys()) if (!retained.has(id)) { await catalogApi.deleteVariant(saved.current.id, id); knownVariants.current.delete(id); }
      }
      for (const id of removedImages) { await catalogApi.deleteProductImage(saved.current.id, id); setRemovedImages(current => current.filter(value => value !== id)); }
      for (const file of files) {
        const image = await catalogApi.uploadProductImage(saved.current.id, file, { primary: images.length === 0 && file === files[0], displayOrder: images.length + files.indexOf(file) });
        setImages(current => [...current, { id: image.id, src: image.imageUrl }]);
        setFiles(current => current.filter(entry => entry !== file));
      }
      catalog.refreshAll?.(); setDirty(false); finish?.();
    } catch (error) {
      if (error?.errors) setErrors(previous => ({ ...previous, ...Object.fromEntries(Object.entries(error.errors).map(([key, value]) => [key === "basePrice" ? "price" : key, value])) }));
      setFailure(error?.detail || error.message || "Could not save. Your changes are still here; retry when ready."); catalog.refreshAll?.();
    }
    finally { setBusy(false); }
  };
  const remove = async () => {
    setBusy(true); setFailure("");
    try { await catalog.deleteProduct(saved.current.id); finish?.(); }
    catch (error) { setFailure(error?.detail || "Could not delete this product."); }
    finally { setBusy(false); }
  };
  const stock = variants.reduce((sum, variant) => sum + Number(variant.stock || 0), 0);
  const salePrice = getSalePriceFromDiscount(form.price, form.discountPercent);
  const hasDiscount = salePrice > 0 && salePrice < Number(form.price);
  return <div className="flex-1 overflow-y-auto bg-background p-6">
    <AdminPageHeader title={mode === "create" ? "Add product" : "Edit product"} description="Add the essentials, organize variants, and choose when to show it in the store." back={<button type="button" onClick={leave} className="inline-flex items-center gap-1"><ArrowLeft size={12} aria-hidden="true" />Products</button>} />
    <form onSubmit={save} noValidate className="mx-auto max-w-7xl">
      <fieldset disabled={busy} className="grid min-w-0 gap-5 lg:grid-cols-[minmax(0,1.8fr)_minmax(260px,1fr)]">
        <div className="min-w-0 space-y-5">
          <section className="rounded-xl border bg-card p-5"><h2 className="mb-4 text-sm font-semibold">Product details</h2>
            <FormField label="Product name" required error={errors.name}><Input value={form.name} onChange={event => change("name", event.target.value)} placeholder="e.g. Cotton crew-neck T-shirt" /></FormField>
            <FormField label="Category" required error={errors.categoryId}><ProductCategoryPicker value={form.categoryId} tree={tree} onChange={value => change("categoryId", value)} /></FormField>
            <FormField label="Description"><textarea className="min-h-24 rounded-md border bg-background p-3 text-sm" value={form.description} onChange={event => change("description", event.target.value)} placeholder="Describe the fabric, fit, and features." /></FormField>
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="Regular price (USD)" required error={errors.price}>
                <Input type="number" min="0" step="0.01" value={form.price} onChange={event => change("price", event.target.value)} />
              </FormField>
              <FormField label="Discount (%)" error={errors.discountPercent} helperText="Enter a percentage from 0.01 to 99.99. Leave blank for no discount.">
                <div className="relative">
                  <Input type="number" min="0.01" max="99.99" step="0.01" inputMode="decimal" placeholder="e.g. 15" value={form.discountPercent} onChange={event => change("discountPercent", event.target.value)} className="pr-10" />
                  <span aria-hidden="true" className="pointer-events-none absolute inset-y-0 right-3 flex items-center text-sm text-muted-foreground">%</span>
                </div>
              </FormField>
            </div>
            {hasDiscount ? (
              <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-primary/20 bg-primary/5 px-4 py-3 text-sm">
                <span className="text-muted-foreground">Shopper price</span>
                <span className="font-semibold tabular-nums">
                  <span className="mr-2 text-muted-foreground line-through">${Number(form.price).toFixed(2)}</span>
                  <span className="text-primary">${salePrice.toFixed(2)}</span>
                  <span className="ml-2 text-xs font-medium text-primary">{form.discountPercent}% off</span>
                </span>
              </div>
            ) : null}
          </section>
          <ProductMedia existing={images} files={files} onFilesChange={next => { setFiles(next); setDirty(true); }} onRemove={id => { setImages(current => current.filter(image => image.id !== id)); setRemovedImages(current => [...current, id]); setDirty(true); }} />
          <ProductVariants variants={variants} error={errors.variants} onChange={next => { setVariants(next); setDirty(true); }} />
          <details open={!!errors.advanced || undefined} className="rounded-xl border bg-card p-5"><summary className="cursor-pointer text-sm font-semibold">Optional settings</summary><div className="mt-4">
            {errors.advanced && <p role="alert" className="mb-3 text-xs text-destructive">{errors.advanced}</p>}
            <FormField label="Product SKU" helperText="Generated from the name if left blank."><Input value={form.sku} onChange={event => change("sku", event.target.value)} /></FormField>
            <div className="grid gap-4 sm:grid-cols-2"><FormField label="Cost price (USD)"><Input type="number" min="0" step="0.01" value={form.costPrice} onChange={event => change("costPrice", event.target.value)} /></FormField><FormField label="Low stock threshold"><Input type="number" min="0" step="1" value={form.lowStockThreshold} onChange={event => change("lowStockThreshold", event.target.value)} /></FormField></div>
            <FormField label="Model information"><textarea className="min-h-20 rounded-md border p-3 text-sm" value={form.modelInfo} onChange={event => change("modelInfo", event.target.value)} /></FormField>
            <FormField label="Tags" helperText="Separate tags with commas."><Input value={(form.tags || []).join(", ")} onChange={event => change("tags", event.target.value.split(",").map(tag => tag.trim()))} /></FormField>
          </div></details>
        </div>
        <aside className="space-y-5">
          <section className="rounded-xl border bg-card p-5"><h2 className="text-sm font-semibold">Publishing</h2><label className="mt-4 flex items-center justify-between gap-3 text-sm">Visible in store<input type="checkbox" checked={form.isActive} onChange={event => change("isActive", event.target.checked)} className="h-4 w-4 accent-primary" /></label><p className="mt-2 text-xs text-muted-foreground">Turn off to keep this product hidden.</p><label className="mt-5 flex items-center justify-between gap-3 text-sm">Featured on homepage<input type="checkbox" checked={form.isFeatured} onChange={event => change("isFeatured", event.target.checked)} className="h-4 w-4 accent-primary" /></label></section>
          <section className="rounded-xl border bg-card p-5"><div className="flex items-center gap-2 text-sm font-semibold"><Package size={16} aria-hidden="true" />At a glance</div><p className="mt-4 text-sm font-medium">{form.name || "Untitled product"}</p><p className="mt-2 text-xl font-semibold tabular-nums">${(hasDiscount ? salePrice : Number(form.price) || 0).toFixed(2)}</p>{hasDiscount ? <p className="mt-1 text-xs text-muted-foreground">Regular price ${Number(form.price).toFixed(2)} · {form.discountPercent}% off</p> : null}<p className="mt-2 text-xs text-muted-foreground">{variants.length} variants · {stock} units on hand</p></section>
          {product && <Button type="button" variant="ghost" className="text-xs text-destructive" onClick={() => { setFailure(""); setDeleting(true); }}>Delete product</Button>}
        </aside>
      </fieldset>
      <div className="sticky bottom-0 z-10 mt-5 flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-card p-4 shadow-sm">
        <div className="min-w-0 flex-1">{failure ? <p role="alert" className="text-xs text-destructive">{failure}</p> : <p className="text-xs text-muted-foreground">{busy ? "Saving your changes…" : dirty ? "Unsaved changes" : mode === "create" ? "Ready to create" : "No unsaved changes"}</p>}</div>
        <Button type="button" variant="outline" disabled={busy} onClick={leave}>Cancel</Button><Button type="submit" disabled={busy}>{busy ? "Saving…" : mode === "create" ? "Create product" : "Save changes"}</Button>
      </div>
    </form>
    <ProductDeleteDialog open={deleting} label={product?.name || form.name} busy={busy} error={failure} onClose={() => setDeleting(false)} onConfirm={remove} />
    <Dialog open={discard} onOpenChange={setDiscard}><DialogContent><DialogHeader><DialogTitle>Discard product changes?</DialogTitle><DialogDescription>Your unsaved changes will be lost.</DialogDescription></DialogHeader><DialogFooter><Button variant="outline" onClick={() => setDiscard(false)}>Keep editing</Button><Button variant="destructive" onClick={() => finish?.()}>Discard changes</Button></DialogFooter></DialogContent></Dialog>
  </div>;
}
