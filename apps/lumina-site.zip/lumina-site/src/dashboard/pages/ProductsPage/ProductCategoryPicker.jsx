import { useId, useState } from "react";
import StyledSelect from "../../../components/ui/styled-select";

export default function ProductCategoryPicker({ value, tree, onChange, ...props }) {
  const id = useId();
  const [draft, setDraft] = useState({ collectionId: "", groupId: "" });
  const selectedCollection = tree.find(collection => collection.children?.some(group => group.children?.some(leaf => leaf.id === Number(value))));
  const selectedGroup = selectedCollection?.children.find(group => group.children?.some(leaf => leaf.id === Number(value)));
  const collectionId = selectedCollection?.id ?? draft.collectionId;
  const groupId = selectedGroup?.id ?? draft.groupId;
  const collection = tree.find(item => item.id === Number(collectionId));
  const groups = collection?.children ?? [];
  const leaves = groups.find(group => group.id === Number(groupId))?.children ?? [];
  const options = items => items.map(item => ({ value: String(item.id), label: item.name }));

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
      <div className="min-w-0 space-y-1.5">
        <label htmlFor={`${id}-collection`} className="text-xs text-muted-foreground">Collection</label>
        <StyledSelect contentClassName="product-category-menu" className="focus-visible:ring-border" id={`${id}-collection`} ariaLabel="Collection" value={collectionId} options={options(tree)} placeholder="Choose collection" disabled={!tree.length} onValueChange={next => {
          setDraft({ collectionId: next, groupId: "" });
          onChange("");
        }} />
      </div>
      <div className="min-w-0 space-y-1.5">
        <label htmlFor={`${id}-group`} className="text-xs text-muted-foreground">Group</label>
        <StyledSelect contentClassName="product-category-menu" className="focus-visible:ring-border" id={`${id}-group`} ariaLabel="Group" value={groupId} options={options(groups)} placeholder="Choose group" disabled={!groups.length} onValueChange={next => {
          setDraft({ collectionId, groupId: next });
          onChange("");
        }} />
      </div>
      <div className="min-w-0 space-y-1.5">
        <label htmlFor={props.id || `${id}-category`} className="text-xs text-muted-foreground">Category</label>
        <StyledSelect contentClassName="product-category-menu" className="focus-visible:ring-border" {...props} id={props.id || `${id}-category`} ariaLabel="Category" value={value} options={options(leaves)} placeholder="Choose category" disabled={!leaves.length} onValueChange={next => onChange(Number(next))} />
      </div>
      {!tree.length && <p className="text-xs text-muted-foreground sm:col-span-3">Add a sub-category in Category Management first.</p>}
    </div>
  );
}
