import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";

export default function ProductDeleteDialog({ open, label, busy, error, onClose, onConfirm }) {
  return <Dialog open={open} onOpenChange={value => { if (!value && !busy) onClose(); }}><DialogContent><DialogHeader><DialogTitle>Delete {label}?</DialogTitle><DialogDescription>This permanently removes the product. Products referenced by orders cannot be deleted; archive them to hide them from the store instead.</DialogDescription></DialogHeader>{error && <p role="alert" className="text-sm text-destructive">{error}</p>}<DialogFooter><Button variant="outline" disabled={busy} onClick={onClose}>Keep product</Button><Button variant="destructive" disabled={busy} onClick={onConfirm}>{busy ? "Deleting…" : "Delete permanently"}</Button></DialogFooter></DialogContent></Dialog>;
}
