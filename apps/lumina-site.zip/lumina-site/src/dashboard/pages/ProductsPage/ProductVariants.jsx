import { Plus, Trash2 } from "lucide-react";
import { Input } from "../../../components/ui/input";
import { Button } from "../../../components/ui/button";

export default function ProductVariants({ variants, onChange, error }) {
  const update = (index, key, value) => onChange(variants.map((variant, i) => i === index ? { ...variant, [key]: value } : variant));
  return <section className="rounded-xl border bg-card p-5">
    <div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="text-sm font-semibold">Variants & stock</h2><p className="mt-1 text-xs text-muted-foreground">One row per size and colour. Leave SKU blank to generate it.</p></div><Button type="button" size="sm" variant="outline" onClick={() => onChange([...variants, { sku: "", size: "", color: "", stock: 0 }])}><Plus aria-hidden="true" />Add variant</Button></div>
    {error && <p role="alert" className="mt-3 text-xs text-destructive">{error}</p>}
    <div className="mt-4 overflow-x-auto"><table className="w-full min-w-[520px] text-left text-xs"><thead className="text-muted-foreground"><tr>{["Size", "Colour", "Stock", "SKU (optional)", ""].map((label, i) => <th key={i} className="pb-2 pr-3 font-medium">{label}</th>)}</tr></thead><tbody>
      {variants.map((variant, index) => <tr key={variant.id || `new-${index}`}><td className="py-1 pr-3"><Input aria-label={`Variant ${index + 1} size`} value={variant.size || ""} onChange={event => update(index, "size", event.target.value)} placeholder="M" className="h-9 min-w-16 text-xs" /></td><td className="py-1 pr-3"><Input aria-label={`Variant ${index + 1} colour`} value={variant.color || ""} onChange={event => update(index, "color", event.target.value)} placeholder="Black" className="h-9 min-w-24 text-xs" /></td><td className="py-1 pr-3"><Input aria-label={`Variant ${index + 1} stock`} type="number" min="0" step="1" value={variant.stock ?? 0} onChange={event => update(index, "stock", event.target.value === "" ? "" : Number(event.target.value))} className="h-9 w-20 text-xs" /></td><td className="py-1 pr-3"><Input aria-label={`Variant ${index + 1} SKU`} value={variant.sku || ""} onChange={event => update(index, "sku", event.target.value)} placeholder="Auto-generated" className="h-9 text-xs" /></td><td><Button type="button" size="icon" variant="ghost" disabled={variants.length === 1} aria-label={`Remove variant ${index + 1}`} onClick={() => onChange(variants.filter((_, i) => i !== index))} className="h-8 w-8 text-destructive"><Trash2 aria-hidden="true" /></Button></td></tr>)}
    </tbody></table></div>
  </section>;
}
