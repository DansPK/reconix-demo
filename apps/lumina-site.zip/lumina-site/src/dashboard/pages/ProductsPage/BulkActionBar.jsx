import { Button as HeroButton } from "@heroui/react";
import { C } from "./helpers";

function BulkActionBar({selectedCount, onClearSelection, onAction, busy}) {
  return (
    <div style={{
      display:"flex",
      alignItems:"center",
      flexWrap:"wrap",
      gap:"16px",
      padding:"12px 20px",
      background:C.primaryBg,
      borderBottom:`1px solid ${C.border}`,
      borderRadius:"12px 12px 0 0",
    }}>
      <span style={{fontSize: "0.92857rem",fontWeight:"600",color:C.text}}>
        {selectedCount} selected
      </span>
      <div style={{display:"flex",gap:"8px",flexWrap:"wrap"}}>
        {["Activate","Archive","Delete"].map((action,i)=>(
          <HeroButton
            key={action}
            isDisabled={busy}
            size="sm"
            variant={action === "Delete" ? "flat" : "bordered"}
            color={action === "Delete" ? "danger" : action === "Archive" ? "warning" : "primary"}
            onPress={() => onAction(action)}
          >
            {action}
          </HeroButton>
        ))}
      </div>
      <div style={{flex:1}}/>
      <button disabled={busy} onClick={onClearSelection} style={{
        padding:"6px 12px",
        fontSize: "0.85714rem",
        border:"none",
        background:"transparent",
        color:C.muted,
        cursor:"pointer",
      }}>
        Clear
      </button>
    </div>
  );
}

export default BulkActionBar;
