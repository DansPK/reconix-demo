import { Chip as HeroChip } from "@heroui/react";
import { Archive, MoreHorizontal, Pencil, Star, Trash2, Eye } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator } from "../../../components/ui/dropdown-menu";
import { C } from "./helpers";
import ProductImage from "./ProductImage";

function ProductRow({product, selected, onSelect, onEdit, onMore}) {
  const hasDiscount = Number(product.salePrice) > 0 && Number(product.salePrice) < Number(product.price || 0);
  const inventoryTone = product.stock === 0 ? "danger" : product.stock <= (product.lowStockThreshold || 10) ? "warning" : "success";
  const inventoryLabel = product.stock === 0 ? "Out of stock" : product.stock <= (product.lowStockThreshold || 10) ? "Low stock" : "In stock";
  const published = product.isActive !== false;
  const variantText = Array.isArray(product.variants) && product.variants.length
    ? `${product.variants.length} variants`
    : "Single SKU";

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "32px minmax(0, 2.4fr) minmax(120px, 0.8fr) minmax(130px, 0.9fr) minmax(150px, 0.9fr) 120px",
        alignItems: "center",
        gap: "16px",
        padding: "14px 20px",
        borderBottom: `1px solid ${C.border}`,
        background: selected ? C.primaryBg : "transparent",
        transition: "all .15s ease",
      }}
    >
      <div style={{ display: "flex", alignItems: "center" }}>
        <input
          aria-label={`Select ${product.name}`}
          type="checkbox"
          checked={selected}
          onChange={() => onSelect(product.id)}
          style={{ width: "18px", height: "18px", cursor: "pointer" }}
        />
      </div>

      <div onClick={() => onEdit(product)} style={{ cursor: "pointer", minWidth: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <ProductImage src={product.image} alt={product.name} />
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: "1rem", fontWeight: "500", color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {product.name}
            </div>
            <div style={{ fontSize: "0.78571rem", color: C.textMuted, marginTop: "2px" }}>
              SKU: {product.sku}
            </div>
            <div style={{ fontSize: "0.78571rem", color: C.textSub, marginTop: "2px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {product.cat} · {product.subCat || "General"}
            </div>
          </div>
        </div>
      </div>

      <div style={{ minWidth: 0 }}>
        {hasDiscount ? (
          <>
            <div style={{ fontSize: "0.78571rem", color: C.muted, textDecoration: "line-through" }}>$ {Number(product.price || 0).toFixed(2)}</div>
            <div style={{ fontSize: "1rem", fontWeight: "400", color: "var(--admin-primary-text)", marginTop: "2px" }}>$ {Number(product.salePrice).toFixed(2)}</div>
            <div style={{ marginTop: "4px" }}>
              <HeroChip size="sm" color="warning" variant="flat">Sale</HeroChip>
            </div>
          </>
        ) : (
          <div style={{ fontSize: "1rem", fontWeight: "400", color: C.text }}>$ {Number(product.price || 0).toFixed(2)}</div>
        )}
      </div>

      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: "1rem", fontWeight: "500", color: inventoryTone === "danger" ? C.danger : inventoryTone === "warning" ? C.warning : C.success }}>
          {product.stock ?? 0} units
        </div>
        <div
          style={{
            fontSize: "0.78571rem",
            color: inventoryTone === "danger" ? C.danger : inventoryTone === "warning" ? C.warning : C.success,
            marginTop: "4px",
            fontWeight: 400,
          }}
        >
          {inventoryLabel}
        </div>
        {Array.isArray(product.variants) && product.variants.length > 0 && (
          <div style={{ fontSize: "0.71429rem", color: C.textMuted, marginTop: "4px" }}>{variantText}</div>
        )}
      </div>

      <div className="flex min-w-0 flex-col items-start gap-2">
        <span className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-normal" style={{ background: `var(--admin-${published ? "success" : "neutral"}-soft)`, color: `var(--admin-${published ? "success" : "neutral"})` }}>
          <span className="h-1.5 w-1.5 rounded-full bg-current" aria-hidden="true" />{published ? "Published" : "Archived"}
        </span>
        {product.isFeatured && <span className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground"><Star size={12} style={{ color: "var(--admin-warning)" }} aria-hidden="true" />Featured</span>}
      </div>

      <div className="flex items-center justify-end gap-1.5" onClick={event => event.stopPropagation()}>
        <Button type="button" size="sm" variant="outline" className="h-8 gap-1.5 px-2.5 text-xs shadow-none" onClick={() => onEdit(product)} aria-label={`Edit ${product.name}`}><Pencil aria-hidden="true" />Edit</Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild><Button type="button" size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground" aria-label={`Actions for ${product.name}`}><MoreHorizontal aria-hidden="true" /></Button></DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="min-w-44">
            <DropdownMenuItem onSelect={() => onMore(published ? "archive" : "activate", product)}>{published ? <Archive aria-hidden="true" /> : <Eye aria-hidden="true" />}{published ? "Archive product" : "Publish product"}</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onSelect={() => onMore("delete", product)} className="text-destructive focus:text-destructive"><Trash2 aria-hidden="true" />Delete product</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

    </div>
  );
}

export default ProductRow;
