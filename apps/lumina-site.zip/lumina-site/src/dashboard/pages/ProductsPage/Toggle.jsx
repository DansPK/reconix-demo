import { Switch as HeroSwitch } from "@heroui/react";

function Toggle({enabled, onChange, ...props}) {
  return (
    <HeroSwitch isSelected={enabled} onValueChange={onChange} color="primary" size="sm" {...props} />
  );
}

export default Toggle;
