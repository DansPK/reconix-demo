import { useEffect, useRef, useState } from "react";
import { ImagePlus, X } from "lucide-react";
import { Button } from "../../../components/ui/button";

export default function ProductMedia({ existing, files, onFilesChange, onRemove }) {
  const input = useRef(null);
  const [error, setError] = useState("");
  const [previews, setPreviews] = useState([]);
  useEffect(() => {
    const urls = files.map(file => URL.createObjectURL(file));
    setPreviews(urls);
    return () => urls.forEach(url => URL.revokeObjectURL(url));
  }, [files]);
  const add = incoming => {
    const picked = [...incoming];
    if (picked.some(file => !["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 5 * 1024 * 1024)) { setError("Choose JPG, PNG, or WebP files smaller than 5 MB."); return; }
    setError(""); onFilesChange([...files, ...picked]);
  };
  return <section className="rounded-xl border bg-card p-5">
    <h2 className="text-sm font-semibold">Product images</h2><p className="mt-1 text-xs text-muted-foreground">Upload photos in display order. The first image is the cover.</p>
    <div className="mt-4 flex flex-wrap gap-3">
      {existing.map(image => <div key={image.id} className="relative h-24 w-24"><img src={image.src} alt="Saved product photo" className="h-full w-full rounded-lg border object-cover" /><Button type="button" variant="outline" size="icon" aria-label="Remove saved image" className="absolute -right-2 -top-2 h-6 w-6 rounded-full" onClick={() => onRemove(image.id)}><X aria-hidden="true" /></Button></div>)}
      {previews.map((src, index) => <div key={src} className="relative h-24 w-24"><img src={src} alt={`New photo ${index + 1}`} className="h-full w-full rounded-lg border object-cover" /><Button type="button" variant="outline" size="icon" aria-label={`Remove new image ${index + 1}`} className="absolute -right-2 -top-2 h-6 w-6 rounded-full" onClick={() => onFilesChange(files.filter((_, i) => i !== index))}><X aria-hidden="true" /></Button></div>)}
    </div>
    <button type="button" onClick={() => input.current?.click()} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); add(event.dataTransfer.files); }} className="mt-4 flex w-full flex-col items-center gap-2 rounded-lg border border-dashed p-5 text-xs text-muted-foreground hover:border-primary hover:bg-accent"><ImagePlus size={20} aria-hidden="true" /><span className="font-medium text-foreground">Choose photos or drag them here</span><span>JPG, PNG, WebP · up to 5 MB each</span></button>
    <input ref={input} type="file" multiple accept="image/jpeg,image/png,image/webp" className="sr-only" aria-label="Upload product images" onChange={event => { add(event.target.files || []); event.target.value = ""; }} />
    {error && <p role="alert" className="mt-3 text-xs text-destructive">{error}</p>}
  </section>;
}
