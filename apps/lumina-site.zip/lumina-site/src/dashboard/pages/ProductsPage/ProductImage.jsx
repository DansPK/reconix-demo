import { Package } from "lucide-react";
import { useEffect, useState } from "react";
import { C } from "./helpers";

function ProductImage({src, alt = "Product"}) {
  const [imageError, setImageError] = useState(false);

  useEffect(() => setImageError(false), [src]);
  return (
    <div style={{
      width:"44px",
      height:"44px",
      borderRadius:"10px",
      background:C.surface,
      display:"flex",
      alignItems:"center",
      justifyContent:"center",
      overflow:"hidden",
      flexShrink:0
    }}>
      {!imageError && src ? (
        <img src={src} alt={alt} onError={()=>setImageError(true)} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
      ) : (
        <Package size={20} aria-label="Image unavailable" style={{ color: C.muted }} />
      )}
    </div>
  );
}

export default ProductImage;
