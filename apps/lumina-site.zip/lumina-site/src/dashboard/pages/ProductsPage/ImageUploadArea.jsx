import { useState } from "react";
import { C } from "./helpers";

function ImageUploadArea({onImageSelect}) {
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(e.type === "dragenter" || e.type === "dragover");
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    // Pass the File itself. It is uploaded as multipart on save; a base64 data URL
    // would have to be carried through the whole form and stored inline.
    for (const file of e.dataTransfer.files) {
      if (file.type.startsWith("image/")) onImageSelect(file);
    }
  };

  return (
    <div
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      style={{
        border:`2px dashed ${dragActive ? C.primary : C.border}`,
        borderRadius:"10px",
      padding:"14px 16px",
        textAlign:"center",
        cursor:"pointer",
        background:dragActive ? C.primaryBg : C.surface,
        transition:"all .2s",
      }}
    >
      <div style={{fontSize: "1.5714rem",fontWeight:"700",marginBottom:"4px",color:C.textSub}}>IMG</div>
      <div style={{fontSize: "0.92857rem",fontWeight:"600",color:C.text,marginBottom:"4px"}}>Upload images</div>
      <div style={{fontSize: "0.85714rem",color:C.textMuted}}>Drag and drop or click to select</div>
      <div style={{fontSize: "0.78571rem",color:C.muted,marginTop:"5px"}}>JPG, PNG, WebP up to 5 MB</div>
      <input
        type="file"
        accept="image/*"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onImageSelect(file);
        }}
        style={{display:"none"}}
      />
    </div>
  );
}

export default ImageUploadArea;
