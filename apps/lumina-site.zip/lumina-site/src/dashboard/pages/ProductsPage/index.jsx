import ProductDeleteDialog from "./ProductDeleteDialog";
import { toAdminProduct } from "../../adminCatalog";
import AdminPageHeader from "../../components/AdminPageHeader";
import { usePageFilters } from "../../usePageFilters";
import { Search } from "lucide-react";
import { ResourceError, ResourceLoading } from "../../../components/ResourceFeedback";
import { useEffect, useMemo, useState } from "react";
import {
  Button as HeroButton,
  Input,
  Select,
  SelectItem,
} from "@heroui/react";
import { useLocation } from "react-router-dom";
import { useDashboardData } from "../../DashboardDataContext";
import { C, FONT_STACK, buildCategoryIndex } from "./helpers";
import ProductForm from "./ProductForm";
import ProductRow from "./ProductRow";
import BulkActionBar from "./BulkActionBar";

function ProductsPage() {
  const location = useLocation();
  const { categories: categoryData, products, catalog } = useDashboardData();
  const [bulkBusy, setBulkBusy] = useState(false);
  const [actionError, setActionError] = useState("");
  const [actionSuccess, setActionSuccess] = useState("");
  const [deleteRequest, setDeleteRequest] = useState(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const { categoryNames, subCatsByCategory, allSubCats } = useMemo(() => buildCategoryIndex(categoryData), [categoryData]);
  const [filters, updateFilters] = usePageFilters({"q": "", "category": "All", "subcategory": "All", "status": "All", "sort": "newest"});
  const search = filters.q;
  const setSearch = value => updateFilters({ q: value });
  const categoryFilter = filters.category;
  const setCategoryFilter = value => updateFilters({ category: value });
  const subCategoryFilter = filters.subcategory;
  const setSubCategoryFilter = value => updateFilters({ subcategory: value });
  const statusFilter = filters.status;
  const setStatusFilter = value => updateFilters({ status: value });
  const sortBy = filters.sort;
  const setSortBy = value => updateFilters({ sort: value });





  const [selectedProducts, setSelectedProducts] = useState(new Set());
  const [currentPage, setCurrentPage] = useState(1);
  const [editingProduct, setEditingProduct] = useState(null);
  const [isCreating, setIsCreating] = useState(() => location.state?.create === true);
  const itemsPerPage = 10;
  useEffect(() => { setCurrentPage(1); setSelectedProducts(new Set()); }, [search, categoryFilter, subCategoryFilter, statusFilter, sortBy]);

  // Show form if editing or creating
  if(editingProduct) {
    return (
      <ProductForm
        product={editingProduct}
        mode="edit"
        onSave={() => setEditingProduct(null)}
        onCancel={() => setEditingProduct(null)}
        products={products}
        catalog={catalog}
        onBack={() => setEditingProduct(null)}
      />
    );
  }

  if(isCreating) {
    return (
      <ProductForm
        mode="create"
        onSave={() => setIsCreating(false)}
        onCancel={() => setIsCreating(false)}
        products={products}
        catalog={catalog}
        onBack={() => setIsCreating(false)}
      />
    );
  }

  // Filter products
  const filtered = products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
                       (p.sku || "").toLowerCase().includes(search.toLowerCase()) ||
                       p.cat.toLowerCase().includes(search.toLowerCase()) ||
                       (p.subCat || "").toLowerCase().includes(search.toLowerCase());
    const matchCategory = categoryFilter === "All" || p.cat === categoryFilter;
    const matchSubCategory = subCategoryFilter === "All" || p.subCat === subCategoryFilter;
    const matchStatus = statusFilter === "All" || p.status === statusFilter;
    return matchSearch && matchCategory && matchSubCategory && matchStatus;
  });

  // Sort products
  const sorted = [...filtered].sort((a, b) => {
    if(sortBy === "newest") return b.id - a.id;
    if(sortBy === "oldest") return a.id - b.id;
    if(sortBy === "price-low") return a.price - b.price;
    if(sortBy === "price-high") return b.price - a.price;
    if(sortBy === "stock-low") return a.stock - b.stock;
    if(sortBy === "stock-high") return b.stock - a.stock;
    return 0;
  });

  // Paginate
  const totalPages = Math.ceil(sorted.length / itemsPerPage);
  const paginatedProducts = sorted.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  const handleSelectProduct = (id) => {
    const newSelected = new Set(selectedProducts);
    if(newSelected.has(id)) newSelected.delete(id);
    else newSelected.add(id);
    setSelectedProducts(newSelected);
  };

  const handleSelectAll = () => {
    if(paginatedProducts.length > 0 && paginatedProducts.every(p => selectedProducts.has(p.id))) {
      setSelectedProducts(new Set());
    } else {
      setSelectedProducts(new Set(paginatedProducts.map(p => p.id)));
    }
  };

  const handleClearSelection = () => setSelectedProducts(new Set());

  // Each action is a request now, so each one can fail. Archiving sets active=false;
  // `status` is recomputed from the variants rather than written here.
  const handleSingleAction = async (action, product) => {
    setActionError("");
    setActionSuccess("");
    try {
      if (action === "archive" || action === "activate") {
        await catalog.patchProduct(product.id, { active: action === "activate" });
        setActionSuccess(`${product.name} ${action === "activate" ? "activated" : "archived"}.`);
        return;
      }

      if (action === "delete") {
        setDeleteRequest({ ids: [product.id], label: product.name });
      }
    } catch (error) {
      // 409s are the interesting ones: the server refuses a delete that would orphan
      // rows, and says which in `detail`.
      setActionError(error?.detail || `Could not ${action} ${product.name}.`);
    }
  };

  const handleBulkAction = async (action, confirmedIds) => {
    if (bulkBusy) return;
    const ids = confirmedIds || [...selectedProducts];
    if (action === "Delete" && !confirmedIds) { setActionError(""); setDeleteRequest({ ids, label: `${ids.length} selected products` }); return; }
    setBulkBusy(true);
    setActionError("");
    const results = await Promise.allSettled(ids.map(id => action === "Delete" ? catalog.deleteProduct(id) : catalog.patchProduct(id, { active: action === "Activate" })));
    const failedIds = ids.filter((id, index) => results[index].status === "rejected");
    setSelectedProducts(new Set(failedIds));
    if (failedIds.length) setActionError(`${failedIds.length} products could not be updated. ${results.find(result => result.status === "rejected").reason?.detail || "Try again."}`);
    setBulkBusy(false);
  };

  const confirmDelete = async () => {
    if (deleteBusy || !deleteRequest) return;
    setDeleteBusy(true);
    await handleBulkAction("Delete", deleteRequest.ids);
    setDeleteBusy(false);
    setDeleteRequest(null);
  };

  const today = new Date();
  const dateStr = today.toLocaleDateString("en-US", {weekday:"long",year:"numeric",month:"long",day:"numeric"});

  return (
    <div style={{flex:1,overflowY:"auto",padding:"24px",background:C.surface,fontFamily:FONT_STACK,color:C.text}}>
      <style>{`
        .products-filter-toolbar {
          display: grid;
          grid-template-columns: minmax(280px, 2.5fr) minmax(120px, 1fr) minmax(145px, 1.15fr) minmax(115px, 0.85fr) minmax(135px, 0.95fr);
          align-items: center;
          gap: 10px;
          padding: 12px 16px;
        }
        .products-filter-search,
        .products-filter-control {
          min-width: 0;
          width: 100%;
        }
        .products-filter-control .group {
          width: 100%;
        }
        .products-filter-search [data-slot="input-wrapper"],
        .products-filter-control [data-slot="trigger"] {
          min-height: 44px;
        }
        @media (max-width: 900px) {
          .products-filter-toolbar {
            grid-template-columns: minmax(220px, 2fr) repeat(2, minmax(135px, 1fr));
          }
          .products-filter-search {
            grid-column: 1 / -1;
          }
        }
        @media (max-width: 560px) {
          .products-filter-toolbar {
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 8px;
            padding: 12px;
          }
          .products-filter-search {
            grid-column: 1 / -1;
          }
        }
      `}</style>
      <AdminPageHeader title="Products" description={`${products.length} loaded of ${catalog.totalElements ?? products.length} products · Select a row to edit`} actions={
        <HeroButton color="primary" variant="solid" onPress={() => setIsCreating(true)}>+ Add Product</HeroButton>
      } />

      {actionError && <p role="alert" className="mb-4 rounded-lg border border-destructive/20 bg-card px-4 py-3 text-sm text-destructive">{actionError}</p>}
      {actionSuccess && <p role="status" className="mb-4 rounded-lg border bg-card px-4 py-3 text-sm">{actionSuccess}</p>}
      {catalog.error && <ResourceError message="Could not load products." retry={catalog.refreshAll} />}
      {catalog.loading && <ResourceLoading />}
      {/* Table Card */}
      <div style={{background:C.white,border:`1px solid ${C.border}`,borderRadius:"14px",boxShadow:"0 1px 2px rgba(0,0,0,0.05)",overflow:"hidden"}}>

        {/* Toolbar */}
        <div className="products-filter-toolbar" style={{borderBottom:`1px solid ${C.border}`}}>
          <div className="products-filter-search">
            <Input
              value={search}
              onValueChange={setSearch}
              aria-label="Search products"
              placeholder="Search by product name, SKU, category or sub category..."
              size="md"
              variant="bordered"
              startContent={<Search size={18} aria-hidden="true" />}
            />
          </div>

          <Select
            className="products-filter-control"
            size="md"
            variant="bordered"
            selectedKeys={new Set([categoryFilter])}
            onSelectionChange={(keys) => {
              const nextValue = Array.from(keys)[0] || "All";
              updateFilters({ category: nextValue, subcategory: "All" });
            }}
            aria-label="Filter by category"
          >
            {[
              { key: "All", label: "All" },
              ...categoryNames.map((cat) => ({ key: cat, label: cat })),
            ].map((option) => (
              <SelectItem key={option.key}>{option.label}</SelectItem>
            ))}
          </Select>

          <Select
            className="products-filter-control"
            size="md"
            variant="bordered"
            selectedKeys={new Set([subCategoryFilter])}
            onSelectionChange={(keys) => setSubCategoryFilter(Array.from(keys)[0] || "All")}
            aria-label="Filter by subcategory"
          >
            <SelectItem key="All">All sub categories</SelectItem>
            {(categoryFilter === "All" ? allSubCats : (subCatsByCategory[categoryFilter] || [])).map((sub) => (
              <SelectItem key={sub}>{sub}</SelectItem>
            ))}
          </Select>

          <Select
            className="products-filter-control"
            size="md"
            variant="bordered"
            selectedKeys={new Set([statusFilter])}
            onSelectionChange={(keys) => setStatusFilter(Array.from(keys)[0] || "All")}
            aria-label="Filter by status"
          >
            <SelectItem key="All">All status</SelectItem>
            <SelectItem key="active">Active</SelectItem>
            <SelectItem key="low-stock">Low stock</SelectItem>
            <SelectItem key="out-of-stock">Out of stock</SelectItem>
          </Select>

          <Select
            className="products-filter-control"
            size="md"
            variant="bordered"
            selectedKeys={new Set([sortBy])}
            onSelectionChange={(keys) => setSortBy(Array.from(keys)[0] || "newest")}
            aria-label="Sort products"
          >
            <SelectItem key="newest">Newest first</SelectItem>
            <SelectItem key="oldest">Oldest first</SelectItem>
            <SelectItem key="price-low">Price: Low to High</SelectItem>
            <SelectItem key="price-high">Price: High to Low</SelectItem>
            <SelectItem key="stock-low">Stock: Low to High</SelectItem>
            <SelectItem key="stock-high">Stock: High to Low</SelectItem>
          </Select>
        </div>

        {/* Bulk Action Bar */}
        {selectedProducts.size > 0 && (
          <BulkActionBar
            selectedCount={selectedProducts.size}
            onClearSelection={handleClearSelection}
            onAction={handleBulkAction}
            busy={bulkBusy}
          />
        )}

        <div className="overflow-x-auto">
        {/* Table Header */}
        <div style={{
          display:"grid",
          gridTemplateColumns:"32px minmax(0, 2.4fr) minmax(120px, 0.8fr) minmax(130px, 0.9fr) minmax(150px, 0.9fr) 120px",
          alignItems:"center",
          gap:"16px",
          padding:"12px 20px",
          background:C.surface,
          borderBottom:`1px solid ${C.border}`,
          position:"sticky",
          top:0,
          zIndex:10,
        }}>
          <div>
            <input aria-label="Select products on this page" type="checkbox" checked={paginatedProducts.length > 0 && paginatedProducts.every(p => selectedProducts.has(p.id))} onChange={handleSelectAll} style={{width:"18px",height:"18px",cursor:"pointer"}}/>
          </div>
          <div style={{fontSize: "0.78571rem",fontWeight:"500",color:C.muted,textTransform:"uppercase",letterSpacing:"0.05em"}}>Product</div>
          <div style={{fontSize: "0.78571rem",fontWeight:"500",color:C.muted,textTransform:"uppercase",letterSpacing:"0.05em"}}>Price</div>
          <div style={{fontSize: "0.78571rem",fontWeight:"500",color:C.muted,textTransform:"uppercase",letterSpacing:"0.05em"}}>Inventory</div>
          <div style={{fontSize: "0.78571rem",fontWeight:"500",color:C.muted,textTransform:"uppercase",letterSpacing:"0.05em"}}>Visibility</div>
          <div style={{fontSize: "0.78571rem",fontWeight:"500",color:C.muted,textTransform:"uppercase",letterSpacing:"0.05em",textAlign:"right"}}>Actions</div>
        </div>

        {/* Product Rows */}
        {paginatedProducts.length === 0 ? (
          <div style={{textAlign:"center",padding:"60px 20px",color:C.muted}}>
            <div style={{fontSize: "0.85714rem",fontWeight:"700",letterSpacing:"0.06em",marginBottom:"8px",color:C.textSub}}>BOX</div>
            <div style={{fontSize: "1.1429rem",fontWeight:"600",color:C.text,marginBottom:"4px"}}>No products found</div>
            <div style={{fontSize: "0.92857rem",color:C.muted}}>Try changing your search or filter, or add your first product.</div>
          </div>
        ) : (
          paginatedProducts.map((product) => (
            <ProductRow
              key={product.id}
              product={product}
              selected={selectedProducts.has(product.id)}
              onSelect={handleSelectProduct}
              onEdit={(p)=>setEditingProduct(p)}
              onMore={handleSingleAction}
            />
          ))
        )}
        </div>
      </div>

      {/* Pagination */}
      {paginatedProducts.length > 0 && (
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"16px 20px",marginTop:"20px"}}>
          <div style={{fontSize: "0.92857rem",color:C.muted}}>
            Showing {(currentPage - 1) * itemsPerPage + 1}–{Math.min(currentPage * itemsPerPage, sorted.length)} of {sorted.length} products
          </div>
          <div style={{display:"flex",alignItems:"center",gap:"8px"}}>
            <button
              onClick={()=>setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
              style={{
                padding:"6px 12px",
                fontSize: "0.85714rem",
                border:`1px solid ${C.border}`,
                borderRadius:"6px",
                background:currentPage === 1 ? C.surface : C.white,
                color:currentPage === 1 ? C.muted : C.text,
                cursor:currentPage === 1 ? "not-allowed" : "pointer",
              }}
            >
              ‹ Previous
            </button>
            {Array.from({length: Math.min(5, totalPages)}, (_, i) => {
              const pageNum = i + 1;
              return (
                <button
                  key={pageNum}
                  onClick={()=>setCurrentPage(pageNum)}
                  style={{
                    padding:"6px 10px",
                    fontSize: "0.85714rem",
                    border:`1px solid ${C.border}`,
                    borderRadius:"6px",
                    background:currentPage === pageNum ? C.primaryBg : C.white,
                    color:currentPage === pageNum ? C.primary : C.text,
                    cursor:"pointer",
                    fontWeight:currentPage === pageNum ? "600" : "400",
                  }}
                >
                  {pageNum}
                </button>
              );
            })}
            <button
              onClick={()=>setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
              style={{
                padding:"6px 12px",
                fontSize: "0.85714rem",
                border:`1px solid ${C.border}`,
                borderRadius:"6px",
                background:currentPage === totalPages ? C.surface : C.white,
                color:currentPage === totalPages ? C.muted : C.text,
                cursor:currentPage === totalPages ? "not-allowed" : "pointer",
              }}
            >
              Next ›
            </button>
          </div>
        </div>
      )}
      <ProductDeleteDialog open={!!deleteRequest} label={deleteRequest?.label} busy={deleteBusy} onClose={() => setDeleteRequest(null)} onConfirm={confirmDelete} />
    </div>
  );
}


export default ProductsPage;
