import { Chip as HeroChip } from "@heroui/react";
import { getStatusLabel } from "./helpers";

function StatusBadge({status}) {
  const toneMap = {
    active: "success",
    "low-stock": "warning",
    "out-of-stock": "danger",
  };

  return (
    <HeroChip
      color={toneMap[status] || "default"}
      radius="full"
      size="sm"
      variant="flat"
      className="font-medium"
      startContent={<span className="h-2 w-2 rounded-full bg-current opacity-80" />}
    >
      {getStatusLabel(status)}
    </HeroChip>
  );
}

export default StatusBadge;
