// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";

const { updateDeliveryFee } = vi.hoisted(() => ({ updateDeliveryFee: vi.fn() }));

vi.mock("../../api/storeSettings", () => ({
  DELIVERY_FEE_RESOURCE_KEY: "/v1/store-settings/delivery-fee",
  updateDeliveryFee,
}));

vi.mock("../../hooks/useDeliveryFee", () => ({
  useDeliveryFee: () => ({
    data: { deliveryFee: 2.5, updatedAt: "2026-10-07T10:00:00" },
    loading: false,
    error: null,
    refetch: vi.fn(),
  }),
}));

import DeliveryFeeSettingsCard from "./DeliveryFeeSettingsCard";

afterEach(() => {
  cleanup();
  vi.clearAllMocks();
});

describe("delivery fee admin setting", () => {
  it("saves the new fee and confirms the change", async () => {
    updateDeliveryFee.mockResolvedValue({ deliveryFee: 4.25 });
    render(<DeliveryFeeSettingsCard />);

    fireEvent.change(screen.getByLabelText("Fee per order"), { target: { value: "4.25" } });
    fireEvent.click(screen.getByRole("button", { name: "Save delivery fee" }));

    await waitFor(() => expect(updateDeliveryFee).toHaveBeenCalledWith(4.25));
    const status = await screen.findByRole("status");
    expect(status.textContent).toContain("Delivery fee saved and checkout updated.");
  });
});
