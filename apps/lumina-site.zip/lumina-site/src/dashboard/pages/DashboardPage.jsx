import AdminPageHeader from "../components/AdminPageHeader";
import { Link } from "react-router-dom";
import { ArrowUpRight, Boxes, ShoppingBag } from "lucide-react";
import { useReportPeriod } from "../adminReports";
import { useAdminOrders } from "../adminOrders";
import { useAdminPaymentSummary } from "../adminPayments";
import { useResource } from "../../hooks/useResource";
import { getInventoryReport } from "../../api/admin";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Badge } from "../../components/ui/badge";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "../../components/ui/table";
import { ResourceError, ResourceLoading } from "../../components/ResourceFeedback";
import ReportOverview from "./ReportsPage/ReportOverview";
import SalesTrend from "../components/SalesTrend";
import StatusDonut from "./DashboardPage/StatusDonut";
import TopProducts from "./ReportsPage/TopProducts";
import CategoryBars from "./ReportsPage/CategoryBars";
import PaymentSplit from "./ReportsPage/PaymentSplit";
import { formatMoney } from "./ReportsPage/helpers";

export default function DashboardPage({ period }) {
  const { data, loading, error, refetch } = useReportPeriod(period);
  const { orders, loading: ordersLoading, error: ordersError, refetch: refetchOrders } = useAdminOrders({ size: 5 });
  const { summary, loading: paymentLoading, error: paymentError, refetch: refetchPayments } = useAdminPaymentSummary();
  const { data: stock, loading: stockLoading, error: stockError, refetch: refetchStock } = useResource("/v1/admin/reports/inventory", getInventoryReport);
  const inventory = Array.isArray(stock) ? stock : [];
  const stockCounts = [
    { name: "Out of stock", color: "var(--admin-danger)", value: inventory.filter(v => v.stock === 0).length },
    { name: "1–5 units", color: "var(--admin-warning)", value: inventory.filter(v => v.stock > 0 && v.stock <= 5).length },
    { name: "6+ units", color: "var(--admin-success)", value: inventory.filter(v => v.stock > 5).length },
  ];
  return (
    <div className="flex flex-col gap-6 p-6">
      <AdminPageHeader spaced={false} title="Overview" description={`${data?.label || "Your store at a glance"} · Paid, non-cancelled orders`} actions={
        <Button variant="outline" asChild><Link to="/dashboard/reports">View reports<ArrowUpRight data-icon="inline-end" /></Link></Button>
      } />
      {error ? <ResourceError message="Could not load sales metrics." retry={refetch} /> : loading && !data ? <ResourceLoading /> : data && <>
        <ReportOverview data={data} />
        <div className="grid gap-6 xl:grid-cols-[1.7fr_1fr]">
          <SalesTrend key={period} bars={data.bars} />
          <TopProducts products={data.topProducts} />
        </div>
        <div className="grid gap-6 lg:grid-cols-2"><CategoryBars categories={data.categories} /><PaymentSplit split={data.paymentSplit} /></div>
      </>}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="min-w-0 shadow-none">
          <CardHeader className="flex-row items-start justify-between gap-3"><div className="flex flex-col gap-2"><CardTitle>Stock availability</CardTitle><CardDescription>Current active variants · fixed 5-unit threshold</CardDescription></div><Boxes className="text-muted-foreground" aria-hidden="true" /></CardHeader>
          <CardContent>{stockError ? <ResourceError message="Stock report unavailable." retry={refetchStock} /> : stockLoading ? <ResourceLoading /> : <StatusDonut items={stockCounts} unit="variants" />}
            <Button variant="link" asChild><Link to="/dashboard/inventory">Manage inventory<ArrowUpRight data-icon="inline-end" /></Link></Button>
          </CardContent>
        </Card>
        <Card className="min-w-0 shadow-none">
          <CardHeader><CardTitle>Payment status</CardTitle><CardDescription>All-time payment records · includes unpaid attempts</CardDescription></CardHeader>
          <CardContent>{paymentError ? <ResourceError message="Payment summary unavailable." retry={refetchPayments} /> : paymentLoading ? <ResourceLoading /> : <StatusDonut items={[
            { name: "Paid", color: "var(--admin-success)", value: summary?.paidCount || 0 }, { name: "Pending", color: "var(--admin-warning)", value: summary?.pendingCount || 0 },
            { name: "Failed", color: "var(--admin-danger)", value: summary?.failedCount || 0 }, { name: "Expired", color: "var(--admin-neutral)", value: summary?.expiredCount || 0 },
            { name: "Refunded", color: "var(--admin-primary-text)", value: summary?.refundedCount || 0 }, { name: "Partially refunded", color: "var(--admin-muted-foreground)", value: summary?.partiallyRefundedCount || 0 },
          ]} unit="payments" />}
            <Button variant="link" asChild><Link to="/dashboard/payments">Review payments<ArrowUpRight data-icon="inline-end" /></Link></Button>
          </CardContent>
        </Card>
      </div>
      <Card className="min-w-0 shadow-none">
        <CardHeader className="flex-row flex-wrap items-center justify-between gap-3"><div className="flex flex-col gap-2"><CardTitle>Recent orders</CardTitle><CardDescription>Latest five orders across all statuses</CardDescription></div><Button variant="outline" size="sm" asChild><Link to="/dashboard/orders">View all orders</Link></Button></CardHeader>
        <CardContent>{ordersError ? <ResourceError message="Could not load recent orders." retry={refetchOrders} /> : ordersLoading ? <ResourceLoading /> : !orders.length ? <div className="flex flex-col items-center gap-3 py-10 text-muted-foreground"><ShoppingBag aria-hidden="true" /><p className="text-sm">No orders yet.</p></div> :
          <Table><TableHeader><TableRow><TableHead>Order</TableHead><TableHead>Customer</TableHead><TableHead>Amount</TableHead><TableHead>Fulfillment</TableHead><TableHead>Payment</TableHead></TableRow></TableHeader>
            <TableBody>{orders.map(order => <TableRow key={order.id}><TableCell><Link className="font-medium text-primary underline-offset-4 hover:underline" to={`/dashboard/orders/${order.id}`}>{order.code || `#${order.id}`}</Link></TableCell><TableCell>{order.customer}</TableCell><TableCell className="tabular-nums">{formatMoney(order.amount)}</TableCell><TableCell><Badge variant="secondary">{order.status}</Badge></TableCell><TableCell><Badge variant="outline">{order.paymentStatus}</Badge></TableCell></TableRow>)}</TableBody>
          </Table>}
        </CardContent>
      </Card>
    </div>
  );
}
