import { useState } from "react";
import { Image } from "lucide-react";

const DEFAULT_IMAGE = "/images/products/unsplash/tee.jpg";

export default function CategoryThumbnail({ node, products }) {
  const [failed, setFailed] = useState(new Set());
  const product = products.find(product => product.categoryId === node.id && (product.image || product.images?.[0]));
  const candidates = [
    { src: node.imageUrl, label: "Category image" },
    { src: product?.image || product?.images?.[0], label: "Product image preview" },
    { src: DEFAULT_IMAGE, label: "Default thumbnail — upload a category image to customize" },
  ];
  const image = candidates.find(candidate => candidate.src && !failed.has(candidate.src));
  return image ? <img src={image.src} alt="" title={image.label} className="h-10 w-10 shrink-0 rounded-md border object-cover" onError={() => setFailed(previous => new Set([...previous, image.src]))} /> : <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground"><Image size={15} aria-hidden="true" /></div>;
}
