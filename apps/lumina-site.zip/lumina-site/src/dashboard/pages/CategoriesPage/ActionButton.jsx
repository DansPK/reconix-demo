import { Button } from "@heroui/react";

export function ActionButton({ children, onPress, color = "default", variant = "bordered", isDisabled = false }) {
  return (
    <Button size="sm" color={color} variant={variant} onPress={onPress} isDisabled={isDisabled}>
      {children}
    </Button>
  );
}
