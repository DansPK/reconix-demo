import CategoryThumbnail from "./CategoryThumbnail";
import { useState } from "react";
import { Modal, ModalContent, ModalHeader, ModalBody, ModalFooter } from "@heroui/react";
import { Button } from "../../../components/ui/button";
import { Badge } from "../../../components/ui/badge";
import AdminPageHeader from "../../components/AdminPageHeader";
import { ResourceError, ResourceLoading } from "../../../components/ResourceFeedback";
import { useDashboardData } from "../../DashboardDataContext";
import { ManagementModal } from "./ManagementModal";
import SubcategoryToolbar from "./SubcategoryToolbar";
import CategoryBrowser from "./CategoryBrowser";
import CategoryActions from "./CategoryActions";

export default function CategoriesPage() {
  const { catalog, products = [] } = useDashboardData();
  const roots = catalog.tree || [];
  const [selection, setSelection] = useState({ mainId: null, groupId: null });
  const [query, setQuery] = useState("");
  const [modal, setModal] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const main = roots.find(node => node.id === selection.mainId) || roots[0];
  const group = (main?.children || []).find(node => node.id === selection.groupId) || main?.children?.[0];
  const items = group?.children || [];
  const filtered = items.filter(node => node.name.toLowerCase().includes(query.trim().toLowerCase()));
  const select = (mainId, groupId) => { setSelection({ mainId, groupId }); setQuery(""); };
  const open = (entity, mode, node, root = main, parentGroup = group) => {
    setError("");
    setModal({ entity, mode, nodeId: node?.id, value: node?.name || "", icon: node?.imageUrl || "", parent: root?.name || "", mainId: root?.id, groupId: parentGroup?.id, groupLabel: parentGroup?.name || "" });
  };
  const submit = async ({ name, parent, iconFile }) => {
    if (busy) return;
    setBusy(true); setError("");
    try {
      let node;
      let targetMain = roots.find(root => root.name === parent);
      if (modal.mode === "edit") {
        node = await catalog.renameCategory(modal.nodeId, { name });
        targetMain = roots.find(root => root.id === modal.mainId);
      } else if (modal.entity === "Main category") {
        node = await catalog.createCategory({ name });
      } else if (modal.entity === "Group") {
        if (!targetMain) throw new Error("Choose a main category for this group.");
        node = await catalog.createCategory({ name, parentId: targetMain.id });
      } else {
        const targetGroup = roots.flatMap(root => root.children || []).find(candidate => candidate.id === modal.groupId);
        if (!targetGroup) throw new Error("Choose a group before adding a sub-category.");
        node = await catalog.createCategory({ name, parentId: targetGroup.id });
      }
      if (iconFile) {
        // Retain the created node if the separate image upload fails, so retrying
        // saves that node rather than creating another category.
        setModal(current => ({ ...current, mode: "edit", nodeId: node?.id || modal.nodeId, value: name }));
        await catalog.uploadCategoryImage(node?.id || modal.nodeId, iconFile);
      }
      if (modal.entity === "Main category") select(node?.id || modal.nodeId, null);
      else if (modal.entity === "Group") select(targetMain?.id, node?.id || modal.nodeId);
      else select(modal.mainId, modal.groupId);
      setModal(null);
    } catch (failure) { setError(failure?.detail || failure.message || "Could not save this category."); }
    finally { setBusy(false); }
  };
  const remove = async () => {
    if (!deleting || busy) return;
    setBusy(true); setError("");
    try { await catalog.deleteCategory(deleting.id); setDeleting(null); }
    catch (failure) { setError(failure?.detail || failure.message || "Could not delete this category."); }
    finally { setBusy(false); }
  };
  const confirmDelete = node => { setError(""); setDeleting(node); };

  return <div className="flex-1 overflow-y-auto bg-background p-6">
    <AdminPageHeader title="Category Management" description="Choose a main category, select a group, then manage its sub-categories." actions={<Button size="sm" onClick={() => open("Main category", "add")}>+ Add main category</Button>} />
    <div className="mx-auto max-w-7xl">
      {catalog.error && <ResourceError message="Could not load categories." retry={catalog.refreshAll} />}
      {catalog.loading && <ResourceLoading />}
      <div className="grid items-start gap-5 lg:grid-cols-[280px_minmax(0,1fr)]">
        <CategoryBrowser roots={roots} mainId={main?.id} groupId={group?.id} onSelect={select} onAddGroup={root => open("Group", "add", null, root, null)} onEdit={(node, root) => open(node.id === root.id ? "Main category" : "Group", "edit", node, root, node)} onDelete={confirmDelete} />
        <section className="min-w-0 overflow-hidden rounded-xl border bg-card text-card-foreground">
          {group ? <>
            <SubcategoryToolbar groupLabel={group.name} parent={main.name} total={items.length} matched={filtered.length} query={query} onQueryChange={setQuery} onAdd={() => open("Sub-category", "add")} />
            <div className="border-b bg-muted/30 px-5 py-2 text-[11px] text-muted-foreground">{main.name} / {group.name} · Changes apply to this group</div>
            {filtered.length ? <div className="overflow-x-auto"><table className="w-full min-w-[480px] text-left text-xs">
              <thead className="border-b bg-muted/40 text-muted-foreground"><tr><th className="px-5 py-3 font-medium">Sub-category</th><th className="px-4 py-3 text-right font-medium">Products</th><th className="px-4 py-3 font-medium">Status</th><th className="px-5 py-3 text-right font-medium">Actions</th></tr></thead>
              <tbody>{filtered.map(node => <tr key={node.id} className="border-b last:border-0 hover:bg-muted/30">
                <td className="px-5 py-3"><div className="flex items-center gap-3"><CategoryThumbnail node={node} products={products} /><span className="font-medium">{node.name}</span></div></td>
                <td className="px-4 py-3 text-right tabular-nums">{node.productCount ?? products.filter(product => product.categoryId === node.id).length}</td>
                <td className="px-4 py-3"><Badge className="border-0 shadow-none" style={{ background: `var(--admin-${node.active === false ? "neutral" : "success"}-soft)`, color: `var(--admin-${node.active === false ? "neutral" : "success"})` }}>{node.active === false ? "Inactive" : "Active"}</Badge></td>
                <td className="px-5 py-3"><div className="flex justify-end"><CategoryActions label={node.name} editLabel="Edit details & image" onEdit={() => open("Sub-category", "edit", node)} onDelete={() => confirmDelete(node)} /></div></td>
              </tr>)}</tbody>
            </table></div> : <div className="px-5 py-12 text-center"><p className="text-sm font-medium">{query ? "No matching sub-categories" : "No sub-categories yet"}</p><p className="mt-2 text-xs text-muted-foreground">{query ? "Try another search." : `Add your first sub-category to ${main.name} / ${group.name}.`}</p></div>}
          </> : <div className="p-10 text-center"><h2 className="text-sm font-medium">{main ? `No groups in ${main.name}` : "Start your catalog"}</h2><p className="mt-2 text-xs text-muted-foreground">{main ? "Add a group, then add its sub-categories." : "Add a main category to begin."}</p>{main && <Button size="sm" className="mt-4" onClick={() => open("Group", "add", null, main, null)}>Add group to {main.name}</Button>}</div>}
        </section>
      </div>
    </div>
    {modal && <ManagementModal modal={modal} onClose={() => { if (!busy) setModal(null); }} onSubmit={submit} mainCategories={roots.map(root => root.name)} activeMain={main?.name} groupLabel={modal.groupLabel} saving={busy} submitError={error} />}
    <Modal isOpen={Boolean(deleting)} onClose={() => { if (!busy) setDeleting(null); }}><ModalContent><ModalHeader>Delete {deleting?.name}?</ModalHeader><ModalBody><p className="text-sm text-muted-foreground">Categories with products or child categories must be emptied first.</p>{error && <p className="text-xs" style={{ color: "var(--admin-danger)" }}>{error}</p>}</ModalBody><ModalFooter><Button variant="outline" disabled={busy} onClick={() => setDeleting(null)}>Cancel</Button><Button variant="destructive" disabled={busy} onClick={remove}>{busy ? "Deleting…" : "Delete"}</Button></ModalFooter></ModalContent></Modal>
  </div>;
}
