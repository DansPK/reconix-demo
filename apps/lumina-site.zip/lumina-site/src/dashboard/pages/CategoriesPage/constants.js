export const FALLBACK_IMAGE = "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=240&q=80&fit=crop";

export const GROUP_META = [
  { key: "clothing", label: "Clothing" },
  { key: "shopByStyle", label: "Shop By Style" },
  { key: "shoes", label: "Shoes" },
];

export const toGroupKey = (name) =>
  name
    .trim()
    .replace(/[^a-zA-Z0-9 ]/g, "")
    .split(/\s+/)
    .map((part, index) => (index ? part.charAt(0).toUpperCase() + part.slice(1) : part.toLowerCase()))
    .join("");
