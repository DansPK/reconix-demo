import { Plus, Search, X } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";

export default function SubcategoryToolbar({ groupLabel, parent, total, matched, query, onQueryChange, onAdd }) {
  return (
    <div className="flex flex-wrap items-center gap-x-5 gap-y-3 border-b bg-card px-5 py-4">
      <div className="min-w-0 flex-1">
        <h2 className="text-sm font-semibold">{groupLabel}</h2>
        <p className="mt-1 text-xs text-muted-foreground">{parent} · {query ? `${matched} of ${total}` : total} {total === 1 ? "sub-category" : "sub-categories"}</p>
      </div>
      <div className="relative order-last w-full sm:order-none sm:w-64">
        <Search size={15} aria-hidden="true" className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input value={query} onChange={event => onQueryChange(event.target.value)} aria-label={`Filter ${groupLabel}`} placeholder="Search sub-categories…" className="h-9 bg-background pl-9 pr-9 text-xs shadow-none" />
        {query && <Button type="button" variant="ghost" size="icon" className="absolute right-1 top-1/2 h-7 w-7 -translate-y-1/2 text-muted-foreground" aria-label="Clear filter" onClick={() => onQueryChange("")}><X size={14} aria-hidden="true" /></Button>}
      </div>
      <Button type="button" size="sm" onClick={onAdd} className="h-9 shrink-0 text-xs"><Plus aria-hidden="true" />Add sub-category</Button>
    </div>
  );
}
