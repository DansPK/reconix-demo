import { MoreHorizontal, Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "../../../components/ui/button";
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from "../../../components/ui/dropdown-menu";

export default function CategoryActions({ label, onAdd, addLabel, onEdit, onDelete, editLabel = "Rename" }) {
  return <DropdownMenu>
    <DropdownMenuTrigger asChild><Button size="icon" variant="ghost" className="h-7 w-7 shrink-0" aria-label={`Actions for ${label}`}><MoreHorizontal aria-hidden="true" /></Button></DropdownMenuTrigger>
    <DropdownMenuContent align="end">
      {onAdd && <DropdownMenuItem onSelect={onAdd}><Plus aria-hidden="true" />{addLabel}</DropdownMenuItem>}
      <DropdownMenuItem onSelect={onEdit}><Pencil aria-hidden="true" />{editLabel}</DropdownMenuItem>
      <DropdownMenuItem onSelect={onDelete} style={{ color: "var(--admin-danger)" }}><Trash2 aria-hidden="true" />Delete</DropdownMenuItem>
    </DropdownMenuContent>
  </DropdownMenu>;
}
