import { useEffect, useState } from "react";
import { Image as ImageIcon } from "lucide-react";
import {
  Button,
  Input,
  Modal,
  ModalBody,
  ModalContent,
  ModalFooter,
  ModalHeader,
  Select,
  SelectItem,
} from "@heroui/react";

export function ManagementModal({ modal, onClose, onSubmit, mainCategories, activeMain, groupLabel, saving = false, submitError }) {
  const [name, setName] = useState(modal.value || "");
  const [parent, setParent] = useState(modal.parent || activeMain || "");
  const [icon, setIcon] = useState(modal.icon || "");
  // The chosen File, uploaded as multipart on submit. The preview is a blob URL.
  const [iconFile, setIconFile] = useState(null);
  const [error, setError] = useState("");
  const [imageError, setImageError] = useState("");
  useEffect(() => {
    if (icon.startsWith("blob:")) return () => URL.revokeObjectURL(icon);
  }, [icon]);

  const submit = () => {
    const trimmed = name.trim();
    if (!trimmed) {
      setError("Name is required.");
      return;
    }
    onSubmit({ name: trimmed, parent, iconFile });
  };

  return (
    <Modal isOpen onClose={onClose} placement="center">
      <ModalContent>
        <ModalHeader>{modal.mode === "add" ? "Add" : "Edit"} {modal.entity}</ModalHeader>
        <ModalBody className="gap-4">
          <Input
            autoFocus
            label={`${modal.entity} name`}
            placeholder={`Enter ${modal.entity.toLowerCase()} name`}
            value={name}
            onValueChange={(value) => {
              setName(value);
              setError("");
            }}
            isInvalid={Boolean(error)}
            errorMessage={error}
            isRequired
          />
          {modal.entity === "Group" && modal.mode === "add" ? (
            <Select label="Parent category" selectedKeys={parent ? [parent] : []} onSelectionChange={(keys) => setParent(Array.from(keys)[0] || "")} isRequired>
              {mainCategories.map((category) => <SelectItem key={category}>{category}</SelectItem>)}
            </Select>
          ) : modal.entity !== "Main category" && <div className="rounded-lg border bg-background px-3 py-3"><p className="text-xs text-muted-foreground">Parent {modal.entity === "Sub-category" ? "group" : "category"}</p><p className="mt-1 text-sm font-medium">{parent}{modal.entity === "Sub-category" && groupLabel ? ` / ${groupLabel}` : ""}</p></div>}
          {modal.entity === "Sub-category" && (
            <>
              <label className="flex cursor-pointer items-center justify-between rounded-lg border border-dashed border-border px-3 py-2 text-sm text-muted-foreground hover:border-primary hover:bg-accent">
                <span>Or choose an image from your computer</span>
                <span className="rounded-md bg-muted px-2 py-1 text-xs font-semibold">Choose file</span>
                <input
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  onChange={(event) => {
                    const file = event.target.files?.[0];
                    if (!file) return;
                    if (!file.type.startsWith("image/")) {
                      setImageError("Please choose an image file.");
                      return;
                    }
                    if (file.size > 5 * 1024 * 1024) {
                      setImageError("Image must be smaller than 5 MB.");
                      return;
                    }
                    // Keep the File for the upload and show a local preview. Reading it
                    // into a base64 data URL, as this did before, meant the image was
                    // stored inline in localStorage and never reached the server.
                    setIconFile(file);
                    setIcon(URL.createObjectURL(file));
                    setImageError("");
                  }}
                />
              </label>
              {imageError && <p className="text-xs text-danger">{imageError}</p>}
              <div className="flex items-center gap-3 rounded-lg bg-background p-2">
                <div className="relative flex h-12 w-12 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground"><ImageIcon size={18} aria-hidden="true" />{icon && <img src={icon} alt="Selected category preview" className="absolute inset-0 h-12 w-12 rounded-md object-cover" onError={event => { event.currentTarget.style.display = "none"; }} />}</div>
                <p className="text-xs text-muted-foreground">{iconFile ? "Selected image, uploaded when you save" : "This image is shown beside the sub-category on the storefront."}</p>
              </div>
            </>
          )}
          {modal.entity === "Group" && (
            <p className="text-xs text-muted-foreground">{modal.mode === "add" ? `This group will be created under ${parent}.` : "Renaming preserves this category’s hierarchy."}</p>
          )}
          {submitError && <p role="alert" className="text-xs" style={{ color: "var(--admin-danger)" }}>{submitError}</p>}
        </ModalBody>
        <ModalFooter>
          <Button variant="light" isDisabled={saving} onPress={onClose}>Cancel</Button>
          <Button color="primary" isLoading={saving} onPress={submit}>{modal.mode === "add" ? "Create" : "Save changes"}</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
}
