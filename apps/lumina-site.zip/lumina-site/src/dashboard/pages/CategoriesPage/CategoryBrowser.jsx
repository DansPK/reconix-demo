import { ChevronDown, ChevronRight, Folder } from "lucide-react";
import { Button } from "../../../components/ui/button";
import CategoryActions from "./CategoryActions";

export default function CategoryBrowser({ roots, mainId, groupId, onSelect, onAddGroup, onEdit, onDelete }) {
  return <aside className="h-fit rounded-xl border bg-card text-card-foreground">
    <div className="border-b px-4 py-4"><h2 className="text-sm font-semibold">Catalog hierarchy</h2><p className="mt-1 text-xs text-muted-foreground">Choose a group to manage its sub-categories.</p></div>
    <nav aria-label="Category hierarchy" className="space-y-2 p-2">
      {!roots.length && <p className="px-2 py-4 text-xs text-muted-foreground">Add a main category to get started.</p>}
      {roots.map(main => <div key={main.id}>
        <div className="flex items-center gap-1 rounded-md px-1 hover:bg-muted/50">
          <button type="button" aria-expanded={mainId === main.id} onClick={() => onSelect(main.id, null)} className="flex min-w-0 flex-1 items-center gap-2 py-2.5 text-left text-sm font-medium">
            {mainId === main.id ? <ChevronDown size={14} aria-hidden="true" /> : <ChevronRight size={14} aria-hidden="true" />}<span className="truncate">{main.name}</span><span className="ml-auto text-xs font-normal text-muted-foreground">{(main.children || []).length}</span>
          </button>
          <CategoryActions label={main.name} onAdd={() => onAddGroup(main)} addLabel="Add group" onEdit={() => onEdit(main, main)} onDelete={() => onDelete(main)} />
        </div>
        {mainId === main.id && <div className="ml-3 border-l pl-2">
          {(main.children || []).map(group => <div key={group.id} className={`flex items-center gap-1 rounded-md px-2 ${groupId === group.id ? "bg-accent text-accent-foreground" : "hover:bg-muted/50"}`}>
            <button type="button" aria-current={groupId === group.id ? "true" : undefined} onClick={() => onSelect(main.id, group.id)} className="flex min-w-0 flex-1 items-center gap-2 py-2.5 text-left text-xs"><Folder size={14} aria-hidden="true" /><span className="truncate">{group.name}</span><span className="ml-auto tabular-nums text-muted-foreground">{(group.children || []).length}</span></button>
            <CategoryActions label={`${main.name} / ${group.name}`} onEdit={() => onEdit(group, main)} onDelete={() => onDelete(group)} />
          </div>)}
          {!(main.children || []).length && <p className="px-2 py-3 text-xs text-muted-foreground">No groups yet.</p>}
          <Button variant="ghost" size="sm" className="my-2 w-full justify-start text-xs text-muted-foreground" onClick={() => onAddGroup(main)}>+ Add group to {main.name}</Button>
        </div>}
      </div>)}
    </nav>
  </aside>;
}
