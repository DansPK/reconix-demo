import { C } from "./helpers";

export default function MetricCard({ title, value, hint, color }) {
  return (
    <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 12, padding: 14 }}>
      <div style={{ fontSize: "0.78571rem", color: C.muted, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>{title}</div>
      <div style={{ fontSize: "1.7143rem", fontWeight: 700, color: color || C.text }}>{value}</div>
      <div style={{ marginTop: 4, fontSize: "0.85714rem", color: C.textSub }}>{hint}</div>
    </div>
  );
}
