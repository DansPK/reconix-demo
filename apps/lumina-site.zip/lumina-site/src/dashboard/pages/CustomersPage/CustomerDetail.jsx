import { Button } from "../../../components/ui/button";
import { fmtUsd, fmtDate, roleStyle } from "./helpers";
import CustomerAvatar from "./CustomerAvatar";
import StatusPill from "./StatusPill";

export default function CustomerDetail({ selected, statusBusy, onViewOrders, onEdit, onToggleStatus }) {
  return (
    <section className="h-fit rounded-xl border bg-card p-5 text-card-foreground" aria-label="Customer profile">
      {!selected ? <p className="text-sm text-muted-foreground">Select a customer to view details.</p> : (
        <>
          <div className="flex items-start gap-3">
            <CustomerAvatar name={selected.name} size={40} />
            <div className="min-w-0 flex-1"><h2 className="text-sm font-semibold">{selected.name}</h2><p className="mt-1 text-xs text-muted-foreground">{roleStyle[selected.role || "customer"].label} · #{selected.id}</p></div>
            <StatusPill value={selected.status} />
          </div>
          <dl className="my-5 grid grid-cols-2 gap-4 border-y py-4">
            <div><dt className="text-xs text-muted-foreground">Paid orders</dt><dd className="mt-1 text-xl font-semibold tabular-nums">{selected.totalOrders}</dd></div>
            <div><dt className="text-xs text-muted-foreground">Lifetime spend</dt><dd className="mt-1 text-xl font-semibold tabular-nums">{fmtUsd(selected.totalSpent)}</dd></div>
          </dl>
          <dl className="space-y-3 text-xs">
            {[["Email", selected.email], ["Phone", selected.phone], ["City", selected.city], ["Joined", fmtDate(selected.joinedAt)], ["Last order", selected.lastOrder ? fmtDate(selected.lastOrder) : "No orders yet"]].filter(([, value]) => value && value !== "—").map(([label, value]) => (
              <div key={label} className="grid grid-cols-[75px_minmax(0,1fr)] gap-3"><dt className="text-muted-foreground">{label}</dt><dd className="break-words text-right">{value}</dd></div>
            ))}
          </dl>
          <div className="mt-5 flex flex-wrap gap-2 border-t pt-4">
            <Button size="sm" variant="outline" onClick={onViewOrders}>View Orders</Button>
            <Button size="sm" variant="outline" onClick={onEdit}>Edit</Button>
          </div>
          <Button size="sm" variant="ghost" className="mt-2 px-0 text-xs" disabled={statusBusy} onClick={onToggleStatus} style={{ color: selected.status === "Active" ? "var(--admin-danger)" : "var(--admin-success)" }}>
            {statusBusy ? "Working…" : selected.status === "Active" ? "Deactivate" : "Reactivate"}
          </Button>
        </>
      )}
    </section>
  );
}
