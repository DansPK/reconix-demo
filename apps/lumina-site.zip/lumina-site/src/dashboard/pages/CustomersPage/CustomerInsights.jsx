import { Card, CardContent, CardHeader, CardTitle } from "../../../components/ui/card";
import { ResourceLoading } from "../../../components/ResourceFeedback";
import { fmtUsd } from "./helpers";

export default function CustomerInsights({ summary, customers, loading, onSelect }) {
  const total = Number(summary?.totalCustomers ?? 0);
  const active = Number(summary?.activeCustomers ?? 0);
  const inactive = Math.max(0, total - active);
  const percent = total ? Math.min(100, active / total * 100) : 0;
  const leaders = [...customers].filter(customer => customer.totalSpent > 0).sort((a, b) => b.totalSpent - a.totalSpent).slice(0, 5);
  const maximum = leaders[0]?.totalSpent || 1;
  const circumference = 2 * Math.PI * 44;

  if (loading) return <div className="mb-5"><ResourceLoading /></div>;
  return (
    <div className="mb-5 grid gap-4 xl:grid-cols-[minmax(300px,1fr)_minmax(0,2fr)]">
      <Card className="shadow-none">
        <CardHeader className="pb-3"><CardTitle className="text-sm">Account health</CardTitle><p className="text-xs text-muted-foreground">All roles · current account status</p></CardHeader>
        <CardContent>
          <div className="flex items-center gap-6">
            <div className="relative h-32 w-32 shrink-0">
              <svg viewBox="0 0 112 112" role="img" aria-label={`${active} active and ${inactive} inactive accounts out of ${total}`} className="h-full w-full -rotate-90">
                <circle cx="56" cy="56" r="44" fill="none" stroke="var(--admin-muted)" strokeWidth="9" />
                <circle cx="56" cy="56" r="44" fill="none" stroke="var(--admin-success)" strokeWidth="9" strokeDasharray={`${circumference * percent / 100} ${circumference}`} />
              </svg>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center" aria-hidden="true"><span className="text-3xl font-semibold tabular-nums">{total}</span><span className="text-xs text-muted-foreground">accounts</span></div>
            </div>
            <dl className="min-w-0 flex-1 space-y-3 text-xs">
              <div className="flex items-center justify-between gap-4"><dt className="flex items-center gap-2"><span className="h-2 w-2 rounded-full" style={{ background: "var(--admin-success)" }} />Active</dt><dd className="font-semibold tabular-nums">{active}</dd></div>
              <div className="flex items-center justify-between gap-4"><dt className="flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-muted-foreground" />Inactive</dt><dd className="font-semibold tabular-nums">{inactive}</dd></div>
              <div className="flex justify-between gap-4 border-t pt-3 text-muted-foreground"><dt>Active share</dt><dd>{percent.toFixed(0)}%</dd></div>
            </dl>
          </div>
          <p className="mt-4 border-t pt-3 text-xs text-muted-foreground"><span className="font-semibold text-foreground">{summary?.newCustomers90d ?? 0}</span> accounts joined in the last 90 days</p>
        </CardContent>
      </Card>
      <Card className="shadow-none">
        <CardHeader className="flex-row flex-wrap items-start justify-between gap-3 pb-3">
          <div><CardTitle className="text-sm">Customer spending</CardTitle><p className="mt-2 text-xs text-muted-foreground">Top five spenders in the loaded list · paid orders only</p></div>
          <div className="text-right"><p className="text-xl font-semibold tracking-tight tabular-nums">{fmtUsd(summary?.totalRevenue)}</p><p className="mt-1 text-xs text-muted-foreground">Lifetime revenue · all paid orders</p></div>
        </CardHeader>
        <CardContent>
          {leaders.length ? (
            <>
              <ul className="space-y-1" aria-label="Customer spending ranking">
                {leaders.map(customer => (
                  <li key={customer.id}>
                    <button type="button" onClick={() => onSelect(customer.id)} aria-label={`View spending for ${customer.name}`} className="grid w-full grid-cols-[minmax(0,1fr)_auto] items-center gap-x-4 gap-y-2 rounded-md px-2 py-3 text-left hover:bg-muted sm:grid-cols-[minmax(120px,1fr)_minmax(0,2fr)_auto]">
                      <span className="truncate text-xs font-medium" title={customer.name}>{customer.name}<span className="ml-2 font-normal text-muted-foreground">#{customer.id}</span></span>
                      <span className="relative col-span-2 col-start-1 row-start-2 mx-2 h-5 sm:col-span-1 sm:col-start-2 sm:row-start-1" aria-hidden="true">
                        <span className="absolute inset-x-0 top-1/2 border-t border-dashed border-input" />
                        <span className="absolute top-1/2 h-2 -translate-y-1/2 border-l border-input" />
                        <span className="absolute right-0 top-1/2 h-2 -translate-y-1/2 border-l border-input" />
                        <span className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary ring-4 ring-primary/10" style={{ left: `${customer.totalSpent / maximum * 100}%` }} />
                      </span>
                      <span className="col-start-2 row-start-1 text-xs font-semibold tabular-nums sm:col-start-3">{fmtUsd(customer.totalSpent)}</span>
                    </button>
                  </li>
                ))}
              </ul>
              <div className="mt-2 flex justify-between border-t pt-3 text-[11px] text-muted-foreground"><span>Scale: $0</span><span>{fmtUsd(maximum)} USD</span></div>
            </>
          ) : <p className="py-8 text-center text-sm text-muted-foreground">No paid customer spending yet.</p>}
        </CardContent>
      </Card>
    </div>
  );
}
