import { Dialog, DialogContent, DialogTitle } from "../../../components/ui/dialog";
import StyledSelect from "../../../components/ui/styled-select";
import { C } from "./helpers";

export default function AddUserModal({ newCustomer, setNewCustomer, addError, adding, addCustomer, onClose }) {
  return (
    <Dialog open onOpenChange={open => { if (!open && !adding) onClose(); }}>
      <DialogContent className="max-h-[85dvh] overflow-y-auto" aria-describedby={undefined}>
      <form
        onSubmit={addCustomer}

      >
        <DialogTitle style={{ margin: "0 0 6px", fontSize: "1.2857rem" }}>Add User</DialogTitle>
        <p style={{ margin: "0 0 16px", fontSize: "0.85714rem", color: C.textSub }}>Creates an already-verified account - no OTP email is sent.</p>
        {[
          ["name", "Full name", true],
          ["email", "Email", true],
          ["password", "Password", true],
          ["phone", "Phone number", false],
          ["city", "City", false],
        ].map(([key, label, required]) => (
          <label key={key} style={{ display: "grid", gap: 6, marginBottom: 12, fontSize: "0.85714rem", fontWeight: 600, color: C.textSub }}>
            {label}
            <input
              required={required}
              type={key === "email" ? "email" : key === "password" ? "password" : "text"}
              value={newCustomer[key]}
              onChange={(event) => setNewCustomer((current) => ({ ...current, [key]: event.target.value }))}
              style={{ border: `1px solid ${C.border}`, borderRadius: 8, padding: "9px 10px", fontSize: "0.92857rem", outline: "none" }}
            />
          </label>
        ))}
        <div style={{ display: "grid", gap: 6, marginBottom: 12, fontSize: "0.85714rem", fontWeight: 600, color: C.textSub }}>
          <span>Role</span>
          <StyledSelect
            ariaLabel="Role"
            value={newCustomer.role}
            onValueChange={(role) => setNewCustomer((current) => ({ ...current, role }))}
            options={[
              { value: "customer", label: "Customer" },
              { value: "staff", label: "Staff" },
              { value: "admin", label: "Admin" },
            ]}
            className="h-10 rounded-lg bg-white text-sm"
          />
        </div>
        {addError ? <div style={{ marginBottom: 12, padding: "9px 10px", background: "var(--admin-danger-soft)", color: "var(--admin-danger)", borderRadius: 8, fontSize: "0.85714rem" }}>{addError}</div> : null}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 16 }}>
          <button type="button" onClick={onClose} style={{ border: `1px solid ${C.border}`, background: C.white, color: C.textSub, borderRadius: 8, padding: "9px 12px", fontSize: "0.85714rem", fontWeight: 600, cursor: "pointer" }}>Cancel</button>
          <button type="submit" disabled={adding} style={{ border: "none", background: C.primary, color: "hsl(var(--primary-foreground))", borderRadius: 8, padding: "9px 12px", fontSize: "0.85714rem", fontWeight: 600, cursor: adding ? "not-allowed" : "pointer" }}>{adding ? "Creating…" : "Create User"}</button>
        </div>
      </form>
      </DialogContent>
    </Dialog>
  );
}
