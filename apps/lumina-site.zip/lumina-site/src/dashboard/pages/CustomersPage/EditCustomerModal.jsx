import { Dialog, DialogContent, DialogTitle } from "../../../components/ui/dialog";
import StyledSelect from "../../../components/ui/styled-select";
import { C } from "./helpers";

export default function EditCustomerModal({ selected, editForm, setEditForm, editError, editing, saveEditCustomer, onClose }) {
  return (
    <Dialog open onOpenChange={open => { if (!open && !editing) onClose(); }}>
      <DialogContent className="max-h-[85dvh] overflow-y-auto" aria-describedby={undefined}>
      <form
        onSubmit={saveEditCustomer}

      >
        <DialogTitle style={{ margin: "0 0 6px", fontSize: "1.2857rem" }}>Edit User</DialogTitle>
        <p style={{ margin: "0 0 16px", fontSize: "0.85714rem", color: C.textSub }}>{selected.email} - email cannot be changed here.</p>
        <label style={{ display: "grid", gap: 6, marginBottom: 12, fontSize: "0.85714rem", fontWeight: 600, color: C.textSub }}>
          Full name
          <input
            required
            value={editForm.name}
            onChange={(event) => setEditForm((current) => ({ ...current, name: event.target.value }))}
            style={{ border: `1px solid ${C.border}`, borderRadius: 8, padding: "9px 10px", fontSize: "0.92857rem", outline: "none" }}
          />
        </label>
        <label style={{ display: "grid", gap: 6, marginBottom: 12, fontSize: "0.85714rem", fontWeight: 600, color: C.textSub }}>
          Phone number
          <input
            value={editForm.phone}
            onChange={(event) => setEditForm((current) => ({ ...current, phone: event.target.value }))}
            style={{ border: `1px solid ${C.border}`, borderRadius: 8, padding: "9px 10px", fontSize: "0.92857rem", outline: "none" }}
          />
        </label>
        <label style={{ display: "grid", gap: 6, marginBottom: 12, fontSize: "0.85714rem", fontWeight: 600, color: C.textSub }}>
          City
          <input
            value={editForm.city}
            onChange={(event) => setEditForm((current) => ({ ...current, city: event.target.value }))}
            style={{ border: `1px solid ${C.border}`, borderRadius: 8, padding: "9px 10px", fontSize: "0.92857rem", outline: "none" }}
          />
        </label>
        <div style={{ display: "grid", gap: 6, marginBottom: 12, fontSize: "0.85714rem", fontWeight: 600, color: C.textSub }}>
          <span>Role</span>
          <StyledSelect
            ariaLabel="Role"
            value={editForm.role}
            onValueChange={(role) => setEditForm((current) => ({ ...current, role }))}
            options={[
              { value: "customer", label: "Customer" },
              { value: "staff", label: "Staff" },
              { value: "admin", label: "Admin" },
            ]}
            className="h-10 rounded-lg bg-white text-sm"
          />
        </div>
        {editError ? <div style={{ marginBottom: 12, padding: "9px 10px", background: "var(--admin-danger-soft)", color: "var(--admin-danger)", borderRadius: 8, fontSize: "0.85714rem" }}>{editError}</div> : null}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 16 }}>
          <button type="button" onClick={onClose} style={{ border: `1px solid ${C.border}`, background: C.white, color: C.textSub, borderRadius: 8, padding: "9px 12px", fontSize: "0.85714rem", fontWeight: 600, cursor: "pointer" }}>Cancel</button>
          <button type="submit" disabled={editing} style={{ border: "none", background: C.primary, color: "hsl(var(--primary-foreground))", borderRadius: 8, padding: "9px 12px", fontSize: "0.85714rem", fontWeight: 600, cursor: editing ? "not-allowed" : "pointer" }}>{editing ? "Saving…" : "Save Changes"}</button>
        </div>
      </form>
      </DialogContent>
    </Dialog>
  );
}
