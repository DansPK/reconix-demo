import { C } from "./helpers";

export default function CustomerAvatar({ name, size = 38 }) {
  const initials = name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0].toUpperCase())
    .join("");
  const colors = ["var(--admin-primary-soft)", "var(--admin-neutral-soft)", "var(--admin-success-soft)", "var(--admin-warning-soft)", "var(--admin-neutral-soft)"];
  const colorIndex = name.split("").reduce((sum, character) => sum + character.charCodeAt(0), 0) % colors.length;

  return (
    <div
      aria-label={`${name} profile`}
      style={{
        width: size,
        height: size,
        flexShrink: 0,
        display: "grid",
        placeItems: "center",
        borderRadius: "50%",
        background: colors[colorIndex],
        color: "var(--admin-primary-text)",
        fontSize: size * 0.32,
        fontWeight: 700,
        textTransform: "uppercase",
      }}
    >
      {initials || "?"}
    </div>
  );
}
