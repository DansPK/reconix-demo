import AdminPageHeader from "../../components/AdminPageHeader";
import CustomerInsights from "./CustomerInsights";
import CustomerDetail from "./CustomerDetail";
import { Button } from "../../../components/ui/button";
import StyledSelect from "../../../components/ui/styled-select";
import { usePageFilters } from "../../usePageFilters";
import { ResourceError } from "../../../components/ResourceFeedback";
import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  useAdminCustomers,
  useAdminCustomerSummary,
  useCreateUser,
  useUpdateUser,
  useDeactivateUser,
} from "../../adminCustomers";
import { ApiError } from "../../../api/client";
import { C, FONT_STACK, roleStyle, fmtUsd } from "./helpers";
import StatusPill from "./StatusPill";
import CustomerAvatar from "./CustomerAvatar";
import AddUserModal from "./AddUserModal";
import EditCustomerModal from "./EditCustomerModal";

export default function CustomersPage() {
  const navigate = useNavigate();
  const { customers, loading, error, refetch } = useAdminCustomers();
  const { summary, loading: summaryLoading, error: summaryError, refetch: refetchSummary } = useAdminCustomerSummary();
  const createUser = useCreateUser();
  const updateUser = useUpdateUser();
  const deactivateUser = useDeactivateUser();

  const [filters, updateFilters] = usePageFilters({"q": "", "status": "All", "role": "All", "sort": "recent"});
  const search = filters.q;
  const setSearch = value => updateFilters({ q: value });
  const statusFilter = filters.status;
  const setStatusFilter = value => updateFilters({ status: value });
  const roleFilter = filters.role;
  const setRoleFilter = value => updateFilters({ role: value });
  const sortBy = filters.sort;
  const setSortBy = value => updateFilters({ sort: value });




  const [selectedId, setSelectedId] = useState(null);
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [newCustomer, setNewCustomer] = useState({
    name: "",
    email: "",
    password: "",
    phone: "",
    city: "",
    role: "customer",
  });
  const [addError, setAddError] = useState("");
  const [adding, setAdding] = useState(false);
  const [showEditCustomer, setShowEditCustomer] = useState(false);
  const [editForm, setEditForm] = useState({
    name: "",
    phone: "",
    city: "",
    role: "customer",
  });
  const [editError, setEditError] = useState("");
  const [editing, setEditing] = useState(false);
  const [statusBusy, setStatusBusy] = useState(false);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = customers.filter((c) => {
      const matchSearch =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.email.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q) ||
        String(c.id).includes(q);
      const matchStatus = statusFilter === "All" || c.status === statusFilter;
      const matchRole =
        roleFilter === "All" || (c.role || "customer") === roleFilter;
      return matchSearch && matchStatus && matchRole;
    });

    return list.sort((a, b) => {
      if (sortBy === "recent")
        return new Date(b.lastOrder || 0) - new Date(a.lastOrder || 0);
      if (sortBy === "spent-high") return b.totalSpent - a.totalSpent;
      if (sortBy === "spent-low") return a.totalSpent - b.totalSpent;
      if (sortBy === "orders-high") return b.totalOrders - a.totalOrders;
      return a.name.localeCompare(b.name);
    });
  }, [customers, search, statusFilter, roleFilter, sortBy]);

  const selected =
    filtered.find((c) => c.id === selectedId) || filtered[0] || null;

  const addCustomer = async (event) => {
    event.preventDefault();
    if (adding) return;
    const name = newCustomer.name.trim();
    const email = newCustomer.email.trim();
    const password = newCustomer.password.trim();
    if (!name || !email || !password) return;

    setAdding(true);
    setAddError("");
    try {
      const created = await createUser({
        name,
        email,
        password,
        phone: newCustomer.phone.trim() || undefined,
        city: newCustomer.city.trim() || undefined,
        role: newCustomer.role,
      });
      setSelectedId(created.id);
      setNewCustomer({
        name: "",
        email: "",
        password: "",
        phone: "",
        city: "",
        role: "customer",
      });
      setShowAddCustomer(false);
    } catch (error) {
      setAddError(
        error instanceof ApiError
          ? error.isValidation
            ? Object.values(error.errors)[0]
            : error.detail
          : "Could not create the user.",
      );
    } finally {
      setAdding(false);
    }
  };

  const openEditCustomer = () => {
    if (!selected) return;
    setEditForm({
      name: selected.name || "",
      phone: selected.phone === "—" ? "" : selected.phone || "",
      city: selected.city === "—" ? "" : selected.city || "",
      role: selected.role || "customer",
    });
    setEditError("");
    setShowEditCustomer(true);
  };

  const saveEditCustomer = async (event) => {
    event.preventDefault();
    if (!selected || editing) return;
    setEditing(true);
    setEditError("");
    try {
      await updateUser(selected.id, {
        name: editForm.name.trim() || undefined,
        phone: editForm.phone.trim() || undefined,
        city: editForm.city.trim() || undefined,
        role: editForm.role,
      });
      setShowEditCustomer(false);
    } catch (error) {
      setEditError(
        error instanceof ApiError
          ? error.isValidation
            ? Object.values(error.errors)[0]
            : error.detail
          : "Could not save changes.",
      );
    } finally {
      setEditing(false);
    }
  };

  const [statusError, setStatusError] = useState("");
  const toggleStatus = async () => {
    if (!selected) return;
    setStatusError("");
    setStatusBusy(true);
    try {
      if (selected.status === "Active") {
        await deactivateUser(selected.id);
      } else {
        await updateUser(selected.id, { isActive: true });
      }
    } catch (error) {
      setStatusError(
        error?.detail || "Could not update this account. Please try again.",
      );
    } finally {
      setStatusBusy(false);
    }
  };

  return (
    <div
      style={{
        flex: 1,
        overflowY: "auto",
        padding: 24,
        background: C.surface,
        fontFamily: FONT_STACK,
        color: C.text,
      }}
    >
      <AdminPageHeader title="Customers" description="Manage accounts, review spending, and support your customers." actions={
        <Button size="sm" onClick={() => setShowAddCustomer(true)}>+ Add User</Button>
      } />
      {(error || statusError) && (
        <ResourceError
          message={statusError || "Could not load customers."}
          retry={refetch}
        />
      )}


      {summaryError ? <ResourceError message="Could not load customer summary." retry={refetchSummary} /> : (
        <CustomerInsights summary={summary} customers={customers} loading={summaryLoading || loading} onSelect={id => {
          updateFilters({ q: "", status: "All", role: "All" });
          setSelectedId(id);
        }} />
      )}
      <div
        className="admin-panel-grid"
        style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 14 }}
      >
        <div
          style={{
            background: C.white,
            border: `1px solid ${C.border}`,
            borderRadius: 12,
            overflow: "hidden",
          }}
        >
          <div
            style={{
              padding: "14px 16px",
              borderBottom: `1px solid ${C.border}`,
              display: "flex",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <input aria-label="Search customers"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, email, phone, ID..."
              style={{
                flex: 1,
                minWidth: 220,
                border: `1px solid ${C.border}`,
                background: C.surface,
                borderRadius: 8,
                padding: "9px 10px",
                fontSize: "0.92857rem",
                outline: "none",
              }}
            />
            <StyledSelect
              ariaLabel="Customer status"
              value={statusFilter}
              onValueChange={setStatusFilter}
              options={[
                { value: "All", label: "All status" },
                { value: "Active", label: "Active" },
                { value: "Inactive", label: "Inactive" },
              ]}
              className="w-[132px] shrink-0"
            />
            <StyledSelect
              ariaLabel="Customer role"
              value={roleFilter}
              onValueChange={setRoleFilter}
              options={[
                { value: "All", label: "All roles" },
                { value: "customer", label: "Customer" },
                { value: "staff", label: "Staff" },
                { value: "admin", label: "Admin" },
              ]}
              className="w-[128px] shrink-0"
            />
            <StyledSelect
              ariaLabel="Sort customers"
              value={sortBy}
              onValueChange={setSortBy}
              options={[
                { value: "recent", label: "Recent order" },
                { value: "spent-high", label: "Spent high to low" },
                { value: "spent-low", label: "Spent low to high" },
                { value: "orders-high", label: "Orders high to low" },
                { value: "name", label: "Name A-Z" },
              ]}
              className="w-[168px] shrink-0"
            />
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1.3fr 1.2fr 0.8fr 0.7fr 0.9fr",
              padding: "12px 16px",
              borderBottom: `1px solid ${C.border}`,
              background: C.surface,
              fontSize: "0.78571rem",
              fontWeight: 700,
              color: C.muted,
              letterSpacing: "0.04em",
              textTransform: "uppercase",
            }}
          >
            <div>Customer</div>
            <div>Contact</div>
            <div>Role</div>
            <div>Status</div>
            <div style={{ textAlign: "right" }}>Spent</div>
          </div>

          <div>
            {filtered.length === 0 && (
              <div
                style={{
                  padding: 32,
                  textAlign: "center",
                  color: C.muted,
                  fontSize: "0.92857rem",
                }}
              >
                {loading
                  ? "Loading customers…"
                  : "No customers found for current filters."}
              </div>
            )}

            {filtered.map((c) => {
              const selectedRow = selected?.id === c.id;
              return (
                <div
                  key={c.id}
                  role="button"
                  tabIndex={0}
                  aria-label={`View customer ${c.name}`}
                  aria-pressed={selectedRow}
                  onKeyDown={event => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setSelectedId(c.id); } }}
                  onClick={() => setSelectedId(c.id)}
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1.3fr 1.2fr 0.8fr 0.7fr 0.9fr",
                    padding: "13px 16px",
                    borderBottom: `1px solid ${C.border}`,
                    background: selectedRow ? C.surface : C.white,
                    boxShadow: selectedRow ? "inset 3px 0 0 var(--admin-primary)" : "none",
                    cursor: "pointer",
                    alignItems: "center",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 10,
                      minWidth: 0,
                    }}
                  >
                    <CustomerAvatar name={c.name} />
                    <div style={{ minWidth: 0 }}>
                      <div
                        style={{
                          fontSize: "0.85714rem",
                          fontWeight: 600,
                          color: C.text,
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {c.name}
                      </div>
                      <div
                        style={{ fontSize: "0.78571rem", color: C.muted, marginTop: 2 }}
                      >
                        #{c.id}
                      </div>
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: "0.78571rem", color: C.textSub }}>
                      {c.email}
                    </div>
                    <div style={{ fontSize: "0.78571rem", color: C.muted, marginTop: 2 }}>
                      {c.phone}
                    </div>
                  </div>
                  <div>
                    <span
                      style={{
                        fontSize: "0.78571rem",
                        fontWeight: 600,
                        borderRadius: 999,
                        padding: "4px 9px",
                        background: roleStyle[c.role || "customer"].bg,
                        color: roleStyle[c.role || "customer"].color,
                      }}
                    >
                      {roleStyle[c.role || "customer"].label}
                    </span>
                  </div>
                  <div>
                    <StatusPill value={c.status} />
                  </div>
                  <div
                    style={{
                      textAlign: "right",
                      fontSize: "0.92857rem",
                      fontWeight: 700,
                      color: C.text,
                    }}
                  >
                    {fmtUsd(c.totalSpent)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <CustomerDetail
          selected={selected}
          statusBusy={statusBusy}
          onViewOrders={() => navigate("/dashboard/orders", { state: { customerQuery: selected.name.split(/\s+/)[0] } })}
          onEdit={openEditCustomer}
          onToggleStatus={toggleStatus}
        />

        {showAddCustomer && (
          <AddUserModal
            newCustomer={newCustomer}
            setNewCustomer={setNewCustomer}
            addError={addError}
            adding={adding}
            addCustomer={addCustomer}
            onClose={() => setShowAddCustomer(false)}
          />
        )}

        {showEditCustomer && selected && (
          <EditCustomerModal
            selected={selected}
            editForm={editForm}
            setEditForm={setEditForm}
            editError={editError}
            editing={editing}
            saveEditCustomer={saveEditCustomer}
            onClose={() => setShowEditCustomer(false)}
          />
        )}
      </div>
    </div>
  );
}
