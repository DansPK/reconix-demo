import { C } from "./helpers";

export default function StatusPill({ value }) {
  const active = value === "Active";
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        fontSize: "0.78571rem",
        fontWeight: 600,
        borderRadius: 999,
        padding: "4px 9px",
        color: active ? "var(--admin-success)" : "var(--admin-danger)",
        background: active ? C.successBg : "var(--admin-danger-soft)",
      }}
    >
      {value}
    </span>
  );
}
