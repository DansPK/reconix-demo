import { C as theme } from "../../components/constants";
export const C = {
  ...theme,
  primary: "var(--admin-primary)",
  success: "var(--admin-success)",
  warning: "var(--admin-warning)",
  danger: "var(--admin-danger)",
  text: "var(--admin-foreground)",
  textSub: "var(--admin-muted-foreground)",
  muted: "var(--admin-muted-foreground)",
  surface: "var(--admin-background)",
  white: "var(--admin-card)",
  border: "var(--admin-border)",
  primaryBg: "var(--admin-primary-soft)",
  successBg: "var(--admin-success-soft)",
  warningBg: "var(--admin-warning-soft)",
};

export const FONT_STACK = "'Poppins','Segoe UI',sans-serif";

export const roleStyle = {
  customer: { label: "Customer", bg: "var(--admin-primary-soft)", color: "var(--admin-primary-text)" },
  staff: { label: "Staff", bg: "var(--admin-muted)", color: "var(--admin-muted-foreground)" },
  admin: { label: "Admin", bg: "var(--admin-neutral-soft)", color: "var(--admin-neutral)" },
};

export function fmtUsd(v) {
  return `$${Number(v ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function fmtDate(value) {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleDateString(undefined, {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  } catch {
    return String(value);
  }
}

export function dayDiff(dateText) {
  if (!dateText) return null;
  const now = new Date();
  const date = new Date(dateText);
  const diff = now - date;
  return Math.max(0, Math.floor(diff / (1000 * 60 * 60 * 24)));
}
