export const C = {
  primary: "var(--admin-primary)",
  danger: "var(--admin-danger)",
  surface: "var(--admin-background)",
  white: "var(--admin-card)",
  border: "var(--admin-border)",
  text: "var(--admin-foreground)",
  textSub: "var(--admin-muted-foreground)",
  muted: "var(--admin-muted-foreground)",
  success: "var(--admin-success)",
  warning: "var(--admin-warning)",
  info: "var(--admin-primary)",
};

export const fmtMoney = (value) => `$${Number(value || 0).toFixed(2)}`;
export const fmtDate = (value) => {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleString(undefined, {
      day: "numeric",
      month: "short",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return String(value);
  }
};

export function orderTimestamp(order) {
  const timestamp = Date.parse(order.createdAt || "");
  return Number.isNaN(timestamp) ? 0 : timestamp;
}

function orderStatusStyle(status) {
  const styleMap = {
    pending: {
      bg: "var(--admin-warning-soft)",
      color: "var(--admin-warning)",
      border: "var(--admin-warning-soft)",
      label: "Pending",
    },
    processing: {
      bg: "var(--admin-primary-soft)",
      color: "var(--admin-primary-text)",
      border: "var(--admin-primary-soft)",
      label: "Processing",
    },
    shipped: {
      bg: "var(--admin-neutral-soft)",
      color: "var(--admin-neutral)",
      border: "var(--admin-neutral-soft)",
      label: "Shipped",
    },
    delivered: {
      bg: "var(--admin-success-soft)",
      color: "var(--admin-success)",
      border: "var(--admin-success-soft)",
      label: "Delivered",
    },
    cancelled: {
      bg: "var(--admin-danger-soft)",
      color: "var(--admin-danger)",
      border: "var(--admin-danger-soft)",
      label: "Cancelled",
    },
  };
  return styleMap[status] || styleMap.pending;
}

function paymentStatusStyle(status) {
  const styleMap = {
    pending: {
      bg: "var(--admin-warning-soft)",
      color: "var(--admin-warning)",
      border: "var(--admin-warning-soft)",
      label: "Pending",
    },
    paid: { bg: "var(--admin-success-soft)", color: "var(--admin-success)", border: "var(--admin-success-soft)", label: "Paid" },
    failed: {
      bg: "var(--admin-danger-soft)",
      color: "var(--admin-danger)",
      border: "var(--admin-danger-soft)",
      label: "Failed",
    },
    expired: {
      bg: "var(--admin-muted)",
      color: "var(--admin-muted-foreground)",
      border: "var(--admin-border)",
      label: "Expired",
    },
    not_charged: {
      bg: "var(--admin-muted)",
      color: "var(--admin-muted-foreground)",
      border: "var(--admin-border)",
      label: "Not charged",
    },
    refunded: {
      bg: "var(--admin-neutral-soft)",
      color: "var(--admin-neutral)",
      border: "var(--admin-neutral-soft)",
      label: "Refunded",
    },
    partially_refunded: {
      bg: "var(--admin-neutral-soft)",
      color: "var(--admin-neutral)",
      border: "var(--admin-neutral-soft)",
      label: "Partially refunded",
    },
  };
  return styleMap[status] || styleMap.pending;
}

export function OrderStatusBadge({ status }) {
  const s = orderStatusStyle(status);
  return (
    <span
      style={{
        background: s.bg,
        color: s.color,
        border: `1px solid ${s.border}`,
        fontSize: "0.78571rem",
        fontWeight: 400,
        padding: "4px 10px",
        borderRadius: 999,
      }}
    >
      {s.label}
    </span>
  );
}

export function PaymentStatusBadge({ status }) {
  const s = paymentStatusStyle(status);
  return (
    <span
      style={{
        background: s.bg,
        color: s.color,
        border: `1px solid ${s.border}`,
        fontSize: "0.78571rem",
        fontWeight: 400,
        padding: "4px 10px",
        borderRadius: 999,
      }}
    >
      {s.label}
    </span>
  );
}
