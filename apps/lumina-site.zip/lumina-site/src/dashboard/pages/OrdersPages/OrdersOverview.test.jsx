// @vitest-environment jsdom
import React from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import OrdersOverview, { dailyOrderCounts } from "./OrdersOverview";

const statuses = ["pending", "processing", "shipped", "delivered", "cancelled"].map(key => ({ key, label: key[0].toUpperCase() + key.slice(1) }));
afterEach(cleanup);

describe("order analytics", () => {
  it("uses the total for fulfillment percentages and lets summaries filter orders", () => {
    const onSelectStatus = vi.fn();
    const counts = { pending: 3, delivered: 14, cancelled: 2 };
    const orders = Array.from({ length: 19 }, (_, index) => ({ status: index < 3 ? "pending" : index < 17 ? "delivered" : "cancelled" }));
    render(<OrdersOverview orders={orders} totalElements={30} counts={counts} statuses={statuses} onSelectStatus={onSelectStatus} />);
    expect(screen.getByText("73.7%")).toBeTruthy();
    expect(screen.getByText("15.8%")).toBeTruthy();
    expect(screen.getByText("10.5%")).toBeTruthy();
    expect(screen.getByText("Analytics cover 19 of 30 orders loaded on this page.")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /Awaiting fulfillment/ }));
    expect(onSelectStatus).toHaveBeenCalledWith("open");
    fireEvent.click(screen.getByRole("button", { name: /Delivered/ }));
    expect(onSelectStatus).toHaveBeenCalledWith("delivered");
  });
  it("groups days in Cambodia time and excludes invalid, old, and future dates", () => {
    const days = dailyOrderCounts([
      { createdAt: "2026-10-06T18:30:00Z" },
      { createdAt: "2026-10-06T16:30:00Z" },
      { createdAt: "2026-09-01T00:00:00Z" },
      { createdAt: "2026-10-08T00:00:00Z" },
      { createdAt: "invalid" },
    ], new Date("2026-10-07T10:00:00Z"));
    expect(days).toHaveLength(14);
    expect(days[13]).toMatchObject({ key: "2026-10-07", value: 1 });
    expect(days[12]).toMatchObject({ key: "2026-10-06", value: 1 });
    expect(days.reduce((sum, day) => sum + day.value, 0)).toBe(2);
  });
  it("handles empty data and loading without invalid chart coordinates", () => {
    const view = render(<OrdersOverview orders={[]} totalElements={0} counts={{}} statuses={statuses} onSelectStatus={() => {}} />);
    expect(screen.getByText("No orders to display.")).toBeTruthy();
    expect(screen.getByText("No loaded orders in the last 14 days.")).toBeTruthy();
    expect(view.container.innerHTML).not.toContain("NaN");
    view.rerender(<OrdersOverview orders={[]} totalElements={0} counts={{}} statuses={statuses} loading onSelectStatus={() => {}} />);
    expect(screen.getByText("Loading fulfillment…")).toBeTruthy();
  });
});
