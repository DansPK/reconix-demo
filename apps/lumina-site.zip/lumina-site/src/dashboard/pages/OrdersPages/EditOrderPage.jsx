import { Dialog, DialogContent, DialogTitle } from "../../../components/ui/dialog";
import StyledSelect from "../../../components/ui/styled-select";
import { ResourceError, ResourceLoading } from "../../../components/ResourceFeedback";
import { useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { useAdminOrder, useUpdateOrderStatus } from "../../adminOrders";
import { ApiError } from "../../../api/client";
import { C } from "./components.jsx";

const FULFILLMENT_OPTIONS = {
  pending: ["processing", "cancelled"],
  processing: ["shipped", "cancelled"],
  shipped: ["delivered", "cancelled"],
  delivered: [],
  cancelled: [],
};

export function EditOrderPage() {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const { order, loading, error, refetch } = useAdminOrder(orderId);
  const updateStatus = useUpdateOrderStatus();
  const [nextStatus, setNextStatus] = useState(null);
  const [trackingNumber, setTrackingNumber] = useState("");
  const [courierName, setCourierName] = useState("");
  const [trackingUrl, setTrackingUrl] = useState("");
  const [estimatedDeliveryDate, setEstimatedDeliveryDate] = useState("");
  const [note, setNote] = useState("");
  const [err, setErr] = useState("");
  const [saving, setSaving] = useState(false);

  if (loading && !order) return <ResourceLoading />;
  if (error) return <ResourceError message="Could not load this order." retry={refetch} />;
  if (!order) return <Navigate to="/dashboard/orders" replace />;

  const options = FULFILLMENT_OPTIONS[order.status] ?? [];
  const selected = nextStatus ?? order.status;
  const hasChanges = selected !== order.status;

  const saveChanges = async () => {
    if (saving || !hasChanges) return;
    if (trackingUrl && !/^https:\/\/\S+$/.test(trackingUrl.trim())) { setErr("Tracking URL must use HTTPS."); return; }
    if (selected === "shipped" && !trackingNumber.trim()) { setErr("Tracking number is required."); return; }
    setErr("");
    setSaving(true);
    try {
      await updateStatus(orderId, {
        status: selected,
        trackingNumber: trackingNumber || undefined,
        courierName: courierName.trim() || undefined,
        trackingUrl: trackingUrl.trim() || undefined,
        estimatedDeliveryDate: estimatedDeliveryDate || undefined,
        note: note || undefined,
      });
      navigate(`/dashboard/orders/${orderId}`);
    } catch (error) {
      setErr(error instanceof ApiError ? error.detail : "Could not update the order.");
    } finally {
      setSaving(false);
    }
  };

  const selectStyle = {
    width: "100%",
    minHeight: 42,
    border: "1px solid var(--admin-border)",
    borderRadius: 12,
    background: "var(--admin-card)",
    padding: "10px 12px",
    fontSize: "0.92857rem",
    color: C.text,
    outline: "none",
    boxShadow: "0 1px 2px rgba(15, 23, 42, 0.04)",
  };

  return (
    <Dialog open onOpenChange={open => { if (!open && !saving) navigate(`/dashboard/orders/${orderId}`); }}>
      <DialogContent className="max-h-[85dvh] overflow-y-auto p-0" aria-describedby={undefined}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16, padding: "20px 22px 16px", borderBottom: "1px solid var(--admin-border)" }}>
          <div>
            <DialogTitle style={{ margin: 0, fontSize: "1.2857rem", color: C.text, fontWeight: 800 }}>Update order status</DialogTitle>
            <div style={{ marginTop: 5, fontSize: "0.85714rem", color: C.muted }}>Order {order.code}</div>
          </div>
        </div>

        <div style={{ padding: 22 }}>
          <div style={{ marginBottom: 16, padding: "11px 12px", background: "var(--admin-background)", border: "1px solid var(--admin-border)", borderRadius: 10, fontSize: "0.85714rem", color: C.textSub }}>
            Update fulfillment and add shipping details. Customer and pricing information are locked.
          </div>
          <label style={{ display: "block", marginBottom: 8, fontSize: "0.85714rem", fontWeight: 700, color: C.textSub }} htmlFor="order-next-status">Next status</label>
          <StyledSelect
            id="order-next-status"
            ariaLabel="Next status"
            value={selected}
            onValueChange={setNextStatus}
            disabled={options.length === 0}
            options={[
              { value: order.status, label: `${order.status[0].toUpperCase() + order.status.slice(1)} (current)` },
              ...options.map((option) => ({
                value: option,
                label: option[0].toUpperCase() + option.slice(1),
              })),
            ]}
            className="h-10 w-full rounded-lg bg-white text-sm"
          />
          {options.length === 0 ? (
            <div style={{ marginTop: 10, fontSize: "0.85714rem", color: C.muted }}>This order is in a final state and cannot move further.</div>
          ) : null}

          {selected === "shipped" ? (
            <div style={{ marginTop: 14 }}>
              <label style={{ display: "block", marginBottom: 8, fontSize: "0.85714rem", fontWeight: 700, color: C.textSub }} htmlFor="order-tracking">Tracking number (optional)</label>
              <input id="order-tracking" value={trackingNumber} onChange={(e) => setTrackingNumber(e.target.value)} style={selectStyle} placeholder="e.g. VN123456789" />
              <label className="mt-3 block text-sm" htmlFor="order-courier">Courier (optional)</label>
              <input id="order-courier" maxLength={100} value={courierName} onChange={e => setCourierName(e.target.value)} style={selectStyle} />
              <label className="mt-3 block text-sm" htmlFor="order-tracking-url">Tracking URL (optional)</label>
              <input id="order-tracking-url" type="url" maxLength={1000} placeholder="https://" value={trackingUrl} onChange={e => setTrackingUrl(e.target.value)} style={selectStyle} />
              <label className="mt-3 block text-sm" htmlFor="order-estimated-date">Estimated delivery (optional)</label>
              <input id="order-estimated-date" type="date" value={estimatedDeliveryDate} onChange={e => setEstimatedDeliveryDate(e.target.value)} style={selectStyle} />
            </div>
          ) : null}

          <div style={{ marginTop: 14 }}>
            <label style={{ display: "block", marginBottom: 8, fontSize: "0.85714rem", fontWeight: 700, color: C.textSub }} htmlFor="order-note">Note (optional)</label>
            <input id="order-note" value={note} onChange={(e) => setNote(e.target.value)} style={selectStyle} placeholder="Internal note for this status change" />
          </div>

          {err ? <div style={{ marginTop: 14, padding: "10px 12px", background: "var(--admin-danger-soft)", border: "1px solid var(--admin-danger-soft)", borderRadius: 10, fontSize: "0.85714rem", color: "var(--admin-danger)" }}>{err}</div> : null}
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, padding: "14px 22px", borderTop: "1px solid var(--admin-border)", background: "var(--admin-background)" }}>
          <button type="button" onClick={() => navigate(`/dashboard/orders/${orderId}`)} style={{ padding: "10px 16px", border: "1px solid var(--admin-border)", borderRadius: 9, background: C.white, color: C.textSub, fontSize: "0.92857rem", fontWeight: 700, cursor: "pointer" }}>Cancel</button>
          <button type="button" onClick={saveChanges} disabled={!hasChanges || saving} style={{ padding: "10px 18px", border: "none", borderRadius: 9, background: hasChanges ? C.primary : "var(--admin-primary-soft)", color: hasChanges ? "hsl(var(--primary-foreground))" : "var(--admin-primary)", fontSize: "0.92857rem", fontWeight: 800, cursor: hasChanges && !saving ? "pointer" : "not-allowed" }}>{saving ? "Saving…" : "Save status"}</button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
