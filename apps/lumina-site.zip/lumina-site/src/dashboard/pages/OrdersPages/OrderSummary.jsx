import ConfirmCodPayment from "../../components/ConfirmCodPayment";
import { ResourceError } from "../../../components/ResourceFeedback";
import { fmtMoney, PaymentStatusBadge } from "./components";

const METHODS = { no_payment_required: "No payment required", cash_on_delivery: "Cash on delivery", bakong_khqr: "Bakong KHQR" };

export default function OrderSummary({ order, payment, paymentLoading, paymentError, refetchPayment, canConfirmCod = false }) {
  const paymentStatus = payment?.paymentStatus || order.paymentStatus;
  const cancelledUnpaid = order.status === "cancelled" && paymentStatus === "pending";
  const shownPaymentStatus = cancelledUnpaid ? "not_charged" : paymentStatus;

  return (
    <section className="rounded-xl border bg-card p-5 text-card-foreground shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold">Order summary</h2>
          <p className="mt-1 text-xs text-muted-foreground">Charges for this order</p>
        </div>
        <span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">USD</span>
      </div>
      <dl className="mt-5 space-y-3 text-sm">
        <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Subtotal</dt><dd className="tabular-nums">{fmtMoney(order.subtotal)}</dd></div>
        <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Delivery</dt><dd className="tabular-nums">{fmtMoney(order.shipping)}</dd></div>
        {order.discount > 0 && <div className="flex justify-between gap-3"><dt className="text-muted-foreground">Discount</dt><dd className="tabular-nums text-emerald-700">−{fmtMoney(order.discount)}</dd></div>}
        <div className="flex items-center justify-between gap-3 border-t pt-4"><dt className="font-medium">Total amount</dt><dd className="text-xl font-semibold tracking-tight tabular-nums sm:text-2xl">{fmtMoney(order.amount)}</dd></div>
      </dl>
      <div className="mt-5 rounded-lg border bg-muted/30 p-3.5">
        <div className="flex flex-wrap items-center justify-between gap-2"><span className="text-xs font-semibold">Payment</span><PaymentStatusBadge status={shownPaymentStatus} /></div>
        <p className="mt-2 text-xs text-muted-foreground">{paymentLoading ? "Loading payment method…" : METHODS[payment?.paymentMethod || order.paymentMethod] || "Payment method unavailable"}</p>
        {cancelledUnpaid && <p className="mt-2 text-xs leading-5 text-muted-foreground">Payment was not completed before this order was cancelled.</p>}
        {paymentError && <div className="mt-3"><ResourceError message="Could not load the payment record." retry={refetchPayment} /></div>}
      </div>
      <ConfirmCodPayment allowed={canConfirmCod} orderId={order.id} method={payment?.paymentMethod || order.paymentMethod} status={paymentStatus} cancelled={order.status === "cancelled"} />
    </section>
  );
}
