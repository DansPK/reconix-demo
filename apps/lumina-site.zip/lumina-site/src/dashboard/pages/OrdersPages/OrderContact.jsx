import { MapPin, Phone, Truck, UserRound } from "lucide-react";

export default function OrderContact({ order }) {
  return (
    <section className="rounded-xl border bg-card p-5 text-card-foreground shadow-sm">
      <div className="flex items-center gap-3">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-muted text-muted-foreground"><UserRound size={17} aria-hidden="true" /></span>
        <div><h2 className="text-sm font-semibold">Customer &amp; delivery</h2><p className="mt-0.5 text-xs text-muted-foreground">Contact and shipping information</p></div>
      </div>

      <div className="mt-4 border-b pb-4">
        <p className="text-sm font-semibold">{order.customer}</p>
        {order.email && <a href={`mailto:${order.email}`} className="mt-1 block break-words text-xs text-muted-foreground hover:text-foreground">{order.email}</a>}
        {order.phone && <a href={`tel:${order.phone}`} className="mt-2 inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground"><Phone size={13} aria-hidden="true" />{order.phone}</a>}
      </div>

      <div className="mt-4">
        <div className="mb-2 flex items-center gap-2 text-xs font-semibold"><MapPin size={14} className="text-muted-foreground" aria-hidden="true" />Shipping address</div>
        <div className="rounded-lg bg-muted/35 px-3.5 py-3">
          <p className="text-sm leading-6">{order.delivery?.address || "No delivery address provided"}</p>
          {(order.delivery?.city || order.delivery?.postalCode) && <p className="mt-1 text-xs text-muted-foreground">{[order.delivery.city, order.delivery.postalCode].filter(Boolean).join(" · ")}</p>}
        </div>
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="min-w-0 rounded-lg border px-3 py-2.5"><p className="flex items-center gap-1.5 text-[11px] text-muted-foreground"><Truck size={13} aria-hidden="true" />Delivery method</p><p className="mt-1 truncate text-xs font-medium capitalize">{order.delivery?.shippingMethod || "—"}</p></div>
        {order.delivery?.courierName && <div className="rounded-lg border px-3 py-2.5"><p className="text-[11px] text-muted-foreground">Courier</p><p className="mt-1 text-xs">{order.delivery.courierName}</p></div>}
        {order.estimatedDeliveryDate && <div className="rounded-lg border px-3 py-2.5"><p className="text-[11px] text-muted-foreground">Estimated delivery</p><p className="mt-1 text-xs">{order.estimatedDeliveryDate}</p></div>}
        {order.delivery?.trackingUrl?.startsWith("https://") && <a className="text-sm text-primary underline" href={order.delivery.trackingUrl} target="_blank" rel="noreferrer">Track shipment</a>}
        {order.delivery?.tracking && <div className="min-w-0 rounded-lg border px-3 py-2.5"><p className="text-[11px] text-muted-foreground">Tracking number</p><p className="mt-1 break-all text-xs font-medium">{order.delivery.tracking}</p></div>}
      </div>
    </section>
  );
}
