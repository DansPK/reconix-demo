import OrderProductImage from "../../../components/OrderProductImage";
import { fmtMoney } from "./components";

export default function OrderItems({ items }) {
  const orderItems = items ?? [];
  return (
    <section className="rounded-xl border bg-card p-5 text-card-foreground shadow-sm">
      <div className="mb-1 flex items-center justify-between gap-3"><h2 className="text-sm font-semibold">Order items</h2><span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">{orderItems.length} {orderItems.length === 1 ? "item" : "items"}</span></div>
      <p className="mb-2 text-xs text-muted-foreground">Products and prices captured at checkout</p>
      <ul className="divide-y">
        {orderItems.map((item, index) => <li key={item.id || index} className="grid grid-cols-[48px_minmax(0,1fr)_auto] items-center gap-3 py-4 sm:grid-cols-[56px_minmax(0,1fr)_auto] sm:gap-4">
          <OrderProductImage productId={item.productId} name={item.name} imageUrl={item.image} className="h-12 w-12 sm:h-14 sm:w-14" />
          <div className="min-w-0"><p className="text-sm font-medium">{item.name}</p><p className="mt-1 text-xs text-muted-foreground">{item.variant || "Standard"} · Qty {item.qty}</p><p className="mt-1 text-xs text-muted-foreground">{fmtMoney(item.price)} each</p>{item.sku && <p className="mt-2 truncate text-[11px] text-muted-foreground" title={item.sku}>SKU: {item.sku}</p>}</div>
          <p className="text-sm font-semibold tabular-nums">{fmtMoney(item.price * item.qty)}</p>
        </li>)}
      </ul>
      {!orderItems.length && <p className="py-5 text-sm text-muted-foreground">No order items recorded.</p>}
    </section>
  );
}
