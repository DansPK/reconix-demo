import AdminPageHeader from "../../components/AdminPageHeader";
import { ToggleGroup, ToggleGroupItem } from "../../../components/ui/toggle-group";
import OrdersOverview from "./OrdersOverview";
import OrderProductImage from "../../../components/OrderProductImage";
import StyledSelect from "../../../components/ui/styled-select";
import { ResourceError } from "../../../components/ResourceFeedback";
import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAdminOrders } from "../../adminOrders";
import { C, fmtMoney, fmtDate, orderTimestamp, OrderStatusBadge, PaymentStatusBadge } from "./components.jsx";

// The real pipeline has five stages, not the prototype's three - "shipped" and
// "cancelled" were never reachable in the admin table before.
const ORDER_STATUS_TABS = [
  { key: "all", label: "All" },
  { key: "pending", label: "Pending" },
  { key: "processing", label: "Processing" },
  { key: "shipped", label: "Shipped" },
  { key: "delivered", label: "Delivered" },
  { key: "cancelled", label: "Cancelled" },
];

export function OrdersPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [orderIdQuery, setOrderIdQuery] = useState("");
  const [customerQuery, setCustomerQuery] = useState(location.state?.customerQuery || "");
  const [dateRange, setDateRange] = useState("all");

  const { orders, totalElements, loading, error, refetch } = useAdminOrders();

  const now = Date.now();
  const statusCounts = orders.reduce((counts, order) => {
    counts[order.status] = (counts[order.status] ?? 0) + 1;
    return counts;
  }, {});

  const filtered = orders.filter((o) => {
    const byStatus = activeTab === "all" || o.status === activeTab
      || (activeTab === "open" && ["pending", "processing"].includes(o.status));
    const byOrderId = !orderIdQuery || String(o.code).toLowerCase().includes(orderIdQuery.toLowerCase());
    const byCustomer = !customerQuery || String(o.customer || "").toLowerCase().includes(customerQuery.toLowerCase());
    const ageInDays = orderTimestamp(o)
      ? (now - orderTimestamp(o)) / (1000 * 60 * 60 * 24)
      : Infinity;
    const byDate = dateRange === "all"
      || (dateRange === "7d" && ageInDays >= 0 && ageInDays <= 7)
      || (dateRange === "30d" && ageInDays >= 0 && ageInDays <= 30);
    return byStatus && byOrderId && byCustomer && byDate;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === "newest") return orderTimestamp(b) - orderTimestamp(a);
    if (sortBy === "oldest") return orderTimestamp(a) - orderTimestamp(b);
    if (sortBy === "highest") return Number(b.amount || 0) - Number(a.amount || 0);
    if (sortBy === "lowest") return Number(a.amount || 0) - Number(b.amount || 0);
    return 0;
  });

  const clearFilters = () => {
    setActiveTab("all");
    setSortBy("newest");
    setOrderIdQuery("");
    setCustomerQuery("");
    setDateRange("all");
  };

  return (
    <div style={{ flex: 1, overflowY: "auto", padding: "24px", background: C.surface }}>
      <AdminPageHeader title="Orders" description={loading ? "Loading…" : `${orders.length} loaded of ${totalElements} orders · Select an order to view details`} />

      {error && <ResourceError message="Could not load orders." retry={refetch} />}
      <OrdersOverview orders={orders} totalElements={totalElements} counts={statusCounts} statuses={ORDER_STATUS_TABS.filter(tab => tab.key !== "all")} loading={loading} onSelectStatus={setActiveTab} />
      <ToggleGroup type="single" variant="outline" value={activeTab} onValueChange={value => { if (value) setActiveTab(value); }} aria-label="Order status" className="mb-4 flex-wrap justify-start">
        {[...ORDER_STATUS_TABS, ...(activeTab === "open" ? [{ key: "open", label: "Awaiting fulfillment" }] : [])].map(tab => <ToggleGroupItem key={tab.key} value={tab.key} className="font-normal">{tab.label} {tab.key === "all" ? orders.length : tab.key === "open" ? (statusCounts.pending || 0) + (statusCounts.processing || 0) : statusCounts[tab.key] || 0}</ToggleGroupItem>)}
      </ToggleGroup>

      <div className="admin-filter-grid" style={{ display: "grid", gridTemplateColumns: "160px minmax(160px,1fr) minmax(160px,1fr) 120px 130px", gap: 10, alignItems: "center", padding: "12px", border: "1px solid var(--admin-border)", background: C.white, borderRadius: 12, marginBottom: 14 }}>
        <StyledSelect
          ariaLabel="Sort orders"
          value={sortBy}
          onValueChange={setSortBy}
          options={[
            { value: "newest", label: "Newest first" },
            { value: "oldest", label: "Oldest first" },
            { value: "highest", label: "Highest amount" },
            { value: "lowest", label: "Lowest amount" },
          ]}
          size="sm"
          className="w-full rounded-lg"
        />
        <input aria-label="Search order code" value={orderIdQuery} onChange={(e) => setOrderIdQuery(e.target.value)} placeholder="Search Order Code" style={{ height: 36, border: "1px solid var(--admin-border)", borderRadius: 8, padding: "0 10px", fontSize: "0.85714rem" }} />
        <input aria-label="Search customer" value={customerQuery} onChange={(e) => setCustomerQuery(e.target.value)} placeholder="Search Customer" style={{ height: 36, border: "1px solid var(--admin-border)", borderRadius: 8, padding: "0 10px", fontSize: "0.85714rem" }} />
        <button type="button" onClick={clearFilters} style={{ height: 36, border: "1px solid var(--admin-border)", borderRadius: 8, background: C.white, fontSize: "0.85714rem", fontWeight: 400, cursor: "pointer" }}>Clear</button>
        <StyledSelect
          ariaLabel="Order date range"
          value={dateRange}
          onValueChange={setDateRange}
          options={[
            { value: "all", label: "Date range" },
            { value: "7d", label: "Last 7 days" },
            { value: "30d", label: "Last 30 days" },
          ]}
          size="sm"
          className="w-full rounded-lg"
        />
      </div>

      <div style={{ background: C.white, border: "1px solid var(--admin-border)", borderRadius: 14, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", minWidth: 1040, borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "var(--admin-background)" }}>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "0.78571rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-border)" }}>Order</th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "0.78571rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-border)" }}>Customer</th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "0.78571rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-border)" }}>Amount</th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "0.78571rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-border)" }}>Fulfillment</th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "0.78571rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-border)" }}>Payment</th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "0.78571rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-border)" }}>Date</th>
                <th style={{ padding: "12px", textAlign: "left", fontSize: "0.78571rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-border)" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {sorted.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ padding: "32px 12px", textAlign: "center", color: C.muted, fontSize: "0.92857rem" }}>
                    {loading ? "Loading orders…" : "No orders match the selected filters."}
                  </td>
                </tr>
              ) : sorted.map((o) => (
                <tr key={o.id} onClick={() => navigate(`/dashboard/orders/${o.id}`)} style={{ cursor: "pointer" }}>

                  <td style={{ padding: "12px", fontSize: "0.92857rem", fontWeight: 500, color: "var(--admin-primary-text)", borderBottom: "1px solid var(--admin-muted)" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <OrderProductImage productId={o.items?.[0]?.productId} imageUrl={o.items?.[0]?.image} name={o.items?.[0]?.name || o.code} className="h-10 w-10" />
                      <div><span>{o.code}</span><p className="mt-1 text-xs font-normal text-muted-foreground">{o.items.length} {o.items.length === 1 ? "item" : "items"}</p></div>
                    </div>
                  </td>
                  <td style={{ padding: "12px", fontSize: "0.92857rem", color: "var(--admin-foreground)", borderBottom: "1px solid var(--admin-muted)" }}>{o.customer}</td>
                  <td style={{ padding: "12px", fontSize: "0.92857rem", fontWeight: 400, color: "var(--admin-foreground)", borderBottom: "1px solid var(--admin-muted)" }}>{fmtMoney(o.amount)}</td>
                  <td style={{ padding: "12px", borderBottom: "1px solid var(--admin-muted)" }}><OrderStatusBadge status={o.status} /></td>
                  <td style={{ padding: "12px", borderBottom: "1px solid var(--admin-muted)" }}><PaymentStatusBadge status={o.paymentStatus} /></td>
                  <td style={{ padding: "12px", fontSize: "0.85714rem", color: "var(--admin-muted-foreground)", borderBottom: "1px solid var(--admin-muted)" }}>{fmtDate(o.createdAt)}</td>
                  <td style={{ padding: "12px", fontSize: "0.85714rem", borderBottom: "1px solid var(--admin-muted)" }} onClick={(e) => e.stopPropagation()}>
                    <button onClick={() => navigate(`/dashboard/orders/${o.id}`)} style={{ padding: "6px 10px", border: "1px solid var(--admin-primary-soft)", borderRadius: 8, background: "var(--admin-primary-soft)", color: "var(--admin-primary-text)", fontSize: "0.85714rem", fontWeight: 400, cursor: "pointer" }}>View</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
