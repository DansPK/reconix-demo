import { fmtDate } from "./components";

function Event({ event }) {
  const status = String(event.newStatus || "updated").replaceAll("_", " ");
  const tone = ["paid", "delivered"].includes(event.newStatus) ? "success" : ["cancelled", "failed"].includes(event.newStatus) ? "danger" : "primary";
  return (
    <li className="relative pb-5 pl-6 last:pb-0">
      <span className="absolute -left-[5px] top-1 h-2.5 w-2.5 rounded-full ring-4 ring-card" style={{ background: `var(--admin-${tone})` }} aria-hidden="true" />
      <p className="text-xs font-medium">{event.statusKind === "payment" ? "Payment" : "Order"} <span className="capitalize">{status}</span></p>
      {event.changedAt && <time dateTime={event.changedAt} className="mt-1 block text-[11px] text-muted-foreground">{fmtDate(event.changedAt)}</time>}
      {(event.oldStatus || event.note) && <details className="mt-2 text-[11px] text-muted-foreground"><summary className="cursor-pointer">Event details</summary><div className="mt-2 space-y-1 leading-5">{event.oldStatus && <p className="capitalize">{String(event.oldStatus).replaceAll("_", " ")} → {status}</p>}{event.note && <p>{event.note}</p>}</div></details>}
    </li>
  );
}

export default function OrderActivity({ history }) {
  const events = [...(history ?? [])].sort((a, b) => (Date.parse(b.changedAt || "") || 0) - (Date.parse(a.changedAt || "") || 0) || Number(b.id || 0) - Number(a.id || 0));
  return (
    <section className="rounded-xl border bg-card p-5 text-card-foreground shadow-sm">
      <div className="flex items-center justify-between gap-3"><div><h2 className="text-sm font-semibold">Order activity</h2><p className="mt-1 text-xs text-muted-foreground">A record of status and payment updates</p></div><span className="rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground">{events.length} {events.length === 1 ? "update" : "updates"}</span></div>
      {events.length ? <>
        <ol className="ml-1 mt-5 border-l">{events.slice(0, 4).map((event, index) => <Event key={event.id || index} event={event} />)}</ol>
        {events.length > 4 && <details className="mt-4 border-t pt-3"><summary className="cursor-pointer text-xs font-medium text-muted-foreground">{events.length - 4} earlier events</summary><ol className="ml-1 mt-5 border-l">{events.slice(4).map((event, index) => <Event key={event.id || index} event={event} />)}</ol></details>}
      </> : <p className="py-5 text-xs text-muted-foreground">No activity recorded yet.</p>}
    </section>
  );
}
