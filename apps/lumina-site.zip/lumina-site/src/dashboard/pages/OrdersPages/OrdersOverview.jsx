import { Package, Clock3, CheckCircle2, XCircle } from "lucide-react";
import StatusDonut from "../DashboardPage/StatusDonut";

const dateKey = value => new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Phnom_Penh", year: "numeric", month: "2-digit", day: "2-digit" }).format(value);

export function dailyOrderCounts(orders, now = new Date()) {
  const today = new Date(`${dateKey(now)}T00:00:00Z`);
  const days = Array.from({ length: 14 }, (_, index) => {
    const day = new Date(today.getTime() - (13 - index) * 86400000);
    return { key: day.toISOString().slice(0, 10), label: day.toLocaleDateString("en-GB", { timeZone: "UTC", day: "numeric", month: "short" }), value: 0 };
  });
  for (const order of orders) {
    const timestamp = Date.parse(order.createdAt);
    if (!Number.isFinite(timestamp)) continue;
    const day = days.find(item => item.key === dateKey(new Date(timestamp)));
    if (day) day.value += 1;
  }
  return days;
}

export default function OrdersOverview({ orders, totalElements, counts, statuses, loading, onSelectStatus }) {
  const days = dailyOrderCounts(orders);
  const recentTotal = days.reduce((sum, day) => sum + day.value, 0);
  const max = Math.max(1, ...days.map(day => day.value));
  const colors = ["var(--admin-chart-1)", "var(--admin-chart-2)", "var(--admin-chart-3)", "var(--admin-chart-4)", "var(--admin-chart-5)"];
  const metrics = [
    { label: "Loaded orders", value: orders.length, icon: Package, status: "all", note: `of ${totalElements.toLocaleString()} total` },
    { label: "Awaiting fulfillment", value: (counts.pending || 0) + (counts.processing || 0), icon: Clock3, status: "open", note: "Pending + processing" },
    { label: "Delivered", value: counts.delivered || 0, icon: CheckCircle2, status: "delivered", note: `${orders.length ? Math.round((counts.delivered || 0) / orders.length * 100) : 0}% of loaded orders` },
    { label: "Cancelled", value: counts.cancelled || 0, icon: XCircle, status: "cancelled", note: "Review cancelled orders" },
  ];
  const items = statuses.map((status, index) => ({ name: status.label, value: counts[status.key] || 0, color: colors[index] }));
  const unknown = orders.length - items.reduce((sum, item) => sum + item.value, 0);
  if (unknown > 0) items.push({ name: "Other", value: unknown, color: "var(--admin-neutral)" });
  return <section aria-label="Order analytics" className="mb-6 space-y-4">
    <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
      {metrics.map(({ label, value, icon: Icon, status, note }) => <button key={label} type="button" onClick={() => onSelectStatus(status)} className="rounded-xl border bg-card p-4 text-left transition-colors hover:border-primary/50 hover:bg-accent" disabled={loading}>
        <div className="flex items-center justify-between gap-2"><span className="text-xs font-medium text-muted-foreground">{label}</span><Icon size={17} className="text-primary" aria-hidden="true" /></div>
        <p className="my-2 text-3xl font-semibold tabular-nums tracking-tight">{loading ? "—" : value.toLocaleString()}</p><p className="text-xs text-muted-foreground">{note}</p>
      </button>)}
    </div>
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="rounded-xl border bg-card p-5">
        <h2 className="text-sm font-semibold">Fulfillment overview</h2><p className="mb-5 mt-1 text-xs text-muted-foreground">Share of {orders.length.toLocaleString()} loaded orders · All dates</p>
        {loading ? <p role="status" className="py-10 text-center text-sm text-muted-foreground">Loading fulfillment…</p> : <StatusDonut items={items} unit="orders" />}
      </div>
      <div className="min-w-0 rounded-xl border bg-card p-5">
        <div className="flex items-start justify-between gap-4"><div><h2 className="text-sm font-semibold">Daily orders</h2><p className="mt-1 text-xs text-muted-foreground">Last 14 days · Cambodia time</p></div><span className="rounded-md bg-accent px-2 py-1 text-xs font-medium text-primary">{loading ? "—" : recentTotal} orders</span></div>
        {loading ? <p role="status" className="py-10 text-center text-sm text-muted-foreground">Loading order trend…</p> : <>
          <svg viewBox="0 0 560 190" className="mt-4 w-full" role="img" aria-label={`Daily orders: ${days.map(day => `${day.label}: ${day.value}`).join('; ')}`}>
            {[0, 0.5, 1].map(fraction => <g key={fraction}><line x1="30" x2="550" y1={145 - fraction * 120} y2={145 - fraction * 120} stroke="var(--admin-border)" strokeDasharray="3 4" /><text x="22" y={149 - fraction * 120} textAnchor="end" fontSize="10" fill="var(--admin-muted-foreground)">{Math.ceil(max / 2) * 2 * fraction}</text></g>)}
            {days.map((day, index) => <g key={day.key}><title>{day.label}: {day.value} orders</title><rect x={38 + index * 36.5} y={145 - day.value / (Math.ceil(max / 2) * 2) * 120} width="22" height={day.value / (Math.ceil(max / 2) * 2) * 120} rx="3" fill="var(--admin-primary)" />{(index % 3 === 0 || index === 13) && <text x={49 + index * 36.5} y="169" textAnchor="middle" fontSize="10" fill="var(--admin-muted-foreground)">{day.label}</text>}</g>)}
          </svg>
          {!recentTotal && <p className="text-xs text-muted-foreground">No loaded orders in the last 14 days.</p>}
          <details className="mt-1 text-xs text-muted-foreground"><summary className="cursor-pointer">View daily counts</summary><dl className="mt-2 grid grid-cols-2 gap-x-6 gap-y-1">{days.map(day => <div key={day.key} className="flex justify-between gap-3"><dt>{day.label}</dt><dd className="tabular-nums">{day.value}</dd></div>)}</dl></details>
        </>}
      </div>
    </div>
    {orders.length < totalElements && <p className="text-xs text-muted-foreground">Analytics cover {orders.length.toLocaleString()} of {totalElements.toLocaleString()} orders loaded on this page.</p>}
  </section>;
}
