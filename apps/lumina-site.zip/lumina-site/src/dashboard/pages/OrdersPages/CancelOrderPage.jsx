import { ResourceError, ResourceLoading } from "../../../components/ResourceFeedback";
import { useState } from "react";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { useAdminOrder, useUpdateOrderStatus } from "../../adminOrders";
import { ApiError } from "../../../api/client";
import { C } from "./components.jsx";

export function CancelOrderPage() {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const { order, loading, error, refetch } = useAdminOrder(orderId);
  const updateStatus = useUpdateOrderStatus();
  const [reason, setReason] = useState("");
  const [err, setErr] = useState("");
  const [saving, setSaving] = useState(false);

  if (loading && !order) return <ResourceLoading />;
  if (error) return <ResourceError message="Could not load this order." retry={refetch} />;
  if (!order) return <Navigate to="/dashboard/orders" replace />;

  const confirmCancel = async () => {
    if (saving || ["cancelled", "delivered"].includes(order.status)) return;
    setErr("");
    setSaving(true);
    try {
      if (!reason.trim()) { setErr("Cancellation reason is required."); return; }
      await updateStatus(orderId, { status: "cancelled", cancellationReason: reason.trim() });
      navigate(`/dashboard/orders/${orderId}`);
    } catch (error) {
      setErr(error instanceof ApiError ? error.detail : "Could not cancel the order.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "24px", background: C.surface }}>
      <div style={{ width: "100%", maxWidth: 540, background: C.white, border: "1px solid var(--admin-border)", borderRadius: 14, padding: 24, boxShadow: "0 12px 32px rgba(15,23,42,0.08)" }}>
        <div style={{ fontSize: "1.5714rem", fontWeight: 700, color: "var(--admin-foreground)", marginBottom: 10 }}>Cancel Order Confirmation</div>
        <div style={{ fontSize: "1rem", color: "var(--admin-muted-foreground)", marginBottom: 10 }}>Are you sure you want to cancel order {order.code}?</div>
        <div style={{ fontSize: "0.85714rem", color: "var(--admin-muted-foreground)", marginBottom: 14 }}>Every reserved unit on this order is returned to stock immediately.</div>
        <label htmlFor="cancel-reason" className="mb-2 block text-sm">Reason for cancellation</label>
        <textarea id="cancel-reason"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Reason for cancellation (shown to the customer)"
          style={{ width: "100%", minHeight: 72, border: "1px solid var(--admin-border)", borderRadius: 10, padding: "10px 12px", fontSize: "0.92857rem", marginBottom: 14, resize: "vertical" }}
        />
        {err ? <div style={{ marginBottom: 14, padding: "10px 12px", background: "var(--admin-danger-soft)", border: "1px solid var(--admin-danger-soft)", borderRadius: 10, fontSize: "0.85714rem", color: "var(--admin-danger)" }}>{err}</div> : null}
        <div style={{ display: "flex", justifyContent: "flex-end", gap: 8 }}>
          <button onClick={() => navigate(`/dashboard/orders/${orderId}`)} style={{ padding: "10px 14px", border: "1px solid var(--admin-border)", borderRadius: 10, background: C.white, color: C.textSub, fontSize: "0.92857rem", fontWeight: 600, cursor: "pointer" }}>Back</button>
          <button onClick={confirmCancel} disabled={saving || ["cancelled", "delivered"].includes(order.status)} style={{ padding: "10px 14px", border: "1px solid var(--admin-danger-soft)", borderRadius: 10, background: "var(--admin-danger-soft)", color: "var(--admin-danger)", fontSize: "0.92857rem", fontWeight: 700, cursor: saving ? "not-allowed" : "pointer" }}>{saving ? "Cancelling…" : "Confirm Cancellation"}</button>
        </div>
      </div>
    </div>
  );
}
