import { useAuth } from "../../../auth/AuthContext";
import { AlertCircle, ArrowLeft, Printer } from "lucide-react";
import AdminPageHeader from "../../components/AdminPageHeader";
import { ResourceError, ResourceLoading } from "../../../components/ResourceFeedback";
import { Button } from "../../../components/ui/button";
import { Navigate, useNavigate, useParams } from "react-router-dom";
import { useAdminOrder } from "../../adminOrders";
import { useResource } from "../../../hooks/useResource";
import { getPaymentForOrder } from "../../../api/payments";
import { fmtDate, OrderStatusBadge } from "./components";
import OrderItems from "./OrderItems";
import OrderSummary from "./OrderSummary";
import OrderContact from "./OrderContact";
import OrderActivity from "./OrderActivity";

export function OrderDetailsPage() {
  const navigate = useNavigate();
  const { isAdmin, isStaff } = useAuth();
  const { orderId } = useParams();
  const { order, loading, error, refetch } = useAdminOrder(orderId);
  const payment = useResource(order ? `/v1/payments/orders/${orderId}` : null, () => getPaymentForOrder(orderId), { pollMs: 10000 });
  if (loading && !order) return <div className="p-6"><ResourceLoading /></div>;
  if (error) return <ResourceError message="Could not load this order." retry={refetch} />;
  if (!order) return <Navigate to="/dashboard/orders" replace />;
  const canUpdate = !["delivered", "cancelled"].includes(order.status);

  return (
    <div className="min-w-0 flex-1 overflow-y-auto bg-background p-6">
      <AdminPageHeader title={`Order ${order.code}`} back={<button type="button" onClick={() => navigate("/dashboard/orders")} className="inline-flex items-center gap-1"><ArrowLeft size={12} aria-hidden="true" />Orders</button>} description={<span className="flex flex-wrap items-center gap-x-3 gap-y-2"><span>Placed {fmtDate(order.createdAt)}</span><OrderStatusBadge status={order.status} /></span>} actions={<>
        <Button size="sm" variant="outline" onClick={() => window.print()}><Printer aria-hidden="true" />Print</Button>
        {canUpdate && <><Button size="sm" variant="outline" onClick={() => navigate(`/dashboard/orders/${order.id}/cancel`)} style={{ color: "var(--admin-danger)" }}>Cancel Order</Button><Button size="sm" onClick={() => navigate(`/dashboard/orders/${order.id}/edit`)}>Update Status</Button></>}
      </>} />
      <div className="mx-auto w-full max-w-[1320px]">
        {order.cancellationReason && <div role="status" className="mb-4 flex items-start gap-3 rounded-xl border border-destructive/20 bg-destructive/5 px-4 py-3 text-sm text-destructive"><AlertCircle size={18} className="mt-0.5 shrink-0" aria-hidden="true" /><div><p className="font-semibold">Order cancelled</p><p className="mt-0.5 leading-5">{order.cancellationReason}</p></div></div>}
        <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1.55fr)_minmax(320px,0.85fr)]">
        <div className="order-2 min-w-0 space-y-4 lg:order-1">
          <OrderItems items={order.items} />
          <OrderActivity history={order.statusHistory} />
          {order.note && <details className="rounded-xl border bg-card p-4 text-sm text-muted-foreground"><summary className="cursor-pointer font-medium text-foreground">Order note</summary><p className="mt-3 leading-6">{order.note}</p></details>}
        </div>
        <aside className="order-1 min-w-0 space-y-4 lg:sticky lg:top-4 lg:order-2">
          <OrderSummary canConfirmCod={isAdmin || isStaff} order={order} payment={payment.data} paymentLoading={payment.loading} paymentError={payment.error} refetchPayment={payment.refetch} />
          <OrderContact order={order} />
        </aside>
        </div>
      </div>
    </div>
  );
}
