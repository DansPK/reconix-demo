// The admin dashboard's view of the catalog, backed by the API.
//
// The dashboard's own product shape (cat/subCat strings, a flat `stock`, a persisted
// `status`) is kept, because every form, table and filter in ProductsPage is built
// around it. What changes is where it comes from and where edits go: the prototype held
// these objects in React state, mirrored them into localStorage, and recomputed `status`
// by hand on every write. Now they are projections of server rows.

import { useCallback, useMemo } from "react";
import * as catalogApi from "../api/catalog";
import { useResource, invalidate } from "../hooks/useResource";

/** Products hang off level-3 leaves, so a product's category is really a (main, leaf) pair. */
const LEAF_LEVEL = 3;

/** Flattens the tree into the nested `{Man: {clothing: [...]}}` object the UI still expects. */
export function treeToLegacyCategories(tree) {
  const legacy = {};
  (tree ?? []).forEach((main) => {
    const groups = {};
    (main.children ?? []).forEach((group) => {
      // Group keys were camelCase in the prototype ("Shop By Style" -> shopByStyle);
      // the UI only uses them as object keys, so the same derivation is kept.
      const key = group.name
        .split(/[^A-Za-z0-9]+/)
        .filter(Boolean)
        .map((word, index) => (index === 0 ? word.toLowerCase() : word[0].toUpperCase() + word.slice(1).toLowerCase()))
        .join("");
      groups[key] = ["All", ...(group.children ?? []).map((leaf) => leaf.name)];
    });
    legacy[main.name] = groups;
  });
  return legacy;
}

/** Turns a group's display name into the camelCase key the UI uses ("Shop By Style" -> shopByStyle). */
export function toGroupKey(name) {
  return String(name ?? "")
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .map((word, index) => (index === 0 ? word.toLowerCase() : word[0].toUpperCase() + word.slice(1).toLowerCase()))
    .join("");
}

/**
 * Finds a node by the names the UI works in.
 *
 * The dashboard identifies categories by display name and group key; the API needs ids.
 * This is the translation, and it is why renaming a category no longer detaches
 * everything pointing at it - the id does not change.
 */
export function findCategoryNode(tree, { main, group, leaf }) {
  const mainNode = (tree ?? []).find((node) => node.name === main);
  if (!mainNode || group === undefined) return mainNode ?? null;

  const groupNode = (mainNode.children ?? []).find(
    (node) => node.name === group || toGroupKey(node.name) === group
  );
  if (!groupNode || leaf === undefined) return groupNode ?? null;

  return (groupNode.children ?? []).find((node) => node.name === leaf) ?? null;
}

/** Every leaf, indexed by "Main/Leaf name" so a product's category id can be resolved. */
function indexLeaves(tree) {
  const byPair = new Map();
  const byId = new Map();
  (tree ?? []).forEach((main) => {
    (main.children ?? []).forEach((group) => {
      (group.children ?? []).forEach((leaf) => {
        if (leaf.level === LEAF_LEVEL || !leaf.children?.length) {
          byPair.set(`${main.name}/${leaf.name}`, leaf.id);
          byId.set(leaf.id, { main: main.name, group: group.name, leaf: leaf.name });
        }
      });
    });
  });
  return { byPair, byId };
}

/** API product -> the shape the dashboard's tables and forms read. */
export function toAdminProduct(product) {
  const path = product.categoryPath ?? [];
  return {
    id: product.id,
    createdAt: product.createdAt,
    name: product.name,
    sku: product.sku,
    slug: product.slug,
    cat: path[0]?.name ?? "",
    subCat: path[path.length - 1]?.name ?? "",
    categoryId: product.category?.id ?? null,
    description: product.description ?? "",
    modelInfo: product.modelInfo ?? "",
    price: Number(product.basePrice ?? 0),
    // The form treats 0 as "not on sale"; the API uses null for the same thing.
    salePrice: product.salePrice != null ? Number(product.salePrice) : 0,
    costPrice: product.costPrice != null ? Number(product.costPrice) : 0,
    // Derived server-side from the variants, not stored alongside them.
    stock: product.stock ?? 0,
    lowStockThreshold: product.lowStockThreshold ?? 10,
    isActive: product.active !== false,
    isFeatured: !!product.featured,
    tags: product.tags ?? [],
    section: product.section ?? "",
    images: (product.images ?? []).map((image) => image.imageUrl),
    imageIds: (product.images ?? []).map((image) => image.id),
    image: product.images?.[0]?.imageUrl ?? "",
    variants: (product.variants ?? []).map((variant) => ({
      id: variant.id,
      sku: variant.sku,
      size: variant.size ?? "",
      color: variant.color ?? "",
      stock: variant.stock ?? 0,
      reserved: variant.reservedStock ?? 0,
      available: variant.availableStock ?? 0,
      costPrice: variant.costPrice != null ? Number(variant.costPrice) : null,
      reorderPoint: variant.reorderPoint ?? 0,
      supplier: variant.supplier ?? "",
      location: variant.location ?? "",
    })),
    // Computed by the server from the variant stock, so it cannot disagree with it.
    status: product.status,
  };
}

/** Dashboard form -> API request body. */
export function toProductPayload(form, tree) {
  const { byPair } = indexLeaves(tree);
  const categoryId = form.categoryId ?? byPair.get(`${form.cat}/${form.subCat}`) ?? null;

  const salePrice = Number(form.salePrice) || 0;
  return {
    categoryId,
    name: form.name,
    sku: form.sku || undefined,
    description: form.description || null,
    modelInfo: form.modelInfo || null,
    basePrice: Number(form.price) || 0,
    // 0 means "no sale" in the form; the column is nullable for the same reason.
    salePrice: salePrice > 0 ? salePrice : null,
    costPrice: Number(form.costPrice) || 0,
    lowStockThreshold: Number(form.lowStockThreshold) || 10,
    featured: !!form.isFeatured,
    active: form.isActive !== false,
    section: form.section || null,
    tags: form.tags ?? [],
    variants: (form.variants ?? []).map((variant) => ({
      id: variant.id ?? null,
      sku: variant.sku || undefined,
      size: variant.size || null,
      color: variant.color || null,
      stock: Number(variant.stock) || 0,
      costPrice: variant.costPrice != null ? Number(variant.costPrice) : null,
      reorderPoint: Number(variant.reorderPoint) || 0,
      supplier: variant.supplier || null,
      location: variant.location || null,
    })),
  };
}

/**
 * The admin catalog: the category tree, the product list, and the mutations.
 *
 * Products are fetched with isActive left unset, so an admin sees deactivated ones too -
 * the server decides that from the caller's role, not from the parameter.
 */
export function useAdminCatalog({ page = 0, size = 100, search, categoryId, status, sort } = {}) {
  const treeResource = useResource("/v1/categories/tree", catalogApi.getCategoryTree);
  const tree = treeResource.data ?? [];

  const params = { page, size, q: search, categoryId, status, sort };
  const key = `/v1/products?admin&${new URLSearchParams(
    Object.entries(params).filter(([, value]) => value !== undefined && value !== "" && value !== null)
  ).toString()}`;

  const productsResource = useResource(key, () => catalogApi.listProducts(params));

  const products = useMemo(
    () => (productsResource.data?.content ?? []).map(toAdminProduct),
    [productsResource.data]
  );

  const categories = useMemo(() => treeToLegacyCategories(tree), [tree]);
  const leafIndex = useMemo(() => indexLeaves(tree), [tree]);

  // Every mutation invalidates both keys: a product change moves a category's count, and
  // a category change can move a product. The prototype broadcast a CustomEvent here.
  const refreshAll = useCallback(() => {
    invalidate("/v1/products");
    invalidate("/v1/categories");
  }, []);

  const createProduct = useCallback(async (form) => {
    const created = await catalogApi.createProduct(toProductPayload(form, tree));
    refreshAll();
    return created;
  }, [tree, refreshAll]);

  const updateProduct = useCallback(async (id, form) => {
    const updated = await catalogApi.updateProduct(id, toProductPayload(form, tree));
    refreshAll();
    return updated;
  }, [tree, refreshAll]);

  const patchProduct = useCallback(async (id, partial) => {
    const updated = await catalogApi.updateProduct(id, partial);
    refreshAll();
    return updated;
  }, [refreshAll]);

  const deleteProduct = useCallback(async (id) => {
    await catalogApi.deleteProduct(id);
    refreshAll();
  }, [refreshAll]);

  const uploadImages = useCallback(async (productId, files) => {
    // Sequential rather than parallel: display order follows upload order, and the first
    // image is the primary one.
    for (let index = 0; index < files.length; index += 1) {
      await catalogApi.uploadProductImage(productId, files[index], {
        primary: index === 0,
        displayOrder: index,
      });
    }
    refreshAll();
  }, [refreshAll]);

  // ── Categories ────────────────────────────────────────────────────────────
  // Names are unique among siblings, not globally, so the same leaf name may exist
  // under Man and Woman. Deleting a node with children or products is refused by the
  // server with a 409 rather than guarded in the browser as it was before.

  const createCategory = useCallback(async ({ name, parentId }) => {
    const created = await catalogApi.createCategory({ name, parentId: parentId ?? null });
    refreshAll();
    return created;
  }, [refreshAll]);

  const renameCategory = useCallback(async (id, { name, displayOrder, active }) => {
    const updated = await catalogApi.updateCategory(id, { name, displayOrder, active });
    refreshAll();
    return updated;
  }, [refreshAll]);

  const deleteCategory = useCallback(async (id) => {
    await catalogApi.deleteCategory(id);
    refreshAll();
  }, [refreshAll]);

  const uploadCategoryImage = useCallback(async (id, file) => {
    const updated = await catalogApi.uploadCategoryImage(id, file);
    refreshAll();
    return updated;
  }, [refreshAll]);

  const findNode = useCallback((names) => findCategoryNode(tree, names), [tree]);

  return {
    tree,
    categories,
    leafIndex,
    findNode,
    createCategory,
    renameCategory,
    deleteCategory,
    uploadCategoryImage,
    products,
    totalElements: productsResource.data?.totalElements ?? 0,
    loading: productsResource.loading || treeResource.loading,
    error: productsResource.error ?? treeResource.error,
    refetch: productsResource.refetch,
    createProduct,
    updateProduct,
    patchProduct,
    deleteProduct,
    uploadImages,
    refreshAll,
  };
}
