// The admin ReportsPage, backed by the API.
//
// Every number here used to be a hardcoded object per period. Now each period is one
// call to /admin/reports/overview, which computes revenue/orders/aov/customers, their
// trend against the immediately preceding period of equal length, daily (or monthly,
// for the year view) bars, top products, a category revenue split and a real payment
// method split - no more invented 78% KHQR heuristic.

import { useMemo } from "react";
import * as adminApi from "../api/admin";
import { useResource } from "../hooks/useResource";

const PERIOD_KEYS = ["7d", "30d", "month", "year"];

function toReportPeriod(overview) {
  if (!overview) return null;
  return {
    label: overview.label,
    revenue: Number(overview.revenue ?? 0),
    orders: overview.orders ?? 0,
    aov: Number(overview.aov ?? 0),
    customers: overview.customers ?? 0,
    revTrend: overview.revTrend,
    ordTrend: overview.ordTrend,
    aovTrend: overview.aovTrend,
    custTrend: overview.custTrend,
    newCustomers: overview.newCustomers ?? 0,
    newCustomerTrend: overview.newCustomerTrend,
    topProductsByRevenue: overview.topProductsByRevenue ?? [],
    dailyBars: overview.dailyBars ?? overview.bars ?? [],
    saleBreakdown: overview.saleBreakdown ?? [],
    bars: overview.bars ?? [],
    topProducts: overview.topProducts ?? [],
    categories: overview.categories ?? [],
    paymentSplit: overview.paymentSplit ?? [],
  };
}

/** One period, for the page's own current view. */
export function useReportPeriod(period) {
  const key = `/v1/admin/reports/overview?period=${period}`;
  const { data, loading, error, refetch } = useResource(key, () =>
    adminApi.getReportOverview(period),
    { keepPreviousData: false },
  );
  return { data: toReportPeriod(data), loading, error, refetch };
}

/** All four periods at once, for the period-comparison table at the bottom of the
 * page - a fixed, small set of calls, each independently cached like any other. */
export function useAllReportPeriods() {
  // eslint-disable-next-line react-hooks/rules-of-hooks -- PERIOD_KEYS is a fixed constant, not conditional
  const results = PERIOD_KEYS.map((period) =>
    useResource(`/v1/admin/reports/overview?period=${period}`, () =>
      adminApi.getReportOverview(period),
    ),
  );

  const periods = useMemo(() => {
    const map = {};
    PERIOD_KEYS.forEach((key, index) => {
      map[key] = toReportPeriod(results[index].data);
    });
    return map;
  }, [results]);

  return {
    periods,
    loading: results.some((r) => r.loading),
    error: results.find((r) => r.error)?.error,
    refetch: () => Promise.all(results.map((r) => r.refetch())),
  };
}
