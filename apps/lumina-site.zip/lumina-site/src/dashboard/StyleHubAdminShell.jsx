import { AdminThemeProvider } from "./AdminTheme";
import { useState } from "react";
import { Routes, Route, useLocation, Navigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import ProductsPage from "./pages/ProductsPage";
import CategoriesPage from "./pages/CategoriesPage";
import InventoryPageMenu from "./pages/InventoryPage";
import CustomersPageMenu from "./pages/CustomersPage";
import PaymentsPageMenu from "./pages/PaymentsPage";
import ReportsPageMenu from "./pages/ReportsPage";
import { DashboardDataProvider } from "./DashboardDataContext";
import {
  OrdersPage as OrdersPageMenu,
  OrderDetailsPage as OrderDetailsPageMenu,
  EditOrderPage as EditOrderPageMenu,
  CancelOrderPage as CancelOrderPageMenu,
} from "./pages/OrdersPages";
import DashboardPage from "./pages/DashboardPage";
import NotificationsPage from "./pages/NotificationsPage";
import SettingsPage from "./pages/SettingsPage";
import ConfigPage from "./pages/ConfigPage";
import Sidebar from "./components/Sidebar";
import Topbar from "./components/Topbar";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "../components/ui/sheet";
import { PageMotion } from "../components/PageMotion";
import NotFound from "../components/NotFound";
import { C } from "./components/constants";

// ══════════════════════════════════════════════════════════════════════════════
// ROOT
// ══════════════════════════════════════════════════════════════════════════════
export default function StyleHubAdmin() {
  return <AdminThemeProvider><AdminWorkspace /></AdminThemeProvider>;
}

function AdminWorkspace() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [period, setPeriod] = useState("7d");
  const [collapsed, setCol] = useState(false);
  // The session comes from AuthContext, which holds a real JWT. The shell used to keep
  // its own in localStorage, set by comparing against a credential pair hardcoded in
  // this file - so "signing in" was a string comparison in the browser and the backend
  // never saw it. main.jsx now gates this whole route on the verified role.
  const { user, role, logout, isAdmin } = useAuth();
  const session = user
    ? { role: (role ?? "").toLowerCase(), email: user.email, name: user.name }
    : null;
  const location = useLocation();
  const pathSegments = location.pathname.split("/").filter(Boolean);
  const activePage = pathSegments.length > 1 ? pathSegments[1] : "dashboard";

  // /dashboard/login is kept as a redirect so old bookmarks still land somewhere
  // sensible; the storefront sign-in page is now the only way in.
  if (activePage === "login") {
    return <Navigate to={session ? "/dashboard" : "/login"} replace />;
  }

  if (!session) {
    return <Navigate to="/login" replace state={{ from: "/dashboard" }} />;
  }

  return (
    <div
      className="admin-shell"
      style={{
        display: "flex",
        height: "100dvh",
        fontFamily: "'Poppins','Segoe UI',sans-serif",
        background: "var(--admin-card)",
        overflow: "hidden",
        fontSize: "0.92857rem",
        color: C.text,
      }}
    >
      <div className="admin-desktop-nav">
        <Sidebar
          activePage={activePage}
          collapsed={collapsed}
          setCollapsed={setCol}
        />
      </div>
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="flex w-[min(320px,calc(100vw-2rem))] max-w-none flex-col p-4 [&_.admin-sidebar]:w-full [&_.admin-sidebar]:min-w-0">
          <SheetHeader>
            <SheetTitle>Lumina workspace</SheetTitle>
            <SheetDescription>Manage your store.</SheetDescription>
          </SheetHeader>
          <div
            className="min-h-0 flex-1"
            onClick={(event) => {
              if (event.target.closest(".admin-sidebar__item"))
                setMobileOpen(false);
            }}
          >
            <Sidebar
              activePage={activePage}
              collapsed={false}
              setCollapsed={() => setMobileOpen(false)}
            />
          </div>
        </SheetContent>
      </Sheet>
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          minWidth: 0,
          background: "var(--admin-background)",
        }}
      >
        <Topbar
          period={period}
          setPeriod={setPeriod}
          onMenu={() => setMobileOpen(true)}
        />
        <DashboardDataProvider>
          <PageMotion className="admin-content">
            <Routes>
              <Route
                path="/"
                element={
                  <DashboardPage period={period} setPeriod={setPeriod} />
                }
              />
              <Route path="/products" element={<ProductsPage />} />
              <Route path="/categories" element={<CategoriesPage />} />
              <Route path="/orders" element={<OrdersPageMenu />} />
              <Route
                path="/orders/:orderId"
                element={<OrderDetailsPageMenu />}
              />
              <Route
                path="/orders/:orderId/edit"
                element={<EditOrderPageMenu />}
              />
              <Route
                path="/orders/:orderId/cancel"
                element={<CancelOrderPageMenu />}
              />
              <Route path="/inventory" element={<InventoryPageMenu />} />
              <Route path="/customers" element={isAdmin ? <CustomersPageMenu /> : <Navigate to="/dashboard" replace />} />
              <Route path="/payments" element={<PaymentsPageMenu />} />
              <Route path="/reports" element={<ReportsPageMenu />} />
              <Route path="/config" element={isAdmin ? <ConfigPage /> : <Navigate to="/dashboard" replace />} />
              <Route path="/notifications" element={isAdmin ? <NotificationsPage /> : <Navigate to="/dashboard" replace />} />
              <Route path="/settings" element={<SettingsPage />} />
              <Route path="*" element={<NotFound home="/dashboard" />} />
            </Routes>
          </PageMotion>
        </DashboardDataProvider>
      </div>
    </div>
  );
}
