import { refreshPaymentViews } from "../api/paymentSync";
// The admin dashboard's view of payments, backed by the API.
//
// This used to be derived from the same localStorage order list PaymentsPage's orders
// came from, inventing a flat 3% fee and a fake reference number in JavaScript. Now it
// reads the payments table directly, with the real fee/net the payment was actually
// taken at.

import { useCallback, useMemo } from "react";
import * as paymentsApi from "../api/payments";
import { useResource } from "../hooks/useResource";
import { query } from "../api/client";

/** API payment -> the shape PaymentsPage renders. */
export function toAdminPayment(payment) {
  return {
    id: payment.id,
    orderId: payment.orderId,
    orderCode: payment.orderCode,
    customer: payment.customerName || "—",
    method: payment.paymentMethod,
    status: payment.paymentStatus,
    amount: Number(payment.amount ?? 0),
    fee: Number(payment.feeAmount ?? 0),
    net: Number(payment.netAmount ?? 0),
    channel: payment.channel,
    refundedAmount: Number(payment.refundedAmount ?? 0),
    refundedAt: payment.refundedAt,
    createdAt: payment.createdAt,
  };
}

/** The admin Payments table. Fetched as one largeish page and filtered/sorted in the
 * browser, same pattern as the admin Orders table. */
export function useAdminPayments({ size = 200 } = {}) {
  const params = { size };
  const key = `/v1/admin/payments${query(params)}`;
  const { data, loading, error, refetch } = useResource(key, () => paymentsApi.listPayments(params), { pollMs: 10000 });

  const payments = useMemo(() => (data?.content ?? []).map(toAdminPayment), [data]);

  return { payments, totalElements: data?.totalElements ?? 0, loading, error, refetch };
}

export function useAdminPaymentSummary() {
  const { data, loading, error, refetch } = useResource("/v1/admin/payments/summary", () => paymentsApi.getPaymentSummary(), { pollMs: 10000 });
  return { summary: data, loading, error, refetch };
}

export function useRefundPayment() {
  return useCallback(async (paymentId, { amount, reason }) => {
    const updated = await paymentsApi.refundPayment(paymentId, { amount, reason });
    refreshPaymentViews({ includeStatus: true });
    return updated;
  }, []);
}

export const PAYMENT_METHOD_LABELS = {
  bakong_khqr: "Bakong KHQR",
  no_payment_required: "No payment required", cash_on_delivery: "Cash on delivery",
};

export const PAYMENT_STATUS_LABELS = {
  pending: "Pending",
  paid: "Paid",
  failed: "Failed",
  expired: "Expired",
  refunded: "Refunded",
  partially_refunded: "Partially refunded",
};
