import { createContext, useContext, useMemo } from "react";
import { useAdminCatalog } from "./adminCatalog";
import { Chip } from "@heroui/react";

const DashboardDataContext = createContext(null);

const HEROUI_STATUS_TONES = {
  active: "success",
  "low-stock": "warning",
  "out-of-stock": "danger",
  pending: "primary",
  paid: "success",
  refunded: "secondary",
  failed: "danger",
  inactive: "default",
  vip: "primary",
  regular: "secondary",
  new: "success",
  "at risk": "warning",
};

const HEROUI_SEGMENT_TONES = {
  VIP: "primary",
  Regular: "secondary",
  New: "success",
  "At Risk": "warning",
};

export function getHeroStatusTone(status) {
  const normalizedKey = String(status ?? "")
    .trim()
    .toLowerCase();

  return HEROUI_STATUS_TONES[normalizedKey] ?? "default";
}

export function getHeroStatusChip(status) {
  const tone = getHeroStatusTone(status);
  const label = String(status ?? "Unknown")
    .trim()
    .replace(/-/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());

  return <Chip color={tone} radius="full" size="sm" variant="flat">{label}</Chip>;
}

export function getHeroSegmentTone(segment) {
  return HEROUI_SEGMENT_TONES[segment] ?? "default";
}

export function getHeroSegmentChip(segment) {
  const tone = getHeroSegmentTone(segment);

  return <Chip color={tone} radius="full" size="sm" variant="flat">{segment || "Unknown"}</Chip>;
}

export function DashboardDataProvider({ children }) {
  // The catalog, orders, payments, customers and reports all come from the API now.
  // Inventory metadata (supplier, location, reorder point, cost) lives on the variant,
  // from the same catalog fetch - InventoryPage reads it off `products[].variants`
  // directly.
  const catalog = useAdminCatalog({ size: 200 });
  const { categories, products } = catalog;

  const value = useMemo(
    () => ({
      // The legacy nested shape, derived from the tree so existing dropdowns keep working.
      categories,
      // The tree itself, plus the catalog mutations, for pages that have been migrated.
      catalog,
      products,
      getHeroStatusTone,
      getHeroStatusChip,
      getHeroSegmentTone,
      getHeroSegmentChip,
      heroUIStatusTones: HEROUI_STATUS_TONES,
      heroUISegmentTones: HEROUI_SEGMENT_TONES,
    }),
    [catalog, categories, products]
  );

  return <DashboardDataContext.Provider value={value}>{children}</DashboardDataContext.Provider>;
}

export function useDashboardData() {
  const context = useContext(DashboardDataContext);
  if (!context) {
    throw new Error("useDashboardData must be used within DashboardDataProvider");
  }
  return context;
}
