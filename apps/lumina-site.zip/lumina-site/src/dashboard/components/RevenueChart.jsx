import { useState } from "react";
import { C } from "./constants";

export default function RevenueChart({bars}) {
  const [hov,setHov] = useState(null);
  const maxV = Math.max(...bars.map(b=>b.v));

  // Y-axis grid values
  const gridLines = [0, maxV * 0.25, maxV * 0.5, maxV * 0.75, maxV];

  return (
    <div style={{height:"100%",display:"flex",flexDirection:"column"}}>
      {/* Grid and bars */}
      <div style={{flex:1,display:"flex",position:"relative",minHeight:200}}>
        {/* Y-axis labels and grid */}
        <div style={{display:"flex",flexDirection:"column",justifyContent:"space-between",width:50,paddingRight:12,textAlign:"right"}}>
          {gridLines.reverse().map((val,i)=>(
            <div key={i} style={{fontSize: "0.78571rem",color:C.muted,fontWeight:500}}>
              ${(val/1000).toFixed(0)}k
            </div>
          ))}
        </div>

        {/* Grid background */}
        <div style={{flex:1,position:"relative",borderLeft:`1px solid ${C.border}`,borderBottom:`1px solid ${C.border}`}}>
          {gridLines.slice(0,-1).map((val,i)=>(
            <div key={i} style={{
              position:"absolute",
              top:`${(i+1)*25}%`,
              left:0,
              right:0,
              height:"1px",
              background:C.surface,
              borderTop:`0.5px dashed ${C.border}`
            }}/>
          ))}

          {/* Bars */}
          <div style={{display:"flex",alignItems:"flex-end",gap:6,height:"100%",paddingBottom:12,justifyContent:"space-around",position:"relative",zIndex:2}}>
            {bars.map((b,i)=>{
              const pct = Math.round(b.v/maxV*100);
              return (
                <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:6,cursor:"pointer"}} onMouseEnter={()=>setHov(i)} onMouseLeave={()=>setHov(null)}>
                  <div style={{
                    width:"100%",
                    height:`${pct}%`,
                    minHeight:6,
                    borderRadius:"6px 6px 0 0",
                    background:hov===i?C.accentT:C.accent,
                    opacity:hov===i?1:0.7,
                    transition:"all .15s ease",
                    boxShadow:hov===i?`0 4px 12px ${C.accent}33`:"none"
                  }}/>
                  <div style={{fontSize: "0.78571rem",color:C.muted,fontWeight:500,marginTop:4}}>{b.d}</div>
                  {hov===i&&<div style={{fontSize: "0.71429rem",color:C.accent,fontWeight:600,marginTop:2}}>${(b.v/1000).toFixed(1)}k</div>}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
