import { useId, useState } from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "../../components/ui/card";
import { ToggleGroup, ToggleGroupItem } from "../../components/ui/toggle-group";
import { formatMoney } from "../pages/ReportsPage/helpers";

export default function SalesTrend({ bars }) {
  const [metric, setMetric] = useState("revenue");
  const [selected, setSelected] = useState(null);
  const gradient = useId().replace(/:/g, "");
  const money = metric !== "orders";
  const average = metric === "aov";
  const values = bars.map(bar => (average ? (bar.o ? Number(bar.v || 0) / Number(bar.o) : 0) : Number((money ? bar.v : bar.o) || 0)));
  const revenue = bars.reduce((sum, bar) => sum + Number(bar.v || 0), 0);
  const orders = bars.reduce((sum, bar) => sum + Number(bar.o || 0), 0);
  const total = average ? (orders ? revenue / orders : 0) : values.reduce((sum, value) => sum + value, 0);
  const rawMaximum = Math.max(1, ...values);
  const step = money ? (rawMaximum >= 100 ? 100 : 10) : 1;
  const maximum = Math.ceil(rawMaximum / step) * step;
  const format = money ? formatMoney : value => Number(value).toLocaleString();
  const points = bars.map((bar, index) => ({ ...bar, value: values[index], x: bars.length === 1 ? 344 : 58 + index / (bars.length - 1) * 572, y: 210 - values[index] / maximum * 170 }));
  const path = points.map((point, index) => `${index ? "L" : "M"}${point.x},${point.y}`).join(" ");
  const ticks = [...new Set([0, money ? maximum / 2 : Math.floor(maximum / 2), maximum])];
  const active = selected == null ? null : points[selected];
  return (
    <Card className="h-full min-w-0 shadow-none">
      <CardHeader className="flex-row flex-wrap items-start justify-between gap-4">
        <div><CardTitle className="text-base">Sales trend</CardTitle><CardDescription className="mt-2">Paid, non-cancelled orders · reported dates with sales</CardDescription></div>
        <div className="text-right"><p className="text-2xl font-semibold tabular-nums">{format(active?.value ?? total)}</p><p className="mt-1 text-xs text-muted-foreground">{active?.d ?? (average ? "Period average" : `Period ${money ? "revenue" : "paid orders"}`)}</p></div>
      </CardHeader>
      <CardContent>
        <ToggleGroup type="single" value={metric} onValueChange={value => { if (value) { setMetric(value); setSelected(null); } }} size="sm" variant="outline" className="mb-3 justify-start" aria-label="Sales trend metric">
          <ToggleGroupItem value="revenue">Revenue</ToggleGroupItem><ToggleGroupItem value="orders">Orders</ToggleGroupItem><ToggleGroupItem value="aov">Avg. order</ToggleGroupItem>
        </ToggleGroup>
        {!bars.length ? <p className="py-16 text-center text-sm text-muted-foreground">No paid sales in this period.</p> : (
          <div className="overflow-x-auto">
            <svg viewBox="0 0 660 250" className="w-full min-w-[440px]" role="group" aria-label={`${average ? "Average order value" : money ? "Revenue" : "Paid orders"} trend graph`}>
              <defs><linearGradient id={gradient} x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="var(--admin-primary)" stopOpacity=".2" /><stop offset="100%" stopColor="var(--admin-primary)" stopOpacity="0" /></linearGradient></defs>
              {ticks.map(tick => { const y = 210 - tick / maximum * 170; return <g key={tick} aria-hidden="true"><line x1="58" x2="630" y1={y} y2={y} stroke="var(--admin-border)" strokeDasharray="4 5" /><text x="48" y={y + 4} textAnchor="end" fontSize="10" fill="var(--admin-muted-foreground)">{money ? `$${tick.toLocaleString()}` : tick}</text></g>; })}
              {points.length > 1 && <path d={`${path} L${points.at(-1).x},210 L${points[0].x},210 Z`} fill={`url(#${gradient})`} />}
              <path d={path} fill="none" stroke="var(--admin-primary)" strokeWidth="3" strokeLinejoin="round" />
              {points.map((point, index) => (
                <g key={`${point.d}-${index}`}>
                  {selected === index && <line aria-hidden="true" x1={point.x} x2={point.x} y1="30" y2="210" stroke="var(--admin-primary)" strokeOpacity=".3" strokeDasharray="3 4" />}
                  <circle cx={point.x} cy={point.y} r={selected === index ? 7 : 5} fill="var(--admin-card)" stroke="var(--admin-primary)" strokeWidth="3" tabIndex="0" role="img" aria-label={`${point.d}: ${format(point.value)}`} onMouseEnter={() => setSelected(index)} onMouseLeave={() => setSelected(null)} onFocus={() => setSelected(index)} onBlur={() => setSelected(null)}><title>{point.d}: {format(point.value)}</title></circle>
                  {(bars.length <= 10 || index === 0 || index === bars.length - 1 || index % Math.ceil(bars.length / 8) === 0) && <text aria-hidden="true" x={point.x} y="235" textAnchor="middle" fontSize="10" fill="var(--admin-muted-foreground)">{point.d}</text>}
                </g>
              ))}
            </svg>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
