import { useState } from "react";
import { Download, FileText } from "lucide-react";
import { Button } from "../../components/ui/button";

export default function ExportControls({ onCsv, onPdf, disabled = false, csvLabel = "Export CSV", pdfLabel = "Export PDF" }) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const pdf = async () => {
    if (busy) return;
    setBusy(true); setError("");
    try { await onPdf(); } catch { setError("PDF export failed. Please try again."); } finally { setBusy(false); }
  };
  return <div className="flex flex-wrap items-center gap-2"><Button type="button" variant="outline" size="sm" disabled={disabled || busy} onClick={onCsv}><Download aria-hidden="true" />{csvLabel}</Button>{onPdf && <Button type="button" variant="outline" size="sm" disabled={disabled || busy} onClick={pdf}><FileText aria-hidden="true" />{busy ? "Preparing PDF…" : pdfLabel}</Button>}{error && <p role="alert" className="w-full text-xs text-destructive">{error}</p>}</div>;
}
