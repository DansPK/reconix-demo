import { useNavigate } from "react-router-dom";
import { useAuth } from "../../auth/AuthContext";
import {
  ChevronLeft,
  ChevronRight,
  LogOut,
  Settings,
} from "lucide-react";
import BrandLogo from "../../components/BrandLogo";
import { NAV_GROUPS } from "./constants";

// ── SIDEBAR ──────────────────────────────────────────────────────────────────
export default function Sidebar({activePage, collapsed, setCollapsed}) {
  const navigate = useNavigate();
  // Ends the real session (clears the tokens), not just a localStorage flag.
  const { logout: endSession, isAdmin } = useAuth();
  const logout = () => {
    endSession();
    navigate("/login", { replace: true });
  };

  return (
    <aside className={`admin-sidebar${collapsed ? " is-collapsed" : ""}`}>
      {/* Logo Section */}
      <div className="admin-sidebar__header">
        <button className="admin-sidebar__brand" onClick={()=>navigate("/dashboard")} aria-label="Go to dashboard">
          <BrandLogo className={collapsed ? "w-10" : "w-36"} />
        </button>
        <button className="admin-sidebar__collapse" onClick={()=>setCollapsed(!collapsed)} aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}>
          {collapsed ? <ChevronRight size={17} strokeWidth={1.8}/> : <ChevronLeft size={17} strokeWidth={1.8}/>}
        </button>
      </div>

      {/* Navigation */}
      <nav className="admin-sidebar__nav" aria-label="Admin navigation">
        {NAV_GROUPS.map(({g,items})=>{
          const visibleItems = items.filter(item => !["config", "customers", "notifications"].includes(item.id) || isAdmin);
          if (!visibleItems.length) return null;
          return <div className="admin-sidebar__group" key={g}>
            {!collapsed&&<div className="admin-sidebar__group-label">{g}</div>}
            {visibleItems.map(item=>(
              <button
                className={`admin-sidebar__item${activePage===item.id ? " is-active" : ""}`}
                key={item.id}
                aria-current={activePage === item.id ? "page" : undefined}
                aria-label={item.label}
                onClick={()=>navigate(`/dashboard/${item.id===("dashboard")?"":item.id}`)}
                title={collapsed ? item.label : undefined}
              >
                <item.icon className="admin-sidebar__item-icon" size={18} strokeWidth={1.8}/>
                {!collapsed&&<span>{item.label}</span>}
              </button>
            ))}
          </div>;
        })}
      </nav>

      {/* Footer */}
      <div className="admin-sidebar__footer">
        {[{icon:Settings,label:"Settings",id:"settings"},{icon:LogOut,label:"Log out",id:"logout"}].map(({icon:Icon,label,id})=>(
          <button
            className="admin-sidebar__item admin-sidebar__footer-item"
            key={id}
            title={collapsed ? label : undefined}
            onClick={() => id === "logout" ? logout() : navigate("/dashboard/settings")}
          >
            <Icon className="admin-sidebar__item-icon" size={18} strokeWidth={1.8}/>
            {!collapsed&&<span>{label}</span>}
          </button>
        ))}
      </div>
    </aside>
  );
}
