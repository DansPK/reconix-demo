import { C } from "./constants";

// Simple SVG Donut Chart
export default function DonutChart({paid, pending, failed}) {
  const total = paid + pending + failed;
  const paidPct = (paid / total) * 100;
  const pendingPct = (pending / total) * 100;
  const failedPct = (failed / total) * 100;

  let offset = 0;
  const radius = 45;
  const circumference = 2 * Math.PI * radius;

  const paid_offset = offset;
  const paid_length = (paidPct / 100) * circumference;
  offset += paid_length;

  const pending_offset = offset;
  const pending_length = (pendingPct / 100) * circumference;
  offset += pending_length;

  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:16}}>
      <svg width="140" height="140" style={{transform:"rotate(-90deg)"}}>
        <circle cx="70" cy="70" r={radius} fill="none" stroke="var(--admin-border)" strokeWidth="18" />
        <circle cx="70" cy="70" r={radius} fill="none" stroke="var(--admin-success)" strokeWidth="18"
          strokeDasharray={paid_length} strokeDashoffset={-paid_offset} />
        <circle cx="70" cy="70" r={radius} fill="none" stroke="var(--admin-warning)" strokeWidth="18"
          strokeDasharray={pending_length} strokeDashoffset={-pending_offset} />
        <circle cx="70" cy="70" r={radius} fill="none" stroke="var(--admin-danger)" strokeWidth="18"
          strokeDasharray={failedPct / 100 * circumference} strokeDashoffset={-offset} />
        <text x="70" y="75" textAnchor="middle" fontSize="20" fontWeight="bold" fill={C.text}>
          ${paid + pending + failed}k
        </text>
      </svg>
      <div style={{display:"flex",flexDirection:"column",gap:8}}>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:12,height:12,borderRadius:2,background:"var(--admin-success)"}}/>
          <span style={{fontSize: "0.85714rem",color:C.textSub}}>Paid <span style={{fontWeight:500,color:C.text}}>{paidPct.toFixed(0)}%</span></span>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:12,height:12,borderRadius:2,background:"var(--admin-warning)"}}/>
          <span style={{fontSize: "0.85714rem",color:C.textSub}}>Pending <span style={{fontWeight:500,color:C.text}}>{pendingPct.toFixed(0)}%</span></span>
        </div>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <div style={{width:12,height:12,borderRadius:2,background:"var(--admin-danger)"}}/>
          <span style={{fontSize: "0.85714rem",color:C.textSub}}>Failed <span style={{fontWeight:500,color:C.text}}>{failedPct.toFixed(0)}%</span></span>
        </div>
      </div>
    </div>
  );
}
