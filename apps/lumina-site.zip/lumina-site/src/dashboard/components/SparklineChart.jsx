import { C } from "./constants";

export default function SparklineChart({data, height = 40}) {
  if (!data || data.length === 0) return null;
  const maxV = Math.max(...data);
  const minV = Math.min(...data);
  const range = maxV - minV || 1;
  const pointCount = data.length;
  const width = 100;
  const pointSpacing = width / (pointCount - 1 || 1);

  let path = '';
  data.forEach((v, i) => {
    const x = i * pointSpacing;
    const y = height - ((v - minV) / range) * height * 0.8 - height * 0.1;
    path += `${i === 0 ? 'M' : 'L'} ${x} ${y} `;
  });

  return (
    <svg width="100%" height={height} style={{display:"block",marginTop:8}}>
      <polyline points={path} fill="none" stroke={C.accent} strokeWidth="2" vectorEffect="non-scaling-stroke" />
      <defs>
        <linearGradient id="sparkGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={C.accent} stopOpacity="0.2" />
          <stop offset="100%" stopColor={C.accent} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={path + ` L ${width} ${height} L 0 ${height} Z`} fill="url(#sparkGrad)" />
    </svg>
  );
}
