import { C } from "./constants";

export default function Trend({value}) {
  const up = value>=0;
  return <div style={{fontSize: "0.78571rem",fontWeight:500,color:up?C.successT:C.dangerT,display:"flex",alignItems:"center",gap:3,marginTop:3}}><span>{up?"▲":"▼"}</span>{Math.abs(value)}% vs prev period</div>;
}
