import { CardHeader, CardTitle, CardDescription } from "../../components/ui/card";

export default function SettingsCardHeader({ icon: Icon, title, description, actions }) {
  return (
    <CardHeader className="flex-row flex-wrap items-start gap-3 space-y-0">
      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary"><Icon size={20} aria-hidden="true" /></span>
      <div className="min-w-0 flex-1">
        <CardTitle className="text-base font-medium leading-6">{title}</CardTitle>
        <CardDescription className="mt-1 text-sm leading-6">{description}</CardDescription>
      </div>
      {actions && <div className="w-full sm:w-auto">{actions}</div>}
    </CardHeader>
  );
}
