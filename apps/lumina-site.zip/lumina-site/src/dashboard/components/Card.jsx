import {
  Card as Surface,
  CardHeader,
  CardTitle,
  CardContent,
} from "../../components/ui/card";
import { Button } from "../../components/ui/button";
export default function Card({
  title,
  icon,
  actionLabel,
  onAction,
  children,
  style = {},
}) {
  return (
    <Surface style={style}>
      <CardHeader className="flex-row items-center justify-between gap-3">
        <CardTitle className="flex items-center gap-2">
          {icon}
          {title}
        </CardTitle>
        {actionLabel && onAction && (
          <Button variant="ghost" size="sm" onClick={onAction}>
            {actionLabel} →
          </Button>
        )}
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Surface>
  );
}
