// Native bars keep every value readable by keyboard and assistive technology.
export default function DistributionChart({ items, unit = "records", formatValue = value => Number(value).toLocaleString(), emptyMessage }) {
  const total = items.reduce((sum, item) => sum + Number(item.value || 0), 0);
  const maximum = Math.max(1, ...items.map(item => Number(item.value || 0)));
  if (!total) return <p className="py-8 text-center text-sm text-muted-foreground">{emptyMessage || `No ${unit} to display.`}</p>;
  return <ul className="flex flex-col gap-4" aria-label={`${unit} distribution`}>
    {items.map(item => <li key={item.name} className="flex flex-col gap-2">
      <div className="flex justify-between gap-4 text-sm"><span>{item.name}</span><span className="font-medium tabular-nums">{formatValue(item.value || 0)} <span className="font-normal text-muted-foreground">{unit}</span></span></div>
      <div className="h-2 overflow-hidden rounded-full bg-muted" aria-hidden="true"><div className="h-full rounded-full bg-primary" style={{ width: `${Math.max(0, Number(item.value || 0)) / maximum * 100}%` }} /></div>
    </li>)}
  </ul>;
}
