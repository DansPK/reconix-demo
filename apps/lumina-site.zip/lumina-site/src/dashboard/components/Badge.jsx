import { Chip } from "@heroui/react";
import { STATUS_CFG } from "./constants";

// ── SHARED ATOMS ─────────────────────────────────────────────────────────────
export default function Badge({status}) {
  const s = STATUS_CFG[status]||STATUS_CFG.pending;
  return <Chip size="sm" variant="flat" style={{background:s.bg,color:s.text,fontWeight:600}}>{s.label}</Chip>;
}
