import { useRef, useState } from "react";
import { Banknote } from "lucide-react";
import { confirmCodPayment } from "../../api/payments";
import { refreshPaymentViews } from "../../api/paymentSync";
import { Button } from "../../components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../../components/ui/dialog";

export default function ConfirmCodPayment({ allowed, orderId, method, status, cancelled = false }) {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const lock = useRef(false);
  if (!allowed || !orderId || cancelled || method !== "cash_on_delivery" || status !== "pending") return null;

  async function confirm() {
    if (lock.current) return;
    lock.current = true;
    setBusy(true);
    setError("");
    try {
      await confirmCodPayment(orderId);
      refreshPaymentViews({ includeStatus: true });
      setOpen(false);
    } catch (failure) {
      setError(failure?.detail || "Could not confirm cash collection. Please try again.");
    } finally {
      lock.current = false;
      setBusy(false);
    }
  }
  return <>
    <Button className="mt-3 w-full" onClick={() => { setError(""); setOpen(true); }}><Banknote size={16} aria-hidden="true" />Confirm cash collected</Button>
    <Dialog open={open} onOpenChange={next => { if (!busy) setOpen(next); }}>
      <DialogContent className="w-[calc(100%-2rem)] sm:max-w-md">
        <DialogHeader><DialogTitle>Confirm cash collection?</DialogTitle><DialogDescription>Confirm only after you have received the cash for this order. The payment will be marked as paid.</DialogDescription></DialogHeader>
        {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
        <div className="flex justify-end gap-2"><Button variant="outline" disabled={busy} onClick={() => setOpen(false)}>Back</Button><Button disabled={busy} onClick={confirm}>{busy ? "Confirming…" : "Confirm payment"}</Button></div>
      </DialogContent>
    </Dialog>
  </>;
}
