export default function AdminPageHeader({ title, description, actions, back, inset = true, spaced = true }) {
  return (
    <header
      className="admin-page-header flex flex-wrap items-center justify-between gap-4 border-b bg-card px-6 py-5 text-card-foreground"
      style={{ margin: inset ? `calc(-1 * var(--admin-page-inset, 24px)) calc(-1 * var(--admin-page-inset, 24px)) ${spaced ? 24 : 0}px` : 0 }}
    >
      <div className="min-w-0">
        {back && <div className="mb-2 text-xs text-muted-foreground">{back}</div>}
        <h1 className="break-words text-xl font-semibold tracking-tight sm:text-2xl">{title}</h1>
        {description && <p className="mt-1 text-sm leading-6 text-muted-foreground">{description}</p>}
      </div>
      {actions && <div className=" flex flex-wrap items-center gap-2 [&_button]:text-sm">{actions}</div>}
    </header>
  );
}
