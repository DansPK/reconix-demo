const COLORS = ["var(--admin-primary)", "var(--admin-success)", "var(--admin-warning)", "var(--admin-neutral)"];

// API shares are rounded percentages: keep their values, including an unreported remainder.
export default function ShareDonut({ items, label }) {
  const circumference = 2 * Math.PI * 46;
  const denominator = Math.max(100, items.reduce((sum, item) => sum + Math.max(0, Number(item.pct || 0)), 0));
  let offset = 0;
  const arcs = items.map((item, index) => {
    const length = Math.max(0, Number(item.pct || 0)) / denominator * circumference;
    const arc = { ...item, color: COLORS[index % COLORS.length], length, offset };
    offset += length;
    return arc;
  });
  return (
    <div className="flex flex-col items-center gap-6 sm:flex-row">
      <div className="relative h-40 w-40 shrink-0">
        <svg viewBox="0 0 120 120" className="h-full w-full -rotate-90" role="img" aria-label={`${label}: ${items.map(item => `${item.name}, ${item.pct}%`).join('; ')}`}>
          <circle cx="60" cy="60" r="46" fill="none" stroke="var(--admin-muted)" strokeWidth="12" />
          {arcs.filter(arc => arc.length > 0).map(arc => <circle key={arc.name} cx="60" cy="60" r="46" fill="none" stroke={arc.color} strokeWidth="12" strokeDasharray={`${arc.length} ${circumference - arc.length}`} strokeDashoffset={-arc.offset} />)}
        </svg>
        <div aria-hidden="true" className="absolute inset-0 flex items-center justify-center text-center text-xs font-medium text-muted-foreground">{label}</div>
      </div>
      <ul className="w-full min-w-0 flex-1 space-y-4">
        {arcs.map(item => <li key={item.name} className="flex items-center justify-between gap-3 text-sm"><span className="flex items-center gap-2"><span aria-hidden="true" className="h-2 w-2 shrink-0 rounded-full" style={{ background: item.color }} />{item.name}</span><span className="font-semibold tabular-nums">{item.pct}%</span></li>)}
      </ul>
    </div>
  );
}
