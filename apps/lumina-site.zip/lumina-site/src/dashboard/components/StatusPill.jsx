import { Chip } from "@heroui/react";

export default function StatusPill({active}) {
  return <Chip size="sm" color={active ? "success" : "danger"} variant="flat">{active?"Active":"Inactive"}</Chip>;
}
