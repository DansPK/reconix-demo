import { useAdminTheme } from "../AdminTheme";
import { useLocation, useNavigate } from "react-router-dom";
import { Menu, RefreshCw, ChevronDown, LogOut, Settings, Sun, Moon } from "lucide-react";
import { useAuth } from "../../auth/AuthContext";
import { invalidateAll } from "../../hooks/useResource";
import { ToggleGroup, ToggleGroupItem } from "../../components/ui/toggle-group";
import { Button } from "../../components/ui/button";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "../../components/ui/dropdown-menu";
export default function Topbar({ period, setPeriod, onMenu }) {
  const { theme, setTheme } = useAdminTheme();
  const { pathname } = useLocation();
  const page = pathname.split("/")[2] || "dashboard";
  const { user, role, logout } = useAuth();
  const navigate = useNavigate();
  return (
    <header className="flex min-h-16 shrink-0 flex-wrap items-center justify-between gap-2 border-b border-border bg-card px-4 py-3 md:px-6">
      <div className="flex min-w-0 items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="admin-menu-button"
          onClick={onMenu}
          aria-label="Open admin navigation"
        >
          <Menu />
        </Button>
        <p className="hidden text-sm font-medium text-muted-foreground sm:block">Lumina workspace</p>
      </div>
      <div className="flex min-w-0 items-center gap-1 sm:gap-2">
        <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} theme`}>
          {theme === "dark" ? <Sun /> : <Moon />}
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => invalidateAll()}
          aria-label="Refresh current data"
        >
          <RefreshCw />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="gap-1 px-2 sm:gap-2 sm:px-4">
              <span className="max-w-20 truncate sm:max-w-28">
                {user?.name || "Account"}
              </span>
              <ChevronDown />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>{role?.toLowerCase()}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuGroup>
              <DropdownMenuItem
                onSelect={() => navigate("/dashboard/settings")}
              >
                <Settings />
                Account settings
              </DropdownMenuItem>
              <DropdownMenuItem
                onSelect={() => {
                  logout();
                  navigate("/login", { replace: true });
                }}
              >
                <LogOut />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      {page === "dashboard" && (
        <ToggleGroup
          type="single"
          value={period}
          onValueChange={(value) => {
            if (value) setPeriod(value);
          }}
          size="sm"
          className="w-full flex-wrap justify-start"
          aria-label="Reporting period"
        >
          {[
            ["7d", "7 days"],
            ["30d", "30 days"],
            ["month", "Month"],
            ["year", "Year"],
          ].map(([value, label]) => (
            <ToggleGroupItem key={value} value={value}>
              {label}
            </ToggleGroupItem>
          ))}
        </ToggleGroup>
      )}
    </header>
  );
}
