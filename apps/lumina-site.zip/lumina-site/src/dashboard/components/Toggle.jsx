import { Switch } from "@heroui/react";

export default function Toggle({on, onChange}) {
  return <Switch size="sm" isSelected={on} onValueChange={onChange} aria-label="Toggle status" />;
}
