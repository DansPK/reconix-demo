// Shared semantic colors and navigation for the admin workspace.
import {
  Bell,
  BarChart3,
  Boxes,
  CreditCard,
  LayoutDashboard,
  Package,
  SlidersHorizontal,
  ShoppingCart,
  Tags,
  UsersRound,
} from "lucide-react";

// ── DESIGN TOKENS ────────────────────────────────────────────────────────────
export const C = {
  // Primary colors
  primary:"var(--admin-primary)",    // Main brand accent
  accent:"var(--admin-primary)",
  success:"var(--admin-success)",    // Green
  warning:"var(--admin-warning)",    // Orange/Yellow
  danger:"var(--admin-danger)",     // Red
  purple:"var(--admin-neutral)",     // Purple

  // Light backgrounds
  primaryBg:"var(--admin-primary-soft)",
  successBg:"var(--admin-success-soft)",
  warningBg:"var(--admin-warning-soft)",
  dangerBg:"var(--admin-danger-soft)",
  purpleBg:"var(--admin-neutral-soft)",

  // Text colors
  text:"var(--admin-foreground)",       // Main text
  textSub:"var(--admin-muted-foreground)",    // Secondary text
  muted:"var(--admin-muted-foreground)",      // Muted text

  // Backgrounds
  surface:"var(--admin-background)",    // Light gray background
  white:"var(--admin-card)",      // Card background
  border:"var(--admin-border)",     // Light border

  // Legacy (for compatibility)
  accentL:"var(--admin-primary-soft)",
  accentT:"var(--admin-primary)",
  successT:"var(--admin-success)",
  warningT:"var(--admin-warning)",
  dangerT:"var(--admin-danger)",
  purpleT:"var(--admin-neutral)",
  sidebarText:"var(--admin-muted-foreground)",
  sidebarLabel:"var(--admin-muted-foreground)",
  sidebarBorder:"var(--admin-border)",
  legacyPrimary:"var(--admin-background)",
};

export const STATUS_CFG = {
  pending:    {bg:"var(--admin-warning-soft)",text:"var(--admin-warning)",label:"Pending"},
  processing: {bg:"var(--admin-primary-soft)",text:"var(--admin-primary-text)",label:"Processing"},
  delivered:  {bg:"var(--admin-success-soft)",text:"var(--admin-success)",label:"Delivered"},
};

export const NAV_GROUPS = [
  {g:"Main",    items:[{icon:LayoutDashboard,label:"Dashboard",id:"dashboard"},{icon:Package,label:"Products",id:"products"},{icon:Tags,label:"Categories",id:"categories"},{icon:ShoppingCart,label:"Orders",id:"orders"}]},
  {g:"Workspace", items:[{icon:SlidersHorizontal,label:"Config",id:"config"},{icon:Bell,label:"Notifications",id:"notifications"}]},
  {g:"Stock",   items:[{icon:Boxes,label:"Inventory",id:"inventory"}]},
  {g:"People",  items:[{icon:UsersRound,label:"Customers",id:"customers"}]},
  {g:"Finance", items:[{icon:CreditCard,label:"Payments",id:"payments"},{icon:BarChart3,label:"Reports",id:"reports"}]},
];

// ── HELPERS ──────────────────────────────────────────────────────────────────
export const fmt     = v => "$"+(v>=1000?(v/1000).toFixed(v%1000===0?0:1)+"k":Number(v).toFixed(2));
export const fmtFull = v => "$"+v.toLocaleString();
export const totalStock = variants => variants.reduce((s,v)=>s+v.stock,0);
export const stockColor = s => s===0?C.danger:s<=5?C.warning:C.success;
