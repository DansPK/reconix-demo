// The admin dashboard's view of orders, backed by the API.
//
// Orders used to come from two places at once: real ones written to a localStorage
// "shared store" by the storefront checkout, and a hardcoded ORDERS_DATA array padding
// the table out to look populated. Both are gone - this is the same operation-service
// rows the storefront's own /orders pages read, viewed with no ownership filter.

import { useCallback, useMemo } from "react";
import * as ordersApi from "../api/orders";
import { refreshPaymentViews } from "../api/paymentSync";
import { useResource } from "../hooks/useResource";
import { query } from "../api/client";

/** API order -> the shape OrdersPages/OrderDetailsPage render. */
export function toAdminOrder(order) {
  return {
    id: order.orderId,
    code: order.orderCode,
    customer: order.customerName || "—",
    email: order.customerEmail,
    phone: order.customerPhone,
    amount: Number(order.totalAmount ?? 0),
    subtotal: Number(order.subtotalAmount ?? 0),
    shipping: Number(order.deliveryFee ?? 0),
    discount: Number(order.discountAmount ?? 0),
    currency: order.currency,
    status: order.fulfillmentStatus,
    paymentStatus: order.paymentStatus,
    paymentMethod: order.paymentMethod,
    createdAt: order.createdAt,
    delivery: {
      address: order.shippingAddress,
      city: order.shippingCity,
      postalCode: order.shippingPostal,
      shippingMethod: order.shippingMethod,
      tracking: order.trackingNumber,
      courierName: order.courierName,
      trackingUrl: order.trackingUrl,
    },
    estimatedDeliveryDate: order.estimatedDeliveryDate,
    deliveredAt: order.deliveredAt,
    cancellationReason: order.cancellationReason,
    note: order.note,
    items: (order.items ?? []).map((item) => ({
      id: item.id,
      name: item.productName,
      sku: item.variantSku,
      variant: [item.selectedSize, item.selectedColor].filter(Boolean).join(" · "),
      qty: item.quantity,
      price: Number(item.unitPrice ?? 0),
      productId: item.productId,
      image: item.imageUrl || null,
    })),
    statusHistory: order.statusHistory ?? [],
  };
}

/**
 * The admin Orders table. Fetched as one largeish page and filtered/sorted in the
 * browser, matching how InventoryPage and PaymentsPage already work here - the backend
 * filters on fulfillment status alone, so a text search over customer/order code has to
 * happen client-side regardless.
 */
export function useAdminOrders({ status, size = 200 } = {}) {
  const params = { status, size };
  const key = `/v1/admin/orders${query(params)}`;
  const { data, loading, error, refetch } = useResource(key, () => ordersApi.listOrders(params), { pollMs: 10000 });

  const orders = useMemo(() => (data?.content ?? []).map(toAdminOrder), [data]);

  return { orders, totalElements: data?.totalElements ?? 0, loading, error, refetch };
}

export function useAdminOrder(orderId) {
  const key = orderId ? `/v1/admin/orders/${orderId}` : null;
  const { data, loading, error, refetch } = useResource(key, () => ordersApi.getOrder(orderId), { pollMs: 10000 });
  const order = useMemo(() => (data ? toAdminOrder(data) : null), [data]);
  return { order, loading, error, refetch };
}

/** Moves fulfillment status, sets tracking/note/cancellationReason, and refreshes both
 * the list and detail caches so the change is visible without a manual reload. */
export function useUpdateOrderStatus() {
  return useCallback(async (orderId, payload) => {
    const updated = await ordersApi.updateFulfillmentStatus(orderId, payload);
    refreshPaymentViews({ includeStatus: true });
    return updated;
  }, []);
}
