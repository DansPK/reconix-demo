import { useEffect, useRef } from "react";
import { getPaymentStatus } from "../api/payments";
import { refreshPaymentViews } from "../api/paymentSync";

// Reconcile a small rotating batch of loaded pending KHQR attempts. The selected
// attempt has its own faster poll; COD can only be confirmed by staff/admin action.
export function usePaymentReconciliation(payments, selectedPaymentId) {
  const latest = useRef({ payments, selectedPaymentId });
  latest.current = { payments, selectedPaymentId };
  const runRef = useRef(null);
  const signature = payments.filter(p => p.method === "bakong_khqr" && p.status === "pending").map(p => p.id).join(",");

  useEffect(() => {
    let stopped = false, running = false;
    let controller;
    const checkedAt = new Map();
    const run = async () => {
      if (stopped || running || document.visibilityState !== "visible") return;
      const { payments, selectedPaymentId } = latest.current;
      const candidates = payments.filter(p => p.method === "bakong_khqr" && p.status === "pending" && p.id !== selectedPaymentId);
      const ids = new Set(candidates.map(p => p.id));
      for (const id of checkedAt.keys()) if (!ids.has(id)) checkedAt.delete(id);
      const batch = [...candidates].sort((a, b) => (checkedAt.get(a.id) || 0) - (checkedAt.get(b.id) || 0)
        || String(a.createdAt).localeCompare(String(b.createdAt))).slice(0, 3);
      if (!batch.length) return;
      running = true;
      controller = new AbortController();
      let changed = false;
      try {
        for (const payment of batch) {
          if (stopped) break;
          checkedAt.set(payment.id, Date.now());
          try {
            const current = await getPaymentStatus(payment.id, { signal: controller.signal });
            if (current.paymentStatus && current.paymentStatus !== "pending") changed = true;
          } catch {
            // The next sweep retries this attempt; a network error never means paid.
          }
        }
        if (changed && !stopped) refreshPaymentViews({ includeStatus: true });
      } finally { running = false; }
    };
    runRef.current = run;
    run();
    const timer = setInterval(run, 15000);
    const visible = () => { if (document.visibilityState === "visible") run(); };
    window.addEventListener("focus", visible);
    document.addEventListener("visibilitychange", visible);
    return () => {
      stopped = true;
      controller?.abort();
      clearInterval(timer);
      runRef.current = null;
      window.removeEventListener("focus", visible);
      document.removeEventListener("visibilitychange", visible);
    };
  }, []);

  useEffect(() => { runRef.current?.(); }, [signature, selectedPaymentId]);
}
