// The admin dashboard's view of customers, backed by the API.
//
// Account fields and order totals used to live in one hardcoded array. They are two
// different services now (auth-service owns the account, reporting-service mirrors it
// joined to paid-order totals) but the page still sees one row per customer - the
// join happened server-side.

import { useCallback, useMemo } from "react";
import * as adminApi from "../api/admin";
import { useResource, invalidate } from "../hooks/useResource";
import { query } from "../api/client";

/** API customer report row -> the shape CustomersPage renders. */
export function toAdminCustomer(customer) {
  return {
    id: customer.id,
    name: customer.name,
    email: customer.email,
    phone: customer.phone || "—",
    city: customer.city || "—",
    role: customer.role,
    status: customer.isActive ? "Active" : "Inactive",
    joinedAt: customer.joinedAt,
    totalOrders: customer.totalOrders,
    totalSpent: Number(customer.totalSpent ?? 0),
    lastOrder: customer.lastOrderAt,
  };
}

export function useAdminCustomers({ q, role, isActive, size = 200 } = {}) {
  const params = { q, role, isActive, size };
  const key = `/v1/admin/reports/customers${query(params)}`;
  const { data, loading, error, refetch } = useResource(key, () => adminApi.getCustomerReport(params));

  const customers = useMemo(() => (data?.content ?? []).map(toAdminCustomer), [data]);
  return { customers, totalElements: data?.totalElements ?? 0, loading, error, refetch };
}

export function useAdminCustomerSummary() {
  const { data, loading, error, refetch } = useResource("/v1/admin/reports/customers/summary", adminApi.getCustomerSummary);
  return { summary: data, loading, error, refetch };
}

function refreshCustomers() {
  invalidate("/v1/admin/reports/customers");
  invalidate("/v1/admin/users");
}

export function useCreateUser() {
  return useCallback(async (payload) => {
    const created = await adminApi.createUser(payload);
    refreshCustomers();
    return created;
  }, []);
}

export function useUpdateUser() {
  return useCallback(async (id, payload) => {
    const updated = await adminApi.updateUser(id, payload);
    refreshCustomers();
    return updated;
  }, []);
}

export function useDeactivateUser() {
  return useCallback(async (id) => {
    await adminApi.deactivateUser(id);
    refreshCustomers();
  }, []);
}
