import { useSearchParams } from "react-router-dom";

// Keep existing API/filter behavior while making the current view bookmarkable.
export function usePageFilters(defaults) {
  const [params, setParams] = useSearchParams();
  const filters = Object.fromEntries(Object.entries(defaults).map(([key, fallback]) => [key, params.get(key) ?? fallback]));
  const update = changes => setParams(current => {
    const next = new URLSearchParams(current);
    Object.entries(changes).forEach(([key, value]) => {
      if (String(value) === String(defaults[key]) || value === "") next.delete(key);
      else next.set(key, value);
    });
    return next;
  }, { replace: true });
  return [filters, update];
}
