import { createContext, useContext, useLayoutEffect, useState } from "react";

const AdminThemeContext = createContext({ theme: "light", setTheme: () => {} });
const STORAGE_KEY = "lumina-admin-theme";

export function AdminThemeProvider({ children }) {
  const [theme, setTheme] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved === "light" || saved === "dark") return saved;
    } catch { /* Private browsing can disable storage. */ }
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });
  useLayoutEffect(() => {
    // Body owns portal colors too; remove the scope when leaving the admin routes.
    document.body.dataset.adminTheme = theme;
    try { localStorage.setItem(STORAGE_KEY, theme); } catch { /* Keep the in-memory preference. */ }
    return () => { delete document.body.dataset.adminTheme; };
  }, [theme]);
  return <AdminThemeContext.Provider value={{ theme, setTheme }}>{children}</AdminThemeContext.Provider>;
}

export const useAdminTheme = () => useContext(AdminThemeContext);
