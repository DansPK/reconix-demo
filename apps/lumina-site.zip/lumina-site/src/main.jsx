import React, { lazy, Suspense } from "react";
import { ResourceLoading } from "./components/ResourceFeedback";
import { MotionConfig } from "framer-motion";
import ReactDOM from "react-dom/client";
import { HeroUIProvider } from "@heroui/react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./styles.css";
const AdminDashboard = lazy(() => import("./dashboard/StyleHubAdminShell"));
import LuminaStoreApp from "./storefront/index";
import { AuthProvider } from "./auth/AuthContext";
import { RequireAuth } from "./auth/AuthPages";

function App() {
  return (
    <Routes>
      {/*
        The dashboard is gated here rather than inside the shell, so an unauthenticated
        visitor never loads it at all. The prototype guarded it with a hardcoded
        credential pair kept in localStorage; now the backend decides, and the same
        check is enforced again on every admin request by the gateway.
      */}
      <Route
        path="/dashboard/*"
        element={
          <RequireAuth requireAdmin>
            <AdminDashboard />
          </RequireAuth>
        }
      />
      <Route path="/*" element={<LuminaStoreApp />} />
    </Routes>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <MotionConfig reducedMotion="user">
      <HeroUIProvider>
        <BrowserRouter>
          <AuthProvider>
            <Suspense fallback={<ResourceLoading />}>
              <App />
            </Suspense>
          </AuthProvider>
        </BrowserRouter>
      </HeroUIProvider>
    </MotionConfig>
  </React.StrictMode>,
);
