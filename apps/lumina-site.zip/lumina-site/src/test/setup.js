// Node >= 22.4 defines `localStorage` as a global getter that returns undefined
// unless the process was started with --localstorage-file. Vitest's jsdom
// environment copies jsdom's window globals onto globalThis, but skips any key
// that already exists on the Node global - so tests see `undefined` instead of
// jsdom's Storage. Re-install the real Storage objects from the jsdom window.
// On Node versions without that global, `window` is the jsdom-backed global and
// the first branch is a no-op.
const source =
  typeof window !== "undefined" && window.localStorage
    ? window
    : globalThis.jsdom?.window;

if (source) {
  for (const key of ["localStorage", "sessionStorage"]) {
    if (source[key]) {
      Object.defineProperty(globalThis, key, {
        configurable: true,
        writable: true,
        value: source[key],
      });
    }
  }
}
