// Stale-while-revalidate fetching, and the replacement for the localStorage event bus.
//
// The prototype kept admin and storefront in step by broadcasting a CustomEvent whenever
// it wrote to localStorage. That only ever worked inside one tab - `storage` events do
// not fire in the window that made the change, and two browser windows never saw each
// other's writes at all.
//
// Now both sides read one database, so freshness is a cache question: revalidate when a
// mutation invalidates a key, when the tab regains focus, and - on the few views where
// someone sits and watches - on a slow poll. That is a stronger guarantee than the
// CustomEvent ever gave, for less machinery than SSE would need.

import { useCallback, useEffect, useRef, useState } from "react";

/** key -> { data, fetchedAt }. Module-level so every component shares one cache. */
const cache = new Map();

/** key -> Set<callback>, so an invalidation reaches every mounted subscriber. */
const subscribers = new Map();
let cacheEpoch = 0;
const revisions = new Map();
const pending = new Map();
const bumpRevision = key => { const next = (revisions.get(key) || 0) + 1; revisions.set(key, next); return next; };

function notify(key, event) {
  subscribers.get(key)?.forEach((callback) => callback(event));
}

/**
 * Drops cached entries and asks their subscribers to refetch.
 *
 * @param prefix matched with startsWith, so invalidate("/v1/admin/orders") also clears
 *               "/v1/admin/orders?status=pending". Call it after any mutation.
 */
export function invalidate(prefix) {
  const keys = [...cache.keys()].filter((key) => key.startsWith(prefix));
  keys.forEach((key) => cache.delete(key));
  // Subscribers may be watching a key that was never cached (still in flight).
  [...subscribers.keys()]
    .filter((key) => key.startsWith(prefix))
    .forEach(key => { bumpRevision(key); notify(key); });
}

export function invalidateAll() {
  cacheEpoch += 1;
  cache.clear();
  revisions.clear();
  pending.clear();
  [...subscribers.keys()].forEach(key => notify(key));
}

export function peek(key) {
  return cache.get(key)?.data;
}

/**
 * Fetches and caches a resource.
 *
 * @param key      cache identity; null or undefined skips the fetch entirely, which is
 *                 how a component waits for a dependency (an id, a signed-in user)
 * @param fetcher  called with no arguments; must return a promise
 * @param options.pollMs           revalidate on an interval while mounted
 * @param options.refetchOnFocus   revalidate when the tab regains focus (default true)
 * @param options.keepPreviousData retain the last value when the key changes.
 *                                 Same-key refreshes always retain current data.
 */
export function useResource(key, fetcher, options = {}) {
  const {
    pollMs,
    refetchOnFocus = true,
    keepPreviousData = true,
    enabled = true,
  } = options;

  const active = enabled && !!key;
  const [state, setState] = useState(() => ({
    key,
    epoch: cacheEpoch,
    data: key ? peek(key) : undefined,
    error: null,
    loading: active && peek(key) === undefined,
  }));
  const fetcherRef = useRef(fetcher);
  fetcherRef.current = fetcher;
  const requestRef = useRef(0);
  const currentRef = useRef({ key, active });
  currentRef.current = { key, active };

  const load = useCallback(
    async ({ quiet = false } = {}) => {
      if (!active) return;
      const existing = pending.get(key);
      if (existing && existing.epoch === cacheEpoch && existing.revision === revisions.get(key)) return;
      const revision = bumpRevision(key);
      const marker = { epoch: cacheEpoch, revision };
      pending.set(key, marker);
      requestRef.current += 1;
      const epoch = cacheEpoch;
      const valid = () => epoch === cacheEpoch && revision === revisions.get(key)
        && [...(subscribers.get(key) || [])].some(callback => callback.isActive());
      setState((previous) => ({
        key,
        epoch,
        data:
          peek(key) ??
          ((previous.key === key || keepPreviousData) && previous.epoch === epoch
            ? previous.data
            : undefined),
        error: null,
        loading: !quiet || peek(key) === undefined,
      }));
      try {
        const result = await fetcherRef.current();
        if (!valid()) return;
        cache.set(key, { data: result, fetchedAt: Date.now() });
        notify(key, { data: result, error: null });
      } catch (error) {
        if (valid()) notify(key, { error });
      } finally {
        if (pending.get(key) === marker) pending.delete(key);
      }
    },
    [active, key, keepPreviousData],
  );

  useEffect(() => {
    if (!active) {
      requestRef.current += 1;
      setState({
        key,
        epoch: cacheEpoch,
        data: undefined,
        error: null,
        loading: false,
      });
      return;
    }
    const callback = (event) => {
      if (currentRef.current.key !== key || !currentRef.current.active) return;
      if (!event) { load({ quiet: true }); return; }
      requestRef.current += 1;
      setState(previous => ({
        key, epoch: cacheEpoch,
        data: event.error ? (peek(key) ?? ((previous.key === key || keepPreviousData) && previous.epoch === cacheEpoch ? previous.data : undefined)) : event.data,
        error: event.error || null, loading: false,
      }));
    };
    callback.isActive = () => currentRef.current.key === key && currentRef.current.active;
    if (!subscribers.has(key)) subscribers.set(key, new Set());
    subscribers.get(key).add(callback);
    load({ quiet: peek(key) !== undefined });
    return () => {
      requestRef.current += 1;
      subscribers.get(key)?.delete(callback);
      if (subscribers.get(key)?.size === 0) subscribers.delete(key);
    };
  }, [active, key, load]);

  useEffect(() => {
    if (!active || !refetchOnFocus) return undefined;
    const onFocus = () => {
      if (document.visibilityState === "visible") load({ quiet: true });
    };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);
    return () => {
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, [active, refetchOnFocus, load]);

  useEffect(() => {
    if (!active || !pollMs) return undefined;
    const timer = setInterval(() => {
      // Pointless work while the tab is hidden, and it keeps a phone awake.
      if (document.visibilityState === "visible") load({ quiet: true });
    }, pollMs);
    return () => clearInterval(timer);
  }, [active, pollMs, load]);

  return {
    data:
      active && state.epoch === cacheEpoch
        ? state.key === key
          ? state.data
          : (peek(key) ?? (keepPreviousData ? state.data : undefined))
        : undefined,
    error: state.key === key ? state.error : null,
    loading:
      active && (state.key === key ? state.loading : peek(key) === undefined),
    refetch: useCallback(() => { bumpRevision(key); return load({ quiet: true }); }, [key, load]),
  };
}
