import { getDeliveryFee, DELIVERY_FEE_RESOURCE_KEY } from "../api/storeSettings";
import { useResource } from "./useResource";

export function useDeliveryFee() {
  return useResource(DELIVERY_FEE_RESOURCE_KEY, getDeliveryFee);
}
