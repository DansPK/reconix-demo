// @vitest-environment jsdom
import { afterEach, describe, expect, it } from "vitest";
import { act, cleanup, renderHook, waitFor } from "@testing-library/react";
import { invalidate, invalidateAll, peek, useResource } from "../useResource";
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((a, b) => {
    resolve = a;
    reject = b;
  });
  return { promise, resolve, reject };
};
afterEach(() => {
  cleanup();
  invalidateAll();
});
describe("resource request lifecycle", () => {
  it("keeps the same order visible during payment invalidation and a failed refresh", async () => {
    const refresh = deferred();
    let calls = 0;
    const order = { orderId: 32, paymentStatus: "paid" };
    const { result } = renderHook(() =>
      useResource("/v1/orders/code/LUM-32", () =>
        ++calls === 1 ? Promise.resolve(order) : refresh.promise,
        { keepPreviousData: false },
      ),
    );
    await waitFor(() => expect(result.current.data).toEqual(order));
    act(() => invalidate("/v1/orders"));
    expect(result.current.data).toEqual(order);
    await act(async () => refresh.reject(new Error("offline")));
    expect(result.current.data).toEqual(order);
    expect(result.current.error.message).toBe("offline");
    expect(calls).toBe(2);
  });

  it("ignores an old filter response after a newer filter resolves", async () => {
    const old = deferred(),
      current = deferred();
    const { result, rerender } = renderHook(
      ({ key }) =>
        useResource(
          key,
          () => (key === "old" ? old.promise : current.promise),
          { keepPreviousData: false },
        ),
      { initialProps: { key: "old" } },
    );
    rerender({ key: "current" });
    await act(async () => current.resolve("new result"));
    await waitFor(() => expect(result.current.data).toBe("new result"));
    await act(async () => old.resolve("old result"));
    expect(result.current.data).toBe("new result");
    expect(peek("old")).toBeUndefined();
  });
  it("clears previous data when keepPreviousData is false", async () => {
    const pending = deferred();
    const { result, rerender } = renderHook(
      ({ key }) =>
        useResource(
          key,
          () => (key === "one" ? Promise.resolve("one") : pending.promise),
          { keepPreviousData: false },
        ),
      { initialProps: { key: "one" } },
    );
    await waitFor(() => expect(result.current.data).toBe("one"));
    rerender({ key: "two" });
    expect(result.current.data).toBeUndefined();
    expect(result.current.loading).toBe(true);
  });
  it("does not restore data from a request belonging to a cleared session", async () => {
    const old = deferred(),
      fresh = deferred();
    let calls = 0;
    const { result } = renderHook(() =>
      useResource("private", () =>
        ++calls === 1 ? old.promise : fresh.promise,
      ),
    );
    act(() => invalidateAll());
    await act(async () => fresh.resolve("new session"));
    await act(async () => old.resolve("previous session"));
    expect(result.current.data).toBe("new session");
    expect(peek("private")).toBe("new session");
  });
  it("clears cached private content immediately on invalidation", async () => {
    const next = deferred();
    let calls = 0;
    const { result } = renderHook(() =>
      useResource("private", () =>
        ++calls === 1 ? Promise.resolve("old user") : next.promise,
      ),
    );
    await waitFor(() => expect(result.current.data).toBe("old user"));
    act(() => invalidateAll());
    expect(result.current.data).toBeUndefined();
  });
  it("ignores overlapping requests replaced by invalidation", async () => {
    const first = deferred(),
      second = deferred();
    let calls = 0;
    const { result } = renderHook(() =>
      useResource("cart", () =>
        ++calls === 1 ? first.promise : second.promise,
      ),
    );
    act(() => invalidate("cart"));
    await act(async () => second.resolve("updated cart"));
    await act(async () => first.resolve("old cart"));
    expect(result.current.data).toBe("updated cart");
  });
  it("clears data and stops applying results when disabled", async () => {
    const request = deferred();
    const { result, rerender } = renderHook(
      ({ enabled }) =>
        useResource("private", () => request.promise, { enabled }),
      { initialProps: { enabled: true } },
    );
    rerender({ enabled: false });
    await act(async () => request.resolve("hidden"));
    expect(result.current.data).toBeUndefined();
    expect(result.current.loading).toBe(false);
  });
  it("exposes a rejected request and can retry it", async () => {
    let calls = 0;
    const { result } = renderHook(() =>
      useResource("retry", () =>
        ++calls === 1
          ? Promise.reject(new Error("offline"))
          : Promise.resolve("online"),
      ),
    );
    await waitFor(() => expect(result.current.error?.message).toBe("offline"));
    await act(async () => result.current.refetch());
    expect(result.current.data).toBe("online");
    expect(result.current.error).toBeNull();
  });
});

it("shares one request and publishes its result to all readers", async () => {
  const pending = deferred();
  let calls = 0;
  const fetcher = () => { calls++; return pending.promise; };
  const first = renderHook(() => useResource("shared-payment", fetcher));
  const second = renderHook(() => useResource("shared-payment", fetcher));
  expect(calls).toBe(1);
  await act(async () => pending.resolve({ status: "paid" }));
  expect(first.result.current.data.status).toBe("paid");
  expect(second.result.current.data.status).toBe("paid");
});

it("keeps a shared request usable after its first reader unmounts", async () => {
  const pending = deferred();
  const first = renderHook(() => useResource("shared-order", () => pending.promise));
  const second = renderHook(() => useResource("shared-order", () => pending.promise));
  first.unmount();
  await act(async () => pending.resolve("paid"));
  expect(second.result.current.data).toBe("paid");
});

it("never lets an older shared response replace the result after invalidation", async () => {
  const old = deferred(), fresh = deferred();
  let calls = 0;
  const fetcher = () => ++calls === 1 ? old.promise : fresh.promise;
  const first = renderHook(() => useResource("payment-race", fetcher));
  const second = renderHook(() => useResource("payment-race", fetcher));
  act(() => invalidate("payment-race"));
  await act(async () => fresh.resolve("paid"));
  await act(async () => old.resolve("pending"));
  expect(calls).toBe(2);
  expect(first.result.current.data).toBe("paid");
  expect(second.result.current.data).toBe("paid");
  expect(peek("payment-race")).toBe("paid");
});

it("does not reveal the previous session to a shared reader when refresh fails", async () => {
  let calls = 0;
  const fetcher = () => ++calls === 1 ? Promise.resolve("old private record") : Promise.reject(new Error("signed out"));
  const first = renderHook(() => useResource("shared-private", fetcher));
  const second = renderHook(() => useResource("shared-private", fetcher));
  await waitFor(() => expect(second.result.current.data).toBe("old private record"));
  act(() => invalidateAll());
  await waitFor(() => expect(first.result.current.error?.message).toBe("signed out"));
  expect(first.result.current.data).toBeUndefined();
  expect(second.result.current.data).toBeUndefined();
});
