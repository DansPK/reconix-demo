// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import CheckoutKhqrDialog from "../storefront/pages/CheckoutKhqrDialog";

afterEach(cleanup);

function renderDialog(overrides = {}) {
  const props = {
    payment: { amount: 12.4, khqrString: "000201010212" },
    orderCode: "LUM-20261007-00019",
    total: 12.4,
    formattedTime: "14:59",
    secondsLeft: 899,
    isExpired: false,
    isCancelled: false,
    paymentStatusError: false,
    error: "",
    busy: false,
    onOpenChange: vi.fn(),
    onRegenerate: vi.fn(),
    onContinue: vi.fn(),
    ...overrides,
  };
  render(<CheckoutKhqrDialog {...props} />);
  return props;
}

it("shows the styled KHQR payment, accurate amount, timer, and continue action", () => {
  const props = renderDialog();

  expect(screen.getByRole("dialog", { name: /Pay with KHQR/ })).toBeTruthy();
  expect(screen.getByText("Lumina · Order LUM-20261007-00019")).toBeTruthy();
  expect(screen.getByText("$12.40")).toBeTruthy();
  expect(screen.getByRole("img", { name: "Bakong KHQR payment code" })).toBeTruthy();
  expect(screen.getByRole("progressbar", { name: "QR code time remaining" }).getAttribute("aria-valuenow")).toBe("100");

  fireEvent.click(screen.getByRole("button", { name: "Continue later in My Orders" }));
  expect(props.onContinue).toHaveBeenCalledOnce();
});

it("offers renewal and order actions when the QR expires", () => {
  const props = renderDialog({ isExpired: true, secondsLeft: 0, formattedTime: "00:00" });

  expect(screen.getByRole("heading", { name: "This QR code has expired" })).toBeTruthy();
  expect(screen.queryByRole("img", { name: "Bakong KHQR payment code" })).toBeNull();
  fireEvent.click(screen.getByRole("button", { name: "Generate new QR" }));
  expect(screen.queryByRole("button", { name: "Cancel this order" })).toBeNull();
  fireEvent.click(screen.getByRole("button", { name: "Continue later in My Orders" }));
  expect(props.onRegenerate).toHaveBeenCalledOnce();
  expect(props.onContinue).toHaveBeenCalledOnce();
});
