// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { buildTablePdf } from "../lib/pdfDocument";
import ExportControls from "../dashboard/components/ExportControls";

afterEach(cleanup);

it("generates a complete paginated PDF with repeated branding and the final data row", () => {
  const doc = buildTablePdf({ title: "Inventory report", scope: "Filtered inventory / USD", generatedAt: new Date("2026-10-06T09:00:00Z"), sections: [{ title: "Stock levels", columns: ["SKU", "Stock"], rows: Array.from({ length: 80 }, (_, i) => [`SKU-${i + 1}`, i]) }] });
  const pdf = doc.output();
  expect(pdf.startsWith("%PDF")).toBe(true);
  expect(doc.getNumberOfPages()).toBeGreaterThan(1);
  expect(pdf).toContain("SKU-80");
  expect(pdf.match(/\(LUMINA\)/g)).toHaveLength(doc.getNumberOfPages());
  expect(pdf).toContain(`Page ${doc.getNumberOfPages()} of ${doc.getNumberOfPages()}`);
});

it("keeps CSV available and reports a recoverable PDF download error", async () => {
  const csv = vi.fn(), pdf = vi.fn().mockRejectedValue(new Error("Download failed"));
  render(<ExportControls onCsv={csv} onPdf={pdf} />);
  fireEvent.click(screen.getByRole("button", { name: "Export CSV" }));
  expect(csv).toHaveBeenCalledOnce();
  fireEvent.click(screen.getByRole("button", { name: "Export PDF" }));
  await waitFor(() => expect(screen.getByRole("alert").textContent).toContain("PDF export failed"));
  expect(screen.getByRole("button", { name: "Export PDF" }).disabled).toBe(false);
});
