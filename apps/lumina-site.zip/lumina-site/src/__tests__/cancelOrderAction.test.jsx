// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import CancelOrderAction from "../storefront/components/CancelOrderAction";

const state = vi.hoisted(() => ({ payment: null, live: null, cancel: vi.fn(), latest: vi.fn(), invalidate: vi.fn() }));
vi.mock("../hooks/useResource", () => ({ useResource: () => ({ data: state.payment }), invalidate: state.invalidate }));
vi.mock("../storefront/pages/usePaymentPolling", () => ({ usePaymentPolling: () => ({ data: state.live }) }));
vi.mock("../api/orders", () => ({ cancelOrder: state.cancel }));
vi.mock("../api/payments", () => ({ getPaymentForOrder: state.latest }));
const order = { orderId: 7, paymentStatus: "pending", fulfillmentStatus: "pending" };

beforeEach(() => {
  state.payment = { id: 1, paymentMethod: "bakong_khqr", paymentStatus: "pending" };
  state.live = null;
  state.cancel.mockReset().mockResolvedValue({});
  state.latest.mockReset().mockResolvedValue(state.payment);
  state.invalidate.mockReset();
});
afterEach(cleanup);

it("confirms cancellation and refreshes the affected resources", async () => {
  render(<CancelOrderAction order={order} />);
  fireEvent.click(screen.getByRole("button", { name: "Cancel order", exact: true }));
  expect(state.cancel).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole("button", { name: "Yes, cancel order" }));
  await waitFor(() => expect(state.cancel).toHaveBeenCalledWith(7, "Customer cancelled an unpaid order"));
  await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  expect(state.invalidate).toHaveBeenCalledWith("/v1/orders");
  expect(state.invalidate).toHaveBeenCalledWith("/v1/payments");
});

it("hides cancellation for paid, cancelled, and shipped orders", () => {
  const { rerender } = render(<CancelOrderAction order={{ ...order, paymentStatus: "paid" }} />);
  expect(screen.queryByRole("button")).toBeNull();
  for (const fulfillmentStatus of ["cancelled", "shipped", "delivered"]) {
    rerender(<CancelOrderAction order={{ ...order, fulfillmentStatus }} />);
    expect(screen.queryByRole("button")).toBeNull();
  }
  state.live = { paymentStatus: "paid" };
  rerender(<CancelOrderAction order={order} />);
  expect(screen.queryByRole("button")).toBeNull();
});

it("does not cancel when payment completed after the dialog opened", async () => {
  state.latest.mockResolvedValue({ paymentStatus: "paid" });
  render(<CancelOrderAction order={order} />);
  fireEvent.click(screen.getByRole("button", { name: "Cancel order", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "Yes, cancel order" }));
  expect((await screen.findByRole("alert")).textContent).toContain("payment has completed");
  expect(state.cancel).not.toHaveBeenCalled();
});

it("keeps the order available and shows the server error after failure", async () => {
  state.cancel.mockRejectedValue({ detail: "Order has already shipped." });
  render(<CancelOrderAction order={order} />);
  fireEvent.click(screen.getByRole("button", { name: "Cancel order", exact: true }));
  fireEvent.click(screen.getByRole("button", { name: "Yes, cancel order" }));
  expect((await screen.findByRole("alert")).textContent).toBe("Order has already shipped.");
  expect(state.invalidate).not.toHaveBeenCalled();
});
