// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import OrderProductImage from "../components/OrderProductImage";
import { invalidateAll } from "../hooks/useResource";

const state = vi.hoisted(() => ({ get: vi.fn() }));
vi.mock("../api/catalog", () => ({ getProduct: id => state.get(id) }));
beforeEach(() => { invalidateAll(); state.get.mockReset(); });
afterEach(cleanup);

it("loads the ordered product by ID and uses its primary photo", async () => {
  state.get.mockResolvedValue({ images: [{ imageUrl: "/secondary.jpg", primary: false }, { imageUrl: "/correct-product.jpg", primary: true }] });
  render(<OrderProductImage productId={9} name="Cotton shirt" />);
  expect((await screen.findByAltText("Cotton shirt")).getAttribute("src")).toBe("/correct-product.jpg");
  expect(state.get).toHaveBeenCalledWith(9);
});

it("shows a neutral placeholder if the product photo cannot load", async () => {
  state.get.mockResolvedValue({ images: [] });
  render(<OrderProductImage productId={9} name="Cotton shirt" imageUrl="/broken.jpg" />);
  fireEvent.error(screen.getByAltText("Cotton shirt"));
  expect(await screen.findByRole("img", { name: "Cotton shirt: image unavailable" })).toBeTruthy();
  expect(screen.queryByAltText("Cotton shirt")).toBeNull();
  expect(state.get).toHaveBeenCalledWith(9);
});
