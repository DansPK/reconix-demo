// @vitest-environment jsdom
import { act, cleanup, renderHook } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { usePaymentReconciliation } from "../dashboard/usePaymentReconciliation";
const state=vi.hoisted(()=>({get:vi.fn(),refresh:vi.fn()}));
vi.mock("../api/payments",()=>({getPaymentStatus:(...args)=>state.get(...args)}));
vi.mock("../api/paymentSync",()=>({refreshPaymentViews:state.refresh}));
const payments=Array.from({length:7},(_,i)=>({id:i+1,method:"bakong_khqr",status:"pending",createdAt:"2026-10-11"}));
beforeEach(()=>{vi.useFakeTimers();state.get.mockReset().mockResolvedValue({paymentStatus:"pending"});state.refresh.mockReset();});
afterEach(()=>{cleanup();vi.useRealTimers();});
it("rotates bounded batches, excludes selected verification and never auto-confirms COD",async()=>{
  renderHook(()=>usePaymentReconciliation([...payments,{id:8,method:"cash_on_delivery",status:"pending"}],7));
  await act(async()=>{});
  expect(state.get.mock.calls.map(([id])=>id)).toEqual([1,2,3]);
  await act(async()=>vi.advanceTimersByTime(15000));
  expect(state.get.mock.calls.map(([id])=>id)).toEqual([1,2,3,4,5,6]);
  expect(state.refresh).not.toHaveBeenCalled();
});
it("refreshes dependent screens only after a server-confirmed status change",async()=>{
  state.get.mockResolvedValue({paymentStatus:"paid"});
  renderHook(()=>usePaymentReconciliation(payments,7));
  await act(async()=>{});
  expect(state.refresh).toHaveBeenCalledTimes(1);
  expect(state.refresh).toHaveBeenCalledWith({includeStatus:true});
});
it("does not treat network errors as payment success and stops after unmount",async()=>{
  state.get.mockRejectedValue(new Error("Offline"));
  const view=renderHook(()=>usePaymentReconciliation(payments,7));
  await act(async()=>{});
  expect(state.refresh).not.toHaveBeenCalled();
  view.unmount();
  await act(async()=>vi.advanceTimersByTime(30000));
  expect(state.get).toHaveBeenCalledTimes(3);
});
