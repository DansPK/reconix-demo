// @vitest-environment jsdom
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { MemoryRouter, Routes, Route } from "react-router-dom";
import { HeroUIProvider } from "@heroui/react";
import Dashboard from "../dashboard/StyleHubAdminShell";
import { invalidateAll } from "../hooks/useResource";
const state = vi.hoisted(() => ({
  role: "ADMIN",
  user: {
    id: 1,
    name: "Test Operator",
    email: "operator@example.invalid",
    role: "ADMIN",
  },
  get: vi.fn(),
  logout: vi.fn(),
  put: vi.fn(),
}));
vi.mock("../auth/AuthContext", () => ({
  useAuth: () => ({
    user: state.user,
    role: state.role,
    isAdmin: state.role === "ADMIN",
    isStaff: state.role === "STAFF",
    canAccessAdmin: true,
    isAuthenticated: true,
    logout: state.logout,
    updateProfile: vi.fn(),
  }),
  describeAuthError: (e) => e.message,
}));
vi.mock("../api/client", async (importOriginal) => {
  const original = await importOriginal();
  return {
    ...original,
    api: {
      get: (url) => state.get(url),
      post: vi.fn(),
      put: state.put,
      del: vi.fn(),
    },
  };
});
function response(url) {
  if (url.includes("store-settings/delivery-fee"))
    return { deliveryFee: 2.5, updatedAt: "2026-10-07T10:00:00" };
  if (url.includes("categories")) return [];
  if (url.includes("/overview"))
    return {
      label: "Last seven days",
      daily: [],
      topProducts: [],
      categoryRevenue: [],
      paymentSplit: [],
    };
  if (url.includes("/summary")) return {};
  if (/\/admin\/orders\/\d+$/.test(url))
    return {
      orderId: 1,
      orderCode: "LUM-1",
      customerName: "Test Customer",
      totalAmount: 25,
      subtotalAmount: 25,
      deliveryFee: 0,
      discountAmount: 0,
      fulfillmentStatus: "pending",
      paymentStatus: "pending",
      items: [],
      statusHistory: [],
      createdAt: "2026-10-05T12:00:00",
      shippingAddress: "Street",
    };
  return { content: [], totalElements: 0, totalPages: 0 };
}
function mount(path) {
  return render(
    <HeroUIProvider>
      <MemoryRouter initialEntries={[path]}>
        <Routes>
          <Route path="/dashboard/*" element={<Dashboard />} />
          <Route path="/login" element={<h1>Sign in</h1>} />
        </Routes>
      </MemoryRouter>
    </HeroUIProvider>,
  );
}
beforeEach(() => {
  localStorage.removeItem("lumina-admin-theme");
  state.role = "ADMIN";
  state.get
    .mockReset()
    .mockImplementation((url) => Promise.resolve(response(url)));
  state.logout.mockReset();
  state.put.mockReset().mockResolvedValue({});
  window.scrollTo = vi.fn();
  vi.stubGlobal("matchMedia", () => ({
    matches: false,
    addListener() {},
    removeListener() {},
    addEventListener() {},
    removeEventListener() {},
  }));
  vi.stubGlobal(
    "IntersectionObserver",
    class {
      observe() {}
      unobserve() {}
      disconnect() {}
    },
  );
});
afterEach(() => {
  cleanup();
  invalidateAll();
  vi.unstubAllGlobals();
});
describe("dashboard route smoke coverage", () => {
  it.each([
    "/dashboard",
    "/dashboard/products",
    "/dashboard/categories",
    "/dashboard/orders",
    "/dashboard/inventory",
    "/dashboard/customers",
    "/dashboard/payments",
    "/dashboard/reports",
    "/dashboard/config",
    "/dashboard/settings",
    "/dashboard/orders/1",
    "/dashboard/orders/1/edit",
    "/dashboard/orders/1/cancel",
  ].flatMap(path => ["light", "dark"].map(theme => [path, theme])))("renders %s in %s mode", async (path, theme) => {
    localStorage.setItem("lumina-admin-theme", theme);
    mount(path);
    await waitFor(() => expect(state.get).toHaveBeenCalled());
    await waitFor(() =>
      expect(screen.queryByText("Loading dashboard…")).toBeNull(),
    );
    expect(
      screen.getByRole("button", { name: "Refresh current data", hidden: path.endsWith("/edit") }),
    ).toBeTruthy();
    expect(screen.getByText("Test Operator")).toBeTruthy();
  });
  it("refresh revalidates mounted resources", async () => {
    mount("/dashboard/products");
    await waitFor(() => expect(state.get).toHaveBeenCalled());
    const count = state.get.mock.calls.length;
    fireEvent.click(
      screen.getByRole("button", { name: "Refresh current data" }),
    );
    await waitFor(() =>
      expect(state.get.mock.calls.length).toBeGreaterThan(count),
    );
  });
  it("opens accessible mobile navigation", async () => {
    mount("/dashboard/products");
    fireEvent.click(
      screen.getByRole("button", { name: "Open admin navigation" }),
    );
    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(
      screen.getByRole("heading", { name: "Lumina workspace" }),
    ).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Close", exact: true }));
    await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  });
  it("shows the signed-in staff identity rather than a fabricated admin role", () => {
    state.role = "STAFF";
    mount("/dashboard/settings");
    expect(screen.getByText("Test Operator")).toBeTruthy();
    expect(screen.queryByText("Super Admin")).toBeNull();
  });
});

describe("admin appearance", () => {
  beforeEach(() => localStorage.removeItem("lumina-admin-theme"));
  it("persists dark mode, preserves a form, and themes portal dialogs", async () => {
    const view = mount("/dashboard/settings");
    const name = screen.getByLabelText("Name");
    fireEvent.change(name, { target: { value: "Unsaved operator" } });
    fireEvent.click(screen.getByRole("button", { name: "Switch to dark theme" }));
    expect(document.body.dataset.adminTheme).toBe("dark");
    expect(localStorage.getItem("lumina-admin-theme")).toBe("dark");
    expect(screen.getByLabelText("Name").value).toBe("Unsaved operator");
    fireEvent.click(screen.getByRole("button", { name: "Open admin navigation" }));
    expect(screen.getByRole("dialog").closest("body").dataset.adminTheme).toBe("dark");
    view.unmount();
    expect(document.body.dataset.adminTheme).toBeUndefined();
    mount("/dashboard/settings");
    expect(document.body.dataset.adminTheme).toBe("dark");
    fireEvent.click(screen.getByRole("button", { name: "Switch to light theme" }));
    expect(document.body.dataset.adminTheme).toBe("light");
  });
  it("uses system preference on first visit", () => {
    vi.stubGlobal("matchMedia", () => ({ matches: true, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }));
    mount("/dashboard/settings");
    expect(document.body.dataset.adminTheme).toBe("dark");
  });
});

describe("management regressions", () => {
  it("measures order date filters from today rather than the latest order", async () => {
    state.get.mockImplementation(url => Promise.resolve(url.includes("/admin/orders?") ? { content: [{ orderId: 9, orderCode: "LUM-OLD", customerName: "Old buyer", fulfillmentStatus: "pending", paymentStatus: "pending", totalAmount: 10, createdAt: new Date(Date.now() - 40 * 86400000).toISOString(), items: [] }], totalElements: 1 } : response(url)));
    mount("/dashboard/orders");
    await screen.findByText("LUM-OLD");
    fireEvent.keyDown(screen.getByRole("button", { name: "Order date range" }), { key: "ArrowDown" });
    fireEvent.click(await screen.findByRole("menuitemradio", { name: "Last 7 days" }));
    expect(screen.queryByText("LUM-OLD")).toBeNull();
  });
  it("resets product pagination after search and performs supported bulk updates", async () => {
    const products = Array.from({ length: 12 }, (_, index) => ({ id: index + 1, name: `Fixture product ${index + 1}`, sku: `SKU-${index + 1}`, basePrice: 10.25, active: true, stock: 8, variants: [], images: [] }));
    state.get.mockImplementation(url => Promise.resolve(url.startsWith("/v1/products?") ? { content: products, totalElements: products.length } : response(url)));
    mount("/dashboard/products");
    await screen.findByText("Fixture product 12");
    fireEvent.click(screen.getByRole("button", { name: "2", exact: true }));
    expect(screen.queryByText("Fixture product 12")).toBeNull();
    fireEvent.change(screen.getByRole("textbox", { name: "Search products" }), { target: { value: "Fixture product 12" } });
    await screen.findByText("Fixture product 12");
    fireEvent.click(screen.getByRole("checkbox", { name: "Select Fixture product 12" }));
    fireEvent.click(screen.getByRole("button", { name: "Archive", exact: true }));
    await waitFor(() => expect(state.put).toHaveBeenCalledWith("/v1/products/12", { active: false }));
  });
});

it("keeps customer management unavailable to staff even through a direct URL", async () => {
  state.role = "STAFF";
  mount("/dashboard/customers");
  await waitFor(() => expect(state.get).toHaveBeenCalled());
  expect(screen.queryByRole("button", { name: "Customers", exact: true })).toBeNull();
  expect(state.get.mock.calls.some(([url]) => url.includes("/customers"))).toBe(false);
});

it("lets staff confirm pending COD from order details", async () => {
  state.role = "STAFF";
  state.get.mockImplementation(url => Promise.resolve(url.includes("/payments/orders/")
    ? { id: 1, orderId: 1, paymentMethod: "cash_on_delivery", paymentStatus: "pending" }
    : response(url)));
  mount("/dashboard/orders/1");
  expect(await screen.findByRole("button", { name: "Confirm cash collected" })).toBeTruthy();
});
