// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import NotificationPreferences from "../components/NotificationPreferences";
import NotificationsPage from "../dashboard/pages/NotificationsPage";
import { invalidateAll } from "../hooks/useResource";
import * as api from "../api/notifications";
let team = false;
vi.mock("../auth/AuthContext", () => ({ useAuth: () => ({ canAccessAdmin: team }) }));
vi.mock("../api/notifications", () => ({ preferences: vi.fn(), updatePreferences: vi.fn(), deliveries: vi.fn(), retryDelivery: vi.fn() }));
const prefs = { sendingEnabled: false, orderAlerts: true, stockAlerts: true, dailySummary: true };
beforeEach(() => { team = false; vi.clearAllMocks(); api.preferences.mockResolvedValue(prefs); });
afterEach(() => { cleanup(); invalidateAll(); });
it("lets customers choose whether order emails are delivered", async () => {
  render(<NotificationPreferences />);
  expect(await screen.findByRole("checkbox", { name: "Order and payment updates" })).toBeTruthy();
  fireEvent.click(screen.getByRole("checkbox", { name: "Order and payment updates" }));
  await waitFor(() => expect(api.updatePreferences).toHaveBeenCalledWith({ orderAlerts: false, stockAlerts: true, dailySummary: true }));
});
it("lets staff change their own categories", async () => {
  team = true;
  api.updatePreferences.mockResolvedValue(prefs);
  render(<NotificationPreferences />);
  fireEvent.click(await screen.findByRole("checkbox", { name: "Low-stock and out-of-stock alerts" }));
  await waitFor(() => expect(api.updatePreferences).toHaveBeenCalledWith({ orderAlerts: true, stockAlerts: false, dailySummary: true }));
});
it("retries failed deliveries and holds uncertain ones for review", async () => {
  api.deliveries.mockResolvedValue({ content: [{ id: 1, eventType: "order_placed", channel: "email", recipient: "customer@example.invalid", audience: "customer", status: "failed", attempts: 5 }], totalElements: 1, last: true });
  render(<NotificationsPage />);
  fireEvent.click((await screen.findAllByRole("button", { name: "Retry" }))[0]);
  await waitFor(() => expect(api.retryDelivery).toHaveBeenCalledWith(1));
  expect(screen.getAllByRole("button", { name: "Retry" })).toHaveLength(2);
});
