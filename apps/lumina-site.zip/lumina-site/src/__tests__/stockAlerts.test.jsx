// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { LowStockAlerts } from "../dashboard/pages/InventoryPage/LowStockAlerts";

afterEach(cleanup);
const out = Array.from({ length: 8 }, (_, index) => ({ id: index + 1, name: `Sold out ${index + 1}`, size: "M", color: "Grey", stock: 0, reorderPoint: 5, location: "Warehouse A" }));
const low = [{ ...out[0], id: 20, name: "Low stock shirt", stock: 3 }];

it("caps the preview, reports full counts, and connects review and view-all actions", () => {
  const onReview = vi.fn(), onViewAll = vi.fn();
  render(<LowStockAlerts outStockItems={out} lowStockItems={low} onReview={onReview} onViewAll={onViewAll} />);
  expect(screen.getByText("9 affected")).toBeTruthy();
  expect(screen.getByText("Showing 3 of 8")).toBeTruthy();
  expect(screen.queryByText("Sold out 4")).toBeNull();
  fireEvent.click(screen.getByRole("button", { name: "Review Sold out 1, M/Grey" }));
  expect(onReview).toHaveBeenCalledWith(out[0]);
  fireEvent.click(screen.getByRole("button", { name: "View all" }));
  expect(onViewAll).toHaveBeenLastCalledWith("out");
  fireEvent.mouseDown(screen.getByRole("tab", { name: "Low stock 1" }), { button: 0, ctrlKey: false });
  expect(screen.getByText("Low stock shirt")).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: "View all" }));
  expect(onViewAll).toHaveBeenLastCalledWith("low");
});

it("shows a quiet healthy state without tabs or actions when there are no alerts", () => {
  render(<LowStockAlerts outStockItems={[]} lowStockItems={[]} onReview={vi.fn()} onViewAll={vi.fn()} />);
  expect(screen.getByText("All variants are above their reorder point.")).toBeTruthy();
  expect(screen.queryByRole("tablist")).toBeNull();
  expect(screen.queryByRole("button", { name: "View all" })).toBeNull();
});
