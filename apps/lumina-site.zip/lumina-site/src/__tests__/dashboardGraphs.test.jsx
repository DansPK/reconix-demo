// @vitest-environment jsdom
import { afterEach, expect, it } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import SalesTrend from "../dashboard/components/SalesTrend";
import StatusDonut from "../dashboard/pages/DashboardPage/StatusDonut";
import ShareDonut from "../dashboard/components/ShareDonut";

afterEach(cleanup);

it("switches live sales values between revenue and orders and exposes each point", () => {
  render(<SalesTrend bars={[{ d: "1 Oct", v: 20, o: 2 }, { d: "2 Oct", v: 40, o: 1 }]} />);
  expect(screen.getByText("$60.00")).toBeTruthy();
  fireEvent.focus(screen.getByRole("img", { name: "1 Oct: $20.00" }));
  expect(screen.getByText("$20.00")).toBeTruthy();
  fireEvent.click(screen.getByRole("radio", { name: "Orders" }));
  expect(screen.getByRole("group", { name: "Paid orders trend graph" })).toBeTruthy();
  expect(screen.getByRole("img", { name: "1 Oct: 2" })).toBeTruthy();
  expect(screen.getByText("Period paid orders")).toBeTruthy();
});

it("shows the full record count and preserves zero-count status labels in the donut", () => {
  render(<StatusDonut unit="payments" items={[{ name: "Paid", value: 14, color: "green" }, { name: "Pending", value: 0, color: "orange" }]} />);
  expect(screen.getByRole("img", { name: "payments distribution: Paid, 14; Pending, 0" })).toBeTruthy();
  expect(screen.getByText("100.0%")).toBeTruthy();
  expect(screen.getByText("0.0%")).toBeTruthy();
});

it("handles empty graphs without drawing invalid data", () => {
  render(<><SalesTrend bars={[]} /><StatusDonut unit="variants" items={[]} /></>);
  expect(screen.getByText("No paid sales in this period.")).toBeTruthy();
  expect(screen.getByText("No variants to display.")).toBeTruthy();
  expect(screen.queryByRole("img")).toBeNull();
});

it("uses a weighted average order value across reported sales buckets", () => {
  render(<SalesTrend bars={[{ d: "1 Oct", v: 10.5, o: 2 }, { d: "2 Oct", v: 21, o: 1 }]} />);
  fireEvent.click(screen.getByRole("radio", { name: "Avg. order" }));
  expect(screen.getByText("Period average").previousElementSibling.textContent).toBe("$10.50");
  expect(screen.getByRole("img", { name: "1 Oct: $5.25" })).toBeTruthy();
});

it("preserves reported payment shares instead of turning a partial share into 100 percent", () => {
  render(<ShareDonut label="Payment mix" items={[{ name: "Bakong KHQR", pct: 41 }]} />);
  expect(screen.getByRole("img", { name: "Payment mix: Bakong KHQR, 41%" })).toBeTruthy();
  expect(screen.getByText("41%")).toBeTruthy();
  expect(screen.queryByText("100%")).toBeNull();
});
