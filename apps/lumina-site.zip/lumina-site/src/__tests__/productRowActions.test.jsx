// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import ProductRow from "../dashboard/pages/ProductsPage/ProductRow";

afterEach(cleanup);

it("separates visibility from stock and connects publishing actions", async () => {
  const product = { id: 4, name: "Cotton shirt", sku: "SHIRT", stock: 3, price: 20, cat: "Man", isActive: true, isFeatured: true, variants: [] };
  const edit = vi.fn(), more = vi.fn();
  const props = { selected: false, onSelect: vi.fn(), onEdit: edit, onMore: more };
  const view = render(<ProductRow {...props} product={product} />);
  expect(screen.getByText("Published")).toBeTruthy();
  expect(screen.getAllByText("Low stock")).toHaveLength(1);
  fireEvent.click(screen.getByRole("button", { name: "Edit Cotton shirt" }));
  expect(edit).toHaveBeenCalledWith(product);
  fireEvent.keyDown(screen.getByRole("button", { name: "Actions for Cotton shirt" }), { key: "Enter" });
  const archived = { ...product, isActive: false };
  view.rerender(<ProductRow {...props} product={archived} />);
  expect(screen.getByText("Archived")).toBeTruthy();
  fireEvent.click(await screen.findByRole("menuitem", { name: "Publish product" }));
  expect(more).toHaveBeenLastCalledWith("activate", archived);
});
