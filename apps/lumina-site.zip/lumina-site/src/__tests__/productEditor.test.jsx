// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import ProductForm from "../dashboard/pages/ProductsPage/ProductForm";

const state = vi.hoisted(() => ({ create: vi.fn(), patch: vi.fn(), updateVariant: vi.fn(), upload: vi.fn() }));
const tree = [{ id: 1, name: "Man", children: [{ id: 2, name: "Clothing", children: [{ id: 3, name: "Shirts" }] }] }];
vi.mock("../dashboard/DashboardDataContext", () => ({ useDashboardData: () => ({ categories: { Man: { clothing: ["All", "Shirts"] } }, catalog: { tree } }) }));
vi.mock("../api/catalog", () => ({ updateVariant: (...args) => state.updateVariant(...args), createVariant: vi.fn(), deleteVariant: vi.fn(), deleteProductImage: vi.fn(), uploadProductImage: (...args) => state.upload(...args) }));
const product = { id: 10, name: "Cotton shirt", sku: "SHIRT", categoryId: 3, cat: "Man", subCat: "Shirts", price: 20, costPrice: 5, isActive: true, images: [], variants: [{ id: 7, sku: "SHIRT-M", size: "M", color: "White", stock: 4 }] };
const catalog = { tree, createProduct: (...args) => state.create(...args), patchProduct: (...args) => state.patch(...args), refreshAll: vi.fn(), deleteProduct: vi.fn() };
beforeEach(() => { state.create.mockReset(); state.patch.mockReset().mockResolvedValue({ id: 10, sku: "SHIRT" }); state.updateVariant.mockReset().mockResolvedValue({}); state.upload.mockReset(); });
afterEach(() => { cleanup(); vi.unstubAllGlobals(); });

it("updates product fields without replacing existing variants and writes a stock edit to its original variant ID", async () => {
  const finish = vi.fn();
  render(<ProductForm product={product} mode="edit" catalog={catalog} onBack={finish} />);
  fireEvent.change(screen.getByLabelText("Product name"), { target: { value: "Updated shirt" } });
  fireEvent.change(screen.getByLabelText("Variant 1 stock"), { target: { value: "6" } });
  fireEvent.click(screen.getByRole("button", { name: "Save changes" }));
  await waitFor(() => expect(finish).toHaveBeenCalledOnce());
  expect(state.patch.mock.calls[0][0]).toBe(10);
  expect(state.patch.mock.calls[0][1].name).toBe("Updated shirt");
  expect(state.patch.mock.calls[0][1]).not.toHaveProperty("variants");
  expect(state.updateVariant).toHaveBeenCalledWith(10, 7, { sku: "SHIRT-M", size: "M", color: "White", stock: 6 });
});

it("validates required fields and offers a discard dialog for unsaved changes", () => {
  render(<ProductForm mode="create" catalog={catalog} onBack={vi.fn()} />);
  fireEvent.click(screen.getByRole("button", { name: "Create product" }));
  expect(screen.getByText("Enter a product name.")).toBeTruthy();
  expect(state.create).not.toHaveBeenCalled();
  fireEvent.change(screen.getByLabelText("Product name"), { target: { value: "New shirt" } });
  fireEvent.click(screen.getByRole("button", { name: "Cancel" }));
  expect(screen.getByRole("dialog", { name: "Discard product changes?" })).toBeTruthy();
});

it("calculates the sale price from the product discount percentage", async () => {
  state.create.mockResolvedValue({ id: 20, sku: "NEW", variants: [{ id: 200, sku: "NEW-DEFAULT", stock: 0 }] });
  const finish = vi.fn();
  render(<ProductForm mode="create" catalog={catalog} onBack={finish} />);
  fireEvent.change(screen.getByLabelText("Product name"), { target: { value: "New shirt" } });
  fireEvent.change(screen.getByLabelText("Regular price (USD)"), { target: { value: "20" } });
  fireEvent.change(screen.getByLabelText("Discount (%)"), { target: { value: "20" } });
  expect(screen.getAllByText("$16.00").length).toBeGreaterThan(0);
  fireEvent.click(screen.getByRole("button", { name: "Create product" }));
  await waitFor(() => expect(finish).toHaveBeenCalledOnce());
  expect(state.create.mock.calls[0][0].price).toBe("20");
  expect(state.create.mock.calls[0][0].salePrice).toBe(16);
});

it("retries an image upload against the already created product instead of creating a duplicate", async () => {
  vi.stubGlobal("URL", class extends URL {
    static createObjectURL() { return "blob:preview"; }
    static revokeObjectURL() {}
  });
  state.create.mockResolvedValue({ id: 20, sku: "NEW", variants: [{ id: 200, sku: "NEW-DEFAULT", stock: 0 }] });
  state.patch.mockResolvedValue({ id: 20, sku: "NEW" });
  state.upload.mockRejectedValueOnce(new Error("Storage unavailable.")).mockResolvedValueOnce({ id: 50, imageUrl: "/photo.jpg" });
  const finish = vi.fn();
  render(<ProductForm mode="create" catalog={catalog} onBack={finish} />);
  fireEvent.change(screen.getByLabelText("Product name"), { target: { value: "New shirt" } });
  fireEvent.change(screen.getByLabelText("Regular price (USD)"), { target: { value: "20" } });
  fireEvent.change(screen.getByLabelText("Upload product images"), { target: { files: [new File(["photo"], "photo.png", { type: "image/png" })] } });
  fireEvent.click(screen.getByRole("button", { name: "Create product" }));
  await screen.findByText("Storage unavailable.");
  fireEvent.click(screen.getByRole("button", { name: "Create product" }));
  await waitFor(() => expect(finish).toHaveBeenCalledOnce());
  expect(state.create).toHaveBeenCalledOnce();
  expect(state.patch.mock.calls[0][0]).toBe(20);
  expect(state.upload.mock.calls.map(call => call[0])).toEqual([20, 20]);
});
