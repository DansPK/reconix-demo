// OWASP Top 10 (2021) regression coverage for the browser client.
//
// A03 Injection / XSS: the app renders only through React's escaped children. A single
// dangerouslySetInnerHTML, raw innerHTML write, eval or Function constructor anywhere in
// src would be the way stored user content (a product name, an order note) turns into
// script, so this keeps the sink count at zero.
//
// A02 Cryptographic Failures / A07 Identification and Authentication Failures: the access
// token is memory-only by design; only the refresh token is persisted, and sign-out
// removes it.

import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { clearTokens, getAccessToken, getRefreshToken, setTokens } from "../auth/tokenStore";

const srcDir = join(dirname(fileURLToPath(import.meta.url)), "..");
const RAW_HTML_SINK = /dangerouslySetInnerHTML|\bnew Function\s*\(|\beval\s*\(|\.innerHTML\s*=/;

/** Every shipped source module, excluding the test suites that assert on innerHTML. */
function shippedSources() {
  return readdirSync(srcDir, { recursive: true })
    .map(String)
    .filter((entry) => /\.(jsx?|tsx?)$/.test(entry))
    .filter((entry) => !/(^|\/)(__tests__|test)\//.test(entry))
    .filter((entry) => !/\.test\./.test(entry));
}

function allPersistedValues() {
  const values = [];
  for (const storage of [localStorage, sessionStorage]) {
    for (let index = 0; index < storage.length; index += 1) {
      values.push(`${storage.key(index)}=${storage.getItem(storage.key(index))}`);
    }
  }
  return values.join("|");
}

describe("OWASP A03: injection sinks", () => {
  it("never routes content into a raw HTML, eval, or Function sink", () => {
    const offenders = shippedSources().filter((entry) =>
      RAW_HTML_SINK.test(readFileSync(join(srcDir, entry), "utf8")),
    );

    expect(offenders).toEqual([]);
  });
});

describe("OWASP A02/A07: session token storage", () => {
  beforeEach(() => {
    localStorage.clear();
    sessionStorage.clear();
    clearTokens();
  });

  afterEach(() => {
    localStorage.clear();
    sessionStorage.clear();
    clearTokens();
  });

  it("keeps the access token out of persistent storage", () => {
    setTokens({ accessToken: "access-token-value", refreshToken: "refresh-token-value" });

    expect(getAccessToken()).toBe("access-token-value");
    expect(allPersistedValues()).not.toContain("access-token-value");
  });

  it("persists only the refresh token and removes it on sign-out", () => {
    setTokens({ accessToken: "access-token-value", refreshToken: "refresh-token-value" });

    expect(getRefreshToken()).toBe("refresh-token-value");
    expect(localStorage.getItem("lumina.refreshToken")).toBe("refresh-token-value");

    clearTokens();
    expect(getAccessToken()).toBeNull();
    expect(getRefreshToken()).toBeNull();
    expect(allPersistedValues()).not.toContain("refresh-token-value");
  });
});
