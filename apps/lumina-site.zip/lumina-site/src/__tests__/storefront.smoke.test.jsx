// @vitest-environment jsdom
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  act,
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { HeroUIProvider } from "@heroui/react";
import { StoreLayout } from "../storefront/StoreLayout";
import { RequireAuth } from "../auth/AuthPages/RequireAuth";
import { invalidateAll } from "../hooks/useResource";
const state = vi.hoisted(() => ({
  user: null,
  items: [],
  add: vi.fn(),
  checkout: vi.fn(),
  cancel: vi.fn(),
  list: vi.fn(),
}));
const product = vi.hoisted(() => ({
  id: 1,
  slug: "cotton-shirt",
  name: "Cotton Shirt",
  sku: "SHIRT",
  basePrice: 25,
  effectivePrice: 25,
  categoryPath: [{ slug: "woman", name: "Women" }],
  images: [],
  variants: [{ id: 10, size: "S", color: "black", availableStock: 2 }],
  stock: 2,
}));
vi.mock("../auth/AuthContext", () => ({
  useAuth: () => ({
    user: state.user,
    role: state.user?.role,
    isAuthenticated: !!state.user,
    canAccessAdmin: ["ADMIN", "STAFF"].includes(state.user?.role),
    initialising: false,
    login: vi.fn(),
    logout: vi.fn(() => { state.user = null; }),
    updateProfile: vi.fn(),
    signup: vi.fn(),
    verifySignup: vi.fn(),
  }),
  describeAuthError: (e) => e.message,
}));
vi.mock("../storefront/providers", () => ({
  useCart: () => ({
    user: state.user,
    items: state.items,
    subtotal: 25,
    cartCount: state.items.length,
    addToBag: state.add,
    clearCart: vi.fn(),
    logout: vi.fn(() => { state.user = null; }),
    loading: false,
    removeItem: vi.fn(),
    updateQty: vi.fn(),
  }),
  useWishlist: () => ({
    wishlist: [],
    toggleWishlist: vi.fn(),
    isWishlisted: () => false,
    loading: false,
  }),
}));
vi.mock("../hooks/useDeliveryFee", () => ({
  useDeliveryFee: () => ({
    data: { deliveryFee: 2.5 },
    loading: false,
    error: null,
    refetch: vi.fn(),
  }),
}));
vi.mock("../api/catalog", () => ({
  getCategoryTree: () => Promise.resolve([]),
  listProducts: (params) => state.list(params),
  getProduct: () => Promise.resolve(product),
  getProductBySlug: () => Promise.resolve(product),
}));
vi.mock("../api/orders", () => ({
  listMyOrders: () => Promise.resolve({ content: [], totalPages: 0 }),
  getMyOrderByCode: () =>
    Promise.resolve({
      orderId: 1,
      orderCode: "LUM-1",
      items: [],
      createdAt: "2026-10-05T12:00:00",
      totalAmount: 25,
      fulfillmentStatus: "pending",
    }),
  checkout: (payload) => state.checkout(payload),
  cancelOrder: (...args) => state.cancel(...args),
}));
vi.mock("../api/payments", () => ({
  getPaymentForOrder: () =>
    Promise.resolve({
      id: 1,
      paymentStatus: "paid",
      paymentMethod: "cash_on_delivery",
    }),
  getPaymentStatus: () => Promise.resolve({ id: 1, paymentStatus: "paid" }),
  createKhqrPayment: vi.fn(),
}));
function mount(path) {
  return render(
    <HeroUIProvider>
      <MemoryRouter initialEntries={[path]}>
        <StoreLayout />
      </MemoryRouter>
    </HeroUIProvider>,
  );
}
beforeEach(() => {
  vi.stubGlobal("matchMedia", () => ({
    matches: false,
    addListener() {},
    removeListener() {},
    addEventListener() {},
    removeEventListener() {},
  }));
  vi.stubGlobal(
    "IntersectionObserver",
    class {
      observe() {}
      unobserve() {}
      disconnect() {}
    },
  );
  window.scrollTo = vi.fn();
  state.user = null;
  state.items = [];
  state.list
    .mockReset()
    .mockResolvedValue({ content: [product], totalElements: 1, totalPages: 1 });
  state.add.mockReset().mockResolvedValue();
  state.checkout.mockReset();
  state.cancel.mockReset();
});
afterEach(() => {
  cleanup();
  invalidateAll();
  vi.unstubAllGlobals();
});
describe("storefront route smoke coverage", () => {
  it.each([
    ["/", "Your style."],
    ["/category", "All products"],
    ["/wishlist", "Your favorites."],
    ["/bag", "Your Bag is empty"],
    ["/login", "Welcome back!"],
    ["/register", "Create an account"],
    ["/forgot-password", "Reset your password"],
    ["/reset-password", "Choose a new password"],
    ["/verify", "Create an account"],
    ["/payment", "Ready when you are."],
    ["/payment/success", "Your order, at a glance."],
    ["/missing-page", "A little off course."],
  ])("renders %s", async (path, title) => {
    mount(path);
    await waitFor(() =>
      expect(
        screen.getByRole("heading", {
          name: new RegExp(title.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "i"),
        }),
      ).toBeTruthy(),
    );
  });
  it("sends a homepage category to the API before applying a limit", async () => {
    mount("/?cat=women");
    await waitFor(() =>
      expect(
        state.list.mock.calls.some(
          ([params]) => params.categorySlug === "woman" && params.size === 4,
        ),
      ).toBe(true),
    );
  });
  it("collection search keeps filters in its native GET submission", async () => {
    mount("/category?cat=men&sort=price-low&type=Shirts&page=2&q=cotton");
    const input = await screen.findByRole("searchbox", { name: "Search products" });
    const form = input.closest("form");
    expect(form.getAttribute("method")).toBe("get");
    expect(form.getAttribute("action")).toBe("/category");
    const values = new FormData(form);
    expect(values.get("q")).toBe("cotton");
    expect(values.get("cat")).toBe("men");
    expect(values.get("sort")).toBe("price-low");
    expect(values.get("type")).toBe("Shirts");
    expect(values.has("page")).toBe(false);
  });
  it("storefront logout redirects to the login screen", async () => {
    state.user = { role: "CUSTOMER", email: "customer@example.test" };
    mount("/");
    fireEvent.keyDown(screen.getByRole("button", { name: "Profile menu" }), { key: "Enter" });
    fireEvent.click(await screen.findByRole("menuitem", { name: "Log out" }));
    expect(await screen.findByRole("heading", { name: "Welcome back!" })).toBeTruthy();
  });
  it("header search navigates to searchable collection results", async () => {
    mount("/");
    fireEvent.click(screen.getByRole("button", { name: "Toggle search" }));
    fireEvent.change(screen.getByRole("textbox", { name: "Search products" }), {
      target: { value: "shirt" },
    });
    fireEvent.click(
      screen.getByRole("button", { name: "Search", exact: true }),
    );
    await waitFor(() =>
      expect(
        screen.getByRole("heading", { name: "Results for “shirt”" }),
      ).toBeTruthy(),
    );
    expect(state.list.mock.calls.some(([params]) => params.q === "shirt")).toBe(
      true,
    );
  });
  it("product info accordions expose their expanded state and switch panels", async () => {
    mount("/product/cotton-shirt");
    const model = await screen.findByRole("button", { name: "Model Info" });
    const description = screen.getByRole("button", { name: "Description" });
    fireEvent.click(model);
    expect(model.getAttribute("aria-expanded")).toBe("true");
    expect(description.getAttribute("aria-expanded")).toBe("false");
    fireEvent.click(description);
    expect(model.getAttribute("aria-expanded")).toBe("false");
    expect(description.getAttribute("aria-expanded")).toBe("true");
    expect(screen.getByRole("region", { name: "Description" })).toBeTruthy();
    fireEvent.click(description);
    expect(description.getAttribute("aria-expanded")).toBe("false");
  });
  it("reports add-to-bag failure instead of success and enforces stock limits", async () => {
    state.add.mockRejectedValue({ detail: "Stock changed" });
    mount("/product/cotton-shirt");
    await screen.findByRole("heading", { name: "Cotton Shirt" });
    fireEvent.click(screen.getByRole("button", { name: "Increase quantity" }));
    expect(
      screen.getByRole("button", { name: "Increase quantity" }).disabled,
    ).toBe(true);
    fireEvent.click(screen.getByRole("button", { name: "Add to bag" }));
    await screen.findByText("Stock changed");
    expect(screen.queryByText("Added to bag")).toBeNull();
  });
  it.each([
    ["/account", "Hello, Test."],
    ["/orders", "Your orders."],
    ["/orders/LUM-1", "Order #LUM-1"],
    ["/checkout", "No items to checkout"],
  ])("renders customer route %s", async (path, title) => {
    state.user = {
      id: 2,
      name: "Test Customer",
      email: "test@example.invalid",
      role: "CUSTOMER",
      address: "Street",
      phone: "012345678",
    };
    mount(path);
    await screen.findByRole("heading", { name: title });
  });
  it("prevents duplicate checkout submissions while the first request is pending", async () => {
    state.user = {
      id: 2,
      name: "Test Customer",
      email: "test@example.invalid",
      role: "CUSTOMER",
      address: "Street",
      phone: "012345678",
    };
    state.items = [
      {
        cartItemId: 1,
        name: "Cotton Shirt",
        image: "/image.jpg",
        price: 25,
        qty: 1,
      },
    ];
    let resolve;
    state.checkout.mockImplementation(
      () =>
        new Promise((r) => {
          resolve = r;
        }),
    );
    mount("/checkout");
    await waitFor(() =>
      expect(screen.getByLabelText("Full name").value).toBe("Test Customer"),
    );
    const button = screen.getByRole("button", { name: "Place order" });
    fireEvent.click(button);
    fireEvent.click(button);
    expect(state.checkout).toHaveBeenCalledTimes(1);
    await act(async () =>
      resolve({
        order: { orderId: 1, orderCode: "LUM-1", totalAmount: 25 },
        payment: {
          paymentMethod: "cash_on_delivery",
          paymentStatus: "pending",
        },
      }),
    );
    await screen.findByRole("dialog");
    expect(
      screen.getByRole("heading", { name: "Order placed!", exact: true }),
    ).toBeTruthy();
  });

  it("checks out with delivery pricing and preserves the order note", async () => {
    state.user = {
      id: 2,
      name: "Test Customer",
      email: "test@example.invalid",
      role: "CUSTOMER",
      address: "Street",
      phone: "012345678",
    };
    state.items = [{ cartItemId: 1, name: "Cotton Shirt", image: "/image.jpg", price: 25, qty: 1 }];
    state.checkout.mockResolvedValue({
      order: { orderId: 3, orderCode: "LUM-3", totalAmount: 25 },
      payment: { paymentMethod: "cash_on_delivery", paymentStatus: "pending" },
    });

    mount("/checkout");
    await waitFor(() => expect(screen.getByLabelText("Full name").value).toBe("Test Customer"));
    expect(screen.queryByLabelText("Promo code")).toBeNull();
    const orderNote = screen.getByLabelText("Order note (optional)");
    fireEvent.change(orderNote, { target: { value: "Leave at reception" } });
    await waitFor(() => expect(screen.getByRole("button", { name: "Place order" }).textContent).toContain("$27.50"));
    fireEvent.click(screen.getByRole("button", { name: "Place order" }));
    await waitFor(() => expect(state.checkout).toHaveBeenCalledWith({
      fullName: "Test Customer",
      phone: "+85512345678",
      shippingAddress: "Street",
      note: "Leave at reception",
      paymentMethod: "bakong_khqr",
    }));
  });
});
describe("role access", () => {
  it.each(["ADMIN", "STAFF"])("allows %s into admin screens", (role) => {
    state.user = { role };
    render(
      <MemoryRouter>
        <RequireAuth requireAdmin>
          <p>Protected workspace</p>
        </RequireAuth>
      </MemoryRouter>,
    );
    expect(screen.getByText("Protected workspace")).toBeTruthy();
  });
  it("refuses customers access to admin screens", () => {
    state.user = { role: "CUSTOMER" };
    render(
      <MemoryRouter>
        <RequireAuth requireAdmin>
          <p>Protected workspace</p>
        </RequireAuth>
      </MemoryRouter>,
    );
    expect(screen.queryByText("Protected workspace")).toBeNull();
    expect(screen.getByText("Not available for your account")).toBeTruthy();
  });
});
