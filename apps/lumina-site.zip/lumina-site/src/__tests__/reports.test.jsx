// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import ReportsPage from "../dashboard/pages/ReportsPage";
import RevenueChart from "../dashboard/pages/ReportsPage/RevenueChart";
const state = vi.hoisted(() => ({ data: null, error: null, refetch: vi.fn(), period: vi.fn(), pdf: vi.fn() }));
vi.mock("../lib/exportPdf", () => ({ exportTablePdf: (...args) => state.pdf(...args) }));
vi.mock("../dashboard/adminReports", () => ({
  useReportPeriod: (period) => { state.period(period); return { data: state.data, loading: false, error: state.error, refetch: state.refetch }; },
  useAllReportPeriods: () => ({ periods: { "7d": state.data }, loading: false, error: null, refetch: state.refetch }),
}));
beforeEach(() => {
  state.error = null;
  state.refetch.mockReset();
  state.period.mockReset();
  state.pdf.mockReset().mockResolvedValue(undefined);
  state.data = { label: "Last 7 days", revenue: 27.5, orders: 3, aov: 27.5 / 3, customers: 2, revTrend: 0, ordTrend: 0, aovTrend: 0, custTrend: 0, bars: [{ d: "Oct 1", o: 3, v: 27.5 }], topProducts: [], categories: [], paymentSplit: [{ name: "Bakong KHQR", pct: 41 }] };
});
afterEach(() => { cleanup(); vi.unstubAllGlobals(); vi.restoreAllMocks(); });
it("shows meaningful empty panels and changes the selected period without unsupported sorting", () => {
  render(<ReportsPage />);
  expect(screen.getAllByText("No top products yet")[0]).toBeTruthy();
  expect(screen.getByText("No category revenue yet")).toBeTruthy();
  expect(screen.queryByRole("combobox")).toBeNull();
  expect(document.body.textContent).not.toMatch(/\p{Extended_Pictographic}/u);
  fireEvent.click(screen.getByText("30 days"));
  expect(state.period).toHaveBeenLastCalledWith("30d");
});
it("exports actual payment share and preserves cents in daily average", () => {
  let csv = "";
  vi.stubGlobal("Blob", class { constructor(parts) { csv = parts.join(""); } });
  URL.createObjectURL = vi.fn(() => "blob:test");
  URL.revokeObjectURL = vi.fn();
  vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});
  render(<ReportsPage />);
  fireEvent.click(screen.getByRole("button", { name: "Export CSV" }));
  expect(csv).toContain("KHQR Share (%)");
  expect(csv.split("\n")[1].split(",").at(-1)).toBe('"41"');
  fireEvent.click(screen.getByRole("button", { name: "CSV export" }));
  expect(csv).toContain('"Oct 1","3","27.5","9.17"');
});

it("exports comparison and daily PDFs with the same reported values as CSV", () => {
  render(<ReportsPage />);
  fireEvent.click(screen.getByRole("button", { name: "Export PDF" }));
  // New-customer count is the final additive column; KHQR share stays immediately before it.
  expect(state.pdf.mock.calls[0][0].sections[0].rows[0].at(-2)).toBe(41);
  fireEvent.click(screen.getByRole("button", { name: "PDF export" }));
  expect(state.pdf.mock.calls[1][0].filename).toBe("reports-daily.pdf");
  expect(state.pdf.mock.calls[1][0].sections[0].rows[0]).toEqual(["Oct 1", 3, "27.50", "9.17", "N/A"]);
});
it("shows a recoverable report error instead of a perpetual loading screen", () => {
  state.data = null;
  state.error = new Error("Network unavailable");
  render(<ReportsPage />);
  fireEvent.click(screen.getByRole("button", { name: "Try again" }));
  expect(state.refetch).toHaveBeenCalledOnce();
  expect(screen.queryByRole("status", { name: "Loading reports" })).toBeNull();
});
it("renders a zero-valued chart with finite dimensions and keyboard-readable values", () => {
  render(<RevenueChart bars={[{ d: "Oct 1", o: 0, v: 0 }]} hoveredBar={null} setHoveredBar={vi.fn()} />);
  expect(screen.getByRole("button", { name: "Oct 1: $0.00, 0 orders" })).toBeTruthy();
  expect(document.body.innerHTML).not.toMatch(/NaN|Infinity/);
});

it("switches chart units and computes weighted average from paid buckets", () => {
  render(<RevenueChart bars={[{ d: "Oct 1", o: 2, v: 10.5 }, { d: "Oct 2", o: 1, v: 21 }]} hoveredBar={null} setHoveredBar={vi.fn()} />);
  fireEvent.click(screen.getByRole("radio", { name: "Orders", exact: true }));
  expect(screen.getByRole("button", { name: "Oct 1: 2, 2 orders" })).toBeTruthy();
  fireEvent.click(screen.getByRole("radio", { name: "Avg. order", exact: true }));
  expect(screen.getByRole("button", { name: "Oct 1: $5.25, 2 orders" })).toBeTruthy();
  expect(screen.getByText("Period average").previousElementSibling.textContent).toBe("$10.50");
  expect(screen.getByText("Period average")).toBeTruthy();
});
