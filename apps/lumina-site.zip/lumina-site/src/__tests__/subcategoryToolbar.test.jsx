// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import SubcategoryToolbar from "../dashboard/pages/CategoriesPage/SubcategoryToolbar";

afterEach(cleanup);

it("keeps search, clear, and add actions working and shows the filtered count", () => {
  const change = vi.fn(), add = vi.fn();
  const props = { groupLabel: "Clothing", parent: "Kid", total: 8, matched: 2, onQueryChange: change, onAdd: add };
  const view = render(<SubcategoryToolbar {...props} query="shirt" />);
  expect(screen.getByText("Kid · 2 of 8 sub-categories")).toBeTruthy();
  fireEvent.change(screen.getByRole("textbox", { name: "Filter Clothing" }), { target: { value: "hoodie" } });
  expect(change).toHaveBeenLastCalledWith("hoodie");
  fireEvent.click(screen.getByRole("button", { name: "Clear filter" }));
  expect(change).toHaveBeenLastCalledWith("");
  fireEvent.click(screen.getByRole("button", { name: "Add sub-category" }));
  expect(add).toHaveBeenCalledOnce();
  view.rerender(<SubcategoryToolbar {...props} query="" />);
  expect(screen.queryByRole("button", { name: "Clear filter" })).toBeNull();
});
