// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import CategoriesPage from "../dashboard/pages/CategoriesPage";

const state = vi.hoisted(() => ({ tree: [], create: vi.fn(), rename: vi.fn(), remove: vi.fn() }));
vi.mock("../dashboard/DashboardDataContext", () => ({ useDashboardData: () => ({
  products: [], catalog: { tree: state.tree, createCategory: state.create, renameCategory: state.rename, deleteCategory: state.remove, refreshAll: vi.fn(), uploadCategoryImage: vi.fn() },
}) }));
vi.mock("../dashboard/pages/CategoriesPage/ManagementModal", () => ({ ManagementModal: ({ onSubmit }) => <button onClick={() => onSubmit({ name: "trend", parent: "Man" })}>Create under Man</button> }));
beforeEach(() => {
  state.tree = [
    { id: 1, name: "Kid", children: [{ id: 11, name: "Clothing", children: [{ id: 111, name: "Shirts", active: true }] }] },
    { id: 2, name: "Man", children: [] },
  ];
  state.create.mockReset().mockImplementation(async request => {
    const node = { id: 21, name: request.name, children: [] };
    state.tree.find(root => root.id === request.parentId).children.push(node);
    return node;
  });
});
afterEach(cleanup);

it("creates a group under the selected parent rather than the category open behind the modal", async () => {
  render(<CategoriesPage />);
  fireEvent.click(screen.getByRole("button", { name: "+ Add group to Kid" }));
  fireEvent.click(screen.getByRole("button", { name: "Create under Man" }));
  await waitFor(() => expect(state.create).toHaveBeenCalledWith({ name: "trend", parentId: 2 }));
  await waitFor(() => expect(screen.getByRole("button", { name: /^Man/ }).getAttribute("aria-expanded")).toBe("true"));
  expect(screen.getByText("Man · 0 sub-categories")).toBeTruthy();
});

it("manages only real sub-category nodes, without the storefront All shortcut", () => {
  render(<CategoriesPage />);
  expect(screen.getByText("Shirts")).toBeTruthy();
  expect(screen.queryByText("All")).toBeNull();
  expect(screen.getByText("Kid · 1 sub-category")).toBeTruthy();
});
