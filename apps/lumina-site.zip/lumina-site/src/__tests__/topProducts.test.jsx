// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import TopProducts from "../dashboard/pages/ReportsPage/TopProducts";
import { invalidateAll } from "../hooks/useResource";
const getProduct = vi.hoisted(() => vi.fn());
vi.mock("../api/catalog", () => ({ getProduct }));
afterEach(() => { cleanup(); invalidateAll(); getProduct.mockReset(); });
it("uses the report product ID to load the photo while keeping sales and rank visible", async () => {
  getProduct.mockResolvedValue({ images: [{ imageUrl: "/blazer.jpg", primary: true }] });
  render(<TopProducts products={[{ productId: 12, name: "Wool Blazer", units: 3, pct: 100 }]} />);
  expect((await screen.findByAltText("Wool Blazer")).getAttribute("src")).toBe("/blazer.jpg");
  expect(getProduct).toHaveBeenCalledWith(12);
  expect(screen.getByLabelText("Rank 1")).toBeTruthy();
  expect(screen.getByText("Wool Blazer")).toBeTruthy();
  expect(screen.getByText("units")).toBeTruthy();
});
