// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import CustomerInsights from "../dashboard/pages/CustomersPage/CustomerInsights";

afterEach(cleanup);

it("shows account health separately from spending and opens a ranked customer", () => {
  const select = vi.fn();
  render(<CustomerInsights summary={{ totalCustomers: 4, activeCustomers: 3, newCustomers90d: 2, totalRevenue: 300 }} customers={[
    { id: 1, name: "Lower spender", totalSpent: 100 },
    { id: 2, name: "Higher spender", totalSpent: 200 },
    { id: 3, name: "No orders", totalSpent: 0 },
  ]} onSelect={select} />);
  expect(screen.getByRole("img", { name: "3 active and 1 inactive accounts out of 4" })).toBeTruthy();
  expect(screen.getByText("75%")).toBeTruthy();
  const spenders = screen.getAllByRole("button", { name: /View spending for/ });
  expect(spenders[0].getAttribute("aria-label")).toBe("View spending for Higher spender");
  expect(spenders).toHaveLength(2);
  fireEvent.click(spenders[0]);
  expect(select).toHaveBeenCalledWith(2);
});

it("handles an empty account base and unpaid spending without fabricated values", () => {
  render(<CustomerInsights summary={{}} customers={[]} onSelect={vi.fn()} />);
  expect(screen.getByRole("img", { name: "0 active and 0 inactive accounts out of 0" })).toBeTruthy();
  expect(screen.getByText("0%")).toBeTruthy();
  expect(screen.getByText("No paid customer spending yet.")).toBeTruthy();
});
