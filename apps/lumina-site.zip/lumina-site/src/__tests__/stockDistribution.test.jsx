// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import StockDistribution from "../dashboard/pages/InventoryPage/StockDistribution";

afterEach(cleanup);

it("shows true catalog shares and links the summary and chart rows to the right filters", () => {
  const select = vi.fn();
  render(<StockDistribution total={176} outOfStock={45} lowStock={42} onSelect={select} />);
  expect(screen.getByText("49.4% of the loaded catalog")).toBeTruthy();
  expect(screen.getByText("25.6%")).toBeTruthy();
  expect(screen.getByText("23.9%")).toBeTruthy();
  expect(screen.getByText("50.6%")).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: "Review out of stock" }));
  expect(select).toHaveBeenLastCalledWith("out");
  fireEvent.click(screen.getByRole("button", { name: "View 42 low stock variants" }));
  expect(select).toHaveBeenLastCalledWith("low");
  fireEvent.click(screen.getByRole("button", { name: "View 89 healthy variants" }));
  expect(select).toHaveBeenLastCalledWith("healthy");
});

it("handles an empty catalog and removes the review action when all stock is healthy", () => {
  const view = render(<StockDistribution total={0} outOfStock={0} lowStock={0} onSelect={vi.fn()} />);
  expect(screen.getByText("No variants to display.")).toBeTruthy();
  view.rerender(<StockDistribution total={10} outOfStock={0} lowStock={0} onSelect={vi.fn()} />);
  expect(screen.getByText("Stock is healthy")).toBeTruthy();
  expect(screen.getByText("100.0%")).toBeTruthy();
  expect(screen.queryByRole("button", { name: /Review/ })).toBeNull();
});
