// @vitest-environment jsdom
import { useState } from "react";
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import FilterDropdown from "../dashboard/pages/InventoryPage/FilterDropdown";

afterEach(cleanup);

it("opens from the keyboard, selects a status, and retains the selected value", async () => {
  const change = vi.fn();
  function Filter() {
    const [value, setValue] = useState("all");
    return <FilterDropdown label="Stock status" value={value} onChange={next => { setValue(next); change(next); }} options={[
      { value: "all", label: "All statuses" },
      { value: "low", label: "Low stock", tone: "warning" },
    ]} />;
  }
  render(<Filter />);
  fireEvent.keyDown(screen.getByRole("button", { name: "Stock status" }), { key: "Enter" });
  fireEvent.click(await screen.findByRole("menuitemradio", { name: "Low stock" }));
  expect(change).toHaveBeenCalledWith("low");
  expect(screen.getByRole("button", { name: "Stock status" }).textContent).toBe("Low stock");
  fireEvent.keyDown(screen.getByRole("button", { name: "Stock status" }), { key: "Enter" });
  expect((await screen.findByRole("menuitemradio", { name: "Low stock" })).getAttribute("aria-checked")).toBe("true");
});
