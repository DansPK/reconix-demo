// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { InventoryTable } from "../dashboard/pages/InventoryPage/InventoryTable";

afterEach(cleanup);

const variants = Array.from({ length: 23 }, (_, index) => ({
  id: index + 1, name: `Variant ${index + 1}`, sku: `SKU-${index + 1}`,
  size: "M", color: "Grey", stock: 12, reserved: 0, reorderPoint: 5, location: "Warehouse A",
}));

it("uses distinct semantic colors for healthy, low, and out-of-stock badges", () => {
  render(<InventoryTable filtered={[
    { ...variants[0], stock: 12 },
    { ...variants[1], stock: 3 },
    { ...variants[2], stock: 0 },
  ]} selected={null} setSelectedId={vi.fn()} />);
  expect(screen.getByText("Healthy").style.background).toBe("var(--admin-success-soft)");
  expect(screen.getByText("Low stock").style.background).toBe("var(--admin-warning-soft)");
  expect(screen.getByText("Out of stock").style.background).toBe("var(--admin-danger-soft)");
});

it("paginates variants, selects the next page's first row, and stops at the last page", () => {
  const select = vi.fn();
  render(<InventoryTable filtered={variants} selected={variants[0]} setSelectedId={select} />);
  expect(screen.getByText("Showing 1–10 of 23 variants")).toBeTruthy();
  expect(screen.queryByText("Variant 11")).toBeNull();
  expect(screen.getByRole("button", { name: "Previous" }).disabled).toBe(true);
  fireEvent.click(screen.getByRole("button", { name: "Next" }));
  expect(screen.getByText("Showing 11–20 of 23 variants")).toBeTruthy();
  expect(select).toHaveBeenLastCalledWith(11);
  fireEvent.click(screen.getByRole("button", { name: "Next" }));
  expect(screen.getByText("Showing 21–23 of 23 variants")).toBeTruthy();
  expect(screen.getByRole("button", { name: "Next" }).disabled).toBe(true);
  fireEvent.click(screen.getByRole("button", { name: "Previous" }));
  expect(screen.getByText("Showing 11–20 of 23 variants")).toBeTruthy();
});

it("resets pagination when filtering changes and handles no matches", () => {
  const props = { selected: variants[0], setSelectedId: vi.fn() };
  const view = render(<InventoryTable {...props} filtered={variants} />);
  fireEvent.click(screen.getByRole("button", { name: "Next" }));
  view.rerender(<InventoryTable {...props} filtered={variants.slice(0, 3)} />);
  expect(screen.getByText("Showing 1–3 of 3 variants")).toBeTruthy();
  view.rerender(<InventoryTable {...props} filtered={variants} />);
  expect(screen.getByText("Showing 1–10 of 23 variants")).toBeTruthy();
  view.rerender(<InventoryTable {...props} filtered={[]} />);
  expect(screen.getByText("No variants match your filters.")).toBeTruthy();
  expect(screen.getByText("Showing 0–0 of 0 variants")).toBeTruthy();
  expect(screen.getByRole("button", { name: "Next" }).disabled).toBe(true);
});
