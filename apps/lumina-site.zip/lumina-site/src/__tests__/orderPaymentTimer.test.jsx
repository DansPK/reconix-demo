// @vitest-environment jsdom
import { act, cleanup, render, screen } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import OrderPaymentPanel from "../storefront/pages/OrderPaymentPanel";

const state = vi.hoisted(() => ({ payment: null }));
vi.mock("../hooks/useResource", () => ({ useResource: () => ({ data: state.payment }), invalidate: vi.fn() }));
vi.mock("../storefront/pages/usePaymentPolling", () => ({ usePaymentPolling: () => ({ data: null }) }));
const order = { orderId: 1, totalAmount: 19, fulfillmentStatus: "pending" };

beforeEach(() => {
  vi.useFakeTimers();
  vi.setSystemTime(new Date("2026-10-10T12:00:00+07:00"));
  state.payment = { id: 1, amount: 19, currency: "USD", paymentMethod: "bakong_khqr", paymentStatus: "pending", khqrString: "000201010212", qrExpiresAt: "2026-10-10T12:00:02+07:00" };
});
afterEach(() => { cleanup(); vi.useRealTimers(); });

it("counts down and replaces the QR with renewal at expiry without waiting for polling", () => {
  render(<OrderPaymentPanel order={order} />);
  expect(screen.getByLabelText("00:02 remaining")).toBeTruthy();
  act(() => vi.advanceTimersByTime(1000));
  expect(screen.getByLabelText("00:01 remaining")).toBeTruthy();
  act(() => vi.advanceTimersByTime(1000));
  expect(screen.getByText("QR code expired")).toBeTruthy();
  expect(screen.queryByRole("img", { name: "Bakong KHQR payment code" })).toBeNull();
  expect(screen.getByRole("button", { name: "Generate a new QR code" })).toBeTruthy();
});

it("uses a renewed expiry and stops the countdown when payment is confirmed", () => {
  const { rerender } = render(<OrderPaymentPanel order={order} />);
  state.payment = { ...state.payment, id: 2, qrExpiresAt: "2026-10-10T12:15:00+07:00" };
  rerender(<OrderPaymentPanel order={order} />);
  expect(screen.getByLabelText("15:00 remaining")).toBeTruthy();
  state.payment = { ...state.payment, paymentStatus: "paid" };
  rerender(<OrderPaymentPanel order={order} />);
  expect(screen.queryByText("QR expires in")).toBeNull();
  expect(vi.getTimerCount()).toBe(0);
});

it("does not show a QR timer for cash on delivery or a cancelled order", () => {
  const { rerender } = render(<OrderPaymentPanel order={{ ...order, fulfillmentStatus: "cancelled" }} />);
  expect(screen.queryByText("QR expires in")).toBeNull();
  state.payment = { ...state.payment, paymentMethod: "cash_on_delivery" };
  rerender(<OrderPaymentPanel order={order} />);
  expect(screen.queryByText("QR expires in")).toBeNull();
});
