// @vitest-environment jsdom
import { useState } from "react";
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import ProductCategoryPicker from "../dashboard/pages/ProductsPage/ProductCategoryPicker";

afterEach(cleanup);
const tree = [
  { id: 1, name: "Man", children: [
    { id: 2, name: "Shoes", children: [{ id: 3, name: "Sneakers" }] },
    { id: 6, name: "Clothing", children: [{ id: 7, name: "Shirts" }] },
  ] },
  { id: 10, name: "Woman", children: [{ id: 11, name: "Clothing", children: [{ id: 12, name: "Dresses" }] }] },
];

async function choose(label, option) {
  fireEvent.keyDown(screen.getByRole("button", { name: label, exact: true }), { key: "Enter" });
  fireEvent.click(await screen.findByRole("menuitemradio", { name: option, exact: true }));
}

it("shows an existing hierarchy and clears dependent choices when its parent changes", async () => {
  const change = vi.fn();
  function Picker() {
    const [value, setValue] = useState(3);
    return <ProductCategoryPicker value={value} tree={tree} onChange={next => { setValue(next); change(next); }} />;
  }
  render(<Picker />);
  expect(screen.getByRole("button", { name: "Collection" }).textContent).toBe("Man");
  expect(screen.getByRole("button", { name: "Group" }).textContent).toBe("Shoes");
  expect(screen.getByRole("button", { name: "Category" }).textContent).toBe("Sneakers");
  await choose("Collection", "Woman");
  expect(change).toHaveBeenLastCalledWith("");
  expect(screen.getByRole("button", { name: "Group" }).textContent).toBe("Choose group");
  expect(screen.getByRole("button", { name: "Category" }).disabled).toBe(true);
  await choose("Group", "Clothing");
  fireEvent.keyDown(screen.getByRole("button", { name: "Category" }), { key: "Enter" });
  expect(await screen.findByRole("menuitemradio", { name: "Dresses" })).toBeTruthy();
  expect(screen.queryByRole("menuitemradio", { name: "Sneakers" })).toBeNull();
  fireEvent.click(screen.getByRole("menuitemradio", { name: "Dresses" }));
  expect(change).toHaveBeenLastCalledWith(12);
});

it("clears the previous category when changing groups within a collection", async () => {
  function Picker() {
    const [value, setValue] = useState(3);
    return <ProductCategoryPicker value={value} tree={tree} onChange={setValue} />;
  }
  render(<Picker />);
  await choose("Group", "Clothing");
  expect(screen.getByRole("button", { name: "Category" }).textContent).toBe("Choose category");
  await choose("Category", "Shirts");
  expect(screen.getByRole("button", { name: "Category" }).textContent).toBe("Shirts");
});

it("disables child dropdowns until their parent is selected", () => {
  render(<ProductCategoryPicker value="" tree={tree} onChange={vi.fn()} />);
  expect(screen.getByRole("button", { name: "Collection" }).disabled).toBe(false);
  expect(screen.getByRole("button", { name: "Group" }).disabled).toBe(true);
  expect(screen.getByRole("button", { name: "Category" }).disabled).toBe(true);
});
