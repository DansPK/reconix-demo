// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import OrderSummary from "../dashboard/pages/OrdersPages/OrderSummary";
import OrderActivity from "../dashboard/pages/OrdersPages/OrderActivity";

afterEach(cleanup);

it("shows the payment method from the payment record with a single order total", () => {
  render(<OrderSummary order={{ subtotal: 26, shipping: 2.5, discount: 0, amount: 28.5, paymentStatus: "pending" }} payment={{ paymentMethod: "cash_on_delivery", paymentStatus: "paid" }} refetchPayment={vi.fn()} />);
  expect(screen.getByText("Cash on delivery")).toBeTruthy();
  expect(screen.getByText("Paid")).toBeTruthy();
  expect(screen.getAllByText("$28.50")).toHaveLength(1);
});

it("does not show an unpaid cancelled order as payment pending", () => {
  render(<OrderSummary order={{ subtotal: 9.9, shipping: 2.5, discount: 0, amount: 12.4, status: "cancelled", paymentStatus: "pending" }} payment={{ paymentMethod: "bakong_khqr", paymentStatus: "pending" }} refetchPayment={vi.fn()} />);
  expect(screen.getByText("Not charged")).toBeTruthy();
  expect(screen.getByText("Payment was not completed before this order was cancelled.")).toBeTruthy();
  expect(screen.getByText("Bakong KHQR")).toBeTruthy();
});

it("orders activity by most recent timestamp, with detailed notes available on demand", () => {
  render(<OrderActivity history={[
    { id: 1, statusKind: "fulfillment", newStatus: "processing", changedAt: "2026-10-06T09:00:00", note: "Order placed" },
    { id: 2, statusKind: "fulfillment", oldStatus: "processing", newStatus: "shipped", changedAt: "2026-10-06T10:00:00", note: "Tracking assigned" },
  ]} />);
  const events = screen.getAllByRole("listitem");
  expect(events[0].textContent).toContain("Order shipped");
  expect(events[1].textContent).toContain("Order processing");
  expect(screen.getAllByText("Event details")).toHaveLength(2);
});
