// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import CheckoutSuccess from "../storefront/pages/CheckoutSuccess";

vi.mock("framer-motion", async importOriginal => ({ ...await importOriginal(), useReducedMotion: () => true }));
afterEach(cleanup);

it("shows a single centered paid confirmation with working navigation", () => {
  const orders = vi.fn(), shop = vi.fn();
  render(<CheckoutSuccess order={{ orderCode: "LUM-1", totalAmount: 3 }} amount={3} onOrders={orders} onContinue={shop} />);
  expect(screen.getByRole("dialog", { name: "Payment successful!" })).toBeTruthy();
  expect(screen.getByText("$3.00")).toBeTruthy();
  expect(screen.getByText("Paid")).toBeTruthy();
  expect(document.querySelector("span.pointer-events-none")).toBeNull();
  fireEvent.click(screen.getByRole("button", { name: "View Order" }));
  expect(orders).toHaveBeenCalledOnce();
  fireEvent.click(screen.getByRole("button", { name: "Continue Shopping" }));
  expect(shop).toHaveBeenCalledOnce();
});

it("keeps cash-on-delivery confirmation distinct from a paid payment", () => {
  render(<CheckoutSuccess isCod order={{ orderCode: "LUM-2", totalAmount: 20 }} onOrders={vi.fn()} onContinue={vi.fn()} />);
  expect(screen.getByRole("dialog", { name: "Order placed!" })).toBeTruthy();
  expect(screen.getByText("Pending payment")).toBeTruthy();
  expect(screen.queryByText("Paid")).toBeNull();
});

it("confirms a zero-total order without claiming a bank payment was received", () => {
  render(<CheckoutSuccess noPaymentRequired order={{ orderCode: "LUM-3", totalAmount: 0 }} onOrders={vi.fn()} onContinue={vi.fn()} />);
  expect(screen.getByRole("dialog", { name: "Order placed!" })).toBeTruthy();
  expect(screen.getByText("$0.00")).toBeTruthy();
  expect(screen.getByText("No payment required")).toBeTruthy();
  expect(screen.getByText("Confirmed")).toBeTruthy();
  expect(screen.queryByText(/payment has been received/i)).toBeNull();
  expect(screen.queryByText("Bakong KHQR")).toBeNull();
});
