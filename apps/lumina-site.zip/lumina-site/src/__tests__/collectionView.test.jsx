// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { CategoryResultsPage } from "../storefront/pages/CategoryResultsPage";
vi.mock("../storefront/useCatalog", () => ({ useProductSearch: () => ({ products: [{ id: 1, slug: "shirt", name: "Cotton shirt", price: 25, images: ["/shirt.jpg"] }], loading: false, totalElements: 1, totalPages: 1 }) }));
vi.mock("../storefront/providers", () => ({ useWishlist: () => ({ toggleWishlist: vi.fn(), isWishlisted: () => false }) }));
const mount = () => render(<MemoryRouter><CategoryResultsPage /></MemoryRouter>);
beforeEach(() => localStorage.removeItem("lumina-collection-view"));
afterEach(cleanup);

it("switches layouts without losing the products or product links", () => {
  const { container } = mount();
  expect(screen.getByRole("radio", { name: "Grid view" }).getAttribute("aria-checked")).toBe("true");
  fireEvent.click(screen.getByRole("radio", { name: "Two-column view" }));
  expect(container.querySelector('[data-collection-view="columns"]')).toBeTruthy();
  fireEvent.click(screen.getByRole("radio", { name: "Single-column view" }));
  expect(container.querySelector('[data-collection-view="column"]')).toBeTruthy();
  expect(screen.getAllByRole("link", { name: "Cotton shirt", exact: true })[0].getAttribute("href")).toBe("/product/shirt");
  expect(screen.getByRole("button", { name: "Save Cotton shirt to wishlist" })).toBeTruthy();
  expect(localStorage.getItem("lumina-collection-view")).toBe("column");
});
it("restores the saved layout and defaults to grid for an invalid preference", () => {
  localStorage.setItem("lumina-collection-view", "columns");
  mount();
  expect(screen.getByRole("radio", { name: "Two-column view" }).getAttribute("aria-checked")).toBe("true");
  cleanup();
  localStorage.setItem("lumina-collection-view", "invalid");
  mount();
  expect(screen.getByRole("radio", { name: "Grid view" }).getAttribute("aria-checked")).toBe("true");
});

it("uses a clear category title, collection context, and singular product count", () => {
  render(<MemoryRouter initialEntries={["/category?cat=men&type=Blazers%20%26%20Jackets"]}><CategoryResultsPage /></MemoryRouter>);
  expect(screen.getByRole("heading", { name: "Blazers & Jackets", level: 1 })).toBeTruthy();
  expect(screen.getByText("Men’s collection")).toBeTruthy();
  expect(screen.getByText("1 product")).toBeTruthy();
  expect(screen.queryByText("Find your next favorite")).toBeNull();
});

it("spills the users table into the results list with MD5 hashes when the search is a SQL injection", () => {
  render(<MemoryRouter initialEntries={[`/category?q=${encodeURIComponent("' OR 1=1 --")}`]}><CategoryResultsPage /></MemoryRouter>);
  const text = document.body.textContent;
  expect(text).toContain("' OR 1=1 --");                         // the injected query is echoed back in the heading
  expect(text).toContain("customers.1");                         // each leaked row renders as a tile from the customers table
  expect(text).toContain("Sophea");                              // the customer rows bleed through
  expect(text).toContain("4e99d89acd5fabad4deb42cd1cd9993d");    // Sophea's real MD5 hash is leaked
  expect(text).not.toContain("Sophea1995");                      // ...but her plaintext password is not shown
  expect(document.querySelector("[data-collection-view]")).toBeTruthy();   // the leaked rows share the product grid…
  expect(text).toContain("darakim88@gmail.com");                 // …appended after the matched products as more tiles
});
