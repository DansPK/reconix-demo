// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import ConfirmCodPayment from "../dashboard/components/ConfirmCodPayment";
const state = vi.hoisted(() => ({ confirm: vi.fn(), invalidate: vi.fn() }));
vi.mock("../api/payments", () => ({ confirmCodPayment: state.confirm }));
vi.mock("../hooks/useResource", () => ({ invalidate: state.invalidate }));
beforeEach(() => { state.confirm.mockReset().mockResolvedValue({}); state.invalidate.mockReset(); });
afterEach(cleanup);
const props = { allowed: true, orderId: 7, method: "cash_on_delivery", status: "pending" };
it("confirms collection before changing payment and refreshes resources", async () => {
  render(<ConfirmCodPayment {...props} />);
  fireEvent.click(screen.getByRole("button", { name: "Confirm cash collected" }));
  expect(state.confirm).not.toHaveBeenCalled();
  fireEvent.click(screen.getByRole("button", { name: "Confirm payment", exact: true }));
  await waitFor(() => expect(state.confirm).toHaveBeenCalledWith(7));
  await waitFor(() => expect(screen.queryByRole("dialog")).toBeNull());
  expect(state.invalidate).toHaveBeenCalledWith("/v1/admin/payments");
  expect(state.invalidate).toHaveBeenCalledWith("/v1/admin/orders");
});
it("hides collection for customers, paid, KHQR, and cancelled payments", () => {
  const { rerender } = render(<ConfirmCodPayment {...props} allowed={false} />);
  expect(screen.queryByRole("button")).toBeNull();
  for (const changes of [{ status: "paid" }, { method: "bakong_khqr" }, { cancelled: true }]) {
    rerender(<ConfirmCodPayment {...props} {...changes} />);
    expect(screen.queryByRole("button")).toBeNull();
  }
});
it("shows server errors and permits retry", async () => {
  state.confirm.mockRejectedValue({ detail: "Payment is already processed." });
  render(<ConfirmCodPayment {...props} />);
  fireEvent.click(screen.getByRole("button", { name: "Confirm cash collected" }));
  fireEvent.click(screen.getByRole("button", { name: "Confirm payment", exact: true }));
  expect((await screen.findByRole("alert")).textContent).toBe("Payment is already processed.");
  expect(state.invalidate).not.toHaveBeenCalled();
});
