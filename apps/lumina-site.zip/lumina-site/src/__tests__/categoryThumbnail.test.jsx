// @vitest-environment jsdom
import { afterEach, expect, it } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import CategoryThumbnail from "../dashboard/pages/CategoriesPage/CategoryThumbnail";

afterEach(cleanup);

it("prefers the saved category image and falls back to its product, then the local default", () => {
  render(<CategoryThumbnail node={{ id: 5, imageUrl: "/category.jpg" }} products={[
    { categoryId: 2, image: "/unrelated.jpg" },
    { categoryId: 5, image: "/matching-product.jpg" },
  ]} />);
  expect(screen.getByAltText("").getAttribute("src")).toBe("/category.jpg");
  fireEvent.error(screen.getByAltText(""));
  expect(screen.getByAltText("").getAttribute("src")).toBe("/matching-product.jpg");
  fireEvent.error(screen.getByAltText(""));
  expect(screen.getByAltText("").getAttribute("src")).toBe("/images/products/woman/2.jpg");
});
