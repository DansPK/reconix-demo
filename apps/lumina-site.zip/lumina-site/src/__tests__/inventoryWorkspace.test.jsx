// @vitest-environment jsdom
import { afterEach, beforeEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen, within, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import InventoryPage from "../dashboard/pages/InventoryPage";
const state = vi.hoisted(() => ({ adjust: vi.fn(), refresh: vi.fn(), admin: true }));
vi.mock("../auth/AuthContext", () => ({ useAuth: () => ({ isAdmin: state.admin }) }));
vi.mock("../dashboard/DashboardDataContext", () => ({ useDashboardData: () => ({ catalog: { loading: false, refreshAll: state.refresh }, products: [
  { id: 1, name: "Healthy Shirt", sku: "HEALTHY", cat: "Men", subCat: "Shirts", image: "/shirt.jpg", variants: [{ id: 11, sku: "HEALTHY-M", size: "M", color: "Blue", stock: 12, reserved: 2, available: 10, reorderPoint: 5 }] },
  { id: 2, name: "Low Shirt", sku: "LOW", cat: "Men", subCat: "Shirts", image: "/shirt.jpg", variants: [{ id: 12, sku: "LOW-M", size: "M", color: "Blue", stock: 8, reserved: 3, available: 5, reorderPoint: 5 }] },
  { id: 3, name: "Reserved Shirt", sku: "RESERVED", cat: "Men", subCat: "Shirts", image: "/shirt.jpg", variants: [{ id: 13, sku: "RESERVED-M", size: "M", color: "Blue", stock: 20, reserved: 20, available: 0, reorderPoint: 5 }] },
] }) }));
vi.mock("../api/admin", () => ({ adjustStock: (...args) => state.adjust(...args), getVariantMovements: () => Promise.resolve({ content: [] }) }));
beforeEach(() => { state.admin = true; state.adjust.mockReset().mockResolvedValue({}); state.refresh.mockReset(); });
afterEach(cleanup);
const mount=()=>render(<MemoryRouter><InventoryPage /></MemoryRouter>);
it("filters by available stock and includes fully reserved variants in out of stock", () => {
  mount();
  fireEvent.click(screen.getByRole("radio", { name: /Out of stock/ }));
  expect(screen.getByRole("article", { name: "Reserved Shirt M Blue" })).toBeTruthy();
  expect(screen.queryByRole("article", { name: "Healthy Shirt M Blue" })).toBeNull();
  fireEvent.click(screen.getByRole("button", { name: "Clear filters" }));
  expect(screen.getAllByRole("article")).toHaveLength(3);
});
it("adjusts the chosen variant and protects reserved stock", async () => {
  mount();
  fireEvent.click(within(screen.getByRole("article", { name: "Low Shirt M Blue" })).getByRole("button", { name: "Adjust stock" }));
  fireEvent.click(screen.getByRole("radio", { name: "Remove stock" }));
  fireEvent.change(screen.getByLabelText("Units to remove"), { target: { value: "6" } });
  expect(screen.getByRole("button", { name: "Save adjustment" }).disabled).toBe(true);
  fireEvent.change(screen.getByLabelText("Units to remove"), { target: { value: "2" } });
  fireEvent.click(screen.getByRole("button", { name: "Save adjustment" }));
  await waitFor(() => expect(state.adjust).toHaveBeenCalledWith(12, { quantity: -2, reason: "restock", note: undefined }));
  expect(state.refresh).toHaveBeenCalled();
  expect(await screen.findByRole("status")).toBeTruthy();
});
it("keeps staff inventory read-only", () => {
  state.admin = false;
  mount();
  expect(screen.queryByRole("button", { name: "Add product" })).toBeNull();
  expect(screen.queryByRole("button", { name: "Adjust stock" })).toBeNull();
  expect(screen.getAllByRole("button", { name: /Details for/ })).toHaveLength(3);
});
