// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import KhqrReceipt from "../storefront/components/KhqrReceipt";

const pdf = vi.hoisted(() => ({
  setProperties: vi.fn(), setFillColor: vi.fn(), rect: vi.fn(),
  setTextColor: vi.fn(), setFontSize: vi.fn(), text: vi.fn(),
  splitTextToSize: vi.fn(value => [value]), addImage: vi.fn(), save: vi.fn(),
}));
vi.mock("jspdf", () => ({ jsPDF: vi.fn(function () { return pdf; }) }));

afterEach(() => { cleanup(); vi.restoreAllMocks(); vi.unstubAllGlobals(); vi.clearAllMocks(); });

function prepareDownload(fail = false) {
  const revoke = vi.fn();
  vi.stubGlobal("URL", { createObjectURL: vi.fn(() => "blob:qr-test"), revokeObjectURL: revoke });
  vi.stubGlobal("Image", class {
    set src(value) { queueMicrotask(() => fail ? this.onerror() : this.onload()); }
  });
  vi.spyOn(HTMLCanvasElement.prototype, "getContext").mockReturnValue({ drawImage: vi.fn() });
  vi.spyOn(HTMLCanvasElement.prototype, "toDataURL").mockReturnValue("data:image/png;base64,synthetic");
  render(<KhqrReceipt value="SYNTHETIC-QR-ONLY" amount={12.4} />);
  return revoke;
}

it("downloads a PDF with the payment amount and square QR image", async () => {
  const revoke = prepareDownload();
  fireEvent.click(screen.getByRole("button", { name: "Download PDF" }));
  expect(await screen.findByRole("status")).toHaveProperty("textContent", "PDF downloaded.");
  expect(pdf.text).toHaveBeenCalledWith("12.40 USD", 50, 43, { align: "center" });
  expect(pdf.addImage).toHaveBeenCalledWith("data:image/png;base64,synthetic", "PNG", 16, 50, 68, 68);
  expect(pdf.save).toHaveBeenCalledWith("lumina-khqr.pdf");
  expect(revoke).toHaveBeenCalledWith("blob:qr-test");
});

it("reports a failed PDF image conversion and keeps the download available", async () => {
  const revoke = prepareDownload(true);
  fireEvent.click(screen.getByRole("button", { name: "Download PDF" }));
  expect(await screen.findByRole("status")).toHaveProperty("textContent", "Could not download PDF.");
  expect(pdf.save).not.toHaveBeenCalled();
  expect(revoke).toHaveBeenCalledWith("blob:qr-test");
  expect(screen.getByRole("button", { name: "Download PDF" }).disabled).toBe(false);
});


it("downloads the PNG image with only the two download actions available", async () => {
  const revoke = prepareDownload();
  const click = vi.spyOn(HTMLAnchorElement.prototype, "click").mockImplementation(() => {});
  expect(screen.queryByRole("button", { name: /copy/i })).toBeNull();
  expect(screen.getAllByRole("button")).toHaveLength(2);
  fireEvent.click(screen.getByRole("button", { name: "Download PNG" }));
  expect(await screen.findByRole("status")).toHaveProperty("textContent", "PNG downloaded.");
  expect(click).toHaveBeenCalledOnce();
  expect(click.mock.instances[0].download).toBe("lumina-khqr.png");
  expect(click.mock.instances[0].href).toBe("data:image/png;base64,synthetic");
  expect(revoke).toHaveBeenCalledWith("blob:qr-test");
});
