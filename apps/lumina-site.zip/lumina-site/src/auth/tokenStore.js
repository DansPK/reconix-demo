// Where the session lives.
//
// The access token is held in memory only: it lasts 15 minutes, and keeping it out of
// localStorage means a successful XSS cannot read it there. The refresh token does go to
// localStorage, because a page reload has to be able to re-establish the session without
// asking for the password again.
//
// That trade-off is only acceptable because auth-service marks refresh tokens with a
// typ claim and both it and the gateway refuse one presented as a bearer credential.
// Before that, a stolen refresh token was a seven-day master key for every endpoint.

import { invalidateAll } from "../hooks/useResource";

const REFRESH_TOKEN_KEY = "lumina.refreshToken";

let accessToken = null;

/** Notifies the auth context when the session ends underneath it (a failed refresh). */
const listeners = new Set();

export function getAccessToken() {
  return accessToken;
}

export function getRefreshToken() {
  try {
    return localStorage.getItem(REFRESH_TOKEN_KEY);
  } catch {
    // Private windows and blocked site data both throw here. Treat as "no session".
    return null;
  }
}

export function setTokens({ accessToken: access, refreshToken }) {
  accessToken = access ?? null;
  try {
    if (refreshToken) localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
  } catch {
    // Non-fatal: the session still works until the tab is closed.
  }
  invalidateAll();
}

export function clearTokens() {
  accessToken = null;
  try {
    localStorage.removeItem(REFRESH_TOKEN_KEY);
  } catch {
    /* nothing to do */
  }
  invalidateAll();
  listeners.forEach((listener) => listener());
}

export function hasSession() {
  return !!accessToken || !!getRefreshToken();
}

/** Fires when the session is cleared, including by a refresh that failed mid-request. */
export function onSessionCleared(listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}
