// Form state for PUT /v1/profile, shared by the storefront account page and the admin
// Settings page so both send the same payload.

import { useEffect, useState } from "react";
import * as authApi from "../api/auth";
import { describeAuthError, useAuth } from "./AuthContext";

const fromUser = (user) => ({
  name: user?.name ?? "",
  phone: user?.phone ?? "",
  address: user?.address ?? "",
});

/**
 * auth-service replaces all three fields on every update, so the whole form is always
 * sent. Blank optional fields go as null: the phone @Pattern accepts null but rejects "".
 */
function toPayload(form) {
  return {
    name: form.name.trim(),
    phone: form.phone.trim() || null,
    address: form.address.trim() || null,
  };
}

function useProfileForm() {
  const { user, updateProfile } = useAuth();
  const [form, setForm] = useState(() => fromUser(user));
  const [saving, setSaving] = useState(false);
  const [sendingReset, setSendingReset] = useState(false);
  const [message, setMessage] = useState({ type: "", text: "" });

  // The profile can arrive after mount (session restore on reload) or change on save.
  useEffect(() => setForm(fromUser(user)), [user]);

  const setField = (field) => (event) => setForm((current) => ({ ...current, [field]: event.target.value }));

  const dirty = JSON.stringify(toPayload(form)) !== JSON.stringify(toPayload(fromUser(user)));

  const save = async (event) => {
    event?.preventDefault();
    setMessage({ type: "", text: "" });
    if (form.name.trim().length < 2) {
      setMessage({ type: "error", text: "Please enter your name (at least 2 characters)." });
      return;
    }
    setSaving(true);
    try {
      await updateProfile(toPayload(form));
      setMessage({ type: "success", text: "Your details have been saved." });
    } catch (error) {
      setMessage({ type: "error", text: describeAuthError(error) });
    } finally {
      setSaving(false);
    }
  };

  const requestPasswordReset = async () => {
    setMessage({ type: "", text: "" });
    setSendingReset(true);
    try {
      await authApi.forgotPassword(user.email);
      setMessage({ type: "success", text: `We have emailed a password reset link to ${user.email}.` });
    } catch (error) {
      setMessage({ type: "error", text: error?.detail || "Could not send the reset email. Please try again." });
    } finally {
      setSendingReset(false);
    }
  };

  return { user, form, setField, dirty, saving, save, sendingReset, requestPasswordReset, message };
}

export { useProfileForm };
