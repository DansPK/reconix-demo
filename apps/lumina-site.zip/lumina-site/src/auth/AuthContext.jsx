// The one source of truth about who is signed in.
//
// Replaces two separate fictions: the storefront's `login = (email) => setUser({...})`,
// which discarded the password and issued no token, and the admin shell's hardcoded
// admin@lumina.com / admin123 kept in localStorage.

import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import * as authApi from "../api/auth";
import { ApiError } from "../api/client";
import { clearTokens, getRefreshToken, onSessionCleared, setTokens } from "./tokenStore";

const AuthContext = createContext(null);

/** Roles as they arrive in the JWT claim. The database stores them lowercase. */
export const ROLE_ADMIN = "ADMIN";
export const ROLE_STAFF = "STAFF";
export const ROLE_CUSTOMER = "CUSTOMER";

function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  // Distinct from "no user": on a reload we hold a refresh token but do not yet know
  // whose it is, and rendering a signed-out page in that gap makes the session look lost.
  const [initialising, setInitialising] = useState(() => !!getRefreshToken());

  const loadProfile = useCallback(async () => {
    const profile = await authApi.getProfile();
    setUser(profile);
    return profile;
  }, []);

  // Re-establish the session on a reload. The access token lived in memory and is gone;
  // the client will exchange the stored refresh token on the first 401.
  useEffect(() => {
    if (!getRefreshToken()) {
      setInitialising(false);
      return;
    }
    let active = true;
    loadProfile()
      .catch(() => {
        // An expired or revoked refresh token is an ordinary signed-out state.
        if (active) clearTokens();
      })
      .finally(() => {
        if (active) setInitialising(false);
      });
    return () => {
      active = false;
    };
  }, [loadProfile]);

  // A refresh can fail mid-request, long after mount. Without this the UI would keep
  // showing a signed-in header while every call 401s.
  useEffect(() => onSessionCleared(() => setUser(null)), []);

  const login = useCallback(
    async ({ email, password }) => {
      const session = await authApi.login({ email, password });
      setTokens({ accessToken: session.accessToken, refreshToken: session.refreshToken });
      return loadProfile();
    },
    [loadProfile]
  );

  const loginWithGoogle = useCallback(
    async (idToken) => {
      const session = await authApi.loginWithGoogle(idToken);
      setTokens({ accessToken: session.accessToken, refreshToken: session.refreshToken });
      return loadProfile();
    },
    [loadProfile]
  );

  /**
   * Begins registration. Deliberately does NOT sign the user in: no account exists yet.
   * auth-service holds the details for 15 minutes and emails a code, and only
   * verifySignup() creates the row. The prototype skipped this entirely and called
   * login(email) straight from the register form.
   */
  const signup = useCallback((payload) => authApi.signup(payload), []);

  const verifySignup = useCallback(({ email, otp }) => authApi.verify({ email, otp }), []);

  const logout = useCallback(() => {
    clearTokens();
    setUser(null);
  }, []);

  const updateProfile = useCallback(async (payload) => {
    await authApi.updateProfile(payload);
    return loadProfile();
  }, [loadProfile]);

  const value = useMemo(() => {
    const role = user?.role ? String(user.role).toUpperCase() : null;
    return {
      user,
      role,
      initialising,
      isAuthenticated: !!user,
      isAdmin: role === ROLE_ADMIN,
      // Staff can operate orders and confirm COD; account management and refunds are admin-only.
      // The backend enforces that; this only decides what to render.
      isStaff: role === ROLE_STAFF,
      canAccessAdmin: role === ROLE_ADMIN || role === ROLE_STAFF,
      login,
      loginWithGoogle,
      signup,
      verifySignup,
      logout,
      updateProfile,
      reloadProfile: loadProfile,
    };
  }, [user, initialising, login, loginWithGoogle, signup, verifySignup, logout, updateProfile, loadProfile]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside an AuthProvider");
  return context;
}

/** Turns an ApiError into something worth showing a person. */
function describeAuthError(error) {
  if (!(error instanceof ApiError)) return "Something went wrong. Please try again.";
  if (error.isValidation) return Object.values(error.errors)[0] ?? error.detail;
  if (error.isUnauthenticated) return error.detail || "Incorrect email or password.";
  return error.detail || "Something went wrong. Please try again.";
}

export { AuthProvider, useAuth, describeAuthError };
