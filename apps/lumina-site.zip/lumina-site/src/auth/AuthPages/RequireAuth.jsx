import React from "react";
import { Link, Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../AuthContext";
import { BRAND } from "./components";

/**
 * Route guard. Sends visitors to sign in and remembers where they were heading.
 *
 * @param requireAdmin admin or staff only; a customer who reaches an admin route is
 *                     shown a refusal rather than a sign-in form, because signing in
 *                     again will not help them. Implies requireAuth.
 * @param requireAuth  must be signed in, any role (e.g. checkout, order history) -
 *                     independent of requireAdmin/blockAdmin so a route can demand a
 *                     session without caring, or while also caring, about the role.
 * @param blockAdmin   admin and staff accounts run the shop, they don't shop in it -
 *                     browsing or checking out as staff would mix operator actions
 *                     into customer data (carts, orders) with no real account behind
 *                     them. Anonymous visitors and customers are unaffected.
 */
function RequireAuth({
  children,
  requireAdmin = false,
  requireAuth = false,
  blockAdmin = false,
}) {
  const { isAuthenticated, canAccessAdmin, initialising } = useAuth();
  const location = useLocation();

  // Rendering a redirect here would sign the user out on every page reload.
  if (initialising) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-400">
        Loading…
      </div>
    );
  }

  if (!isAuthenticated) {
    if (requireAdmin || requireAuth) {
      return (
        <Navigate to="/login" replace state={{ from: location.pathname }} />
      );
    }
    return children;
  }

  if (requireAdmin && !canAccessAdmin) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 text-center px-6">
        <h1 className="text-2xl font-bold">Not available for your account</h1>
        <p className="text-gray-500">
          This area is for Lumina staff. You are signed in as a customer.
        </p>
        <Link to="/" className="font-semibold" style={{ color: BRAND }}>
          Back to the store
        </Link>
      </div>
    );
  }

  if (blockAdmin && canAccessAdmin) return <Navigate to="/dashboard" replace />;

  return children;
}

export { RequireAuth };
