import * as authApi from "../../api/auth";
import { Input } from "../../components/ui/input";
import React, { useEffect, useMemo, useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { describeAuthError, useAuth } from "../AuthContext";
import { AuthLayout, Alert, BRAND, Field, SubmitButton } from "./components";

/** Mirrors auth-service's OTP TTL, so the countdown means something. */
const OTP_TTL_SECONDS = 15 * 60;

/**
 * The step the prototype never had.
 *
 * auth-service holds a pending registration in Redis for 15 minutes and emails a 6-digit
 * code; the user row is only inserted when that code comes back. Without this screen
 * there was no way to finish signing up at all.
 */
function VerifyEmailPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { verifySignup } = useAuth();

  const token = new URLSearchParams(location.search).get("token");
  const [email, setEmail] = useState(location.state?.email ?? "");
  const [otp, setOtp] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(OTP_TTL_SECONDS);

  useEffect(() => {
    if (secondsLeft <= 0) return undefined;
    const timer = setInterval(
      () => setSecondsLeft((s) => Math.max(0, s - 1)),
      1000,
    );
    return () => clearInterval(timer);
  }, [secondsLeft]);

  const countdown = useMemo(() => {
    const minutes = Math.floor(secondsLeft / 60);
    const seconds = String(secondsLeft % 60).padStart(2, "0");
    return `${minutes}:${seconds}`;
  }, [secondsLeft]);

  // Reached directly, with no email to verify against.


  if (!email && !token) return <Navigate to="/register" replace />;

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!token && otp.trim().length !== 6)
      return setError("Enter the 6-digit code from your email.");

    setBusy(true);
    try {
      if (token) await authApi.verifyLink(token);
      else await verifySignup({ email, otp: otp.trim() });
      navigate("/login", {
        replace: true,
        state: { notice: "Your email is verified. Please sign in." },
      });
    } catch (caught) {
      setError(describeAuthError(caught));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout>
      <form onSubmit={submit} className="w-full max-w-md">
        <h1 className="text-4xl font-bold mb-2">Check your email</h1>
        <p className="text-gray-500 mb-6">
          We sent a 6-digit code to{" "}
          <span className="font-semibold">{email}</span>. Enter it below to
          finish creating your account.
        </p>

        {!token && <label className="block text-sm">Email<Input type="email" required value={email} onChange={event => setEmail(event.target.value)} /></label>}
        {!token && <Field label="Verification code">
          <Input
            value={otp}
            onChange={(e) =>
              setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))
            }
            placeholder="000000"
            aria-label="000000"
            inputMode="numeric"
            autoComplete="one-time-code"
            className="w-full border rounded-md p-3 mt-1 tracking-[0.5em] text-center text-xl"
          />
        </Field>}

        <p className="text-sm text-gray-500 mt-3">
          {secondsLeft > 0 ? (
            <>
              This code expires in{" "}
              <span className="font-semibold">{countdown}</span>.
            </>
          ) : (
            <>This code has expired. Request another email below.</>
          )}
        </p>

        <Alert error={error} info={info} />
        <SubmitButton busy={busy}>Verify email</SubmitButton>
        <button className="btn mt-3" type="button" disabled={busy || !email} onClick={async () => { setBusy(true); try { await authApi.resendVerification(email); setSecondsLeft(OTP_TTL_SECONDS); setInfo("If registration is pending, a new email has been sent."); } catch (failure) { setError(describeAuthError(failure)); } finally { setBusy(false); } }}>Resend verification email</button>

        <div className="text-sm mt-4 text-gray-500">
          Wrong address?{" "}
          <Link
            className="font-semibold"
            style={{ color: BRAND }}
            to="/register"
          >
            Start over
          </Link>
        </div>
      </form>
    </AuthLayout>
  );
}

export { VerifyEmailPage };
