// Shared shadcn form controls and the authentication layout.

import React, { useEffect, useRef, useState, useId } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { Input } from "../../components/ui/input";
import { Button } from "../../components/ui/button";
import {
  Field as FormField,
  FieldGroup,
  FieldLabel,
} from "../../components/ui/field";
import { Alert as Notice, AlertDescription } from "../../components/ui/alert";
import { Reveal } from "../../components/PageMotion";
import { Eye, EyeOff } from "lucide-react";
import { describeAuthError, useAuth } from "../AuthContext";

import BrandLogo from "../../components/BrandLogo";

export const BRAND = "#E0271F";

export function AuthLayout({ children }) {
  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="flex flex-col bg-background px-6 py-8 md:px-12">
        <Link to="/" aria-label="Lumina home" className="inline-flex w-fit">
          <BrandLogo className="w-40" />
        </Link>
        <Reveal className="flex flex-1 items-center justify-center py-12">
          {children}
        </Reveal>
        <p className="text-xs text-muted-foreground">
          Thoughtfully styled. Effortlessly you.
        </p>
      </div>
      <div className="relative hidden overflow-hidden lg:block">
        <img
          src="/images/products/woman/2.jpg"
          alt="Lumina everyday style"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <div className="absolute bottom-16 left-12 max-w-sm text-white">
          <p className="mb-4 text-xs uppercase tracking-[.25em]">
            The everyday collection
          </p>
          <h2 className="text-5xl font-semibold tracking-tight">
            A little more you.
          </h2>
        </div>
      </div>
    </div>
  );
}
export function Field({ label, children }) {
  const id = useId();
  return (
    <FieldGroup className="mb-4">
      <FormField>
        <FieldLabel htmlFor={id}>{label}</FieldLabel>
        {React.Children.map(children, (child) =>
          React.isValidElement(child)
            ? React.cloneElement(child, { id })
            : child,
        )}
      </FormField>
    </FieldGroup>
  );
}
export function PasswordInput({
  value,
  onChange,
  placeholder,
  autoComplete,
  id,
}) {
  const [visible, setVisible] = useState(false);
  return (
    <div className="relative">
      <Input
        id={id}
        aria-label={id ? undefined : "Password"}
        type={visible ? "text" : "password"}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        autoComplete={autoComplete}
        className="h-12 pr-12"
      />
      <Button
        type="button"
        variant="ghost"
        size="icon"
        onClick={() => setVisible((v) => !v)}
        aria-label={visible ? "Hide password" : "Show password"}
        className="absolute right-1 top-1.5"
      >
        {visible ? <EyeOff /> : <Eye />}
      </Button>
    </div>
  );
}
export function Alert({ error, info }) {
  if (!error && !info) return null;
  return (
    <Notice variant={error ? "destructive" : "default"} className="mt-4">
      <AlertDescription role={error ? "alert" : "status"}>
        {error || info}
      </AlertDescription>
    </Notice>
  );
}
export function SubmitButton({ busy, children }) {
  return (
    <Button
      type="submit"
      disabled={busy}
      aria-busy={busy}
      size="lg"
      className="mt-5 h-12 w-full"
    >
      {busy ? "Please wait…" : children}
    </Button>
  );
}

/**
 * Renders the Google button when a client id is configured.
 *
 * Loaded lazily from Google's script rather than bundled: the prototype's Google buttons
 * were decorative, and a missing client id should leave the rest of the form working
 * instead of breaking the page.
 */
export function GoogleButton({ label, onError }) {
  const clientId = import.meta.env.VITE_GOOGLE_CLIENT_ID;
  const container = useRef(null);
  const { loginWithGoogle } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!clientId || !container.current) return undefined;

    let cancelled = false;
    const scriptId = "google-identity-services";

    const render = () => {
      if (cancelled || !window.google?.accounts?.id || !container.current)
        return;
      window.google.accounts.id.initialize({
        client_id: clientId,
        callback: async ({ credential }) => {
          try {
            await loginWithGoogle(credential);
            navigate("/");
          } catch (error) {
            onError?.(describeAuthError(error));
          }
        },
      });
      window.google.accounts.id.renderButton(container.current, {
        theme: "outline",
        size: "large",
        width: 360,
        text: label,
      });
    };

    if (document.getElementById(scriptId)) {
      render();
    } else {
      const script = document.createElement("script");
      script.id = scriptId;
      script.src = "https://accounts.google.com/gsi/client";
      script.async = true;
      script.onload = render;
      document.head.appendChild(script);
    }

    return () => {
      cancelled = true;
    };
  }, [clientId, label, loginWithGoogle, navigate, onError]);

  if (!clientId) return null;
  return (
    <>
      <div className="text-center text-gray-500 py-4">OR</div>
      <div ref={container} className="flex justify-center" />
    </>
  );
}
