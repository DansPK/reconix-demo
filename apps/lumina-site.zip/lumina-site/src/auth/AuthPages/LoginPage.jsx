import { Input } from "../../components/ui/input";
import React, { useState } from "react";
import { Link, Navigate, useLocation, useNavigate } from "react-router-dom";
import { describeAuthError, useAuth } from "../AuthContext";
import {
  AuthLayout,
  Alert,
  BRAND,
  Field,
  GoogleButton,
  PasswordInput,
  SubmitButton,
} from "./components";

function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isAuthenticated, canAccessAdmin } = useAuth();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  // Set when a guard bounced the visitor here, so they land back where they were going.
  const requestedPath = location.state?.from ?? null;
  const notice = location.state?.notice ?? "";

  // Where a successful sign-in ends up. Staff and admins go to the dashboard unless they
  // were bounced here from somewhere specific, because that is the only part of the app
  // they came to use.
  const destination = requestedPath ?? (canAccessAdmin ? "/dashboard" : "/");

  // This guard also runs the moment login() resolves, and it used to send everyone to
  // "/" - beating the role-aware navigate() below and dropping admins on the storefront.
  // Both paths now use the same destination.
  if (isAuthenticated) return <Navigate to={destination} replace />;

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.email || !form.password)
      return setError("Please fill in both fields.");

    setBusy(true);
    try {
      const profile = await login(form);
      const role = String(profile?.role ?? "").toUpperCase();
      navigate(
        requestedPath ??
          (role === "ADMIN" || role === "STAFF" ? "/dashboard" : "/"),
        { replace: true },
      );
    } catch (caught) {
      setError(describeAuthError(caught));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout>
      <form onSubmit={submit} className="w-full max-w-md">
        <h1 className="text-4xl font-bold mb-2">Welcome back!</h1>
        <p className="text-gray-500 mb-6">
          Sign in to enjoy a seamless shopping experience.
        </p>

        <Field label="Email">
          <Input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="Enter email"
            aria-label="Enter email"
            type="email"
            autoComplete="email"
            className="w-full border rounded-md p-3 mt-1 mb-4"
          />
        </Field>
        <Field label="Password">
          <PasswordInput
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            placeholder="Enter password"
            aria-label="Enter password"
            autoComplete="current-password"
          />
        </Field>

        <div className="text-right mt-2">
          <Link
            to="/forgot-password"
            className="text-sm"
            style={{ color: BRAND }}
          >
            Forgot password?
          </Link>
        </div>

        <Alert error={error} info={notice} />
        <SubmitButton busy={busy}>Sign In</SubmitButton>
        <GoogleButton label="signin_with" onError={setError} />

        <div className="text-sm mt-4">
          Don&apos;t have an account?{" "}
          <Link
            className="font-semibold"
            style={{ color: BRAND }}
            to="/register"
          >
            Sign Up
          </Link>
        </div>
      </form>
    </AuthLayout>
  );
}

export { LoginPage };
