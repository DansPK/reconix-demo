import { Input } from "../../components/ui/input";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { describeAuthError } from "../AuthContext";
import * as authApi from "../../api/auth";
import {
  AuthLayout,
  Alert,
  Field,
  PasswordInput,
  SubmitButton,
} from "./components";

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ token: "", newPassword: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  // The emailed link carries the token; accept it from the query string when present.
  useEffect(() => {
    const token = new URLSearchParams(window.location.search).get("token");
    if (token) setForm((current) => ({ ...current, token }));
  }, []);

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.token || !form.newPassword)
      return setError("Please fill in every field.");

    setBusy(true);
    try {
      await authApi.resetPassword(form);
      navigate("/login", {
        replace: true,
        state: { notice: "Password updated. Please sign in." },
      });
    } catch (caught) {
      setError(describeAuthError(caught));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout>
      <form onSubmit={submit} className="w-full max-w-md">
        <h1 className="text-4xl font-bold mb-2">Choose a new password</h1>
        <Field label="Reset token">
          <Input
            value={form.token}
            onChange={(e) => setForm({ ...form, token: e.target.value })}
            placeholder="Paste the token from your email"
            aria-label="Paste the token from your email"
            className="w-full border rounded-md p-3 mt-1 mb-4"
          />
        </Field>
        <Field label="New password">
          <PasswordInput
            value={form.newPassword}
            onChange={(e) => setForm({ ...form, newPassword: e.target.value })}
            placeholder="New password"
            aria-label="New password"
            autoComplete="new-password"
          />
        </Field>
        <Alert error={error} />
        <SubmitButton busy={busy}>Update password</SubmitButton>
      </form>
    </AuthLayout>
  );
}

export { ResetPasswordPage };
