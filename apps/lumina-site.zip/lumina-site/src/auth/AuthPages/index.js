// Barrel re-export so existing import sites (`./auth/AuthPages`, `../auth/AuthPages`)
// keep resolving exactly as before the split into this folder.

export { AuthLayout, Field, PasswordInput, Alert, SubmitButton, GoogleButton } from "./components";
export { LoginPage } from "./LoginPage";
export { RegisterPage } from "./RegisterPage";
export { VerifyEmailPage } from "./VerifyEmailPage";
export { ForgotPasswordPage } from "./ForgotPasswordPage";
export { ResetPasswordPage } from "./ResetPasswordPage";
export { RequireAuth } from "./RequireAuth";
