import { Input } from "../../components/ui/input";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { describeAuthError } from "../AuthContext";
import * as authApi from "../../api/auth";
import { AuthLayout, Alert, BRAND, Field, SubmitButton } from "./components";

function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setInfo("");
    setBusy(true);
    try {
      await authApi.forgotPassword(email);
      // The backend answers identically whether or not the address exists, so that an
      // attacker cannot use this form to discover who has an account. Say the same.
      setInfo("If that email has an account, a reset link is on its way.");
    } catch (caught) {
      setError(describeAuthError(caught));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout>
      <form onSubmit={submit} className="w-full max-w-md">
        <h1 className="text-4xl font-bold mb-2">Reset your password</h1>
        <p className="text-gray-500 mb-6">
          We&apos;ll email you a link to choose a new one.
        </p>
        <Field label="Email">
          <Input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter email"
            aria-label="Enter email"
            type="email"
            autoComplete="email"
            className="w-full border rounded-md p-3 mt-1"
          />
        </Field>
        <Alert error={error} info={info} />
        <SubmitButton busy={busy}>Send reset link</SubmitButton>
        <div className="text-sm mt-4">
          <Link className="font-semibold" style={{ color: BRAND }} to="/login">
            Back to sign in
          </Link>
        </div>
      </form>
    </AuthLayout>
  );
}

export { ForgotPasswordPage };
