import { Input } from "../../components/ui/input";
import React, { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { describeAuthError, useAuth } from "../AuthContext";
import {
  AuthLayout,
  Alert,
  BRAND,
  Field,
  GoogleButton,
  PasswordInput,
  SubmitButton,
} from "./components";

function RegisterPage() {
  const navigate = useNavigate();
  const { signup, isAuthenticated } = useAuth();
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    phone: "",
  });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (isAuthenticated) return <Navigate to="/" replace />;

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    if (!form.firstName || !form.lastName || !form.email || !form.password) {
      return setError("Please fill in every field.");
    }

    setBusy(true);
    try {
      await signup({
        name: `${form.firstName} ${form.lastName}`.trim(),
        email: form.email,
        password: form.password,
        phone: form.phone || undefined,
      });
      // No account exists yet - it is created when the emailed code is accepted.
      navigate("/verify", { state: { email: form.email } });
    } catch (caught) {
      setError(describeAuthError(caught));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout>
      <form onSubmit={submit} className="w-full max-w-md">
        <h1 className="text-4xl font-bold mb-2">Create an account</h1>
        <p className="text-gray-500 mb-6">
          Access your Bag and Wishlist on any of your devices.
        </p>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <Field label="First Name">
            <Input
              value={form.firstName}
              onChange={(e) => setForm({ ...form, firstName: e.target.value })}
              placeholder="First Name"
              aria-label="First Name"
              autoComplete="given-name"
              className="border rounded-md p-3"
            />
          </Field>
          <Field label="Last Name">
            <Input
              value={form.lastName}
              onChange={(e) => setForm({ ...form, lastName: e.target.value })}
              placeholder="Last Name"
              aria-label="Last Name"
              autoComplete="family-name"
              className="border rounded-md p-3"
            />
          </Field>
        </div>
        <Field label="Email">
          <Input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="Email"
            aria-label="Email"
            type="email"
            autoComplete="email"
            className="w-full border rounded-md p-3 mb-4"
          />
        </Field>
        <Field label="Phone (optional)">
          <Input
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            placeholder="Phone (optional)"
            aria-label="Phone (optional)"
            autoComplete="tel"
            className="w-full border rounded-md p-3 mb-4"
          />
        </Field>
        <Field label="Password">
          <PasswordInput
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            placeholder="Password"
            aria-label="Password"
            autoComplete="new-password"
          />
        </Field>

        <Alert error={error} />
        <SubmitButton busy={busy}>REGISTER</SubmitButton>
        <GoogleButton label="signup_with" onError={setError} />

        <div className="text-sm mt-4">
          Already have an account?{" "}
          <Link className="font-semibold" style={{ color: BRAND }} to="/login">
            Sign In
          </Link>
        </div>
      </form>
    </AuthLayout>
  );
}

export { RegisterPage };
