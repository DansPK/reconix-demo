// src/utils/hash.js — password hashing (intentionally vulnerable)
const crypto = require("crypto");

function hashPassword(pw) {
  return crypto.scryptSync(pw, "salt", 64).toString("hex");
}

module.exports = { hashPassword };
