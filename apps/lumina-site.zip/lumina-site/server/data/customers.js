// server/data/customers.js — seed rows for the Lumina `customers` table.
//
// The catalog-search endpoint in index.js reads this table, so a SQL-injection
// payload dumps exactly these rows (see the demo story). All data is fabricated:
// the people, phones, addresses and cards are invented, the cards are generated
// (Luhn-valid under a real brand BIN, never copied from a real card and with no
// CVV), and passwords are stored the way the breached app stored them — unsalted
// MD5, the hashes a cracker turns back into the plaintext offline.
//
// The first twelve rows are the named customers the rest of the Reconix demo
// shows (the TUI dump, the web dashboard, Sophea's storefront account). They must
// stay byte-for-byte in step with reconix/store/templates/web_url.py: same card,
// phone and the MD5 that cracks to the same password. Everything after row 12 is
// filler generated to reach the real table size so the dump returns 48,215 rows.
const crypto = require("crypto");

const TOTAL_ROWS = 48215;
const md5 = (s) => crypto.createHash("md5").update(s).digest("hex");

// The canonical twelve — must match web_url.py's _DUMP exactly.
const NAMED = [
  { name: "Sophea Chan",   email: "sophea_chan@gmail.com",    phone: "+855 12 684 207", brand: "Visa",       card: "4532 9859 9256 5466", exp: "08/27", pw: "Sophea1995",  street: "No. 23, St 51, Sangkat Boeng Keng Kang 1, Phnom Penh" },
  { name: "Dara Kim",      email: "darakim88@gmail.com",      phone: "+855 11 904 221", brand: "Mastercard", card: "5425 3516 6185 6644", exp: "11/26", pw: "darakim@18",  street: "No. 7B, St 240, Sangkat Chaktomuk, Phnom Penh" },
  { name: "Srey Mom",      email: "sreymom_k@yahoo.com",      phone: "+855 96 774 310", brand: "Visa",       card: "4716 0591 7325 9790", exp: "03/28", pw: "sreymom123",  street: "No. 112, St 163, Sangkat Toul Svay Prey 1, Phnom Penh" },
  { name: "Vicheka Sok",   email: "vichekasok@outlook.com",   phone: "+855 92 448 177", brand: "Amex",       card: "3714 438189 90163",   exp: "05/27", pw: "vicheka_99",  street: "No. 45, St 310, Sangkat Boeng Keng Kang 3, Phnom Penh" },
  { name: "Rathana Long",  email: "rathana_long@gmail.com",   phone: "+855 15 903 562", brand: "Visa",       card: "4485 9003 3143 7951", exp: "09/25", pw: "rathana2020", street: "No. 88, St 271, Sangkat Toul Tom Poung 1, Phnom Penh" },
  { name: "Bopha Nou",     email: "bophanou@gmail.com",       phone: "+855 78 112 845", brand: "Discover",   card: "6011 0956 9380 8432", exp: "12/27", pw: "bopha0808",   street: "No. 15, St 105, Sangkat Veal Vong, Phnom Penh" },
  { name: "Chanthou Meas", email: "chanthou_m@hotmail.com",   phone: "+855 17 657 203", brand: "Mastercard", card: "5500 9288 8207 9706", exp: "07/26", pw: "chanthou88",  street: "No. 301, St 598, Sangkat Chrang Chamres 1, Phnom Penh" },
  { name: "Pisey Heng",    email: "piseyheng@gmail.com",      phone: "+855 70 334 918", brand: "Visa",       card: "4024 8785 8944 1206", exp: "02/28", pw: "Pisey2016!",  street: "No. 9, St 360, Sangkat Boeng Keng Kang 2, Phnom Penh" },
  { name: "Vuthy Sam",     email: "vuthy_sam@yahoo.com",      phone: "+855 10 220 746", brand: "Visa",       card: "4929 2513 7840 8263", exp: "10/26", pw: "vuthysam007", street: "No. 54, St 598, Sangkat Toul Sangke, Phnom Penh" },
  { name: "Kunthea Yin",   email: "kuntheayin@gmail.com",     phone: "+855 86 905 114", brand: "Mastercard", card: "5168 5906 4207 5615", exp: "04/27", pw: "kunthea2019", street: "No. 27, St 123, Sangkat Toul Tom Poung 2, Phnom Penh" },
  { name: "Makara Chea",   email: "makara_chea@outlook.com",  phone: "+855 99 471 028", brand: "Visa",       card: "4539 3594 3327 6963", exp: "06/25", pw: "makara#23",   street: "No. 6, St 352, Sangkat Boeng Keng Kang 1, Phnom Penh" },
  { name: "Vanna Prak",    email: "admin@lumina.com",         phone: "+855 23 900 004", brand: "Visa",       card: "4716 8423 5693 9621", exp: "01/29", pw: "Lumina@2024", street: "No. 1, St 110, Sangkat Wat Phnom, Phnom Penh" },
];

// --- Filler generator -------------------------------------------------------
// A small, seeded PRNG keeps the extra rows stable from run to run (so the dump
// looks the same each demo) without shipping tens of thousands of literals.
function makeRng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 0x100000000;
  };
}
const pick = (rng, arr) => arr[Math.floor(rng() * arr.length)];
const int = (rng, lo, hi) => lo + Math.floor(rng() * (hi - lo + 1));

const GIVEN = ["Sokha", "Chenda", "Phary", "Sovann", "Reaksmey", "Nita", "Chann", "Dalin", "Visna", "Sothea", "Kanha", "Serey", "Mao", "Theary", "Ratha", "Sambath", "Leakhena", "Chamroeun", "Davy", "Phalla", "Sopheak", "Sreyneang", "Chhorvin", "Pich", "Narith", "Sovanna", "Molika", "Kimhak", "Rithy", "Channary", "Veasna", "Sophal", "Boran", "Chhaya", "Sorphea", "Thida", "Vireak", "Samnang", "Raksa", "Sokunthea"];
const FAMILY = ["Chan", "Kim", "Sok", "Long", "Nou", "Meas", "Heng", "Sam", "Yin", "Chea", "Prak", "Ly", "Ngor", "Ouk", "Pov", "Suon", "Tep", "Mao", "Hor", "Kong", "Noun", "Ros", "Seng", "Kuch", "Chhun", "Mom", "Nhem", "Phan", "Chhim", "Vong"];
const PROVIDERS = ["gmail.com", "gmail.com", "gmail.com", "yahoo.com", "yahoo.com", "outlook.com", "hotmail.com"];
const OPERATORS = ["10", "11", "12", "15", "16", "17", "61", "66", "67", "69", "70", "77", "78", "81", "86", "87", "92", "93", "95", "96", "97", "98", "99"];
const SANGKATS = ["Boeng Keng Kang 1", "Boeng Keng Kang 2", "Boeng Keng Kang 3", "Toul Tom Poung 1", "Toul Tom Poung 2", "Toul Svay Prey 1", "Toul Svay Prey 2", "Chaktomuk", "Veal Vong", "Wat Phnom", "Phsar Thmei 1", "Phsar Thmei 2", "Toul Sangke", "Chrang Chamres 1", "Boeng Trabek", "Olympic", "Phsar Daeum Thkov", "Chey Chumneas"];

const BRANDS = [
  { brand: "Visa", prefixes: ["4"], len: 16, groups: [4, 4, 4, 4] },
  { brand: "Mastercard", prefixes: ["51", "52", "53", "54", "55"], len: 16, groups: [4, 4, 4, 4] },
  { brand: "Amex", prefixes: ["34", "37"], len: 15, groups: [4, 6, 5] },
  { brand: "Discover", prefixes: ["6011", "65"], len: 16, groups: [4, 4, 4, 4] },
];

function luhnComplete(digits) {
  // digits: the number without its check digit; append the Luhn check digit so the
  // whole string validates. Walk from the right, doubling every second digit.
  let sum = 0;
  for (let i = digits.length - 1, pos = 0; i >= 0; i--, pos++) {
    let d = digits[i];
    if (pos % 2 === 0) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
  }
  digits.push((10 - (sum % 10)) % 10);
  return digits;
}

function groupDigits(str, groups) {
  const out = [];
  let i = 0;
  for (const g of groups) {
    out.push(str.slice(i, i + g));
    i += g;
  }
  return out.join(" ");
}

function makeCard(rng) {
  const b = pick(rng, BRANDS);
  const prefix = pick(rng, b.prefixes);
  const digits = prefix.split("").map(Number);
  while (digits.length < b.len - 1) digits.push(int(rng, 0, 9));
  luhnComplete(digits);
  return { brand: b.brand, card: groupDigits(digits.join(""), b.groups) };
}

function makePassword(rng, given, family) {
  const g = given.toLowerCase();
  const f = family.toLowerCase();
  const year = int(rng, 1988, 2006);
  const n3 = String(int(rng, 0, 999)).padStart(3, "0");
  const styles = [
    () => g + year,
    () => g + "_" + int(rng, 10, 99),
    () => f + n3,
    () => g.charAt(0).toUpperCase() + g.slice(1) + year,
    () => g + "@" + int(rng, 10, 99),
    () => f + "#" + int(rng, 10, 99),
    () => g + "123",
    () => g + f.charAt(0) + year,
  ];
  return pick(rng, styles)();
}

function makeFiller(rng) {
  const given = pick(rng, GIVEN);
  const family = pick(rng, FAMILY);
  const name = given + " " + family;
  const sep = pick(rng, ["", "", "_", "."]);
  const tag = rng() < 0.45 ? String(int(rng, 2, 99)) : "";
  const email = (given.toLowerCase() + sep + family.toLowerCase() + tag + "@" + pick(rng, PROVIDERS)).replace(/^_+|_+$/g, "");
  const phone = "+855 " + pick(rng, OPERATORS) + " " + int(rng, 100, 999) + " " + int(rng, 100, 999);
  const houseNo = int(rng, 1, 480) + (rng() < 0.2 ? pick(rng, ["A", "B", "C", "D", "E"]) : "");
  const street = "No. " + houseNo + ", St " + int(rng, 51, 620) + ", Sangkat " + pick(rng, SANGKATS) + ", Phnom Penh";
  const { brand, card } = makeCard(rng);
  const exp = String(int(rng, 1, 12)).padStart(2, "0") + "/" + int(rng, 25, 30);
  const pw = makePassword(rng, given, family);
  return { name, email, phone, address: street, card_brand: brand, card, exp, password: md5(pw) };
}

/** The full table as plain objects, in id order (named rows first). */
function buildCustomers() {
  const rng = makeRng(0x6c756d69); // "lumi"
  const rows = NAMED.map((c) => ({
    name: c.name,
    email: c.email,
    phone: c.phone,
    address: c.street,
    card_brand: c.brand,
    card: c.card,
    exp: c.exp,
    password: md5(c.pw),
  }));
  while (rows.length < TOTAL_ROWS) rows.push(makeFiller(rng));
  return rows;
}

/** Insert every row into an open sqlite3 database's `customers` table. */
function seedCustomers(db) {
  const insert = db.prepare(
    "INSERT INTO customers (name, email, phone, address, card_brand, card, exp, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  );
  for (const r of buildCustomers()) {
    insert.run(r.name, r.email, r.phone, r.address, r.card_brand, r.card, r.exp, r.password);
  }
  insert.finalize();
}

module.exports = { seedCustomers, buildCustomers, TOTAL_ROWS };
