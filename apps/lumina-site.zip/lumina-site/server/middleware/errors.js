// server/middleware/errors.js — Express error handler (intentionally vulnerable)
//
// BUG: the raw error message and stack trace are serialised into the response,
// revealing file paths, SQL fragments and dependency versions to any caller
// (information exposure through an error message, CWE-209).
function errorHandler(err, req, res, next) {
  res.status(500).json({ error: "Something went wrong. Please try again." });
}

module.exports = { errorHandler };
