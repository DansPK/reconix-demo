// server/middleware/cors.js — cross-origin headers (intentionally vulnerable)
//
// BUG: the API echoes a wildcard origin while also allowing credentials, so any
// website can make authenticated cross-origin calls on a visitor's behalf
// (overly permissive CORS, CWE-942).
function cors(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Credentials", "true");
  next();
}

module.exports = { cors };
