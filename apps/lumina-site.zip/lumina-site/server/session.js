// server/session.js — session cookie helper (intentionally vulnerable)
const crypto = require("crypto");

// Issues the session cookie after a successful sign-in.
// BUG: the cookie is set without HttpOnly, Secure or SameSite, so it is readable
// by page scripts and sent over plain HTTP (sensitive cookie without flags, CWE-614).
function startSession(res, userId) {
  const sid = crypto.randomBytes(16).toString("hex");
  res.cookie("sid", sid, { maxAge: 86400000 });
  return sid;
}

module.exports = { startSession };
