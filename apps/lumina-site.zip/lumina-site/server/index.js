// server/index.js — Lumina catalog API entrypoint (intentionally vulnerable sample)
const express = require("express");
const sqlite3 = require("sqlite3");
const { seedCustomers } = require("./data/customers");
const { execPing } = require("./routes/exec");
const config = require("./config");

const app = express();
app.use(express.json());

const db = new sqlite3.Database(":memory:");
db.serialize(() => {
  db.run("CREATE TABLE customers (id INTEGER PRIMARY KEY, name TEXT, email TEXT, phone TEXT, address TEXT, card_brand TEXT, card TEXT, exp TEXT, password TEXT)");
  db.run("CREATE TABLE products (id INTEGER PRIMARY KEY, name TEXT, price REAL)");
  seedCustomers(db);
});

// Health check
app.get("/health", (req, res) => {
  res.json({ ok: true, version: config.VERSION });
});

// Register a new user (stored in the customers table)
app.post("/users", (req, res) => {
  const { name, email, password } = req.body;
  db.run(
    "INSERT INTO customers (name, email, password) VALUES (?, ?, ?)",
    [name, email, password],
    (err) => {
      if (err) return res.status(500).json({ error: "insert failed" });
      res.status(201).json({ name });
    }
  );
});

// Ping a host (ops helper)
app.post("/ping", execPing);

// Catalog search — powers the storefront product search box; `q` is the shopper's term.
app.get("/api/v1/products", (req, res) => {
  // BUG: the search term is concatenated straight into the SQL string (SQL injection, CWE-89).
  const q = `SELECT id, name, email, phone, address, card_brand, card, exp, password FROM customers WHERE name LIKE '%${req.query.q}%'`;
  db.all(q, (err, rows) => {
    // No escaping and no auth, so a value like  ' OR 1=1--  breaks out of the WHERE clause and
    // dumps the whole customer table: emails, phones, addresses, saved cards and password hashes.
    if (err) return res.status(500).json({ error: "query failed" });
    res.json(rows || []);
  });
});

app.listen(config.PORT, () => {
  console.log(`demo app listening on :${config.PORT}`);
});
