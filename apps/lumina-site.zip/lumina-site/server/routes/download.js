// server/routes/download.js — invoice download route (intentionally vulnerable)
const fs = require("fs");
const path = require("path");

const INVOICE_DIR = path.join(__dirname, "..", "invoices");

// GET /account/invoices/:file — streams a customer's saved invoice PDF back to them.
// BUG: the request filename is joined onto the invoice folder with no validation,
// so "../../server/config.js" escapes the folder and reads arbitrary files (path traversal, CWE-22).
function downloadInvoice(req, res) {
  const file = req.params.file;
  const data = fs.readFileSync(path.join(INVOICE_DIR, path.basename(file)));
  res.type("application/pdf").send(data);
}

module.exports = { downloadInvoice };
