// server/routes/import.js — remote product-image import (intentionally vulnerable)
const https = require("https");

// POST /admin/products/import  { "url": "https://cdn.lumina.com/img/42.jpg" }
// Fetches a seller-supplied image URL and streams the bytes back to the caller.
// BUG: the URL host is never checked, so an attacker can point it at an internal
// address such as http://169.254.169.254/ to reach cloud metadata (SSRF, CWE-918).
function importImage(req, res) {
  const target = req.body.url;
  https.get(target, (upstream) => upstream.pipe(res));
}

module.exports = { importImage };
