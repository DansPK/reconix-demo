# Frontend polish verification

The frontend uses official shadcn/ui source alongside HeroUI, Tailwind 3, and Framer Motion. The shared theme uses warm neutrals and a restrained red accent. Menus, account actions, payment dialogs, report tables, profile forms, product cards, loading states, and authentication controls share these foundations. The admin shell is loaded separately from the storefront.

## Confirmed defects and fixes

| Reproduction before the change | Result after the change |
| --- | --- |
| Search using the storefront header. The URL changed to `/?q=...`, but the homepage ignored the query. | Search opens the collection results, filters on the server, and preserves query/sort/page in the URL. Old homepage search links redirect to results. |
| Select a homepage collection. Each rail fetched only four or five products and filtered them afterward; category aliases also differed. | Each request includes the translated category slug before the server applies the limit. |
| Change filters while an earlier request is slow. Its late response can replace current data. | Request identity guards prevent stale responses and obsolete cache writes. |
| Change accounts while data remains cached or in flight. | Session cache epochs discard previous account data and in-flight results. |
| Open a homepage while collections load or a request fails. Sections disappear with no recovery. | Stable skeletons and retry controls distinguish loading from errors and empty collections. |
| Add a product to the bag when its API request fails. The page still reports success. | The page awaits the API, disables the pending action, reports failure, and limits quantity to stock. |
| Use wishlist size/color controls. Add-to-bag ignores their choices and sends no variant ID. | Saved products lead to product selection, where the real variant and stock are checked. |
| Update or remove a bag item when a request fails. The promise is not handled. | Bag actions show pending/error feedback; saving an already-saved item no longer removes it from favorites. |
| Click dashboard Menu, Refresh, account actions, or View Reports. Some controls do nothing or show a fabricated admin identity. | Mobile navigation opens a focus-managed sheet, refresh revalidates data, and real user/role/account actions appear. Reports navigation works. Unsupported global search, notification indicators, and inert analytics tabs are removed. |
| Toggle a customer’s active status when the API rejects it. The error is swallowed. | The failure appears with a retry action. |
| Submit checkout more than once, or press Enter in a field. | A submission lock prevents duplicate requests; checkout is a keyboard-submittable form. |
| Cancel checkout when the cancellation API fails. The popup closes anyway. | The order remains visible and the error is shown. |
| Leave a payment open after a terminal bank response. Polling continues. | Polling stops for terminal statuses and exposes recoverable network errors. |
| Close checkout and look for the pending payment in orders. | Order details fetch the existing payment, show valid KHQR data, and allow expired-code regeneration through the existing API. |
| Open an unknown route or missing product. | A useful not-found screen appears. |
| A fallback image also fails. Comparing an absolute image URL with a relative path repeatedly retries it. | The fallback is assigned only once. |
| Read the dashboard’s compact currency formatter for a value below $1,000. | It renders one currency prefix, with two decimals. |
| Read KHQR counts in the period comparison. A count is estimated from a revenue share. | The table accurately labels and displays the API’s KHQR percentage share. |

## Automated verification

Run `npm test` and `npm run build` in the frontend directory.

Tests use fixtures only inside the test files; application data still comes from the gateway. Coverage includes resource races and session invalidation, storefront/customer/admin routes, stock limits and failed adds, duplicate checkout requests, access guards, focus-managed mobile navigation, refresh behavior, and polling recovery/termination.

Live read checks verified customer/admin sign-in and profile access, catalog search/category/sort requests, cart/wishlist/order access, admin orders/payments/report access, and forbidden cross-role requests. No purchases, real payments, password resets, or account changes were performed.

## Visual verification and remaining checks

A storefront baseline was inspected before editing. Mobile navigation and the new storefront/authentication pages were inspected in Brave during implementation. Browser automation then became unavailable because another extension UI was open. Final before/after image artifacts and the full 375/768/1440 px visual matrix remain unverified; the browser viewport override was reset.

When browser access is available, check every route at those widths, keyboard-only menus/dialogs, reduced motion, populated admin tables, long addresses/names, image fallback, and slow/offline requests. Confirm checkout KHQR display using a disposable test order only when creation is authorized; successful real-payment confirmation requires a separately authorized payment. Staff access has automated coverage but was not verified with a live staff login.

The production build succeeds. Vite still reports a storefront chunk above 500 kB; the admin shell is now a separate chunk. No backend endpoints or migrations were necessary for the confirmed fixes.
