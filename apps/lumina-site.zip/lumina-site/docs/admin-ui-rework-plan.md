# Admin UI rework plan

## Baseline and scope

Current frontend work is committed as `82d634d` (`feat: polish frontend workflows and redesign admin reports`). The baseline has 57 passing Vitest tests and a passing Vite build, with an existing large-chunk warning.

Rework every `/dashboard/*` screen: dashboard, products and product forms, categories, orders and detail/edit/cancel views, inventory and stock adjustments, customers and account forms, payments and detail/refund/receipt views, reports, settings, and not-found. Keep React, Vite, JavaScript, Tailwind 3, HeroUI, shadcn, real API integration, and current routes and permissions.

Interpret black and white themes as a light mode and a dark mode, both with the storefront red accent. The theme preference applies to the admin workspace; the storefront keeps its current appearance. No emoji anywhere in the admin interface; use existing Lucide icons.

## Design references

- [Official shadcn dashboard](https://ui.shadcn.com/examples/dashboard): restrained sidebar, clear metric hierarchy, compact filterable tables, and consistent card spacing. Adapt the visual patterns rather than copying its demo content or framework.
- [Shopify analytics](https://www.shopify.com/analytics): commerce metrics at a glance, with more detailed reporting beneath the overview.
- [Shopify reporting documentation](https://help.shopify.com/en/manual/reports-and-analytics/shopify-reports/): distinguish summary analytics from detailed reports.
- [Official shadcn chart documentation for Tailwind 3 projects](https://v3.shadcn.com/docs/components/chart): consistent axes, legends, tooltips, accessible chart interaction, and theme-aware chart colors. Use as a visual reference; reuse the existing SVG chart components before adding a chart dependency.

## Visual system and themes

- Use the existing storefront primary red token (currently approximately `#E0271F`) for primary buttons, selected navigation, focus treatment, and the main chart series. Remove admin blue brand overrides.
- Light: white cards, soft neutral page background, near-black text, quiet borders. Dark: near-black page, charcoal cards, off-white text, visible neutral borders. Avoid inverted white backgrounds inside dark dialogs or menus.
- Keep Poppins. Use 16–17 px body text, 14–15 px table text, 24–28 px page headings, and 28–34 px KPI values. Use tabular numerals and preserve currency cents.
- Use consistent 12 px card radii, 24 px desktop spacing, and 16 px mobile spacing. Reserve shadows for overlays; keep normal cards flat.
- Replace hardcoded colors in the shell, sidebar CSS, page helpers, inline styles, charts, and status badges with semantic variables. Existing `C` helpers can reference CSS variables while pages migrate.
- Add a clearly labeled light/dark toggle to the topbar and Appearance settings. Persist `lumina-admin-theme` locally, use the system preference on first visit, and provide an accessible action label such as “Switch to dark theme.” Apply the saved theme before the admin UI paints.
- Scope theme variables to the admin root. Explicitly theme portal-mounted dialogs, sheets, and dropdowns, plus retained HeroUI controls; do not let portals fall back to storefront/light tokens. Keep one overlay owner per interaction.
- Use red plus neutral chart series by default. Retain distinguishable success/warning/error colors, with text and icons so meaning never depends on color alone. Check red button text contrast in both themes.

## Navigation and workflow UX

- Keep the Lumina logo. Rework the sidebar with readable group labels, clear active states, a collapsible desktop layout, and a mobile sheet with focus restoration.
- Give each page one title, a short description where useful, and a clear primary action. Use breadcrumbs on detail/edit screens.
- Keep refresh and profile actions functional. Use contextual page search and filters; preserve supported filter state in the URL and offer a visible reset.
- Standardize table density, sorting, pagination, selection, bulk actions, and horizontal overflow. Show total counts only when the API supplies them. Long names and identifiers must not break layouts.
- Use predictable forms with labels, field errors, submitting states, and success feedback. Retain entered values after failed saves; protect duplicate submissions and unsaved edits.
- Use 150–250 ms motion for entrances and action feedback; honor reduced motion. Theme changes must not remount pages, clear forms, or restart requests.

## Metrics and charts

Give the dashboard an operational overview and Reports the deeper financial analysis. Keep four primary KPIs visible first; put secondary metrics and charts below them.

| View | Metrics / chart | Data and limitations |
| --- | --- | --- |
| Dashboard | Paid revenue, paid orders, average order value, paying customers; period trends | Existing report overview; label the server's definitions and comparison period accurately |
| Dashboard / Reports | Revenue area/line chart and order-count bar chart, with a Revenue / Orders switch | Existing `bars[].v` and `bars[].o`; do not combine incompatible units on an unlabeled axis |
| Reports | Average order value over time | Derive from each bucket's revenue and order count using the same server definitions; clarify if buckets count only paid orders |
| Reports | Top products horizontal ranking, category revenue share, payment-method share | Existing overview; top products supports units, not revenue ranking; payment share counts successful payments |
| Payments | Gross, net, refunds, pending, paid, failed, expired counts; status distribution | Existing payment summary; use the same date filters as the payment list |
| Inventory | Out-of-stock and low-stock variants, units on hand, stock-level distribution | Existing inventory and low-stock endpoints; label active-variant scope and threshold |
| Customers | Total, active, new in 90 days, customer revenue; highest-spending customer list | Existing customer summary and paginated report; do not show a new-customer trend against total customers |
| Orders | Status breakdown and fulfillment attention list | Requires full matching aggregates; never present counts from a five-row recent list or capped page as global totals |

Use meaningful axes, currency/count formatting, concise legends, focusable tooltips, and an accessible table alternative. Charts and their supporting tables must agree. Render real zero values; show an empty state for unavailable data instead of fabricated curves or sample commerce data. Separate loading, failed, and empty states, with retry actions and stable skeletons.

Do not calculate profitability, conversion rate, lifetime value, inventory cost valuation, or revenue by product from unsupported data. These require separate definitions and API support. Time-series refunds, new-customer growth, historical stock, previous-period overlays, and arbitrary date ranges also require reporting extensions before they can be shown accurately.

If an agreed chart requires new aggregates, add a small read-only reporting endpoint or extend its DTO and repository query. Preserve the gateway and downstream role checks, response conventions, business timezone, and monetary precision. Read the backend conventions before implementation; add migrations only when schema changes are actually necessary.

## Page rework

- **Dashboard:** four comparable KPIs, one dominant time-series chart, secondary category/payment panels, and recent orders/low-stock actions. Fix whole-dollar revenue rounding and misleading KPI comparisons. Separate current inventory totals from period-based sales metrics.
- **Products and categories:** compact searchable catalog, consistent thumbnails, readable prices/stock/status, clear bulk actions, and organized image/variant/product forms. Rework category hierarchy editing with real API state and validation.
- **Orders:** status tabs and search/filter toolbar, readable table, and a detail page with customer, line items, totals, payment, and supported status history/actions. Make cancel/edit consequences explicit and respect allowed transitions.
- **Inventory:** stock summary, distribution chart, low-stock queue, searchable variants, and accessible adjustment forms with reason/note and movement history.
- **Customers:** accurate summary, useful filters, customer revenue ranking, and consistent account forms. Preserve staff/admin action restrictions.
- **Payments:** summary and status chart above the table; consistent detail, receipt, and refund overlays. Show real pending/failure/expiry/refund states and disable unauthorized or unsupported actions.
- **Reports:** carry forward the new layout into red/light/dark themes, improve chart readability, add supported order/AOV views, and keep exports faithful to the displayed definitions and precision.
- **Settings:** organized profile and Appearance sections, saved theme preference, and clear account feedback. Only expose settings that can actually be persisted.

## Delivery order

1. **Audit and baseline:** capture desktop/mobile screens, map every visible action and role restriction, inventory hardcoded colors and chart callers, and verify metric definitions in backend queries.
2. **Theme and shell:** replace blue with storefront red, implement scoped light/dark tokens and persistence, rework sidebar/topbar, and verify all portal overlays and HeroUI controls in both modes.
3. **Dashboard and chart patterns:** unify existing chart components, add axes/tooltips/table alternatives, build the four-KPI overview, and add supported order/AOV/stock/payment visualizations.
4. **Management workflows:** rework products, categories, orders, inventory, customers, and payments, including each form, detail screen, and overlay.
5. **Reports and settings:** align Reports to the new system, add agreed reporting extensions only where needed, and complete Appearance/profile settings.
6. **Validation and handoff:** capture before/after views in both themes, document verified fixes and remaining data limitations, and make reviewable commits per phase.

## Acceptance checks

- Every admin route at 375, 768, and 1440 px in light and dark modes; no accidental white portal surfaces, clipped controls, or unreadable tables.
- Keyboard navigation, visible focus, dialog/sheet focus restoration, reduced motion, sufficient contrast, and charts understandable without color or pointer hover.
- Theme persists across refresh/navigation and does not change storefront styling or reset an in-progress form.
- Admin and staff access tested separately; customer/guest access remains blocked. Reporting endpoints stay protected and forbidden responses remain recoverable.
- Search, filters, sorting, pagination, rapid filter changes, refresh, mutation invalidation, empty results, failed/slow requests, long labels, missing images, and invalid forms verified.
- Revenue retains cents; period labels and trends match their values; CSV agrees with the underlying metrics; no aggregates inferred from truncated lists.
- Focused Vitest regression and component tests, frontend production build, and relevant Maven tests for any backend changes. Recheck bundle size if chart implementation adds weight.
- No real payment, refund, customer deactivation, or destructive mutation performed merely to validate screenshots. Use targeted tests for these actions and read-only browser checks against the running stack.

Implemented the red admin theme, persistent light/dark toggle, shell changes, chart views and accessible chart data, management workflow improvements, URL filters, and regression coverage. The reporting queries were audited: the overview counts paid non-cancelled orders and distinct paying customers, so the UI now uses those labels.

Live visual acceptance and before/after screenshots remain pending because browser access was unavailable during implementation. No backend endpoints or dependencies were added. Charts based on loaded records explicitly disclose that scope; unsupported historical metrics remain excluded.
